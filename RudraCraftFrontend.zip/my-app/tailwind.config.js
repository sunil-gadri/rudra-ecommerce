// tailwind.config.js
module.exports = {
  content: [
    './src/**/*.{html,js,jsx,ts,tsx}', // Adjust the paths as needed
  ],
  theme: {
    extend: {
      colors: {
        'custom-color': '#feece2',
        'color-shopnow': '#7A6E54',
      },
    },
  },
  plugins: [],
}
