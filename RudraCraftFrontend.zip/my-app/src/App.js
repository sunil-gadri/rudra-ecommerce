import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import HomePage from "./Pages/HomePage";
import React from "react";
import AnimatedComponent from "./Assets/animatedcomponent/AnimatedComponent";
import { Collection } from "./Pages/Collection";
import { Products } from "./Pages/Products";
import { CheckOutPage } from "./Pages/CheckOutPage";
import { ShoppingCartPage } from "./Pages/ShoppingCartPage";
import { SignUpPage } from "./Pages/SignUpPage";
import { SigninPage } from "./Pages/SigninPage";
import { ResetPasswordPage } from "./Pages/ResetPasswordPage";
import { PageNotFound } from "./Pages/PageNotFound";
import { WishList } from "./Pages/WishList";
import { PrivacyPolicyPage } from "./Pages/PrivacyPolicyPage";
import { RefundPolicyPage } from "./Pages/RefundPolicyPage";
import { BlogsPage } from "./Pages/BlogsPage";
import { BlogReadMorePage } from "./Pages/BlogReadMorePage";
import { FaqsPage } from "./Pages/FaqsPage";
import { LoadingProvider } from "./Components/LoadingContext";
import ContactUs from "./Pages/ContactUs";
import { About } from "./Pages/About";
import { AllShopProduct } from "../src/Pages/AllShopProduct";
import ShippingPolicy from "./Pages/ShippingPolicy";
import { Disclaimer } from "./Pages/Disclaimer";
import { TermsAndConditions } from "./Pages/TermsAndConditions";

function App() {
  return (
      <LoadingProvider>
        <div>
          <AnimatedComponent />
        </div> 
        <Router>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="*" element={<PageNotFound />} />
            <Route path="/shop" element={<AllShopProduct />} />
            <Route path="/collections" element={<Collection />} />
            <Route path="/product" element={<Products />} />
            <Route path="/checkout" element={<CheckOutPage />} />
            <Route path="/cart" element={<ShoppingCartPage />} />
            <Route path="/signup" element={<SignUpPage />} />
            <Route path="/signin" element={<SigninPage  />} />
            <Route path="/reset" element={<ResetPasswordPage />} />
            <Route path="/wishlist" element={<WishList />} />
            <Route path="/privacypolicy" element={<PrivacyPolicyPage />} />
            <Route path="/refundpolicy" element={<RefundPolicyPage />} />
            <Route path="/termsandconditions" element={<TermsAndConditions />} />
            <Route path="/shipping-policy" element={<ShippingPolicy />} />
            <Route path="/blogs" element={<BlogsPage />} />
            <Route path="/blogs/readmore" element={<BlogReadMorePage />} />
            <Route path="/about" element={<About />} />
            <Route path="/FAQs" element={<FaqsPage />} />
            <Route path="/contact-us" element={<ContactUs />} />
            <Route path="/disclaimer" element={<Disclaimer/>} />
            </Routes>
        </Router>
      </LoadingProvider>
  );
}

export default App;
