import React from "react";
import Layout from "../Components/Layout";
import { SignUp } from "../Components/SignUp";

export const SignUpPage = () => {
  return (
    <>
      <Layout>

    <SignUp/>

      </Layout>
    </>
  );
};
