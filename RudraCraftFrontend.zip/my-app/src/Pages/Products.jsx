import React from 'react'
import Layout from "../Components/Layout";
import { OurServices } from '../Components/OurServices';
import { Product } from '../Components/Product';
import { ProductDiscription } from '../Components/ProductDiscription';
import { ClassyCollection } from '../Components/ClassyCollection';
import { DiscountBanner } from '../Components/DiscountBanner';
import Subscription from '../Components/Subscription';


export const Products = () => {
  return (
    <>    
    <Layout>

       <Product/>
       <div className='mt-10'> <ProductDiscription/></div>
       <DiscountBanner/>
       <ClassyCollection/>
        <div className='mt-10'><Subscription/></div>
       <div className='mt-10'><OurServices/></div>
       </Layout>
    </>
  )
}
