import cimg1 from "../../src/Assets/CIMG1.jpg";
import cimg2 from "../../src/Assets/CIMG2.jpg";
import cimg3 from "../../src/Assets/CIMG3.jpg";
import cimg4 from "../../src/Assets/CIMG4.jpg";
import Form from "react-bootstrap/Form";
import React, { useState, useEffect, useRef } from "react";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import { useMediaQuery } from "@mui/material";
import { MdOutlineFilterList } from "react-icons/md";
import Layout from "../Components/Layout";
import { MdKeyboardArrowRight } from "react-icons/md";
import { OurServices } from "../Components/OurServices";

export const AllShopProduct = () => {
  const [loading, setLoading] = useState(false);
  const [isCollection1Expanded, setIsCollection1Expanded] = useState(true);
  const [isCollection2Expanded, setIsCollection2Expanded] = useState(true);
  const [isCollection3Expanded, setIsCollection3Expanded] = useState(true);
  const [isCollection4Expanded, setIsCollection4Expanded] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    };

    if (menuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [menuOpen]);

  const toggleCollection1 = () => {
    setIsCollection1Expanded(!isCollection1Expanded);
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const toggleCollection2 = () => {
    setIsCollection1Expanded(false);
    setIsCollection2Expanded(!isCollection2Expanded);
  };

  const toggleCollection3 = () => {
    setIsCollection2Expanded(false);
    setIsCollection3Expanded(!isCollection3Expanded);
  };

  const toggleCollection4 = () => {
    setIsCollection3Expanded(false);
    setIsCollection4Expanded(!isCollection4Expanded);
  };

  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");
  const overlayStyle = {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 9999,
  };

  const loaderStyle = {
    border: "6px solid #f3f3f3",
    borderTop: "6px solid #3498db",
    borderRadius: "50%",
    width: "70px",
    height: "70px",
    animation: "spin 2s linear infinite",
  };

  const keyframesStyle = `
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `;

  return (
    <Layout>


<div style={{width: "100%" , height: "12rem" , backgroundColor: "#CFD9E2" , display: "flex"  , alignItems: "center" , justifyContent: "center"}}>

        <div style={{display: "flex" , flexDirection: "column"}}>
            <h1 style={{fontWeight: "lighter" , color: "#3F4754" , fontSize: "2rem"}}>Products</h1>
            <div style={{display: "flex" , justifyContent: "center" , alignItems: "center" , gap: ".5em"}}>
                <a style={{color: "#3F4754"}} href="/">Home</a>
                <MdKeyboardArrowRight />
                <a style={{color: "#3F4754"}}  href="#">Shop</a>
            </div>
        </div>

    </div>

    <div
      style={{
        width: "100%",
        marginTop: "3rem",
        display: "flex",
        padding: "0 1rem",
      }}
    >
      <div
        style={{
          width: "100%",
          height: "120rem",
          backgroundColor: "#CFD9E2",
          display: isXs ? "none" : "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "start",
          paddingTop: "2rem",
        }}
      >
        <div
          style={{
            width: "80%",
            display: "flex",
            flexDirection: "column",
            gap: "1rem",
          }}
        >
          <div>
            <h4>Product Categories</h4>
            <hr />
          </div>

          <div className="flex flex-col gap-3">
            <div
              onClick={toggleCollection1}
              style={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
              }}
            >
              <h5 style={{ minWidth: "60%" }}>Home Furnishing</h5>
              {isCollection1Expanded ? (
                <FaChevronUp
                  style={{ marginLeft: "5rem", fontSize: "small" }}
                />
              ) : (
                <FaChevronDown
                  style={{ marginLeft: "5rem", fontSize: "small" }}
                />
              )}
            </div>
            {isCollection1Expanded && (
              <div className="flex flex-col gap-2  ">
                <div className="flex flex-col gap-2">
                  {[
                    "Bed Covers",
                    "Bed Sheets",
                    "Cushion Cover",
                    "Dohars",
                    "Handicrafts",
                    "Quilts",
                    "Stoles",
                    "Table Covers",
                    "Ties",
                    "Wall Hangings",
                  ].map((label, index) => (
                    <div key={index} className="flex gap-2 items-center">
                      <input
                        style={{ width: "1rem", height: "1rem" }}
                        type="checkbox"
                        name={`Checkbox${index + 6}`}
                        id={`Checkbox${index + 6}`}
                      />
                      <label
                        style={{ cursor: "pointer" }}
                        className="text-[1rem]"
                        htmlFor={`Checkbox${index + 6}`}
                      >
                        {label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3 mt-1">
            <div
              onClick={toggleCollection2}
              style={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
              }}
            >
              <h5 style={{ minWidth: "60%" }}>Product Type:</h5>
              {isCollection2Expanded ? (
                <FaChevronUp
                  style={{ marginLeft: "5rem", fontSize: "small" }}
                />
              ) : (
                <FaChevronDown
                  style={{ marginLeft: "5rem", fontSize: "small" }}
                />
              )}
            </div>
            {isCollection2Expanded && (
              <div className="flex flex-col gap-2  ">
                <div className="flex flex-col gap-2">
                  {[
                    "Black Headscarf",
                    "Coloured Headscarf",
                    "Emirati Sheila",
                    "Female Turban",
                    "Summer Scarf",
                  ].map((label, index) => (
                    <div key={index} className="flex gap-2 items-center">
                      <input
                        style={{ width: "1rem", height: "1rem" }}
                        type="checkbox"
                        name={`Checkbox2${index + 6}`}
                        id={`Checkbox2${index + 6}`}
                      />
                      <label
                        style={{ cursor: "pointer" }}
                        className="text-[1rem]"
                        htmlFor={`Checkbox2${index + 6}`}
                      >
                        {label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3 mt-1">
            <div
              onClick={toggleCollection3}
              style={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
              }}
            >
              <h5 style={{ minWidth: "60%" }}>Availability:</h5>
              {isCollection3Expanded ? (
                <FaChevronUp
                  style={{ marginLeft: "5rem", fontSize: "small" }}
                />
              ) : (
                <FaChevronDown
                  style={{ marginLeft: "5rem", fontSize: "small" }}
                />
              )}
            </div>
            {isCollection3Expanded && (
              <div className="flex flex-col gap-2">
                <div className="flex gap-2 items-center">
                  <input
                    style={{ width: "1rem", height: "1rem" }}
                    type="checkbox"
                    name=""
                    id=""
                  />
                  <label className="text-[1rem]" htmlFor="">
                    In Stock (2)
                  </label>
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3 mt-1">
            <div
              onClick={toggleCollection4}
              style={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
              }}
            >
              <h5 style={{ minWidth: "60%" }}>Price:</h5>
              {isCollection4Expanded ? (
                <FaChevronUp
                  style={{ marginLeft: "5rem", fontSize: "small" }}
                />
              ) : (
                <FaChevronDown
                  style={{ marginLeft: "5rem", fontSize: "small" }}
                />
              )}
            </div>
            {isCollection4Expanded && (
              <div className="flex flex-col gap-2"></div>
            )}
          </div>
        </div>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-evenly",
        }}
      >
        <div
          style={{
            display: "flex",
            alignSelf: isXs ? "" : "end",
            justifyContent: "space-between",
          }}
        >
          <div
            style={{
              display: isXs ? "flex" : "none",
              justifyContent: "center",
              alignItems: "center",
              gap: ".2rem",
            }}
          >
            {isXs && (
              <MdOutlineFilterList
                style={{
                  display: isXs ? "block" : "none",
                  cursor: "pointer",
                  fontSize: "1.5rem",
                  color: "grey",
                }}
                onClick={toggleMenu}
              />
            )}
            <ul
              ref={menuRef}
              style={{
                display: isXs ? "block" : "flex",
                position: isXs ? "fixed" : "",
                top: isXs ? "0" : "",
                left: isXs ? (menuOpen ? "0" : "-200px") : "",
                bottom: isXs ? "0" : "",
                zIndex: isXs ? "20" : "",
                backgroundColor: isXs ? "white" : "",
                width: isXs ? "200px" : "",
                padding: isXs ? "2rem 2rem" : "",
                lineHeight: "2.8rem",
                boxShadow: isXs ? "6px 2px 20px rgba(0,0,0,0.2)" : "",
                listStyle: "none",
                margin: "0",
                gap: "3rem",
                alignItems: "center",
                justifyContent: "center",
                fontSize: isXs ? ".9rem" : "",
                transition: "left 0.3s ease",
              }}
            ></ul>
            <span>Filter</span>
          </div>

          <Form.Select
            style={{
              width: isXs ? "6.4rem" : "18rem",
              border: isXs ? "none" : "1px solid #7A6E54",
              color: "#7A6E54",
            }}
            aria-label="Default select example"
          >
            <option value="" disabled selected>
              Sort By
            </option>
            <option value="1">Best Selling</option>
            <option value="2">Alphabetically A-Z</option>
            <option value="3">Price Low to High</option>
            <option value="3">High Low to Low</option>
          </Form.Select>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: isXs ? "repeat(2, 1fr)" : "",
            paddingLeft: isXs ? "0rem" : "",
          }}
          className="grid grid-cols-4 grid-rows-4 gap-8 pl-9 mt-12"
        >
          {[
            cimg4,
            cimg3,
            cimg1,
            cimg2,
            cimg3,
            cimg4,
            cimg2,
            cimg1,
            cimg4,
            cimg3,
            cimg1,
            cimg2,
            cimg4,
            cimg3,
            cimg1,
            cimg2,
          ].map((image, index) => (
            <div>
              <a
                href="/product"
                key={index}
                className="flex flex-col gap-3 items-center"
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    border: ".5px solid #CFD9E2",
                  }}
                >
                  <div>
                    <img
                      width={900}
                      src={image}
                      alt={`Classy Collection ${index + 1}`}
                    />
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      margin: ".6rem",
                      gap: ".4rem",
                    }}
                  >
                    <div>
                      <a style={{ fontSize: "1rem", color: "black" }} href="#">
                        Shawl Head Wrap
                      </a>
                    </div>
                    <div style={{ fontSize: "1rem", color: "#A0522D" }}>
                      $1.00
                    </div>
                  </div>
                </div>
              </a>
            </div>
          ))}
          {loading && (
            <div style={overlayStyle}>
              <div style={loaderStyle}></div>
              <style>{keyframesStyle}</style>{" "}
            </div>
          )}
        </div>

        <div style={{ marginTop: "5rem" }}>
          <Stack spacing={2}>
            <Pagination
              sx={{ alignSelf: "center" }}
              count={10}
              color="primary"
              size="large"
            />
          </Stack>
        </div>
      </div>
    </div>

       <div className='mt-12'><OurServices/></div>

    </Layout>
  );
};
