import React from "react";
import { CheckOut } from "../Components/CheckOut";
import cart from "../Assets/Cart.svg";

export const CheckOutPage = () => {
  return (
    <>
<div
  style={{
    width: "100%",
    height: "9rem",
    backgroundColor: "#CFD9E2",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative", 
  }}
>
  <div
    style={{
      position: "absolute",
      left: "50%",
      transform: "translateX(-50%)",
      display: "flex",
    }}
  >
    <h1
      style={{
        fontWeight: "lighter",
        color: "#3F4754",
        fontSize: "2rem",
        margin: 0, 
      }}
    >
      Checkout
    </h1>
  </div>

  <div
    style={{
      position: "absolute",
      right: "5rem",
      display: "flex",
      alignItems: "center",
    }}
  >
   <a href="/cart"> <img src={cart} alt="Cart" width={18} /></a>
  </div>
</div>


      <CheckOut />
    </>
  );
};
