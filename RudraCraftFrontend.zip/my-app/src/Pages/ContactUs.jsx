import React from 'react'
import Layout from "../Components/Layout";
import { MdKeyboardArrowRight } from "react-icons/md";
import { FaLocationDot } from "react-icons/fa6";
import { MdEmail } from "react-icons/md";
import { MdCall } from "react-icons/md";

function ContactUs() {
  return (<>
    <Layout>
      <div className='w-full bg-[#CFD9E2] flex items-center justify-center h-[12rem]'>
        <div className='flex flex-col' >
          <h1 className='font-light text-[#3F4754] text-3xl text-center'>
            Contact Us
          </h1>
          <div className='flex justify-center items-center gap-2' >
            <a className='text-[#3F4754]' href="/">
              Home
            </a>
            <MdKeyboardArrowRight />
            <a className='text-[#3F4754]' href="#">
              Contact Us
            </a>
          </div>
        </div>
      </div>

      <div className='bg-[#EEEAE8]'>

        <div className='flex flex-col md:flex-row justify-center bg-[#EEEAE8] pt-10 md:pt-20'>
          <div className='flex justify-center border-1 border-gray px-4 md:pl-10'>
            <iframe className='h-80 md:h-full' src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d299600.26366363966!2d75.46829103351848!3d26.96715096384316!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5699ea20ee5%3A0x53625211402ee851!2sSHREE%20RUDRA%20CRAFT%20AND%20CREATIONS!5e0!3m2!1sen!2sin!4v1740646577951!5m2!1sen!2sin" width="650" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
          <div className='flex flex-col gap-3 border border-red-500 p-4 md:p-6'>
            <div className='text-[2.7rem] '>Let's Discuss</div>
            <div className='text-[18px]'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium tempora  porro ab, dolor veniam iusto consequatur aut tenetur vel.</div>
            <input className='border-1 border-gray-300 h-[3rem]  p-3 bg-[#DCD8D5] text-[18px]' placeholder="First Name" type="text" />
            <input className='border-1 border-gray-300 h-[3rem]  p-3 bg-[#DCD8D5] text-[18px]' placeholder="Email" type="text" />
            <textarea className='border-1 border-gray-300 p-3 bg-[#DCD8D5] text-[18px]' rows="5" placeholder="Comment" type="text"></textarea>
            <button className='text-white bg-[#88472E] w-[130px] py-2 text-[18px]'>Send</button>
          </div>
        </div>

        {/* Contact Information Section */}
        <div className="flex flex-col md:flex-row justify-start py-5 px-4 md:px-5 w-full gap-8">
          <div className="flex flex-col items-center text-center mb-5 md:mb-0 w-full md:w-auto">
            <div className="text-4xl"><FaLocationDot /></div>
            <div className="w-full md:w-48">125, Taneja Block, Saket Colony, Adarsh Nagar, Jaipur, Rajasthan 302004</div>
          </div>

          <div className="flex flex-col items-center text-center mb-5 md:mb-0 w-full md:w-auto">
            <div className="text-4xl"><MdEmail /></div>
            <div className="w-full md:w-48">info@rudracrafts.com</div>
          </div>

          <div className="flex flex-col items-center text-center w-full md:w-auto">
            <div className="text-4xl"><MdCall /></div>
            <div className="w-full md:w-48">+91-9983339820</div>
          </div>
        </div>

      </div>
    </Layout>
  </>
  )
}

export default ContactUs;
