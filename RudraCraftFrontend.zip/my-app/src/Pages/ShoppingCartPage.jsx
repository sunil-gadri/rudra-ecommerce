import React from "react";
import Layout from "../Components/Layout";
import { YourShoppingCart } from "../Components/YourShoppingCart";

export const ShoppingCartPage = () => {
  return (
    <>
      <Layout>
       <YourShoppingCart/>
      </Layout>
    </>
  );
};
