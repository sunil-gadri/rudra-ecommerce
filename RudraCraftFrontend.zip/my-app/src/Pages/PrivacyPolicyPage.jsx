import React from "react";
import Layout from "../Components/Layout";
import { MdKeyboardArrowRight } from "react-icons/md";
import policyimg from "../../src/Assets/policyimg.jpg";

export const PrivacyPolicyPage = () => {
  const sections = [
    {
      title: "Information We Collect",
      subsections: [
        {
          subtitle: "1.1. Personal Information",
          content: "When you register, place an order, or contact us, we may collect: Name, Email address, Mobile number, Shipping & billing address, Payment details (processed through secure payment gateways; we do not store card data)"
        },
        {
          subtitle: "1.2. Device & Usage Information",
          content: "When you use our website or app, we may collect: IP address, Device type, OS, browser type, App version, Crash reports & diagnostics, Pages/products viewed, Time spent on the app or website"
        },
        {
          subtitle: "1.3. Cookies & Tracking Technologies",
          content: "We use cookies and analytics tools to: Improve navigation, Personalize user experience, Save user preferences, Analyze site/app performance"
        }
      ]
    },
    {
      title: "How We Use Your Information",
      content: "We use your information to: Process and deliver orders, Communicate order updates, offers, and notifications, Provide customer support, Improve our products, services, and app experience, Prevent fraud and protect security, Send marketing and promotional messages (only with user consent)"
    },
    {
      title: "Sharing of Information",
      subsections: [
        {
          subtitle: "3.1. Trusted Partners",
          content: "To ensure smooth functioning: Delivery & courier partners, Payment gateway providers, Customer support tools, Analytics & marketing services. These partners are required to protect your data according to legal standards."
        },
        {
          subtitle: "3.2. Legal Requirements",
          content: "We may disclose information: To comply with applicable laws, To respond to government requests, To protect the rights and safety of RudraCraft or users"
        }
      ]
    },
    {
      title: "Data Security",
      content: "We use industry-standard security measures to protect your information, including: Encryption, Secure servers, Limited access controls, Fraud detection tools. However, no method of transmission over the internet or mobile networks is 100% secure."
    },
    {
      title: "Mobile App Permissions",
      content: "The RudraCraft app may request certain permissions for functionality: Storage Access (to save app files or images), Camera Access (for profile photo or scanning features), Notifications (to send order updates and offers), Location - Optional (for delivery accuracy). Permissions can be managed in your device settings."
    },
    {
      title: "Your Rights",
      content: "You have the right to: Access your personal data, Request correction of inaccurate details, Request deletion of your account, Opt-out of marketing communications, Disable cookies (via browser settings). To exercise these rights, contact us at: support@rudracrafts.com"
    },
    {
      title: "Retention of Information",
      content: "We retain your information: As long as your account remains active, As required for legal, tax, or fraud-prevention purposes, As needed to provide services efficiently. You can request account deletion anytime."
    },
    {
      title: "Children's Privacy",
      content: "Our website/app is not intended for children under 13. We do not knowingly collect data from minors. If a parent believes their child has provided information, they may contact us for removal."
    },
    {
      title: "Third-Party Links",
      content: "Our platforms may contain links to external websites or apps. We are not responsible for the content, privacy practices, or policies of those third parties."
    },
    {
      title: "Changes to This Privacy Policy",
      content: "We may update this Privacy Policy periodically. Any changes will be posted on this page with an updated 'Last Updated' date. Continued use of our website/app after changes means you accept the updated policy."
    }
  ];

  return (
    <>
      <Layout>
        <div className="w-full flex justify-center items-center">
          <div className="relative text-start">
            <img src={policyimg} alt="policyimg" />
            <div className="absolute top-1/2 left-[4%] -translate-y-1/2">
              <h1 className="text-[20px] md:text-[48px]">Privacy Policy</h1>
              <div className="flex items-center gap-[1px] justify-start">
                <a className="text-[#3F4754]" href="/">
                  Home
                </a>
                <MdKeyboardArrowRight />
                <a className="text-[#3F4754]" href="#">
                  Privacy Policy
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 p-12">
          <div className="flex flex-col gap-2">
            <h2 className="text-4xl font-bold">Privacy Policy – RudraCraft</h2>
           
            <p className="text-lg text-gray-700 leading-relaxed">
              At RudraCraft ("Company", "we", "our", "us"), we value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, store, and safeguard your data when you access or use our website (rudracrafts.com) and mobile application (RudraCraft App).
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              By using our services, you agree to the practices described in this Privacy Policy.
            </p>
          </div>

          {sections.map((section, index) => (
            <div key={index} className="flex flex-col gap-3">
              <h3 className="text-2xl font-semibold">{index + 1}. {section.title}</h3>
              
              {section.subsections ? (
                <div className="flex flex-col gap-3 ml-4">
                  {section.subsections.map((subsection, subIndex) => (
                    <div key={subIndex} className="flex flex-col gap-2">
                      <h4 className="text-xl font-semibold text-gray-800">{subsection.subtitle}</h4>
                      <p className="text-lg text-gray-700 leading-relaxed">{subsection.content}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-lg text-gray-700 leading-relaxed">{section.content}</p>
              )}
            </div>
          ))}

          <div className="flex flex-col gap-4 mt-6 pt-6 border-t border-gray-300">
            <h3 className="text-2xl font-semibold">Contact Us</h3>
            <p className="text-lg text-gray-700 leading-relaxed">
              For questions, requests, or concerns about this Privacy Policy, contact us:
            </p>
            <div className="flex flex-col gap-2 ml-4">
              <p className="text-lg"><strong>RudraCraft – Customer Support</strong></p>
              <p className="text-lg"><strong>Email:</strong> support@rudracrafts.com</p>
              <p className="text-lg"><strong>Phone:</strong> (Add your phone number)</p>
              <p className="text-lg"><strong>Address:</strong> (Add your business address)</p>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
};