import React from "react";
import Layout from "../Components/Layout";
import { OurServices } from '../Components/OurServices';
import Subscription from "../Components/Subscription";
import { MdKeyboardArrowRight } from "react-icons/md";
import { CollectionsContainer } from "../Components/CollectionsContainer";

export const Collection = () => {
  return (
    <>
      <Layout>
      <div style={{width: "100%" , height: "12rem" , backgroundColor: "#CFD9E2" , display: "flex"  , alignItems: "center" , justifyContent: "center"}}>

<div style={{display: "flex" , flexDirection: "column"}}>
    <h1 style={{fontWeight: "lighter" , color: "#3F4754" , fontSize: "2rem"}}>All Collections</h1>
    <div style={{display: "flex" , justifyContent: "center" , alignItems: "center" , gap: ".5em"}}>
        <a style={{color: "#3F4754"}} href="/">Home</a>
        <MdKeyboardArrowRight />
        <a style={{color: "#3F4754"}}  href="#">Collections</a>
    </div>
</div>

</div>     
   <CollectionsContainer/>
        
      <div className='mt-12'><OurServices/></div>
      <Subscription/>
      </Layout>
    </>
  );
};
