import React from "react";
import Layout from "../Components/Layout";
import policyimg from "../Assets/policyimg.jpg";
import { MdKeyboardArrowRight } from "react-icons/md";

export const RefundPolicyPage = () => {
  const sections = [
    {
      title: "Eligibility for Returns",
      subsections: [
        {
          subtitle: "You can request a return if:",
          content: "You received a damaged, defective, or incorrect product. The product is unused, unwashed, and in original condition. All original tags, labels, and packaging are intact."
        },
        {
          subtitle: "Non-returnable Items",
          content: "For hygiene and product integrity reasons, the following items are not eligible for return: Innerwear or personal-use items, Customized or personalized orders, Items on clearance or final sale, Used or washed products"
        }
      ]
    },
    {
      title: "Return Request Window",
      content: "Returns must be initiated within 3 days of delivery. After 3 days, we will not be able to accept return requests."
    },
    {
      title: "How to Initiate a Return",
      subsections: [
        {
          subtitle: "Website",
          content: "Go to My Orders → Select the product → Click on Return."
        },
        {
          subtitle: "Mobile App",
          content: "Open the Orders section → Choose the item → Tap Request Return. You will need to upload a clear picture/video showing the issue (damage, defect, incorrect item, etc.)."
        }
      ]
    },
    {
      title: "Return Pickup Process",
      content: "Once your return request is approved, a pickup will be arranged from your address. The product must be packed securely in the original packaging. If pickup service is not available at your location, you may be asked to self-ship the product. For self-shipment, courier charges will be reimbursed (as per actuals or fixed limit)."
    },
    {
      title: "Refund Policy",
      subsections: [
        {
          subtitle: "Refunds are processed after:",
          content: "1. The product reaches our warehouse, and 2. It passes the quality inspection."
        },
        {
          subtitle: "Refund Timeline",
          content: "UPI / Wallet / Store Credit: 24–48 hours after approval. Bank Account / Credit or Debit Card / Net Banking: 5–7 business days. COD Orders: Refund is issued via Bank Transfer or Wallet only."
        },
        {
          subtitle: "Important Note",
          content: "If the returned product fails quality check (used, damaged, missing tags), refund will be rejected and the item will be shipped back to you."
        }
      ]
    },
    {
      title: "Replacement Policy",
      content: "You can request a replacement if the product is: Damaged, Defective, or Incorrect. Replacement depends on stock availability. If we cannot provide a replacement, a full refund will be issued."
    },
    {
      title: "Order Cancellation",
      content: "You can cancel the order before it is shipped for a full refund. Once shipped, cancellation is not possible—you may apply for a return after delivery."
    },
    {
      title: "Wrong Address / Failed Delivery",
      content: "If an order is returned to us due to: Incorrect address, Customer unavailable, Phone not reachable, or Refusal to accept delivery. Then reshipping charges may apply. Refunds (if eligible) will exclude delivery charges."
    }
  ];

  return (
    <>
      <Layout>
        <div className="w-full flex justify-center items-center">
          <div className="relative text-start">
            <img src={policyimg} alt="policyimg" />
            <div className="absolute top-1/2 left-[4%] -translate-y-1/2">
              <h1 className="text-[20px] md:text-[48px]">Return & Refund Policy</h1>
              <div className="flex items-center gap-[1px] justify-start">
                <a className="text-[#3F4754]" href="/">
                  Home
                </a>
                <MdKeyboardArrowRight />
                <a className="text-[#3F4754]" href="#">
                  Return & Refund Policy
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 p-12">
          <div className="flex flex-col gap-2">
            <h2 className="text-4xl font-bold">Return & Refund Policy</h2>
            <p className="text-lg text-gray-600">RudraCraft Website & Mobile App</p>
            <p className="text-lg text-gray-700 leading-relaxed">
              At RudraCraft, we care about your satisfaction. If you are not fully happy with your purchase, we're here to help. Please read the following Return & Refund Policy to understand how returns, replacements, and refunds work on our platform.
            </p>
          </div>

          {sections.map((section, index) => (
            <div key={index} className="flex flex-col gap-3">
              <h3 className="text-2xl font-semibold">{index + 1}. {section.title}</h3>
              
              {section.subsections ? (
                <div className="flex flex-col gap-4 ml-4">
                  {section.subsections.map((subsection, subIndex) => (
                    <div key={subIndex} className="flex flex-col gap-2">
                      <h4 className="text-xl font-semibold text-gray-800">{subsection.subtitle}</h4>
                      <p className="text-lg text-gray-700 leading-relaxed">{subsection.content}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-lg text-gray-700 leading-relaxed">{section.content}</p>
              )}
            </div>
          ))}

          <div className="flex flex-col gap-4 mt-6 pt-6 border-t border-gray-300">
            <h3 className="text-2xl font-semibold">Contact Us</h3>
            <p className="text-lg text-gray-700 leading-relaxed">
              For any questions regarding Returns or Refunds:
            </p>
            <div className="flex flex-col gap-2 ml-4">
              <p className="text-lg">
                <strong>📧 Email:</strong> support@rudracrafts.com
              </p>
              <p className="text-lg">
                <strong>📞 Phone:</strong> +91-XXXXXXXXXX
              </p>
              <p className="text-lg">
                <strong>🌐 Website:</strong> www.rudracrafts.com
              </p>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
};  