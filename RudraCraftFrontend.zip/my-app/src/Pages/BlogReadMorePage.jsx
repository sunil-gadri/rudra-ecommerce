import React from "react";
import Layout from "../Components/Layout";
import { BlogReadMore } from "../Components/BlogReadMore";

export const BlogReadMorePage = () => {
  return (
    <>
      <Layout>
        <BlogReadMore />
      </Layout>
    </>
  );
};
