import React from "react";
import BannerImg from "../../src/Assets/About/bannner.jpg";
import about2 from "../../src/Assets/About/about2.jpg";
import about3 from "../../src/Assets/About/about3.jpg";
import about5 from "../../src/Assets/About/about5.jpg";
import Whychoose from "../../src/Assets/About/Why choose.jpg";
import Ourvision from "../../src/Assets/About/our vision.jpg";
import { useMediaQuery } from '@mui/material';
import Layout from "../Components/Layout";
import { OurServices } from "../Components/OurServices";
import Subscription from "../Components/Subscription";
import { MdKeyboardArrowRight } from "react-icons/md";

export const About = () => {

  const isXs = useMediaQuery('(min-width:0px) and (max-width:900px)');

  return (
    <>
      <Layout>

        <div className='w-full bg-[#CFD9E2] flex items-center justify-center h-[12rem]'>
          <div className='flex flex-col' >
            <h1 className='font-light text-[#3F4754] text-3xl text-center'>
              About Us
            </h1>
            <div className='flex justify-center items-center gap-2' >
              <a className='text-[#3F4754]' href="/">
                Home
              </a>
              <MdKeyboardArrowRight />
              <a className='text-[#3F4754]' href=" ">
                About Us
              </a>
            </div>
          </div>
        </div>
        <div

          style={{ backgroundColor: "#F3F2F0" }}
          className="w-100  flex flex-col gap-4"
        >
          <div>
            <img src={BannerImg} alt="about" />
          </div>

          <div className=" flex p-4 flex-col justify-center items-center gap-5">
            <div
              style={{ border: "1px solid lightgrey", display: 'grid', gridTemplateColumns: isXs ? '1fr' : '' }}
              className="grid grid-cols-2 p-4 gap-16"
            >
              <div className="w-[550px] h-[450px]">
                <img className="w-[100%] h-[100%] cover" src={about3} alt="overvision" />
              </div>
              <div className="flex items-left flex-col justify-center gap-3">
                <h1 style={{ textAlign: isXs ? 'center' : '', fontSize: '2.4rem' }}>Welcome to Rudra Craft</h1>
                <span style={{ width: isXs ? "100%" : '90%', textAlign: isXs ? 'center' : '' }}>
                  At Rudra Craft, we believe style starts at home and flows into everyday living. Since 2005, we’ve evolved from a small unit offering designer Bed-sheets, Dohars, Shawls, and Apparels into a trusted brand for Home Furnishings, Décor, Women’s Fashion, and Accessories.
                </span>
                <span style={{ width: isXs ? "100%" : '90%', textAlign: isXs ? 'center' : '' }}>
                  Our products reflect a perfect blend of modern trends and traditional craftsmanship, created with high-quality materials and thoughtful designs. We’re known for our consistent quality, elegant collections, and customer-first approach.
                </span>
                <span style={{ width: isXs ? "100%" : '90%', textAlign: isXs ? 'center' : '' }}>
                  Whether you're styling your space, updating your wardrobe, or searching for the perfect gift — Rudra Craft makes every purchase special and meaningful.
                </span>
              </div>
            </div>
            <div data-aos="fade-up"
              style={{ border: "1px solid lightgrey", display: 'grid', gridTemplateColumns: isXs ? '1fr' : '' }}
              className="grid grid-cols-2 p-4 gap-16 "
            >
              <div className="flex items-left flex-col justify-center gap-3">
                <h1 style={{ textAlign: isXs ? 'center' : '', fontSize: '2.4rem' }}>OUR MISSION </h1>
                <span style={{ width: isXs ? "100%" : '90%', textAlign: isXs ? 'center' : '' }}>
                  Our mission is to enrich everyday living by offering thoughtfully designed and finely crafted products that reflect beauty, quality, and comfort. We aim to inspire and empower our customers through:
                </span>
                <ul style={{ listStyleType: "circle", lineHeight: "2rem", paddingLeft: '1rem' }}>
                  <li>
                    Exceptional craftsmanship and the use of high-grade materials.
                  </li>
                  <li>
                    Trendsetting collections that cater to modern yet culturally rooted lifestyles.
                  </li>
                  <li>
                    Unwavering customer satisfaction through personalized service and consistent quality.
                  </li>
                  <li>
                    Sustainable and ethical practices that respect artisans and the environment.
                  </li>
                </ul>

                <span style={{ width: isXs ? "100%" : '90%', textAlign: isXs ? 'center' : '' }}>
                  We strive to be more than just a brand – we aim to be a part of our customers’ stories, homes, and memories.
                </span>

              </div>
              <div className="w-[550px] h-[450px]">
                <img className="w-[100%] h-[100%] cover" src={about2} alt="whoweareimg" />
              </div>
            </div>

            <div data-aos="fade-up" style={{ position: "relative", width: '100%', height: '100%' }}>
              <img style={{ width: '100%', height: '30rem', objectFit: 'cover' }} src={Ourvision} alt="vision-iamge" />

              <div
                style={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  color: "white",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: "1rem",
                  width: "100%",
                }}
              >
                <h1 style={{ color: '#D7B29B', fontSize: '2.4rem' }}>Our Vision</h1>
                <span
                  style={{
                    lineHeight: "1.6rem",
                    width: isXs ? "88%" : "60%",
                    textAlign: 'justify',
                    textAlignLast: 'center'
                  }}
                >
                  At Rudra Craft, our vision is to be recognized as a global leader in the home décor and fashion lifestyle space, celebrated for our authenticity, innovation, and integrity. We are committed to preserving and promoting Indian craftsmanship while embracing global design trends. As we grow, we aim to continuously evolve with the changing needs and preferences of our customers, expanding our presence across markets without compromising on our core values. We strive to create a brand experience that seamlessly blends tradition with modern living. We envision a world where homes are cozier, styles are bolder, and every product tells a unique story of creativity, culture, and care.
                </span>
              </div>
            </div>

            <div data-aos="fade-up"
              style={{ border: "1px solid lightgrey", display: 'grid', gridTemplateColumns: isXs ? '1fr' : '' }}
              className="grid grid-cols-2 p-4 gap-20 "
            >
              <div className="w-[550px] h-[450px]">
                <img className="w-[100%] h-[100%]" src={about5} alt="Whatweoffer" />
              </div>
              <div className="flex items-left flex-col justify-center gap-3">
                <h1 style={{ textAlign: isXs ? 'center' : '', fontSize: '2rem' }}>What We Offer</h1>
                <span style={{ width: isXs ? "100%" : '90%', textAlign: isXs ? 'center' : '' }}>
                  We offer a curated range of products that bring comfort, elegance, and expression into your daily life. Our collection includes:
                </span>
                <ul style={{ listStyleType: "circle", lineHeight: "2rem" }}>
                  <li>
                    <span className="font-bold">Home Furnishings: </span>Designer Bedsheets, Dohars, Cushion Covers, Table Linen & more — crafted to transform your living space.</li>
                  <li>
                    <span className="font-bold">Women’s Apparel:</span>Trendy Kurtis, Ethnic Wear, Shawls, Stoles, and Fusion Styles — tailored for the modern woman who values both fashion and comfort.
                  </li>
                  <li>
                    <span className="font-bold"> Women’s Accessories: </span>
                    Stylish and tasteful accessories that complete your look — the perfect complement to your outfit and personality.
                  </li>
                  <li>
                    <span className="font-bold">Gifting & Lifestyle: </span> Unique items ideal for festive gifting, housewarmings, or just treating yourself with something special.
                  </li>
                </ul>

                <span style={{ width: isXs ? "100%" : '90%', textAlign: isXs ? 'center' : '' }}>
                  At Rudra Craft, we don’t just sell products — we help you celebrate your space, your style, and yourself.
                </span>
              </div>
            </div>

            <div data-aos="fade-up"
              style={{ border: "1px solid lightgrey", display: 'grid', gridTemplateColumns: isXs ? '1fr' : '' }}
              className="grid grid-cols-2 p-4 gap-20 "
            >
              <div className="flex items-left flex-col justify-center gap-3">
                <h1 style={{ textAlign: isXs ? 'center' : '', fontSize: '2rem' }}>Why Choose Rudra Craft?</h1>

                <span>We know you have choices — and that’s why we go the extra mile to make Rudra Craft your preferred destination</span>

                <ul style={{ listStyleType: "circle", lineHeight: "2rem" }}>
                  <li>
                    <span className="font-bold"> Versatile Collection: </span>From elegant bedsheets to stylish women's wear, everything under one roof </li>
                  <li>
                    <span className="font-bold">Trusted Legacy Since 2005 : </span> 15+ years of excellence and customer satisfaction
                  </li>
                  <li>
                    <span className="font-bold"> Handpicked Materials: </span>
                    We use only the best fabrics and accessories for every product.
                  </li>
                  <li>
                    <span className="font-bold">Art Meets Trend: </span> A perfect blend of traditional craftsmanship with modern aesthetics.
                  </li>
                  <li>
                    <span className="font-bold">Customer-First Approach: </span> Easy shopping experience, secure payments, and prompt delivery.
                  </li>
                  <li>
                    <span className="font-bold">Proudly Made in India: </span>Supporting local artisans and promoting homegrown talent.
                  </li>
                </ul>
                <span>Choose Rudra Craft – where style meets substance, and every detail is designed for you.</span>
              </div>
              <div>
                <img src={Whychoose} alt="whatweoffer" />
              </div>
            </div>

            <div className="flex flex-col md:flex-row p-[24px] gap-[50px] border border-gray">
              <div data-aos="fade-up" className="flex flex-col gap-2 w-full md:w-[50%]" style={{ textAlign: "left" }}>
                <h2>Our Commitment</h2>
                <span>
                  At the heart of Rudra Craft lies a strong commitment to quality, trust, and timeless design. We are dedicated to:
                </span>

                <ul style={{ listStyleType: "circle", lineHeight: "2rem" }}>
                  <li>
                    Delivering excellence in every product – from raw material to final finish.
                  </li>
                  <li>
                    Celebrating craftsmanship by working with skilled artisans and designers.
                  </li>
                  <li>Ensuring customer satisfaction with attentive service and flexible support.</li>
                  <li>Offering value for money without compromising on style or substance. </li>
                  <li>Maintaining ethical and sustainable practices throughout our journey. </li>
                </ul>
              </div>
              <div data-aos="fade-up" className="flex flex-col gap-2 mb-6 w-full md:w-[50%]" style={{ textAlign: "left" }}>
                <h2>Join the Rudra Craft Family</h2>
                <span>At Rudra Craft, we’re more than just a brand — we’re a community of craft lovers, style seekers, and quality enthusiasts. When you choose Rudra Craft, you’re not just making a purchase — you’re becoming part of a family that values artistry, tradition, and innovation. </span>
                <span>By joining our family, you’ll be the first to explore new arrivals, enjoy exclusive deals, and get access to inspiration and styling tips for your home and wardrobe. Whether you're a loyal customer, a décor enthusiast, or a fashion-forward woman, there’s always something waiting for you at Rudra Craft. </span>
                <span>Let’s grow, celebrate, and create beautiful moments together. Welcome to the family! </span>
              </div>
            </div>
          </div>
        </div>
        <div className='mt-12'><OurServices /></div>
        <Subscription />
      </Layout>
    </>
  );
};
