import Layout from "../Components/Layout";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Faqs } from "../Components/Faqs";

export const FaqsPage = () => { 

  return (
    <>
      <Layout>
        <div
          style={{
            width: "100%",
            height: "12rem",
            backgroundColor: "#CFD9E2",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div style={{ display: "flex", flexDirection: "column" }}>
            <h1
              style={{
                fontWeight: "lighter",
                color: "#3F4754",
                fontSize: "2rem",
                textAlign: 'center'
              }}
            >
              FAQs
            </h1>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                gap: ".5em",
              }}
            >
              <a style={{ color: "#3F4754" }} href="/">
                Home
              </a>
              <MdKeyboardArrowRight />
              <a style={{ color: "#3F4754" }} href="#">
              FAQs
              </a>
            </div>
          </div>
        </div>
        <Faqs/>
      </Layout>
    </>
  );
};
