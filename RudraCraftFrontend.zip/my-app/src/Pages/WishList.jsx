import React from 'react'
import Layout from "../Components/Layout";
import { MdKeyboardArrowRight } from "react-icons/md";
import { useMediaQuery } from '@mui/material';
import img9 from "../../src/Assets/img-9.jpg";
import { RiDeleteBinLine } from "react-icons/ri";

export const WishList = () => {
    const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  return (
    <>
   <Layout>

   <div style={{width: "100%" , height: "12rem" , backgroundColor: "#CFD9E2" , display: "flex"  , alignItems: "center" , justifyContent: "center"}}>

<div style={{display: "flex" , justifyContent: 'center', flexDirection: "column"}}>
    <h1 style={{fontWeight: "lighter" , color: "#3F4754" , fontSize: "2rem", textAlign: 'center'}}>Wishlist</h1>
    <div style={{display: "flex" , justifyContent: "center" , alignItems: "center" , gap: ".5em"}}>
        <a style={{color: "#3F4754"}} href="/">Home</a>
        <MdKeyboardArrowRight />
        <a style={{color: "#3F4754"}}  href="#">Wishlist</a>
    </div>
</div>

</div>
      <div
        style={{ display: "none" }}
        className="flex justify-center items-center flex-col p-10"
      >
        <h1>Nothing found in wishlist!</h1>
        <a
          href="/shop"
          style={{
            backgroundColor: "#7A6E54",
            height: "3.2rem",
            marginTop: isXs ? "1rem" : "2rem",
            color: "white",
            width: isXs ? "100%" : "20%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          Continue Shopping
        </a>
      </div>

      {/* when full */}

      <div className="grid grid-cols-4 p-11 gap-4 ">
        <div className="flex flex-col justify-center gap-2 p-2" style={{border: '1px solid lightgrey'}}>
          <img src={img9} alt="" />
          <span style={{border: '1px solid lightgrey'}} className="text-xl text-center p-2">Shawl Head Wrap</span>
          <span style={{border: '1px solid lightgrey'}} className="text-xl text-center p-2">$30</span>
          <a style={{color: 'white'}} href="#"><button style={{width: '100%', height: '3rem', backgroundColor: '#7A6E54'}}>Select Option</button></a>
     <a style={{color: 'black'}} href="#"><button className="flex justify-center items-center gap-1" style={{width: '100%', height: '3rem', border: '1px solid lightgrey'}}>Remove  <RiDeleteBinLine />
      </button></a>
      
        </div>

        <div className="flex flex-col justify-center gap-2 p-2" style={{border: '1px solid lightgrey'}}>
          <img src={img9} alt="" />
          <span style={{border: '1px solid lightgrey'}} className="text-xl text-center p-2">Shawl Head Wrap</span>
          <span style={{border: '1px solid lightgrey'}} className="text-xl text-center p-2">$30</span>
          <a style={{color: 'white'}} href="#"><button style={{width: '100%', height: '3rem', backgroundColor: '#7A6E54'}}>Select Option</button></a>
     <a style={{color: 'black'}} href="#"><button className="flex justify-center items-center gap-1" style={{width: '100%', height: '3rem', border: '1px solid lightgrey'}}>Remove  <RiDeleteBinLine />
      </button></a>
      
      

        </div>

        <div className="flex flex-col justify-center gap-2 p-2" style={{border: '1px solid lightgrey'}}>
          <img src={img9} alt="" />
          <span style={{border: '1px solid lightgrey'}} className="text-xl text-center p-2">Shawl Head Wrap</span>
          <span style={{border: '1px solid lightgrey'}} className="text-xl text-center p-2">$30</span>
          <a style={{color: 'white'}} href="#"><button style={{width: '100%', height: '3rem', backgroundColor: '#7A6E54'}}>Select Option</button></a>
     <a style={{color: 'black'}} href="#"><button className="flex justify-center items-center gap-1" style={{width: '100%', height: '3rem', border: '1px solid lightgrey'}}>Remove  <RiDeleteBinLine />
      </button></a>

        </div>

        <div className="flex flex-col justify-center gap-2 p-2" style={{border: '1px solid lightgrey'}}>
          <img src={img9} alt="" />
          <span style={{border: '1px solid lightgrey'}} className="text-xl text-center p-2">Shawl Head Wrap</span>
          <span style={{border: '1px solid lightgrey'}} className="text-xl text-center p-2">$30</span>
          <a style={{color: 'white'}} href="#"><button style={{width: '100%', height: '3rem', backgroundColor: '#7A6E54'}}>Select Option</button></a>
     <a style={{color: 'black'}} href="#"><button className="flex justify-center items-center gap-1" style={{width: '100%', height: '3rem', border: '1px solid lightgrey'}}>Remove  <RiDeleteBinLine />
      </button></a>
      
        </div>
      </div>

      </Layout>
    </>
  )
}
