import React from "react";
import Layout from "../Components/Layout";
import { ResetPassword } from "../Components/ResetPassword";

export const ResetPasswordPage = () => {
  return (
    <>
      <Layout>
        <ResetPassword/>
      </Layout>
    </>
  );
};
