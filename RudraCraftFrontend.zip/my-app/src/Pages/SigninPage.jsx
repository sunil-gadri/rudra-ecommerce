import React from 'react'
import Layout from "../Components/Layout";
import { SignIn } from '../Components/SignIn';

export const SigninPage = () => {
  return (
    <>
    <Layout>

<SignIn/>

  </Layout>
    </>
  )
}
