import Layout from "../Components/Layout";
// import { Blogs } from '../Components/blogs/Blogs';
import React from 'react';
import blogimg1 from "../../src/Assets/blogimg-1.jpg";
import { MdKeyboardArrowRight } from "react-icons/md";
import { CgShapeRhombus } from "react-icons/cg";
import {useMediaQuery } from "@mui/material";

export const BlogsPage = () => {
  const isXs = useMediaQuery("(max-width:900px)");

  return (
    <>
    <Layout>
    <div 
        style={{
          width: "100%",
          height: "12rem",
          backgroundColor: "#CFD9E2",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column" }}>
          <h1
            style={{
              fontWeight: "lighter",
              color: "#3F4754",
              fontSize: "2rem",
              textAlign: "center",
            }}
          >
            Blogs
          </h1>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: ".5em",
            }}
          >
            <a style={{ color: "#3F4754" }} href="/">
              Home
            </a>
            <MdKeyboardArrowRight />
            <a style={{ color: "#3F4754" }} href="#">
              Blogs
            </a>
          </div>
          <div className="flex gap-3 items-center justify-center mt-4">
            <h5 className="mb-0">FASHION</h5>
            <CgShapeRhombus style={{ fontSize: ".7rem" }} />

            <h5 className="mb-0">BEAUTY</h5>
            <CgShapeRhombus style={{ fontSize: ".7rem" }} />

            <h5 className="mb-0">CULTURE</h5>
          </div>
        </div>
      </div>

      <div
        style={{ display: "grid", gridTemplateColumns: isXs ? "1fr" : "" }}
        className="grid grid-cols-3 gap-4 p-8"
      >
        <div data-aos="fade-up"
          style={{
            border: "1px solid lightgrey",
            textAlign: isXs ? "center" : "",
          }}
          className="flex flex-col justify-between gap-4 p-4"
        >
          <img src={blogimg1} alt="" />
          <div
            style={{ fontSize: isXs ? ".7rem" : "" }}
            className="flex justify-between"
          >
            <span style={{ color: "#87472D" }}>31 October, 2024</span>
            <span>|</span>
            <span style={{ color: "#87472D" }}>karthika R</span>
            <span>|</span>
            <span style={{ color: "#87472D" }}>0 comments</span>
          </div>
          <h3 style={{ lineHeight: "2rem" }} className="m-0">
            The Art of Draping: 7 Unique Ways to Style Your Stole
          </h3>
          <p className="m-0">
            This blog explores various innovative ways to drape a stole, from
            traditional to modern styles. It can include step-by-step images and
            videos to guide readers.
          </p>
          <a
            className="flex justify-center items-center text-white"
            style={{
              backgroundColor: "#7A6E54",
              width: isXs ? "100%" : "30%",
              height: "3rem",
            }}
            href="/blogs/readmore"
          >
            Read More
          </a>
        </div>

        <div data-aos="fade-up"
          style={{
            border: "1px solid lightgrey",
            textAlign: isXs ? "center" : "",
          }}
          className="flex flex-col justify-between gap-4 p-4"
        >
          <img src={blogimg1} alt="" />
          <div
            style={{ fontSize: isXs ? ".7rem" : "" }}
            className="flex justify-between"
          >
            <span style={{ color: "#87472D" }}>31 October, 2024</span>
            <span>|</span>
            <span style={{ color: "#87472D" }}>karthika R</span>
            <span>|</span>
            <span style={{ color: "#87472D" }}>0 comments</span>
          </div>
          <h3 style={{ lineHeight: "2rem" }} className="m-0">
            How to Choose the Perfect Stole for Your Outfit
          </h3>
          <p className="m-0">
            A guide on how to pair stoles with different types of outfits,
            including traditional wear, casuals, and formal attire. Content
            Highlights:
          </p>
          <a
            className="flex justify-center items-center text-white"
            style={{
              backgroundColor: "#7A6E54",
              width: isXs ? "100%" : "30%",
              height: "3rem",
            }}
            href="/blogs/readmore"
          >
            Read More
          </a>
        </div>

        <div data-aos="fade-up"
          style={{
            border: "1px solid lightgrey",
            textAlign: isXs ? "center" : "",
          }}
          className="flex flex-col justify-between gap-4 p-4"
        >
          <img src={blogimg1} alt="" />
          <div
            style={{ fontSize: isXs ? ".7rem" : "" }}
            className="flex justify-between"
          >
            <span style={{ color: "#87472D" }}>31 October, 2024</span>
            <span>|</span>
            <span style={{ color: "#87472D" }}>karthika R</span>
            <span>|</span>
            <span style={{ color: "#87472D" }}>0 comments</span>
          </div>
          <h3 style={{ lineHeight: "2rem" }} className="m-0">
            Stoles: The Perfect Companion for Every Season
          </h3>
          <p className="m-0">
            Highlight how stoles can be styled for different seasons — from
            lightweight cotton stoles for summer to warm woolen ones for winter.
            Content Highlights:
          </p>
          <a
            className="flex justify-center items-center text-white"
            style={{
              backgroundColor: "#7A6E54",
              width: isXs ? "100%" : "30%",
              height: "3rem",
            }}
            href="/blogs/readmore"
          >
            Read More
          </a>
        </div>
      </div>
      </Layout>
    </>
  )
}
