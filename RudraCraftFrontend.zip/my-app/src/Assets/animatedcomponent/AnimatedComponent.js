import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

const AnimatedComponent = ({ children, ...aosProps }) => {
  useEffect(() => {
    AOS.init({
      duration: 1000, // Default duration of animations
      once: false, // Animation triggers every time the element comes into view
    });
  }, []);

  
 return (
    <div
      data-aos={aosProps['data-aos']}
      data-aos-duration={aosProps['data-aos-duration']}
      data-aos-delay={aosProps['data-aos-delay']}
      data-aos-offset={aosProps['data-aos-offset']}
    >
      {children}
    </div>
  );
};

export default AnimatedComponent;
