import React from 'react'
import { MdKeyboardArrowRight } from "react-icons/md";

export const Product = () => {
  return (
    
    <div style={{width: "100%" , height: "12rem" , backgroundColor: "#CFD9E2" , display: "flex"  , alignItems: "center" , justifyContent: "center"}}>

        <div style={{display: "flex" , flexDirection: "column" , alignItems: 'center'}}>
            <h1 style={{fontWeight: "lighter" , color: "#3F4754" , fontSize: "2rem"}}>Shawl Head Wrap</h1>
            <div style={{display: "flex" , justifyContent: "center" , alignItems: "center" , gap: ".5em"}}>
                <a style={{color: "#3F4754"}} href="/">Home</a>
                <MdKeyboardArrowRight />
                <a style={{color: "#3F4754"}}  href="#">Shop</a>
                <MdKeyboardArrowRight />
                <a style={{color: "#3F4754"}}  href="#">Shawl Head Wrap</a>
                
            </div>
        </div>

    </div>
  )
}
