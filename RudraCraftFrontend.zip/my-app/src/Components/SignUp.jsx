import React from "react";
import { useMediaQuery } from "@mui/material";

export const SignUp = () => {
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  const containerStyle = {
    position: "relative",
    display: "inline-block",
    width: "100%",
  };

  const inputStyle = {
    border: "1px solid lightgrey",
    height: "3rem",
    padding: "1rem",
    width: "100%",
    boxSizing: "border-box",
  };

  const asteriskStyle = {
    position: "absolute",
    top: "50%",
    right: "1rem",
    transform: "translateY(-50%)",
    color: "red",
    fontWeight: "bold",
  };

  return (
    <>
      <div
        style={{ backgroundColor: "#EEEAE8" ,  padding:  isXs ? "1rem" : "" }}
        className="flex justify-center p-20"
      >
        <div
          style={{
            backgroundColor: "#D6CBC6",
            width: isXs ? "100%" : "50%",
            height: "50%",
            padding:  isXs ? "2rem" : "3rem"
          }}
          className="flex justify-center flex-col gap-3"
        >
          <h1 className="text-center">Sign Up</h1>
          <div className="flex gap-2 justify-center">
            {" "}
            <p>Already have an account?</p>{" "}
            <a style={{ color: "#87472D" }} href="/signin">
              Sign in
            </a>{" "}
          </div>
          <input
            style={{
              border: "1px solid lightgrey",
              height: "3rem",
              padding: "1rem",
              marginTop: "1.5rem",
            }}
            placeholder="First Name"
            type="text"
            name="firstname"
            id="firstname"
          />
          <input
            style={{
              border: "1px solid lightgrey",
              height: "3rem",
              padding: "1rem",
            }}
            placeholder="Last Name"
            type="text"
            name="lastname"
            id="lastname"
          />
          <div style={containerStyle}>
            <span style={asteriskStyle}>*</span>
            <input
              style={inputStyle}
              placeholder="Email"
              type="email"
              name="email"
              id="email"
            />
          </div>
          <div style={containerStyle}>
            <span style={asteriskStyle}>*</span>
            <input
              style={inputStyle}
              placeholder="Password"
              type="password"
              name="password"
              id="password"
            />
          </div>
          <a href="#">
            <button
              style={{
                backgroundColor: "#7A6E54",
                color: "white",
                width: "100%",
                height: "3rem",
                marginTop: "2rem",
              }}
            >
              Create
            </button>
          </a>
        </div>
      </div>
    </>
  );
};
