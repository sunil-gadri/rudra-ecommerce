import React from "react";
import { useTheme, useMediaQuery } from "@mui/material";

export default function Subscription() {
  const theme = useTheme();
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  return (
    <div
      style={{
        width: "100%",
        padding: isXs ? "14rem 2rem" : "0rem 4rem",
        height: "16rem",
        backgroundColor: "#CFD9E2",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: isXs ? "column" : "row",
        marginBottom: '5rem'
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: isXs ? "center" : "",
          alignItems: isXs ? "center" : "",
        }}
        data-aos="fade-right"
      >
        <p
          style={{
            fontSize: "2rem",
            textAlign: isXs ? "center" : "",
            fontFamily: "lora",
          }}
        >
          Stay Ahead of the Trends
        </p>
        <p
          style={{
            width: "100%",
            fontFamily: "lora",
            textAlign: isXs ? "center" : "",
          }}
        >
          Sign up for our newsletter and be the first to know about the latest
          arrivals, exclusive offers, and fashion tips!
        </p>
      </div>
      <div
        data-aos="fade-left"
        style={{
          display: "flex",
          gap: isXs ? "2rem" : "1rem",
          justifyContent: "space-between",
          alignItems: "center",
          flexDirection: isXs ? "column" : "row",
        }}
      >
        <input
          style={{
            width: isXs ? "18rem" : "27rem",
            padding: "1rem 0rem",
            backgroundColor: "transparent",
            borderBottom: "1px solid",
            fontSize: "1.1rem",
            fontFamily: "lora",
            outline: "none",
          }}
          placeholder="Enter Your Email Here"
          type="email"
          name=""
          id=""
        />
        <button
          style={{
            width: "10rem",
            height: "3.5rem",
            color: "white",
            backgroundColor: "#7A6E54",
            fontFamily: "lora",
          }}
          type="button"
        >
          Subscribe
        </button>
      </div>
    </div>
  );
}
