import React, { useState } from "react";
import img9 from "../Assets/img-9.jpg";
import { TfiWrite } from "react-icons/tfi";
import { Button, Spinner } from "react-bootstrap";
import { RiDeleteBinLine } from "react-icons/ri";
import { useTheme, useMediaQuery } from "@mui/material";

export const Cart = () => {
  const [hoverMinus, setHoverMinus] = useState(false);
  const [hoverPlus, setHoverPlus] = useState(false);
  const handleMouseEnterMinus = () => setHoverMinus(true);
  const handleMouseLeaveMinus = () => setHoverMinus(false);
  const handleMouseEnterPlus = () => setHoverPlus(true);
  const handleMouseLeavePlus = () => setHoverPlus(false);

  const [loading, setLoading] = useState(false);

  const theme = useTheme();
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  const handleApplyClick = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 2000);
  };

  const increase = () => {
    setQuantity((prevQuantity) => prevQuantity + 1);
  };

  const [quantity, setQuantity] = useState(1);

  const decrease = () => {
    setQuantity((prevQuantity) => Math.max(prevQuantity - 1, 1));
  };
  const price = 30;
  return (
    <>
      <div
        style={{ padding: isXs ? "2rem" : "" }}
        className="p-16 flex flex-col justify-between gap-3"
      >
        <div className="flex justify-between">
          <h5>Product</h5>
          <h5 style={{ display: isXs ? "none" : "" }}>Quantity</h5>
          <h5 style={{ display: isXs ? "none" : "" }}>Total</h5>
        </div>
        <hr />

        <div
          style={{
            flexDirection: isXs ? "column" : "",
            gap: isXs ? "2rem" : "",
            alignItems: isXs ? "start" : "",
          }}
          className="flex justify-between items-center w-full"
        >
          <div
            style={{
              flexDirection: isXs ? "column" : "",
              width: isXs ? "90%" : "",
              alignItems: isXs ? "start" : "",
            }}
            className="flex items-center gap-4 w-1/3"
          >
            <div
              style={{
                width: isXs ? "100%" : "30%",
                border: "1px solid lightgrey",
                borderRadius: "5px",
                padding: ".5rem",
              }}
            >
              <img src={img9} alt="img9" />
            </div>

            <div className="flex flex-col">
              <h5 className="m-0">Shawl Head Wrap</h5>

              <div className="flex">
                <div className="flex items-center">
                  <span className="text-xs">Color: Almond</span>
                  <hr style={{ rotate: "90deg", width: "1rem" }} />
                </div>

                <div className="flex items-center">
                  <span className="text-xs">Material: Chiffon</span>
                </div>
              </div>

              <h5 style={{ fontSize: isXs ? "2rem" : "" }} className="m-0">
                $30
              </h5>
            </div>
            <div
              style={{
                width: isXs ? "100%" : "",
                justifyContent: isXs ? "start" : "",
                display: isXs ? "" : "none",
              }}
              className="flex items-center justify-center gap-3 w-1/3"
            >
              <button
                style={{
                  padding: ".1rem 1rem",
                  border: "1px solid lightgrey",
                  fontSize: "1.8rem",
                  color: hoverMinus ? "white" : "black",
                  backgroundColor: hoverMinus ? "#7A6E54" : "transparent",
                  transition: "background-color 0.3s ease",
                }}
                onClick={decrease}
                onMouseEnter={handleMouseEnterMinus}
                onMouseLeave={handleMouseLeaveMinus}
              >
                -
              </button>
              <span style={{ fontSize: "1.2rem" }}>{quantity}</span>
              <button
                style={{
                  padding: ".1rem 1rem",
                  border: "1px solid lightgrey",
                  fontSize: "1.8rem",
                  color: hoverPlus ? "white" : "black",
                  backgroundColor: hoverPlus ? "#7A6E54" : "transparent",
                  transition: "background-color 0.3s ease",
                }}
                onClick={increase}
                onMouseEnter={handleMouseEnterPlus}
                onMouseLeave={handleMouseLeavePlus}
              >
                +
              </button>
              <button>
                <RiDeleteBinLine style={{ fontSize: "1.3rem" }} />
              </button>
            </div>
          </div>

          <div
            style={{
              width: isXs ? "100%" : "",
              justifyContent: isXs ? "start" : "",
              display: isXs ? "none" : "",
            }}
            className="flex items-center justify-center gap-3 w-1/3"
          >
            <button
              style={{
                padding: ".1rem 1rem",
                border: "1px solid lightgrey",
                fontSize: "1.8rem",
                color: hoverMinus ? "white" : "black",
                backgroundColor: hoverMinus ? "#7A6E54" : "transparent",
                transition: "background-color 0.3s ease",
              }}
              onClick={decrease}
              onMouseEnter={handleMouseEnterMinus}
              onMouseLeave={handleMouseLeaveMinus}
            >
              -
            </button>
            <span style={{ fontSize: "1.2rem" }}>{quantity}</span>
            <button
              style={{
                padding: ".1rem 1rem",
                border: "1px solid lightgrey",
                fontSize: "1.8rem",
                color: hoverPlus ? "white" : "black",
                backgroundColor: hoverPlus ? "#7A6E54" : "transparent",
                transition: "background-color 0.3s ease",
              }}
              onClick={increase}
              onMouseEnter={handleMouseEnterPlus}
              onMouseLeave={handleMouseLeavePlus}
            >
              +
            </button>
            <button>
              <RiDeleteBinLine style={{ fontSize: "1.3rem" }} />
            </button>
          </div>

          <div
            style={{ display: isXs ? "none" : "" }}
            className="w-1/3 flex justify-end"
          >
            <h5>${price * quantity}</h5>
          </div>
        </div>

        <hr />

        <div className="flex justify-center">
          <a href="/shop">
            {" "}
            <button
              style={{
                width: "12rem",
                height: "3rem",
                backgroundColor: "#7A6E54",
                color: "white",
              }}
            >
              Continue Shopping
            </button>
          </a>
        </div>

        <div
          className="flex items-center pl-5 pr-5 justify-center gap-4"
          style={{
            width: "100%",
            height: isXs ? "35rem" : "18rem",
            backgroundColor: "#CFD9E2",
            marginTop: "1rem",
            flexDirection: isXs ? "column" : "",
            
          }}
        >
          <div className="flex flex-col gap-2">
            <div className="flex gap-2">
              <TfiWrite fontSize={20} />

              <h6>Add Note</h6>
            </div>
            <textarea
              style={{ width: isXs ? "15rem" : "25rem", height: "10rem", padding: "1rem" }}
              placeholder="Write Your Text Here"
              name=""
              id=""
            ></textarea>
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex gap-3">
              <span>Subtotal</span>
              <h5>${price * quantity}</h5>
            </div>

            <span>Taxes and shipping calculated at checkout</span>

            <a href="/checkout">
              {" "}
              <button
                style={{
                  width: "100%",
                  height: "3rem",
                  backgroundColor: "#7A6E54",
                  color: "white",
                  marginTop: "1rem",
                }}
              >
                Check Out
              </button>
            </a>

            <div className="flex justify-center items-center gap-2 w-100">
              <input
                className="mt-3 p-3"
                style={{ width: "70%", height: "3rem" }}
                placeholder="Discount Code...."
                type="text"
                name=""
                id=""
              />
              <div
                style={{
                  width: "30%",
                  height: "3rem",
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Button
                  style={{
                    width: "100%",
                    height: "3rem",
                    padding: "0 2rem",
                    backgroundColor: "#7A6E54",
                    color: "white",
                    marginTop: "1rem",
                    border: "none",
                    borderRadius: "0px",
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}
                  onClick={handleApplyClick}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden="true"
                        style={{ marginRight: "0.5rem" }}
                      />
                    </>
                  ) : (
                    "Apply"
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
