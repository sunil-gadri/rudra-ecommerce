import React, { useState, useEffect } from "react";
import { IoArrowUp } from "react-icons/io5";

const styles = {
  button: {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    padding: "20px 20px" ,
    backgroundColor: "#A91E28",
    color: "white",
    border: "none",
    borderRadius: "50px",
    cursor: "pointer",
    zIndex: "99999",
    boxShadow: "0px 4px 18px rgba(0, 0, 0, 0.3)",
  },
};

export const BackToTop = () => {
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };
    
    window.addEventListener("scroll", handleScroll);
    
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <>
      {isVisible && (
        <button
          id="btn-back-to-top"
          onClick={scrollToTop}
          style={styles.button}
        >
          <IoArrowUp />
        </button>
      )}
    </>
  );
};
