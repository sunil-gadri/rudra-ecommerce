import React from "react";
import { useTheme, useMediaQuery } from "@mui/material";

export const ResetPassword = () => {
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  const inputStyle = {
    border: "1px solid lightgrey",
    height: "3rem",
    padding: "1rem",
    width: "100%",
    boxSizing: "border-box",
  };
  return (
    <>
      <div
        style={{ backgroundColor: "#EEEAE8" , padding:  isXs ? "1rem" : ""  }}
        className="flex justify-center p-20"
      >
        <div
          style={{
            backgroundColor: "#D6CBC6",
            width: isXs ? "100%" : "50%",
            padding:  isXs ? "2rem" : "3rem",
            height: "50%",
          }}
          className="flex justify-center flex-col gap-3"
        >
          <h1 className="text-center">Reset your password</h1>
          <span className="text-center">
            We will send you an email to reset your password
          </span>
          <div className="flex gap-2 justify-center"> </div>

          <div>
            <input
              style={inputStyle}
              placeholder="Email"
              type="email"
              name="email"
              id="email"
            />
          </div>

          <div className="flex gap-4  ">
            <a className="w-100" href="/signin">
              <button
                style={{
                  border: "1px solid black",
                  color: "black",
                  width: "100%",
                  height: "3rem",
                  marginTop: "2rem",
                }}
              >
                Cancel
              </button>
            </a>

            <a className="w-100" href="#">
              <button
                style={{
                  backgroundColor: "#7A6E54",
                  color: "white",
                  width: "100%",
                  height: "3rem",
                  marginTop: "2rem",
                }}
              >
                Submit
              </button>
            </a>
          </div>
        </div>
      </div>
    </>
  );
};
