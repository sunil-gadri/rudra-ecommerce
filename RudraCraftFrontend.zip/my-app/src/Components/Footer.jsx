
import React, { useState } from "react";
import footerlogo from "../Assets/logo.png";
import phone from "../Assets/phone.svg";
import mail from "../Assets/email.svg";
import location from "../Assets/location.svg";
import insta from "../Assets/insta.svg";
import fb from "../Assets/fb.svg";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import { useMediaQuery } from '@mui/material';
import twitter from "../Assets/twitter.svg";
import { createGlobalStyle } from 'styled-components';
const GlobalStyle = createGlobalStyle`
    a {
        text-decoration: none; 
    }
`;

const Footer = () => {
  const [isCollection1Expanded, setIsCollection1Expanded] = useState(false);
  const [isCollection2Expanded, setIsCollection2Expanded] = useState(false);
  const [isCollection3Expanded, setIsCollection3Expanded] = useState(false);

  const toggleCollection1 = () => {
    setIsCollection1Expanded(!isCollection1Expanded);
  };

  const toggleCollection2 = () => {
    setIsCollection1Expanded(false);
    setIsCollection2Expanded(!isCollection2Expanded);
  };

  const toggleCollection3 = () => {
    setIsCollection1Expanded(false);
    setIsCollection3Expanded(!isCollection3Expanded);
  };


  const isXs = useMediaQuery('(min-width:0px) and (max-width:900px)');

  return (
    <>
      <div style={{ display: isXs ? 'none' : '' }}>
        <GlobalStyle />
        <div style={{ height: isXs ? "40em" : "30rem", marginTop: "0rem", backgroundColor: '#191E26' }}>


          <div
            style={{ position: "absolute", bottom: "8rem" }}
            className="grid grid-cols-5 gap-16 p-6 "
          >
            <div className="flex flex-col gap-3">
              <img width={120} src={footerlogo} alt="" />
              <p
                style={{ fontFamily: "lora", lineHeight: "1.2rem", width: "100%", color: "rgb(255, 255, 255, .5)", fontSize: ".8rem" }}

              >
                It is a long established fact that a reader will be distracted by
                the readable content.
              </p>
              <div style={{ display: "flex", gap: "1.5rem", marginTop: "2rem" }}>
                <img src={insta} alt="" width={20} />
                <img src={fb} alt="" width={20} />
                <img src={twitter} alt="" width={18} />
              </div>
            </div>

            <div style={{ fontFamily: "lora", fontSize: ".9rem" }} className="flex flex-col gap-3 text-white from-current items-center">
              <div style={{ gap: "1rem", display: "flex", flexDirection: "column" }}>
                <div>
                  <h1
                    style={{ fontFamily: "lora", color: "white", fontSize: "1rem", display: "flex" }}
                  >
                    Shop
                  </h1>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                  <a style={{ color: "#ACACAC" }} href="#">Shop All</a>
                  <a style={{ color: "#ACACAC" }} href="#">New In</a>
                  <a style={{ color: "#ACACAC" }} href="/shop">Bestsellers</a>
                  <a style={{ color: "#ACACAC" }} href="/collections">Collections</a>
                  <a style={{ color: "#ACACAC" }} href="#">Lookbook</a>
                  <a style={{ color: "#ACACAC" }} href="#">Gifts Cards</a>
                </div>
              </div>
            </div>

            <div style={{ fontFamily: "lora", fontSize: ".9rem" }} className="flex flex-col gap-3 text-white from-current items-center">
              <div style={{ gap: "1rem", display: "flex", flexDirection: "column" }}>

                <div>
                  <h1
                    style={{ fontFamily: "lora", color: "white", fontSize: "1rem", display: "flex" }}
                  >
                    Customer Care
                  </h1>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                  <a style={{ color: "#ACACAC" }} href="shipping-policy">Shipping & Delivery Policy</a>
                  <a style={{ color: "#ACACAC" }} href="refundpolicy">Refund Policy</a>
                  <a style={{ color: "#ACACAC" }} href="privacypolicy">Privacy Policy</a>
                  <a style={{ color: "#ACACAC" }} href="/termsandconditions">Terms and Conditions</a>
                  <a style={{ color: "#ACACAC" }} href="/signin">Account</a>
                  <a style={{ color: "#ACACAC" }} href="/contact-us">Contact Us</a>
                </div>
              </div>
            </div>

            <div style={{ fontFamily: "lora", fontSize: ".9rem" }} className="flex flex-col gap-3 text-white from-current items-center">
              <div style={{ gap: "1rem", display: "flex", flexDirection: "column" }}>

                <div>
                  <h1
                    style={{ fontFamily: "lora", color: "white", fontSize: "1rem", display: "flex" }}
                  >
                    Company
                  </h1>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                  <a style={{ color: "#ACACAC" }} href="/about">About</a>
                  <a style={{ color: "#ACACAC" }} href="/blogs">Stories</a>
                  <a style={{ color: "#ACACAC" }} href="/FAQs">FAQs</a>
                  <a style={{ color: "#ACACAC" }} href="/disclaimer">Disclaimer</a>

                </div>
              </div>
            </div>



            <div style={{ fontFamily: "lora", fontSize: ".9rem" }} className="flex flex-col gap-6 text-white from-current">
              <h1
                style={{ fontFamily: "lora", color: "white", fontSize: "1rem" }}
              >
                Contact
              </h1>
              <div className="flex gap-2 items-center">
                <img width={20} src={phone} alt="" />
                <a style={{ color: "#ACACAC" }} href="#">+91-9983339820</a>
              </div>

              <div className="flex items-center  gap-2">
                <img width={20} src={mail} alt="" />
                <a style={{ color: "#ACACAC" }} href="#">info@rudracrafts.com</a>
              </div>

              <div className="flex items-start  gap-2">
                <img width={20} src={location} alt="" />
                <a style={{ color: "#ACACAC" }} href="#">125, Taneja Block, Saket Colony, Adarsh Nagar, Jaipur, Rajasthan 302004</a>
              </div>
            </div>
          </div>

          <div style={{ position: "absolute", bottom: "1rem", width: "100%", display: "flex", justifyContent: "center", flexDirection: "column", alignItems: "center", gap: "1rem" }}>
            <hr style={{ width: "100%", border: "none", borderTop: ".1px solid rgb(255, 255, 255 , .2)" }} />
            <div style={{ display: "flex", gap: "2rem" }}>

              <p style={{ fontFamily: "lora", color: "white", fontSize: "1.1rem" }}> &copy;Rudra Cratf all rights Reserved</p>
              <p style={{ fontFamily: "lora", color: "grey", fontSize: "1.1rem" }}>Powered By Infomagine Softwares Pvt. Ltd.</p>
            </div>

{/* 
            <div style={{ display: "flex", fontFamily: "lora", gap: "2rem", color: "white", fontSize: "1rem" }}>
              <a style={{ color: "white" }} href="refundpolicy">Refund Policy</a>
              <a style={{ color: "white" }} href="/privacypolicy">Privacy Policy</a>
              <a style={{ color: "white" }} href="/termsandconditions">Terms and Conditions</a>
            </div> */}
          </div>

        </div>
      </div>


      <div style={{ display: isXs ? '' : 'none' }}>
        <GlobalStyle />

        <div style={{ height: isXs ? "auto" : "30rem", marginTop: "3rem", backgroundColor: '#191E26', padding: '3rem 2rem' }}>

          <div className="flex flex-col items-start gap-4">
            <img style={{ width: "5rem" }} src={footerlogo} alt="" />
            <p
              style={{ fontFamily: "lora", lineHeight: "1.2rem", width: "100%", color: "rgb(255, 255, 255, .5)", fontSize: ".8rem", textAlign: 'left' }}

            >
              It is a long established fact that a reader will be distracted by
              the readable content.
            </p>

            <div style={{ fontFamily: "lora", fontSize: ".9rem" }} className="flex flex-col gap-6 text-white from-current">

              <div className="flex gap-2 items-center">
                <img width={20} src={phone} alt="" />
                <a style={{ color: "#ACACAC" }} href="#">+91-9983339820</a>
              </div>

              <div className="flex items-center  gap-2">
                <img width={20} src={mail} alt="" />
                <a style={{ color: "#ACACAC" }} href="#">info@rudracraft.com</a>
              </div>

              <div className="flex items-start  gap-2">
                <img width={20} src={location} alt="" />
                <a style={{ color: "#ACACAC" }} href="#">125, Taneja Block, Saket Colony, Adarsh Nagar, Jaipur, Rajasthan 302004</a>
              </div>

            </div>

            <div style={{ display: "flex", gap: "1.5rem", marginTop: "1.5rem" }}>
              <img src={insta} alt="" width={20} />
              <img src={fb} alt="" width={20} />
              <img src={twitter} alt="" width={18} />
            </div>

          </div>
          <div style={{ marginTop: '3rem', display: 'flex', flexDirection: 'column', gap: '.5rem' }}>
            <div className="flex flex-col gap-3">
              <div
                onClick={toggleCollection1}
                style={{
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  color: 'white',
                  width: '100%'
                }}
              >
                <h6 style={{ fontSize: '.9rem' }}>Shop</h6>
                {isCollection1Expanded ? (
                  <FaChevronUp
                    style={{ marginLeft: "14rem", fontSize: ".7rem", color: 'white' }}
                  />
                ) : (
                  <FaChevronDown
                    style={{ marginLeft: "14rem", fontSize: ".7rem", color: 'white' }}
                  />
                )}
              </div>
              {isCollection1Expanded && (
                <div className="flex flex-col gap-2">
                  <div className="flex gap-3 flex-col items-start text-sm">
                    <a style={{ color: "#ACACAC" }} href="#">Shop All</a>
                    <a style={{ color: "#ACACAC" }} href="#">New In</a>
                    <a style={{ color: "#ACACAC" }} href="/shop">Bestsellers</a>
                    <a style={{ color: "#ACACAC" }} href="/collections">Collections</a>
                    <a style={{ color: "#ACACAC" }} href="#">Lookbook</a>
                    <a style={{ color: "#ACACAC" }} href="#">Gifts Cards</a>
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col gap-3">
              <div
                onClick={toggleCollection2}
                style={{
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  color: 'white',
                  width: '100%'
                }}
              >
                <h6 style={{ fontSize: '.9rem', marginTop: "1rem" }}>Customer Care</h6>
                {isCollection2Expanded ? (
                  <FaChevronUp
                    style={{ marginLeft: "9.8rem", fontSize: ".7rem", color: 'white' }}
                  />
                ) : (
                  <FaChevronDown
                    style={{ marginLeft: "9.8rem", fontSize: ".7rem", color: 'white' }}
                  />
                )}
              </div>
              {isCollection2Expanded && (
                <div className="flex flex-col gap-2">
                  <div className="flex gap-3 flex-col items-start  text-sm">
                <a style={{ color: "#ACACAC" }} href="shipping-policy">Shipping & Delivery Policy</a>
                  <a style={{ color: "#ACACAC" }} href="refundpolicy">Refund Policy</a>
                  <a style={{ color: "#ACACAC" }} href="privacypolicy">Privacy Policy</a>
                  <a style={{ color: "#ACACAC" }} href="/termsandconditions">Terms and Conditions</a>
                  <a style={{ color: "#ACACAC" }} href="/signin">Account</a>
                  <a style={{ color: "#ACACAC" }} href="/contact-us">Contact Us</a>
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col gap-3">
              <div
                onClick={toggleCollection3}
                style={{
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  color: 'white',
                  width: '100%'
                }}
              >
                <h6 style={{ fontSize: '.9rem', marginTop: "1rem" }}>Company</h6>
                {isCollection3Expanded ? (
                  <FaChevronUp
                    style={{ marginLeft: "12.2rem", fontSize: ".7rem", color: 'white' }}
                  />
                ) : (
                  <FaChevronDown
                    style={{ marginLeft: "12.2rem", fontSize: ".7rem", color: 'white' }}
                  />
                )}
              </div>
              {isCollection3Expanded && (
                <div className="flex flex-col gap-2">
                  <div className="flex gap-3 flex-col items-start  text-sm">
                    <a style={{ color: "#ACACAC" }} href="/about">About</a>
                    <a style={{ color: "#ACACAC" }} href="/blogs">Stories</a>
                    <a style={{ color: "#ACACAC" }} href="/FAQs">FAQs</a>
                    <a style={{ color: "#ACACAC" }} href="/disclaimer">Disclaimer</a>
                  </div>
                </div>
              )}
            </div>
          </div>


          <div style={{ width: "100%", display: "flex", justifyContent: "center", flexDirection: "column", alignItems: "center", gap: "1rem" }}>
            <hr style={{ width: "100%", border: "none", borderTop: ".1px solid rgb(255, 255, 255 , .6)" }} />
            <div style={{ display: "flex", gap: ".5rem", flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>

              <p style={{ fontFamily: "lora", color: "white", fontSize: ".8rem" }}> &copy;StoleSutra all rights Reserved</p>
              <p style={{ fontFamily: "lora", color: "grey", fontSize: ".8rem" }}>Powered By Infomagine Softwares Pvt. Ltd.</p>
            </div>


            <div style={{ display: "flex", flexDirection: 'column', alignItems: 'center', fontFamily: "lora", gap: "1rem", color: "white", fontSize: ".8rem" }}>
              <a style={{ color: "white" }} href="#">Refund Policy</a>
              <a style={{ color: "white" }} href="#">Privacy Policy</a>
              <a style={{ color: "white" }} href="#">Terms Of Service</a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Footer;
