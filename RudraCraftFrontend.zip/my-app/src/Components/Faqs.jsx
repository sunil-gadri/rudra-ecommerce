import React, { useState, useRef } from "react";
import { useMediaQuery } from "@mui/material";
import { FaPlus } from "react-icons/fa6";
import { FiMinus } from "react-icons/fi";

const faqData = [
  {
    category: "Shopping",
    items: [
      {
        q: "How do I place an order on the Rudra Crafts app?",
        a: "Simply browse your favorite products, select the size or variant (if applicable), add them to your cart, and proceed to checkout. Complete the payment to confirm your order."
      },
      {
        q: "What payment methods do you accept?",
        a: "We accept all major payment options, including UPI, Debit/Credit Cards, Net Banking, and Wallets for a smooth and secure shopping experience."
      },
      {
        q: "How can I track my order?",
        a: "Once your order is shipped, you will receive a tracking link via SMS or email. You can also check the real-time status in the \"My Orders\" section of the app."
      }
    ]
  },
  {
    category: "Manage Your Account",
    items: [
      {
        q: "How do I update my profile details?",
        a: "Go to the My Account section in the app and tap on Edit Profile to update your name, email, phone number, or address."
      },
      {
        q: "I forgot my password. How can I reset it?",
        a: "Click on Forgot Password on the login screen, enter your registered email or mobile number, and follow the instructions to reset your password."
      },
      {
        q: "Can I change my mobile number or email ID?",
        a: "Yes, you can update your registered mobile number or email ID from the Account Settings section. For security reasons, verification may be required."
      }
    ]
  },
  {
    category: "Cancellation & Refund",
    items: [
      {
        q: "What is your return policy?",
        a: "You can request a return within 7 days of delivery if the product is unused, in original condition, and has all tags intact."
      },
      {
        q: "How do I initiate a return?",
        a: "Go to My Orders in the app, select the product you want to return, and tap on Request Return. Follow the steps to complete the process."
      },
      {
        q: "When will I receive my refund?",
        a: "Once the returned product is picked up and verified, your refund will be processed within 5–7 business days to your original payment method."
      }
    ]
  },
  {
    category: "Payment",
    items: [
      {
        q: "What payment methods are available?",
        a: "We accept UPI, Debit/Credit Cards, Net Banking, and major Wallets for secure and seamless payments."
      },
      {
        q: "My payment failed. What should I do?",
        a: "If a payment fails, please try again after a few minutes. Any amount deducted will be automatically refunded to your original payment method within 3–5 business days."
      },
      {
        q: "Is online payment safe on the Rudra Crafts app?",
        a: "Yes, all transactions are secured with industry-standard encryption, ensuring a safe and protected shopping experience."
      }
    ]
  },
  {
    category: "Offers & Promotions",
    items: [
      {
        q: "How can I apply a coupon code?",
        a: "Enter your coupon code on the checkout page and the discount will be applied automatically if the offer is valid."
      },
      {
        q: "Why is my promo code not working?",
        a: "Your promo code may be expired, already used, or not applicable to certain products. Please check the offer terms & conditions."
      },
      {
        q: "How do I stay updated on new offers?",
        a: "Enable app notifications and subscribe to our updates to receive the latest deals, discounts, and exclusive promotions."
      }
    ]
  },
  {
    category: "Authenticity & Genuineness",
    items: [
      {
        q: "Are all products on Rudra Crafts genuine?",
        a: "Yes, every product on our app is 100% authentic, sourced directly from trusted manufacturers and crafted with high-quality materials."
      },
      {
        q: "How can I be sure of the product quality?",
        a: "We follow strict quality checks before shipping. Each item goes through multiple inspections to ensure it matches our standards for design, fabric, and finish."
      },
      {
        q: "Do you provide original product images?",
        a: "Yes, all product photos are real and professionally shot, ensuring you get a true representation of what you're purchasing."
      }
    ]
  },
  {
    category: "General Queries",
    items: [
      {
        q: "How can I contact customer support?",
        a: "You can reach us through the Help & Support section in the app or email us at our customer service address for quick assistance."
      },
      {
        q: "Do you have a physical store?",
        a: "Rudra Crafts primarily operates online, allowing us to offer a wide range of products at the best prices. Any store updates will be shared on the app."
      },
      {
        q: "How often do you add new products?",
        a: "We update our collection regularly with new designs and trending styles, so be sure to check the app often for fresh arrivals!"
      }
    ]
  }
];

const FaqItem = ({ item, isXs }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const contentRef = useRef(null);
  const [height, setHeight] = useState("0px");

  const toggleExpand = () => {
    const newState = !isExpanded;
    setIsExpanded(newState);
    if (contentRef.current) {
      setHeight(newState ? `${contentRef.current.scrollHeight}px` : "0px");
    }
  };

  return (
    <>
      <div
        onClick={toggleExpand}
        style={{
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          width: "100%",
          justifyContent: "space-between",
          padding: "1.3rem 0.5rem",
          borderBottom: "1px solid lightgrey"
        }}
      >
        <h6
          style={{
            fontSize: isXs ? "1rem" : "1.1rem",
            color: "#87462D",
            margin: "0",
            flex: 1,
            paddingRight: "1rem"
          }}
        >
          {item.q}
        </h6>
        {isExpanded ? (
          <FiMinus style={{ fontSize: "1.2rem", color: "#87462D", flexShrink: 0 }} />
        ) : (
          <FaPlus style={{ fontSize: "1.2rem", color: "#87462D", flexShrink: 0 }} />
        )}
      </div>

      <div
        ref={contentRef}
        style={{
          height: height,
          transition: "height 0.6s ease",
          overflow: "hidden"
        }}
      >
        <div style={{ padding: "1rem 0.5rem", paddingBottom: "1.5rem", paddingLeft: "1.5rem" }}>
          <span style={{ fontSize: "1rem", color: "#333", lineHeight: "1.6" }}>
            {item.a}
          </span>
        </div>
      </div>
    </>
  );
};

export const Faqs = () => {
  const isXs = useMediaQuery("(max-width:900px)");

  return (
    <div style={{ maxWidth: "900px", margin: "0 auto", padding: "2rem 1rem" }}>
      <h1 style={{ textAlign: "center", marginBottom: "2rem", color: "#87462D" }}>
        Frequently Asked Questions
      </h1>

      {faqData.map((section, idx) => (
        <div key={idx} style={{ marginBottom: "2rem" }}>
          <h2 style={{ fontSize: isXs ? "1.3rem" : "1.6rem", color: "#87462D", marginBottom: "1rem", borderBottom: "2px solid #87462D", paddingBottom: "0.5rem" }}>
            {section.category}
          </h2>
          <div style={{ border: "1px solid lightgrey", borderLeft: "none", borderRight: "none" }}>
            {section.items.map((item, itemIdx) => (
              <FaqItem key={itemIdx} item={item} isXs={isXs} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};