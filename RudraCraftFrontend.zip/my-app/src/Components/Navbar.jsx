import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import search from "../Assets/Search.svg";
import login from "../Assets/Login.svg";
import logo from "../Assets/logo.png";
import wishlist from "../Assets/Wishlist.svg";
import cart from "../Assets/Cart.svg";
import Marquee from "react-fast-marquee";
import { useTheme, useMediaQuery } from "@mui/material";
import { RiMenu2Fill } from "react-icons/ri";
import Modal from "react-bootstrap/Modal";
import Box from "@mui/material/Box";
import Input from "@mui/material/Input";
import { MdSearch } from "react-icons/md";
import { FeaturedProduct } from "./FeaturedProduct";
import { NavLink } from "react-router-dom";

export const Navbar = () => {
  const [loading, setLoading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const navigate = useNavigate();
  const theme = useTheme();
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  const [modalShow, setModalShow] = useState(false);
  const [modalShow2, setModalShow2] = useState(false);

  const handleNavigate = () => {
    setLoading(true);
    setTimeout(() => {
      navigate("/blogs");
      setLoading(false);
    }, 1000);
  };

  const activeStyle = { color: "#a55130" };
  const linkStyle = { color: "#89867F", textDecoration: "none" };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    };

    if (menuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [menuOpen]);

  const handleClick = (event, url) => {
    event.preventDefault();
    setLoading(true);
    setTimeout(() => {
      navigate(url);
      setLoading(false);
    }, 3000);
  };

  const overlayStyle = {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "#EEEAE8",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 9999,
    opacity: loading ? 1 : 0,
    pointerEvents: loading ? 'auto' : 'none',
    transition: "opacity 0.5s ease, visibility 0.5s easeout",
  };

  const loaderStyle = {
    border: "6px solid white",
    borderTop: "6px solid #87472D",
    borderRadius: "50%",
    width: "70px",
    height: "70px",
    animation: "spin 2s linear infinite",
  };

  const keyframesStyle = `
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `;

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  function MyVerticallyCenteredModal1(props) {
    return (
      <Modal
        backdrop="static"
        {...props}
        size="xl"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        style={{ height: "95vh", margin: 0 }}
        dialogClassName="custom-modal"
      >
        <Modal.Header closeButton></Modal.Header>
        <Modal.Body style={{ overflowY: "auto", height: "calc(100vh - 100px)" }}>
          <Box
            component="form"
            sx={{ "& > :not(style)": { m: 1 } }}
            noValidate
            autoComplete="off"
            style={{
              display: "flex",
              justifyContent: "center",
              position: "relative",
            }}
          >
            <Input
              style={{ width: "40rem" }}
              placeholder="Search"
              inputProps={{ "aria-label": "search" }}
            />
            <MdSearch style={{ position: "absolute", left: "52.5rem", top: ".8rem" }} />
          </Box>

          <FeaturedProduct />
        </Modal.Body>
      </Modal>
    );
  }

  function MyVerticallyCenteredModal2(props) {
    const headerStyle = {
      backgroundColor: "#e0e0e0",
      borderRadius: "0",
    };

    return (
      <Modal
        backdrop="static"
        {...props}
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton style={headerStyle}></Modal.Header>
        <Modal.Body style={headerStyle}>
          <Box
            component="form"
            sx={{ "& > :not(style)": { m: 1 } }}
            noValidate
            autoComplete="off"
            style={{
              display: "flex",
              justifyContent: "center",
              flexDirection: "column",
              padding: "1rem",
            }}
          >
            <h2 className="text-center">Sign in</h2>

            <input
              style={{
                border: "1px solid lightgrey",
                height: "3rem",
                padding: "1rem",
                marginTop: "1.5rem",
              }}
              placeholder="Email"
              type="email"
              name="email"
              id="email"
            />
            <input
              style={{
                border: "1px solid lightgrey",
                height: "3rem",
                padding: "1rem",
              }}
              placeholder="Password"
              type="password"
              name="password"
              id="password"
            />

            <div className="flex justify-between">
              <a style={{ color: "#87472D" }} className="mt-2" href="/reset">
                Forgot Your Password?
              </a>
              <a style={{ color: "#87472D" }} className="mt-2" href="/signup">
                Signup
              </a>
            </div>

            <button
              style={{
                backgroundColor: "#7A6E54",
                color: "white",
                width: "100%",
                height: "3rem",
                marginTop: "2rem",
                marginBottom: "2rem",
              }}
            >
              Sign in
            </button>
          </Box>
        </Modal.Body>
      </Modal>
    );
  }

  return (
    <nav>
      <div
        style={{
          width: "100%",
          height: "7rem",
          backgroundColor: "#fffff",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: isXs ? "2rem 1.4rem" : "2rem 4rem",
          gap: "1rem",
        }}
      >
        {isXs && (
          <RiMenu2Fill
            style={{
              display: isXs ? "block" : "none",
              cursor: "pointer",
              fontSize: "1.5rem",
              color: "grey",
            }}
            onClick={toggleMenu}
          />
        )}
        <div
          style={{
            display: "flex",
            gap: "1.5rem",
            display: isXs ? "none" : "flex",
          }}
        >
          <button>
            <img
              onClick={() => setModalShow(true)}
              src={search}
              alt="Search"
              width={18}
            />
          </button>
          <button>
            <img
              onClick={() => setModalShow2(true)}
              src={login}
              alt="Login"
              width={18}
            />
          </button>
        </div>

        <MyVerticallyCenteredModal1
          show={modalShow}
          onHide={() => setModalShow(false)}
        />

        <MyVerticallyCenteredModal2
          show={modalShow2}
          onHide={() => setModalShow2(false)}
        />

        <div
          style={{
            fontFamily: "Lora-Medium",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            style={{ display: isXs ? "flex" : "none", justifyContent: "start" }}
          >
            <img style={{ width: isXs ? "80%" : "" }} src={logo} alt="Logo" />
          </div>

          <ul
            ref={menuRef}
            style={{
              display: isXs ? "block" : "flex",
              position: isXs ? "fixed" : "",
              top: isXs ? "0" : "",
              left: isXs ? (menuOpen ? "0" : "-200px") : "",
              bottom: isXs ? "0" : "",
              zIndex: isXs ? "20" : "",
              backgroundColor: isXs ? "white" : "",
              width: isXs ? "200px" : "",
              padding: isXs ? "2rem 2rem" : "",
              lineHeight: "2.8rem",
              boxShadow: isXs ? "6px 2px 20px rgba(0,0,0,0.2)" : "",
              listStyle: "none",
              margin: "0",
              gap: "3rem",
              alignItems: "center",
              justifyContent: "center",
              fontSize: isXs ? ".9rem" : "",
              transition: "left 0.3s ease",
            }}
          >
            <NavLink
              style={({ isActive }) =>
                isActive ? { ...linkStyle, ...activeStyle } : linkStyle
              }
              onClick={(e) => handleClick(e, "/")}
              to="/"
            >
              <li>HOME</li>
            </NavLink>
            <NavLink
              style={({ isActive }) =>
                isActive ? { ...linkStyle, ...activeStyle } : linkStyle
              }
              onClick={(e) => handleClick(e, "/about")}
              to="/about"
            >
              <li>ABOUT</li>
            </NavLink>
            <NavLink
              style={({ isActive }) =>
                isActive ? { ...linkStyle, ...activeStyle } : linkStyle
              }
              onClick={(e) => handleClick(e, "/shop")}
              to="/shop"
            >
              <li>SHOP</li>
            </NavLink>
            <div style={{ display: isXs ? "none" : "" }}>
              <img src={logo} alt="Logo" />
            </div>
            <NavLink
              style={({ isActive }) =>
                isActive ? { ...linkStyle, ...activeStyle } : linkStyle
              }
              onClick={(e) => handleClick(e, "/collections")}
              to="/collections"
            >
              <li>COLLECTIONS</li>
            </NavLink>
            <NavLink
              style={({ isActive }) =>
                isActive ? { ...linkStyle, ...activeStyle } : linkStyle
              }
              onClick={(e) => handleClick(e, "/blogs")}

              to="/blogs"
            >
              <li>BLOG</li>
            </NavLink>
            <NavLink
              style={({ isActive }) =>
                isActive ? { ...linkStyle, ...activeStyle } : linkStyle
              }
              onClick={(e) => handleClick(e, "/contact-us")}

              to="/contact-us"
            >
              <li>CONTACT US</li>
            </NavLink>
            {loading && (
              <div style={overlayStyle}>
                <div style={loaderStyle}></div>
                <style>{keyframesStyle}</style>
              </div>
            )}
          </ul>
        </div>

        <div style={{ display: "flex", gap: "1.5rem" }}>
          <a href="/wishlist">
            <img
              style={{ display: isXs ? "none" : "" }}
              src={wishlist}
              alt="Wishlist"
              width={18}
            />
          </a>
          <img
            style={{ display: isXs ? "" : "none" }}
            src={search}
            alt="Search"
            width={18}
          />
          <a href="/cart">
            <img src={cart} alt="Cart" width={16} />
          </a>
        </div>
      </div>

      <div
        style={{
          width: "100%",
          height: "2.4rem",
          backgroundColor: "#a91e28",
          color: "white",
          display: "flex",
          alignItems: "center",
          fontSize: ".9rem",
        }}
      >
        <Marquee>
          <div style={{ display: "flex", gap: "5rem" }}>
            <span>"Limited Edition Festive Shawls – Now on Sale!"</span>
            <span>"Limited Edition Festive Shawls – Now on Sale!"</span>
            <span>"Limited Edition Festive Shawls – Now on Sale!"</span>
          </div>
        </Marquee>
      </div>
    </nav>
  );
};
