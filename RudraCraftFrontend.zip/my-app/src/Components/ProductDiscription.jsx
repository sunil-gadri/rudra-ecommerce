import React, { useState, useRef, useEffect } from "react";
import { TiHeartFullOutline } from "react-icons/ti";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import { HiOutlineShoppingBag } from "react-icons/hi2";
import { CiDeliveryTruck } from "react-icons/ci";
import { useNavigate } from 'react-router-dom';
import { PiKeyReturn } from "react-icons/pi";
// import Spinner from 'react-bootstrap/Spinner';
// import visa from "../Assets/visaelectron.svg";
// import paypal from "../Assets/paypal.svg";
// import mastercard from "../Assets/mastercard.svg";
import { useTheme, useMediaQuery } from "@mui/material";
import img11 from "../Assets/img-11.jpg";
import img15 from "../Assets/img-15.jpg";
import img12 from "../Assets/img-12.jpg";
import img13 from "../Assets/img-13.jpg";
import img9 from "../Assets/img-9.jpg";
import Box from "@mui/material/Box";
import Rating from "@mui/material/Rating";
import StarIcon from "@mui/icons-material/Star";
import { FaUser } from "react-icons/fa";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
// import { Link } from 'react-router-dom';

function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      backdrop="static"
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Write a Review
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="flex flex-col justify-center">
          <Rating
            sx={{ fontSize: "2.5rem" }}
            name="size-large"
            defaultValue={0}
            size="large"
          />
          <input
            style={{
              width: "48rem",
              padding: "1rem",
              border: "1px solid grey",
              marginTop: "1.4rem",
            }}
            placeholder="Name"
            type="text"
            name=""
            id=""
          />
          <input
            style={{
              width: "48rem",
              padding: "1rem",
              border: "1px solid grey",
              marginTop: "1.4rem",
            }}
            placeholder="Email"
            type="Email"
            name=""
            id=""
          />
          <textarea
            style={{
              border: "1px solid grey",
              width: "48rem",
              height: "10rem",
              marginTop: "1.4rem",
              padding: "1rem",
            }}
            placeholder="Your Review"
            name=""
            id=""
          ></textarea>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button
          style={{ backgroundColor: "#87462D", border: "none", width: "100%" }}
          onClick={props.onHide}
        >
          Submit
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export const ProductDiscription = () => {
  const [isCollection1Expanded, setIsCollection1Expanded] = useState(false);
  const [isCollection2Expanded, setIsCollection2Expanded] = useState(false);
  const [isCollection3Expanded, setIsCollection3Expanded] = useState(false);
  const [modalShow, setModalShow] = React.useState(false);
  const [isPressed, setIsPressed] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [hoverMinus, setHoverMinus] = useState(false);
  const [hoverPlus, setHoverPlus] = useState(false);
  const [hoverAddToBag, setHoverAddToBag] = useState(false);
  const [largeImage, setLargeImage] = useState(img9); // Default large image
  const [selectedImage, setSelectedImage] = useState(img9); // State for selected image
  const [selectedColor, setSelectedColor] = useState("#ef6269"); // Default color
  const navigate = useNavigate();
  const [collection1Height, setCollection1Height] = useState("0px");
  const [collection2Height, setCollection2Height] = useState("0px");
  const [collection3Height, setCollection3Height] = useState("0px");
  const [loading, setLoading] = useState(false);


  const collection1Ref = useRef(null);
  const collection2Ref = useRef(null);
  const collection3Ref = useRef(null);

  const theme = useTheme();
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  useEffect(() => {
    setCollection1Height(
      isCollection1Expanded ? `${collection1Ref.current.scrollHeight}px` : "0px"
    );
  }, [isCollection1Expanded]);

  useEffect(() => {
    setCollection2Height(
      isCollection2Expanded ? `${collection2Ref.current.scrollHeight}px` : "0px"
    );
  }, [isCollection2Expanded]);

  useEffect(() => {
    setCollection3Height(
      isCollection3Expanded ? `${collection3Ref.current.scrollHeight}px` : "0px"
    );
  }, [isCollection3Expanded]);

 
  const handleClick = (event) => {
   
    setLoading(true);
   
    setTimeout(() => {
     
      setLoading(false);
    }, 1000);
   
   setIsPressed(!isPressed);
  };

  const increase = () => {
    setQuantity((prevQuantity) => prevQuantity + 1);
  };
  const handleColorChange = (color) => {
    setSelectedColor(color);
  };

  const decrease = () => {
    setQuantity((prevQuantity) => Math.max(prevQuantity - 1, 1));
  };

  const handleMouseEnterMinus = () => setHoverMinus(true);
  const handleMouseLeaveMinus = () => setHoverMinus(false);
  const handleMouseEnterPlus = () => setHoverPlus(true);
  const handleMouseLeavePlus = () => setHoverPlus(false);
  const handleMouseEnterAddToBag = () => setHoverAddToBag(true);
  const handleMouseLeaveAddToBag = () => setHoverAddToBag(false);

  const handleImageClick = (imageSrc) => {
    setLargeImage(imageSrc);
    setSelectedImage(imageSrc); // Update selected image
  };

  const handleColorButtonClick = (color) => {
    setSelectedColor(color);
  };

  

  const price = 30;
  const value = 3.5;
  const labels = {
    0.5: "Useless",
    1: "Useless+",
    1.5: "Poor",
    2: "Poor+",
    2.5: "Ok",
    3: "Ok+",
    3.5: "Good",
    4: "Good+",
    4.5: "Excellent",
    5: "Excellent+",
  };

  return (
    <>
      <div className="p-4">
        <div
          style={{ gridTemplateColumns: isXs ? "100%" : "" }}
          className="grid grid-cols-2 grid-rows-1"
        >
          <div className="flex gap-2">
            <div
              style={{ width: isXs ? "23.2%" : "13%" }}
              className="flex flex-col gap-2"
            >
              <img
                src={img9}
                alt=""
                onClick={() => handleImageClick(img9)}
                style={{
                  cursor: "pointer",
                  border: selectedImage === img9 ? "1.5px solid black" : "none",
                  backgroundColor: selectedColor,
                }}
              />
              <img
                src={img11}
                alt=""
                onClick={() => handleImageClick(img11)}
                style={{
                  cursor: "pointer",
                  border:
                    selectedImage === img11 ? "1.5px solid black" : "none",
                  backgroundColor: selectedColor,
                }}
              />
              <img
                src={img12}
                alt=""
                onClick={() => handleImageClick(img12)}
                style={{
                  cursor: "pointer",
                  border:
                    selectedImage === img12 ? "1.5px solid black" : "none",
                  backgroundColor: selectedColor,
                }}
              />
              <img
                src={img13}
                alt=""
                onClick={() => handleImageClick(img13)}
                style={{
                  cursor: "pointer",
                  border:
                    selectedImage === img13 ? "1.5px solid black" : "none",
                  backgroundColor: selectedColor,
                }}
              />
            </div>

            <div style={{ width: isXs ? "100%" : "40rem" }}>
              <img src={largeImage} alt="Large display" />
            </div>
          </div>

          <div
            style={{ padding: isXs ? "0" : "", marginTop: isXs ? "2rem" : "0" }}
            className="pl-10 flex flex-col gap-2"
          >
            <div
              style={{
                flexDirection: isXs ? "column" : "",
                // alignItems: isXs ? "start" : "",
              }}
              className="flex items-start justify-between"
            >
              <div className="flex justify-between w-100 ">
                <h3>Shawl Head Wrap</h3>

                <button
                  onClick={handleClick}
                  style={{
                    backgroundColor: isPressed ? "" : "",
                    color: isPressed ? "#ff0000" : "lightgrey",
                    border: "none",
                    borderRadius: "5px",
                    padding: "5px",
                    cursor: "pointer",
                    display: isXs ? "" : "none",
                    alignSelf: "end",
                    fontSize: "24px",
                    transition: "background-color 0.3s ease",
                  }}
                >
                  <TiHeartFullOutline />
                </button>
              </div>

              <div className="flex items-center w-100 justify-end">
                <button
                  onClick={handleClick}
                  style={{
                    backgroundColor: isPressed ? "" : "",
                    color: isPressed ? "#ff0000" : "lightgrey",
                    border: "none",
                    borderRadius: "5px",
                    padding: "5px",
                    cursor: "pointer",
                    display: isXs ? "none" : "flex",
                    alignItems: "center",

                    fontSize: "24px",
                    transition: "background-color 0.3s ease",
                  }}
                >
                  <TiHeartFullOutline />
                </button>

                <span style={{ display: isXs ? "none" : "" }}>
                  Add to Wishlist
                </span>
              </div>

              <p
                style={{
                  fontSize: isXs ? ".8rem" : ".5rem",
                  width: isXs ? "100%" : "",
                  display: isXs ? "" : "none",
                }}
              >
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illum
                ex explicabo ea dolore ut reiciendis officiis doloribus ipsa
                cupiditate! Est voluptatem molestias earum debitis, repellat
                quas nihil exercitationem rem distinctio.
              </p>

              <div
                style={{ gap: isXs ? "" : "" }}
                className="flex items-center justify-between"
              >
                <Box
                  sx={{
                    width: 200,
                    display: isXs ? "flex" : "none",
                  }}
                >
                  <Rating
                    name="text-feedback"
                    value={value}
                    readOnly
                    precision={0.5}
                    emptyIcon={
                      <StarIcon style={{ opacity: 0.55 }} fontSize="inherit" />
                    }
                  />
                </Box>
              </div>
            </div>
            <Box
              sx={{
                width: 200,
                display: isXs ? "none" : "flex",
                alignItems: "center",
              }}
            >
              <Rating
                name="text-feedback"
                value={value}
                readOnly
                precision={0.5}
                emptyIcon={
                  <StarIcon style={{ opacity: 0.55 }} fontSize="inherit" />
                }
              />
            </Box>

            <p
              style={{
                fontSize: isXs ? ".8rem" : ".8rem",
                width: isXs ? "100%" : "",
                display: isXs ? "none" : "",
              }}
            >
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illum ex
              explicabo ea dolore ut reiciendis officiis doloribus ipsa
              cupiditate! Est voluptatem molestias earum debitis, repellat quas
              nihil exercitationem rem distinctio.
            </p>
            <h2>${price * quantity}</h2>
            <div>Color Available:</div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  handleColorChange("#ef6269");
                  handleImageClick(img9); // Optionally set default image
                }}
                style={{
                  width: "1.5rem",
                  height: "1.5rem",
                  backgroundColor: "#ef6269",
                  borderRadius: "50%",
                  border: selectedColor === "#ef6269" ? "1px solid black" : "",
                }}
                type="button"
              ></button>
              <button
                onClick={() => {
                  handleColorChange("peachpuff");
                  handleImageClick(img15); // Optionally set default image
                }}
                style={{
                  width: "1.5rem",
                  height: "1.5rem",
                  backgroundColor: "peachpuff",
                  borderRadius: "50%",
                  border:
                    selectedColor === "peachpuff" ? "1px solid black" : "",
                }}
                type="button"
              ></button>
            </div>
            <div
              style={{
                flexDirection: isXs ? "column" : "",
                gap: isXs ? "2rem" : "",
                alignItems: isXs ? "start" : "",
              }}
              className="flex justify-between items-center mt-3"
            >
              <div
                style={{ display: "flex", alignItems: "center", gap: "1rem" }}
              >
                <button
                  style={{
                    padding: ".1rem 1rem",
                    border: "1px solid lightgrey",
                    fontSize: "1.8rem",
                    color: hoverMinus ? "white" : "black",
                    backgroundColor: hoverMinus ? "#7A6E54" : "transparent",
                    transition: "background-color 0.3s ease",
                  }}
                  onClick={decrease}
                  onMouseEnter={handleMouseEnterMinus}
                  onMouseLeave={handleMouseLeaveMinus}
                >
                  -
                </button>
                <span style={{ fontSize: "1.2rem" }}>{quantity}</span>
                <button
                  style={{
                    padding: ".1rem 1rem",
                    border: "1px solid lightgrey",
                    fontSize: "1.8rem",
                    color: hoverPlus ? "white" : "black",
                    backgroundColor: hoverPlus ? "#7A6E54" : "transparent",
                    transition: "background-color 0.3s ease",
                  }}
                  onClick={increase}
                  onMouseEnter={handleMouseEnterPlus}
                  onMouseLeave={handleMouseLeavePlus}
                >
                  +
                </button>
              </div>
                  <a style={{ width: isXs ? "100%" : "70%",}} href="/cart">
              <button
                className="flex items-center justify-center gap-2"
                style={{
                  border: "1px solid",
                  width: isXs ? "100%" : "100%",
                  height: "3.2rem",
                  backgroundColor: hoverAddToBag ? "#7A6E54" : "transparent",
                  color: hoverAddToBag ? "white" : "black",
                  transition: "background-color 0.3s ease",
                }}
                onMouseEnter={handleMouseEnterAddToBag}
                onMouseLeave={handleMouseLeaveAddToBag}
              >
                <HiOutlineShoppingBag style={{ fontSize: "1.4rem" }} />
                Add to Bag
              </button>
              </a>
            </div>
            <a
          
            href="/checkout"
            style={{
                backgroundColor: "#7A6E54",
                height: "3.2rem",
                marginTop: isXs ? "1rem" : "2rem",
                color: "white",
                width: isXs ? "100%" : "",
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center'
              }}
            >
              Buy Now
            </a>

            
            {loading && (
              <div style={overlayStyle}>
                <div style={loaderStyle}></div>
                <style>{keyframesStyle}</style>{" "}
              </div>
            )}
            <hr style={{ width: isXs ? "100%" : "" }} />
            <div
              style={{
                flexDirection: isXs ? "column" : "",
                alignItems: isXs ? "start" : "",
              }}
              className="flex items-center gap-2"
            >
              <CiDeliveryTruck
                style={{ fontSize: "1.7rem", display: isXs ? "none" : "" }}
              />
              <div
                style={{
                  color: "#87472D",
                  display: "flex",
                  alignItems: "center",
                  gap: ".3rem",
                }}
                className="font-medium text-[1rem]"
              >
                <CiDeliveryTruck
                  style={{ fontSize: "1.7rem", display: isXs ? "" : "none" }}
                />
                Estimated delivery:{" "}
              </div>{" "}
              <span>5-7 Days from order date.</span>
            </div>

            <div
              style={{
                flexDirection: isXs ? "column" : "",
                alignItems: isXs ? "start" : "",
              }}
              className="flex items-center gap-2"
            >
              <PiKeyReturn
                style={{ fontSize: "1.7rem", display: isXs ? "none" : "" }}
              />
              <div
                style={{
                  color: "#87472D",
                  display: "flex",
                  alignItems: "center",
                  gap: ".3rem",
                }}
                className="font-medium text-[1rem]"
              >
                <PiKeyReturn
                  style={{ fontSize: "1.5rem", display: isXs ? "" : "none" }}
                />
                Free Shipping & Returns:{" "}
              </div>{" "}
              <span>On orders above $79</span>
            </div>

            <div
              style={{
                width: isXs ? "100%" : "100%",
                backgroundColor: "#F3F2F0",
                padding: "1.3rem 2rem",
                transition: "height 0.3s ease",
                overflow: "hidden",
              }}
              className="flex flex-col gap-3 mt-8 items-start"
            >
              <div
                onClick={() => setIsCollection1Expanded(!isCollection1Expanded)}
                style={{
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  color: "white",
                  width: "100%",
                }}
              >
                <h6 style={{ fontSize: "1rem", color: "#87462D", margin: "0" }}>
                  Description
                </h6>
                {isCollection1Expanded ? (
                  <FaChevronUp
                    style={{
                      marginLeft: "27rem",
                      fontSize: ".7rem",
                      color: "#87462D",
                    }}
                  />
                ) : (
                  <FaChevronDown
                    style={{
                      marginLeft: isXs ? "8rem" : "27rem",
                      fontSize: ".7rem",
                      color: "#87462D",
                    }}
                  />
                )}
              </div>
            </div>

            <div
              ref={collection1Ref}
              style={{
                height: collection1Height,
                transition: "height 0.6s ease",
                overflow: "hidden",
                marginTop: "1rem",
              }}
            >
              <div className="flex flex-col gap-2">
                <div className="flex gap-3 flex-col items-start text-sm">
                  <div
                    style={{ width: isXs ? "100%" : "100%" }}
                    className="flex flex-col gap-3"
                  >
                    <p>
                      Nam tempus turpis at metus scelerisque placerat nulla
                      deumantos solicitud felis. Pellentesque diam dolor,
                      elementum etos lobortis des mollis ut risus. Sedcus
                      faucibus an sullamcorper mattis drostique des commodo
                      pharetras loremos.Donec pretium egestas sapien et mollis.
                    </p>
                    <h5>Lorem ipsum dolor sit amet</h5>
                    <p>
                      Sonsectetur adipiscing elit, sed do eiusmod tempor
                      incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure
                      dolor in reprehenderit in voluptate velit esse cillum
                      dolore eu fugiat nulla pariatur.
                    </p>
                    <h5>Lorem ipsum dolor sit amet</h5>
                    <p>
                      Sonsectetur adipiscing elit, sed do eiusmod tempor
                      incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure
                      dolor in reprehenderit in voluptate velit esse cillum
                      dolore eu fugiat nulla pariatur.
                    </p>
                    <h5>Lorem ipsum dolor sit amet</h5>
                    <p>
                      Sonsectetur adipiscing elit, sed do eiusmod tempor
                      incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure
                      dolor in reprehenderit in voluptate velit esse cillum
                      dolore eu fugiat nulla pariatur.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div
              style={{
                width: isXs ? "100%" : "100%",
                backgroundColor: "#F3F2F0",
                padding: "1.3rem 2rem",
                transition: "height 0.3s ease",
                overflow: "hidden",
              }}
              className="flex flex-col gap-3 mt-0 items-start"
            >
              <div
                onClick={() => setIsCollection2Expanded(!isCollection2Expanded)}
                style={{
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  color: "white",
                  width: "100%",
                }}
              >
                <h6 style={{ fontSize: "1rem", color: "#87462D", margin: "0" }}>
                  Shipping Information
                </h6>
                {isCollection2Expanded ? (
                  <FaChevronUp
                    style={{
                      marginLeft: "21.5rem",
                      fontSize: ".7rem",
                      color: "#87462D",
                    }}
                  />
                ) : (
                  <FaChevronDown
                    style={{
                      marginLeft: isXs ? "3.5rem" : "22.5rem",
                      fontSize: ".7rem",
                      color: "#87462D",
                    }}
                  />
                )}
              </div>
            </div>

            <div
              ref={collection2Ref}
              style={{
                height: collection2Height,
                transition: "height 0.6s ease",
                overflow: "hidden",
                marginTop: "1rem",
              }}
            >
              <div className="flex flex-col gap-2">
                <div className="flex gap-3 flex-col items-start text-sm">
                  <div className="flex flex-col gap-3">
                    <p>
                      Nam tempus turpis at metus scelerisque placerat nulla
                      deumantos solicitud felis. Pellentesque diam dolor,
                      elementum etos lobortis des mollis ut risus. Sedcus
                      faucibus an sullamcorper mattis drostique des commodo
                      pharetras loremos.Donec pretium egestas sapien et mollis.
                    </p>
                    <h5>Lorem ipsum dolor sit amet</h5>
                    <p>
                      Sonsectetur adipiscing elit, sed do eiusmod tempor
                      incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure
                      dolor in reprehenderit in voluptate velit esse cillum
                      dolore eu fugiat nulla pariatur.
                    </p>
                    <h5>Lorem ipsum dolor sit amet</h5>
                    <p>
                      Sonsectetur adipiscing elit, sed do eiusmod tempor
                      incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure
                      dolor in reprehenderit in voluptate velit esse cillum
                      dolore eu fugiat nulla pariatur.
                    </p>
                    <h5>Lorem ipsum dolor sit amet</h5>
                    <p>
                      Sonsectetur adipiscing elit, sed do eiusmod tempor
                      incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure
                      dolor in reprehenderit in voluptate velit esse cillum
                      dolore eu fugiat nulla pariatur.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div
              style={{
                width: isXs ? "100%" : "100%",
                backgroundColor: "#F3F2F0",
                padding: "1.3rem 2rem",
                transition: "height 0.3s ease",
                overflow: "hidden",
              }}
              className="flex flex-col gap-3 mt-0 items-start"
            >
              <div
                onClick={() => setIsCollection3Expanded(!isCollection3Expanded)}
                style={{
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  color: "white",
                  width: "100%",
                }}
              >
                <h6 style={{ fontSize: "1rem", color: "#87462D", margin: "0" }}>
                  Reviews
                </h6>
                {isCollection3Expanded ? (
                  <FaChevronUp
                    style={{
                      marginLeft: isXs ? "9.8rem" : "28.9rem",
                      fontSize: ".7rem",
                      color: "#87462D",
                    }}
                  />
                ) : (
                  <FaChevronDown
                    style={{
                      marginLeft: isXs ? "9.8rem" : "28.9rem",
                      fontSize: ".7rem",
                      color: "#87462D",
                    }}
                  />
                )}
              </div>
            </div>

            <div
              ref={collection3Ref}
              style={{
                height: collection3Height,
                transition: "height 0.6s ease",
                overflow: "hidden",
                marginTop: "1rem",
              }}
            >
              <div className="flex flex-col gap-2">
                <div className="flex gap-3 flex-col items-start text-sm">
                  <div className="flex items-center gap-3">
                    <div
                      style={{
                        backgroundColor: "lightgrey",
                        padding: ".6rem",
                        borderRadius: "5px",
                      }}
                    >
                      {" "}
                      <FaUser style={{ fontSize: "1.5rem", fill: "white" }} />
                    </div>
                    <div>
                      <div>
                        <h6>John Dikkar</h6>
                      </div>
                      <Rating
                        name="text-feedback"
                        value={value}
                        readOnly
                        size="small"
                        precision={1}
                        emptyIcon={
                          <StarIcon
                            style={{ opacity: 0.55 }}
                            fontSize="inherit"
                          />
                        }
                      />
                    </div>
                  </div>
                  <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Quo illo beatae doloremque repellendus dolorem ab accusamus
                    alias fugit, optio nihil, dicta omnis magnam iusto aperiam
                    deleniti doloribus voluptatem eum architecto.
                  </p>
                </div>

                <div className="flex gap-3 flex-col items-start text-sm">
                  <div className="flex items-center gap-3">
                    <div
                      style={{
                        backgroundColor: "lightgrey",
                        padding: ".6rem",
                        borderRadius: "5px",
                      }}
                    >
                      {" "}
                      <FaUser style={{ fontSize: "1.5rem", fill: "white" }} />
                    </div>
                    <div>
                      <div>
                        <h6>John Dikkar</h6>
                      </div>
                      <Rating
                        name="text-feedback"
                        value={value}
                        readOnly
                        size="small"
                        precision={1}
                        emptyIcon={
                          <StarIcon
                            style={{ opacity: 0.55 }}
                            fontSize="inherit"
                          />
                        }
                      />
                    </div>
                  </div>
                  <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Quo illo beatae doloremque repellendus dolorem ab accusamus
                    alias fugit, optio nihil, dicta omnis magnam iusto aperiam
                    deleniti doloribus voluptatem eum architecto.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setModalShow(true)}
                className="flex items-center justify-center"
                style={{
                  backgroundColor: "#FAAF00",
                  width: "100%",
                  height: "3rem",
                  marginTop: "4rem",
                }}
              >
                <h6 className="m-0"> Write a Review</h6>
              </button>
              <MyVerticallyCenteredModal
                show={modalShow}
                onHide={() => setModalShow(false)}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

const overlayStyle = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100%",
  height: "100%",
  backgroundColor: "rgba(0, 0, 0, 0.6)",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  zIndex: 9999,
};

const loaderStyle = {
  border: "6px solid #f3f3f3",
  borderTop: "6px solid #3498db",
  borderRadius: "50%",
  width: "70px",
  height: "70px",
  animation: "spin 1s linear infinite",
};

const keyframesStyle = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;