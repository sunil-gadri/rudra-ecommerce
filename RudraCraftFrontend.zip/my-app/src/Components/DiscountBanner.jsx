import React from "react";
import { useTheme, useMediaQuery } from "@mui/material";

export const DiscountBanner = () => {
  const theme = useTheme();
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  return (
    <>

    </>
  );
};
