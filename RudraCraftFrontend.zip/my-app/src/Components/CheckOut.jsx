import { IoCardOutline } from "react-icons/io5";
import React, { useState } from "react";
import img9 from "../Assets/img-9.jpg";
import { useTheme, useMediaQuery } from "@mui/material";

export const CheckOut = () => {
  const countries = [
    { value: "AU", label: "Australia" },
    { value: "AT", label: "Austria" },
    { value: "BE", label: "Belgium" },
    { value: "CA", label: "Canada" },
    { value: "CZ", label: "Czechia" },
    { value: "DK", label: "Denmark" },
    { value: "FI", label: "Finland" },
    { value: "FR", label: "France" },
    { value: "DE", label: "Germany" },
    { value: "HK", label: "Hong Kong SAR" },
    { value: "IN", label: "India" },
    { value: "IE", label: "Ireland" },
    { value: "IL", label: "Israel" },
    { value: "IT", label: "Italy" },
    { value: "JP", label: "Japan" },
    { value: "MY", label: "Malaysia" },
    { value: "NL", label: "Netherlands" },
    { value: "NZ", label: "New Zealand" },
    { value: "NO", label: "Norway" },
    { value: "PL", label: "Poland" },
    { value: "PT", label: "Portugal" },
    { value: "SG", label: "Singapore" },
    { value: "KR", label: "South Korea" },
    { value: "ES", label: "Spain" },
    { value: "SE", label: "Sweden" },
    { value: "CH", label: "Switzerland" },
    { value: "AE", label: "United Arab Emirates" },
    { value: "GB", label: "United Kingdom" },
    { value: "US", label: "United States" },
  ];

  const [selectedCountry, setSelectedCountry] = useState("");

  const handleChange = (event) => {
    setSelectedCountry(event.target.value);
  };

  const theme = useTheme();
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");
  return (
    <>
      <div style={{gridTemplateColumns: isXs ? "1fr" : ''}} className="grid grid-cols-2 mt-10">
        <div style={{padding: isXs ? "2rem" : '' }} className="pt-10 pl-32 pr-10 pb-4 flex flex-col gap-8">
          <div className=" flex flex-col gap-2">
            <div className="flex justify-between">
            <h6>Contact</h6>
            <a style={{ color: '#87472D'}} href="/signin">Log in</a> 
            </div>
            <input
              style={{
                width: "100%",
                padding: ".7rem",
                fontSize: ".9rem",
                border: "1px solid lightgrey",
              }}
              placeholder="Email or Phone Number"
              type="Email"
              name=""
              id=""
            />
            
            <div className="flex gap-2">
              <input style={{cursor: 'pointer'}}  type="checkbox" name="" id="Email me with news and offers" />
              <label style={{ fontSize: ".9rem",cursor: 'pointer' }} htmlFor="Email me with news and offers">
                Email me with news and offers
              </label>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <div className=" flex flex-col gap-2">
              <h6>Delivery</h6>
              <select
                name="countryCode"
                id="Select0"
                required
                autoComplete="shipping country"
                style={{
                  border: "1px solid lightgrey",
                  padding: ".7rem",
                  fontSize: ".9rem",
                }}
                value={selectedCountry}
                onChange={handleChange}
              >
                <option value="">Select a country</option>
                {countries.map((country) => (
                  <option key={country.value} value={country.value}>
                    {country.label}
                  </option>
                ))}
              </select>

              <input
                className="mt-2"
                style={{
                  width: "100%",
                  padding: ".7rem",
                  fontSize: ".9rem",
                  border: "1px solid lightgrey",
                }}
                placeholder="Address"
                type="text"
                name=""
                id=""
              />

              <input
                className="mt-2"
                style={{
                  width: "100%",
                  fontSize: ".9rem",
                  padding: ".7rem",
                  border: "1px solid lightgrey",
                }}
                placeholder="Appartment, Suite, etc (Optional)"
                type="text"
                name=""
                id=""
              />

              <div style={{flexDirection:  isXs ? "column" : ''}} className="flex gap-2">
                <select
                  name="countryCode"
                  id="Select0"
                  required
                  autoComplete="shipping country"
                  style={{
                    border: "1px solid lightgrey",
                    padding: ".8rem",
                    fontSize: ".9rem",
                    height: "3rem",
                    width: "19rem",
                    fontSize: ".9rem",
                    marginTop: ".5rem",
                  }}
                  value={selectedCountry}
                  onChange={handleChange}
                >
                  <option value=""> City</option>
                  {countries.map((country) => (
                    <option key={country.value} value={country.value}>
                      {country.label}
                    </option>
                  ))}
                </select>

                <select
                  name="countryCode"
                  id="Select0"
                  required
                  autoComplete="shipping country"
                  style={{
                    border: "1px solid lightgrey",
                    padding: ".8rem",
                    height: "3rem",
                    marginTop: ".5rem",
                    fontSize: ".9rem",
                  }}
                  value={selectedCountry}
                  onChange={handleChange}
                >
                  <option value="">State</option>
                  {countries.map((country) => (
                    <option key={country.value} value={country.value}>
                      {country.label}
                    </option>
                  ))}
                </select>

                <input
                  className="mt-2"
                  style={{
                    width: "100%",
                    fontSize: ".9rem",
                    padding: ".7rem",
                    border: "1px solid lightgrey",
                  }}
                  placeholder="Pincode"
                  type="text"
                  name=""
                  id=""
                />
              </div>
            </div>

            <div className="flex gap-2">
              <input style={{cursor: 'pointer'}}  type="checkbox" name="" id=" Save this information for next time" />
              <label style={{ fontSize: ".9rem", cursor: 'pointer' }} htmlFor=" Save this information for next time">
                Save this information for next time
              </label>
            </div>
          </div>
          <div className=" flex flex-col gap-2">
            <h6>Shipping method</h6>
            <div
              className="flex items-center pl-4"
              style={{
                width: "100%",
                height: "3rem",
                backgroundColor: "#F5F5F5",
                color: "grey",
                fontSize: ".9rem",
              }}
            >
              Enter your shipping address to view available shipping methods.
            </div>
          </div>

          <div className=" flex flex-col gap-1">
            <h5>Payment</h5>
            <p>All transactions are secure and encrypted.</p>

            <div
              className="flex flex-col p-4 gap-2"
              style={{
                width: "100%",
                height: "17rem",
                backgroundColor: "#F5F5F5",

                fontSize: ".9rem",
              }}
            >
              <div className="flex justify-between w-100">
                {" "}
                <h6>Credit Card</h6>
                <div>
                  <IoCardOutline style={{ fontSize: "1.5rem" }} />
                </div>
              </div>

              <input
                className="mt-2"
                style={{
                  width: "100%",
                  padding: ".7rem",
                  border: "1px solid lightgrey",
                }}
                placeholder="Card Number"
                type="number"
                name=""
                id=""
              />

              <div className="flex gap-3">
                <input
                  className="mt-2"
                  style={{
                    width: "100%",
                    padding: ".7rem",
                    border: "1px solid lightgrey",
                  }}
                  placeholder="Expiration date (MM / YY)"
                  type="number"
                  name=""
                  id=""
                />
                <input
                  className="mt-2"
                  style={{
                    width: "100%",
                    padding: ".7rem",
                    border: "1px solid lightgrey",
                  }}
                  placeholder="Security Code"
                  type="number"
                  name=""
                  id=""
                />
              </div>
              <input
                className="mt-2"
                style={{
                  width: "100%",
                  padding: ".7rem",
                  border: "1px solid lightgrey",
                }}
                placeholder="Name On Card"
                type="text"
                name=""
                id=""
              />
            </div>

            <button
              style={{
                width: "100%",
                height: "3rem",
                backgroundColor: "#7A6E54",
                marginTop: "1.5rem",
                color: "white",
              }}
              type="button"
            >
              Pay Now
            </button>
          </div>
          <div>
            <hr />
            <p className="text-xs">All rights reserved Rudra Craft</p>
          </div>
        </div>

        <div style={{ backgroundColor: "#F5F5F5", padding: "3rem" }}>
          <div
            style={{
              position: "sticky",
              top: "60px",
              backgroundColor: "#F5F5F5",
              zIndex: 1000,
              display: 'flex',
              flexDirection: 'column',
              gap: '3rem'
            }}
          >


            <div className="flex items-center gap-3">
              <div className="flex items-center gap-3">
                <div
                  style={{
                    width: isXs ? "30%" : "10%",
                    border: "1px solid lightgrey",
                    borderRadius: "5px",
                    padding: ".5rem",
                  }}
                >
                  <img src={img9} alt="img9" />
                </div>
                <div className="flex flex-col">
                  <h5>Shawl Head Wrap</h5>
                  <span className="text-xs">Almond / L / Chiffon</span>
                </div>
              </div>
              <span>$30</span>
            </div>
                    <div className="flex flex-col gap-3">

                      <div className="flex justify-between ">
                        <span>Subtotal</span>
                        <span>$30</span>
                      </div>

                      <div className="flex justify-between">
                        <span>Shipping</span>
                        <span>$10</span>
                      </div>
                      <hr />
                      <div style={{color: '#87472D'}} className="flex justify-between">
                        <h5>Total</h5>
                        <h5>$70</h5>
                      </div>
                      
                    </div>
          </div>
        </div>
      </div>
    </>
  );
};
