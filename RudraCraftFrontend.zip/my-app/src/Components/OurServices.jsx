import React from "react";
import delivery from  '../Assets/24.svg'
import shipping from  '../Assets/shipping.svg'
import timely from  '../Assets/support.svg'
import { useTheme, useMediaQuery } from '@mui/material';
import securedpayment from '../Assets/secured payment.svg'
import safecheckout from '../Assets/safe checkout.svg'

export const OurServices = () => {
  const theme = useTheme();
  const isXs = useMediaQuery('(min-width:0px) and (max-width:900px)');


  return (
    <div style={{gridTemplateColumns: isXs ? '1fr' : ''}} className="grid grid-cols-5 p-11 gap-16 items-center ">
      <div data-aos="fade-up" style={{display: "flex" , flexDirection: "column" , justifyContent: "center"  , alignItems: "center" }}>
        <div><img src={timely} alt="" width={55} /></div>
        <p style={{fontSize: "1.3rem" , fontFamily: "lora" , marginTop: "1rem"}}>Timely Delivery</p>
        <p style={{fontFamily: "lora" , textAlign: "center" , fontSize: ".9rem"}}>
        Experience prompt delivery, ensuring your shawls and stoles arrive on time, every time.
        </p>

      </div>

      <div data-aos="fade-up" style={{display: "flex" , flexDirection: "column" , justifyContent: "center"  , alignItems: "center" }}>
        <div><img src={shipping} alt="" width={60}  /></div>
        <p style={{fontSize: "1.3rem" , fontFamily: "lora" , marginTop: "1rem"}}>Free Shipping</p>
        <p style={{fontFamily: "lora" , textAlign: "center", textAlignLast: "center"  , fontSize: ".9rem"}}>
        Enjoy free shipping across India for a seamless shopping experience.
        </p>

      </div>

      <div data-aos="fade-up" style={{display: "flex" , flexDirection: "column" , justifyContent: "center"  , alignItems: "center" }}>
        <div><img src={delivery} alt="" width={50} /></div>
        <p style={{fontSize: "1.3rem" , fontFamily: "lora" , marginTop: "1rem"}}>24/7 Support</p>
        <p style={{fontFamily: "lora" , textAlign: "center", textAlignLast: "center"  , fontSize: ".9rem"}}>
        Our customer support is available 24/7 to help with any inquiries or issues.
        </p>

      </div>

      <div data-aos="fade-up" style={{display: "flex" , flexDirection: "column" , justifyContent: "center"  , alignItems: "center" }}>
        <div><img src={securedpayment} alt="" width={50}  /></div>
        <p style={{fontSize: "1.3rem" , fontFamily: "lora" , marginTop: "1rem"}}>Secured Payment</p>
        <p style={{fontFamily: "lora" , textAlign: "center", textAlignLast: "center"  , fontSize: ".9rem"}}>
        Shop securely with our multiple safe payment options protecting your data.
        </p>

      </div>

      <div data-aos="fade-up" style={{display: "flex" , flexDirection: "column" , justifyContent: "center"  , alignItems: "center" }}>
        <div><img src={safecheckout} alt="" width={50}  /></div>
        <p style={{fontSize: "1.3rem" , fontFamily: "lora" , marginTop: "1rem"}}>Safe Check Out</p>
        <p style={{fontFamily: "lora" , textAlign: "center", textAlignLast: "center"  , fontSize: ".9rem"}}>
        Our encrypted checkout process ensures your information remains secure.
        </p>

      </div> 
    </div>
  );
};
