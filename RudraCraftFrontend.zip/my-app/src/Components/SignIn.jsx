import React from 'react'
import {useMediaQuery } from "@mui/material";

export const SignIn = () => {
    const inputStyle = {
        border: '1px solid lightgrey',
        height: '3rem',
        padding: '1rem',
        width: '100%',
        boxSizing: 'border-box',
      };

      const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");
  return (
    <>
    <div style={{backgroundColor: '#EEEAE8',  padding:  isXs ? "1rem" : ""}} className="flex justify-center p-20">
        <div
          style={{
            backgroundColor: "#D6CBC6",
            width: isXs ? "100%" : "50%",
            height: "50%",
            padding:  isXs ? "2rem" : "3rem"
          }}
          className="flex justify-center flex-col gap-3"
        >
          <h1 className="text-center">Sign in</h1>
          <div className="flex gap-2 justify-center">
            
          </div>
          
         <div>
      <input
        style={inputStyle}
        placeholder="Email"
        type="email"
        name="email"
        id="email"
      />
    </div>
          <div >
      <input
        style={inputStyle}
        placeholder="Password"
        type="password"
        name="password"
        id="password"
      />
    </div>
      <a href="#"><button style={{backgroundColor: '#7A6E54', color: 'white', width: '100%', height: '3rem' , marginTop: '2rem'}}>Sign in</button></a>
      <hr />
      <div className="flex justify-between">
        <a style={{color: '#87472D', fontWeight: 'bold'}} className=" mt-2" href="/reset">Forgot Your Password?</a>
        <a style={{color: '#87472D', fontWeight: 'bold'}} className=" mt-2" href="/signup">Signup</a>
      </div>
          
        </div>
        
      </div>
    </>
  )
}
