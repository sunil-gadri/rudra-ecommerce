import React from "react";
import { Navbar } from "./Navbar";

import { BackToTop } from "./BackToTop";
import Footer from "./Footer";

const layout = ({ children }) => {
  return (
    <div >
      <Navbar />
      <BackToTop />
      <div className="main-content">{children}</div>

      <Footer />
    </div>
  );
};

export default layout;