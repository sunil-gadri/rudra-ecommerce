import React from "react";
import img9 from "../Assets/img-9.jpg";
import img11 from "../Assets/img-11.jpg";
import img12 from "../Assets/img-12.jpg";
import img13 from "../Assets/img-13.jpg";
import img14 from "../Assets/img-14.jpg";
import img15 from "../Assets/img-15.jpg";
import img16 from "../Assets/img-16.jpg";
import img17 from "../Assets/img-17.jpg";
import { useTheme, useMediaQuery } from '@mui/material';


export const CollectionsContainer = () => {

    
  const theme = useTheme();
  const isXs = useMediaQuery('(min-width:0px) and (max-width:900px)');
  return (
    <>
      <div style={{display: 'grid', gridTemplateColumns: isXs ? '1fr' : ''}} className="grid grid-cols-4 grid-rows-2 gap-4 mt-16 p-4">
        <div style={{ position: "relative" }}>
          <img src={img9} alt="" />
         <a href="/shop">
          <div
            style={{
              width: "10rem",
              height: "2.8rem",
              backgroundColor: "rgb(255 , 255, 255, .8)",
              position: "absolute",
              top: "70%",
              left: "50%",
              translate: "-50% -50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: 'black'
            }}
          >
            New Release
          </div>
          </a>

        </div>
        <div style={{ position: "relative" }}>
          <img src={img11} alt="" />
          <a href="/shop">
          <div
            style={{
              width: "10rem",
              height: "2.8rem",
              backgroundColor: "rgb(255 , 255, 255, .8)",
              position: "absolute",
              top: "70%",
              left: "50%",
              translate: "-50% -50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: 'black'
            }}
          >
           Womens Mufflers
          </div>
          </a>
        </div>
        <div style={{ position: "relative" }}>
          <img src={img12} alt="" />
          <a href="/shop">
          <div
            style={{
              width: "12rem",
              height: "2.8rem",
              backgroundColor: "rgb(255 , 255, 255, .8)",
              position: "absolute",
              top: "70%",
              left: "50%",
              translate: "-50% -50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: 'black'
            }}
          >
           Tres Chic Collections
          </div>
          </a>
        </div>

        <div style={{ position: "relative" }}>
          <img src={img13} alt="" />
          <a href="/shop">
          <div
            style={{
              width: "10rem",
              height: "2.8rem",
              backgroundColor: "rgb(255 , 255, 255, .8)",
              position: "absolute",
              top: "70%",
              left: "50%",
              translate: "-50% -50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: 'black'
            }}
          >
           Women Shawls
          </div>
          </a>
        </div>
        <div style={{ position: "relative" }}>
          <img src={img14} alt="" />
          <a href="/shop">
          <div
            style={{
              width: "10rem",
              height: "2.8rem",
              backgroundColor: "rgb(255 , 255, 255, .8)",
              position: "absolute",
              top: "70%",
              left: "50%",
              translate: "-50% -50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: 'black'
            }}
          >
           Women Scarf
          </div>
          </a>
        </div>
        <div style={{ position: "relative" }}>
          <img src={img15} alt="" />
          <a href="/shop">
          <div
            style={{
              width: "10rem",
              height: "2.8rem",
              backgroundColor: "rgb(255 , 255, 255, .8)",
              position: "absolute",
              top: "70%",
              left: "50%",
              translate: "-50% -50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: 'black'
            }}
          >
           Women Stoles
          </div>
          </a>
        </div>
        <div style={{ position: "relative" }}>
          <img src={img16} alt="" />
          <a href="/shop">
          <div
            style={{
              width: "10rem",
              height: "2.8rem",
              backgroundColor: "rgb(255 , 255, 255, .8)",
              position: "absolute",
              top: "70%",
              left: "50%",
              translate: "-50% -50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: 'black'
            }}
          >
           Heritage Collection
          </div>
          </a>
        </div>
        <div style={{ position: "relative" }}>
          <img src={img17} alt="" />
          <a href="/shop">
          <div
            style={{
              width: "10rem",
              height: "2.8rem",
              backgroundColor: "rgb(255 , 255, 255, .8)",
              position: "absolute",
              top: "70%",
              left: "50%",
              translate: "-50% -50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: 'black'
            }}
          >
           Festival Shawls
          </div>
          </a>
        </div>
      </div>
    </>
  );
};
