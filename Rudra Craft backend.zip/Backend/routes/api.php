<?php

use Illuminate\Support\Facades\Route;

// Import all your controllers
use App\Http\Controllers\Api\CustomerAuthController;
use App\Http\Controllers\Api\AdminAuthController;
use App\Http\Controllers\Api\CustomerProfileController;
use App\Http\Controllers\Api\WishlistController;
use App\Http\Controllers\Api\ParentCategoryController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\ManufacturerController;
use App\Http\Controllers\Api\BrandController;
use App\Http\Controllers\Api\ProductSizeController;
use App\Http\Controllers\Api\ProductPatternController;
use App\Http\Controllers\Api\ProductColorController;
use App\Http\Controllers\Api\GstController;
use App\Http\Controllers\Api\SpecificationController;
use App\Http\Controllers\Api\SpecificationHeadingController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\ProductDescriptionController;
use App\Http\Controllers\Api\SliderController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\AddressController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\OfferController;
use App\Http\Controllers\Api\InvoiceController;
use App\Http\Controllers\Api\CouponController;
use App\Http\Controllers\Api\HomepageController;

// ────────────────────────────────────────────────
//  PUBLIC ROUTES — No authentication needed
// ────────────────────────────────────────────────

Route::prefix('products')->group(function () {
    Route::get('latest',           [HomepageController::class, 'latestProducts']);
    Route::get('by-category/{category_id}', [HomepageController::class, 'productsByCategory']);
    Route::get('latest_all',       [HomepageController::class, 'latestProductsAll']);
    Route::get('best_selling_all', [HomepageController::class, 'bestSellingAll']);
    Route::get('best_selling',     [HomepageController::class, 'bestSelling']);
    Route::post('by_discount',     [HomepageController::class, 'productsByDiscount']);
    Route::post('by_upto_discount',[HomepageController::class, 'productsByUptoDiscount']);
    Route::post('by_category_price',[HomepageController::class, 'productsByCategoryAndPrice']);
});

Route::get('homepage', [HomepageController::class, 'homepage']);


// Products – public read operations
Route::get('products',               [ProductController::class, 'index']);
Route::get('products/{product}',     [ProductController::class, 'show']);
Route::get('products/search',        [ProductController::class, 'search']);

// Product helpers
Route::get('product/count',          [ProductController::class, 'count']);
Route::get('product_title',          [ProductController::class, 'titles']);
Route::get('product-description/product/{product_id}', [ProductDescriptionController::class, 'showByProduct']);

Route::get('categories',             [CategoryController::class, 'index']);
Route::get('categories/{category}',  [CategoryController::class, 'show']);

// Sliders public
Route::get('slider/key/{key}',       [SliderController::class, 'getByKey']);

// Customer public auth
Route::post('customer/signup',       [CustomerAuthController::class, 'register']);
Route::post('customer/login',        [CustomerAuthController::class, 'login']);

// ────────────────────────────────────────────────
//  CUSTOMER PROTECTED ROUTES (require auth:api)
// ────────────────────────────────────────────────
Route::middleware('auth:api')->group(function () {

    // Auth
    Route::post('customer/logout',   [CustomerAuthController::class, 'logout']);

    // Profile
    Route::get('customer/profile', function () {
        return response()->json([
            'success' => true,
            'user' => auth('api')->user(),
        ]);
    });

    Route::get('customer-profile/{id}', [CustomerProfileController::class, 'show']);
    Route::put('customer-profile/{id}', [CustomerProfileController::class, 'updateProfile']);  


    // Wishlist
    Route::post('wishlist/{customer_id}',      [WishlistController::class, 'addToWishlist']);
    Route::get('wishlist/{customer_id}',       [WishlistController::class, 'getWishlist']);
    Route::delete('wishlist/{customer_id}/{product_id}', [WishlistController::class, 'removeFromWishlist']);

    // Cart
    Route::post('cart/{customer_id}',          [CartController::class, 'addToCart']);
    Route::post('cart/{customer_id}/increment',[CartController::class, 'incrementQuantity']);
    Route::post('cart/{customer_id}/decrement',[CartController::class, 'decrementQuantity']);
    Route::get('cart/{customer_id}',           [CartController::class, 'getCart']);
    Route::post('cart/apply-coupon',           [CartController::class, 'applyCoupon']);
    Route::post('cart/remove-coupon',          [CartController::class, 'removeCoupon']);
    Route::delete('cart/{customer_id}/product/{product_id}', [CartController::class, 'removeProduct']);

    // Address
    Route::post('address/{customer_id}',       [AddressController::class, 'addAddress']);
    Route::get('address/{customer_id}',        [AddressController::class, 'getAddresses']);
    Route::put('address/{customer_id}/{address_id}', [AddressController::class, 'updateAddress']);
    Route::delete('address/{customer_id}/{address_id}', [AddressController::class, 'deleteAddress']);

    // Orders – customer can create and view their orders
    Route::post('orders',                      [OrderController::class, 'createOrder']);
    Route::get('customers/{customer_id}/orders', [OrderController::class, 'getCustomerOrders']);
    Route::get('orders/{order_id}', [OrderController::class, 'getOrder']);



    // Payment verification – public path as per your test
    Route::post('verify_payment',              [OrderController::class, 'verifyPayment']);
});

// ────────────────────────────────────────────────
//  ADMIN PROTECTED ROUTES (require auth:admin)
// ────────────────────────────────────────────────
Route::post('admin/login', [AdminAuthController::class, 'login']);

Route::middleware('auth:admin')->group(function () {

    Route::post('admin/logout', [AdminAuthController::class, 'logout']);

    // Admin product CRUD
    Route::post('products',                    [ProductController::class, 'store']);
    Route::put('products/{product}',           [ProductController::class, 'update']);
    Route::delete('products/{product}',        [ProductController::class, 'destroy']);

    Route::post('categories',        [CategoryController::class, 'store']);
    Route::put('categories/{category}', [CategoryController::class, 'update']);
    Route::delete('categories/{category}', [CategoryController::class, 'destroy']);
    Route::get('category/count',     [CategoryController::class, 'count']);

    // Other admin resources (full CRUD)
    Route::get('parent-categories',            [ParentCategoryController::class, 'index']);
    Route::post('parent-categories',           [ParentCategoryController::class, 'store']);
    Route::get('parent-categories/{id}',       [ParentCategoryController::class, 'show']);
    Route::put('parent-categories/{id}',       [ParentCategoryController::class, 'update']);
    Route::delete('parent-categories/{id}',    [ParentCategoryController::class, 'destroy']);   

    Route::get('manufacturer',                 [ManufacturerController::class, 'index']);
    Route::post('manufacturer',                [ManufacturerController::class, 'store']);
    Route::get('manufacturer/{id}',            [ManufacturerController::class, 'show']);
    Route::put('manufacturer/{id}',            [ManufacturerController::class, 'update']);
    Route::delete('manufacturer/{id}',         [ManufacturerController::class, 'destroy']);

    Route::get('brands',                       [BrandController::class, 'index']);
    Route::post('brands',                      [BrandController::class, 'store']);
    Route::get('brands/{id}',                  [BrandController::class, 'show']);
    Route::put('brands/{id}',                  [BrandController::class, 'update']);
    Route::delete('brands/{id}',               [BrandController::class, 'destroy']);

    Route::get('product_sizes',                [ProductSizeController::class, 'index']);
    Route::post('product_sizes',               [ProductSizeController::class, 'store']);
    Route::get('product_sizes/{id}',           [ProductSizeController::class, 'show']);
    Route::put('product_sizes/{id}',           [ProductSizeController::class, 'update']);
    Route::delete('product_sizes/{id}',        [ProductSizeController::class, 'destroy']);

    Route::get('product_pattern',              [ProductPatternController::class, 'index']);
    Route::post('product_pattern',             [ProductPatternController::class, 'store']);
    Route::get('product_pattern/{id}',         [ProductPatternController::class, 'show']);
    Route::put('product_pattern/{id}',         [ProductPatternController::class, 'update']);
    Route::delete('product_pattern/{id}',      [ProductPatternController::class, 'destroy']);

    Route::get('product_colors',               [ProductColorController::class, 'index']);
    Route::post('product_colors',              [ProductColorController::class, 'store']);
    Route::get('product_colors/{id}',          [ProductColorController::class, 'show']);
    Route::put('product_colors/{id}',          [ProductColorController::class, 'update']);
    Route::delete('product_colors/{id}',       [ProductColorController::class, 'destroy']);

    Route::get('gst',                          [GstController::class, 'index']);
    Route::post('gst',                         [GstController::class, 'store']);
    Route::get('gst/{id}',                     [GstController::class, 'show']);
    Route::put('gst/{id}',                     [GstController::class, 'update']);
    Route::delete('gst/{id}',                  [GstController::class, 'destroy']);

    // Specifications
    Route::get('specification/{heading_id}',   [SpecificationController::class, 'show']);
    Route::get('specification',                [SpecificationController::class, 'index']);
    Route::post('specification',               [SpecificationController::class, 'store']);
    Route::get('specification/{id}',           [SpecificationController::class, 'show']);
    Route::put('specification/{id}',           [SpecificationController::class, 'update']);
    Route::delete('specification/{id}',        [SpecificationController::class, 'destroy']);

    Route::get('specification_heading',        [SpecificationHeadingController::class, 'index']);
    Route::post('specification_heading',       [SpecificationHeadingController::class, 'store']);
    Route::get('specification_heading/{id}',   [SpecificationHeadingController::class, 'show']);
    Route::put('specification_heading/{id}',   [SpecificationHeadingController::class, 'update']);
    Route::delete('specification_heading/{id}',[SpecificationHeadingController::class, 'destroy']);

    // Product description
    Route::get('product-description',          [ProductDescriptionController::class, 'index']);
    Route::post('product-description',         [ProductDescriptionController::class, 'store']);
    Route::get('product-description/{id}',     [ProductDescriptionController::class, 'show']);
    Route::put('product-description/{id}',     [ProductDescriptionController::class, 'update']);
    Route::delete('product-description/{id}',  [ProductDescriptionController::class, 'destroy']);

    // Slider
    Route::get('slider',                       [SliderController::class, 'index']);
    Route::post('slider',                      [SliderController::class, 'store']);
    Route::get('slider/{id}',                  [SliderController::class, 'show']);
    Route::put('slider/{id}',                  [SliderController::class, 'update']);
    Route::delete('slider/{id}',               [SliderController::class, 'destroy']);

    // Offers API
    Route::prefix('offers')->group(function () {
    Route::post('/',        [OfferController::class, 'createOffer']);
    Route::get('/',         [OfferController::class, 'getOffers']);
    Route::get('/{offer_id}', [OfferController::class, 'getOfferById']);
    Route::put('/{offer_id}', [OfferController::class, 'updateOffer']);
    Route::delete('/{offer_id}', [OfferController::class, 'deleteOffer']);
    Route::get('/{key}',    [OfferController::class, 'getOfferByKey']);
    });

    Route::prefix('invoices')->group(function () {
    Route::get('/', [InvoiceController::class, 'index']);
    Route::get('/{invoice_id}', [InvoiceController::class, 'show']);
    Route::get('/{invoice_id}/preview', [InvoiceController::class, 'preview']);
    Route::get('/{invoice_id}/download', [InvoiceController::class, 'download']);
    });

    Route::post('coupon/', [CouponController::class, 'store']);          
    Route::get('coupon/', [CouponController::class, 'index']);           
    Route::get('coupon/{id}', [CouponController::class, 'show']);        
    Route::put('coupon/{id}', [CouponController::class, 'update']);      
    Route::delete('coupon/{id}', [CouponController::class, 'destroy']);  

    Route::post('/available', [CouponController::class, 'availableCoupons']);

    Route::get('orders/{order_id}/admin', [OrderController::class, 'getOrder']);
    Route::get('/orders', [OrderController::class, 'getAllOrders']);
    Route::put('orders/{order_id}/status', [OrderController::class, 'updateStatus']);


    Route::get('customer-profile', [CustomerProfileController::class, 'index']);
    Route::post('customer-profile', [CustomerProfileController::class, 'store']);
    Route::put('customer-profile-admin/{id}', [CustomerProfileController::class, 'adminUpdate']);  
    Route::delete('customer-profile/{id}', [CustomerProfileController::class, 'destroy']);

    Route::get('customer-profile/count',  [CustomerProfileController::class, 'count']);
    Route::get('customer-profile/active', [CustomerProfileController::class, 'activeCount']);
});