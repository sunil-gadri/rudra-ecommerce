<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Specification extends Model
{
    protected $table = 'specification_tbl';

    public $timestamps = false;

    protected $fillable = [
        'specification_heading_id',
        'specification',
        'created_at'
    ];
}