<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductColor extends Model
{
    protected $table = 'product_color_tbl';
    public $timestamps = false;

    protected $fillable = [
        'color_name',
        'hex_value',
        'created_at'
    ];
}
