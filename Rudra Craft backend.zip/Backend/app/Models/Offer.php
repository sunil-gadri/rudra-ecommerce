<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Offer extends Model
{
    protected $table = 'offers_tbl';
    protected $fillable = ['heading', 'key', 'price', 'discount'];

    public function details()
    {
        return $this->hasMany(OfferDetail::class, 'offer_id');
    }
}