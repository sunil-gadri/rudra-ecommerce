<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $table = 'invoice_tbl';
    public $timestamps = true;

    protected $fillable = ['order_id', 'invoice_number'];
}