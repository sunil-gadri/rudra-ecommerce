<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OfferDetail extends Model
{
    protected $table = 'offer_detail_tbl';
    protected $fillable = [
        'offer_id', 'text1', 'text2', 'product_category_ids',
        'image', 'details_heading'
    ];

    public function getImageUrlAttribute()
    {
        return $this->image 
            ? asset('/uploads/offers/' . $this->image)
            : null;
    }
}