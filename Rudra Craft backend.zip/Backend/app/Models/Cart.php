<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    protected $table = 'cart_tbl';
    public $timestamps = false;

    protected $fillable = [
        'customer_id', 'product_id', 'quantity', 'coupon_code', 'created_at'
    ];
}