<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    protected $table = 'order_item_tbl';
    public $timestamps = true;

    protected $fillable = [
        'order_id', 'product_id', 'product_name', 'product_description',
        'price', 'base_price', 'discount', 'discounted_price', 'tax',
        'quantity', 'product_size', 'category', 'product_color', 'product_pattern'
    ];
}