<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpecificationHeading extends Model
{
    protected $table = 'specification_heading_tbl';

    public $timestamps = false;

    protected $fillable = [
        'specification_heading',
        'created_at'
    ];
}