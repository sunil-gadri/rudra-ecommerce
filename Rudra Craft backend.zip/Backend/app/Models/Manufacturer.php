<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manufacturer extends Model
{
    protected $table = 'manufacturer_tbl';

    public $timestamps = false;

    protected $fillable = [
        'manufacturer_name',
        'image',
        'created_at'
    ];
}