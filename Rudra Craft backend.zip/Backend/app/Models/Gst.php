<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gst extends Model
{
    protected $table = 'gst_tbl';

    public $timestamps = false;

    protected $fillable = [
        'gst',
        'created_at'
    ];
}