<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'product_tbl';
    public $timestamps = false;

    protected $fillable = [
        'product_title',
        'product_parent_category_id',
        'product_category_id',
        'product_tags',
        'product_status',
        'product_description'
    ];

    public function images()
    {
        return $this->hasMany(ProductImage::class);
    }

    public function attributes()
    {
        return $this->hasOne(ProductAttribute::class);
    }

    public function generalInfo()
    {
        return $this->hasOne(ProductGeneralInfo::class);
    }

    public function meta()
    {
        return $this->hasOne(ProductMeta::class);
    }
}