<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table = 'order_tbl';
    public $timestamps = false;

    protected $fillable = [
        'customer_id', 'total_amount', 'total_discount', 'order_amount',
        'coupon_code', 'coupon_discount', 'status', 'payment_status',
        'razorpay_order_id', 'razorpay_payment_id', 'razorpay_signature',
        'order_at', 'updated_at', 'shipping_name', 'shipping_phone',
        'shipping_email', 'building', 'street_address', 'city', 'state',
        'postal_code', 'country', 'address_type', 'shipping_cost'
    ];
}