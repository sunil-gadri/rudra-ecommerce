<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use PHPOpenSourceSaver\JWTAuth\Contracts\JWTSubject;

class Customer extends Authenticatable implements JWTSubject
{
    protected $table = 'customer_tbl';

    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'phone',
        'gender',
        'status',
        'password',
        'profile_image'
    ];

    protected $hidden = ['password'];

    /* JWT REQUIRED METHODS */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }
}
