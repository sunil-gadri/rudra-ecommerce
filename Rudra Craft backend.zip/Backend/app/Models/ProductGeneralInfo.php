<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductGeneralInfo extends Model
{
    protected $table = 'product_general_info_tbl';
    public $timestamps = false;

    protected $fillable = [
        'product_id',
        'manufacturer_name',
        'manufacturer_brand',
        'stock',
        'price',
        'gst',
        'discount',
        'base_price',
        'discounted_price',
        'gst_amount'
    ];
}