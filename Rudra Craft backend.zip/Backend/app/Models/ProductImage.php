<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model
{
    protected $table = 'product_images_tbl'; 

    protected $fillable = [
        'product_id',
        'image'
    ];

    public $timestamps = false;
}
