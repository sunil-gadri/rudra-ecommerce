<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wishlist extends Model
{
    protected $table = 'wishlist_tbl';

    public $timestamps = false;

    protected $fillable = [
        'customer_id',
        'product_id',
        'created_at'
    ];
}