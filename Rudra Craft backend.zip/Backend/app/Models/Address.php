<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    protected $table = 'address_tbl';

    protected $fillable = [
        'customer_id', 'full_name', 'phone', 'email', 'building',
        'street_address', 'city', 'state', 'postal_code', 'country',
        'address_type', 'is_default', 'created_at', 'updated_at'
    ];

    protected $casts = [
        'is_default'  => 'boolean',
        'created_at'  => 'datetime',
        'updated_at'  => 'datetime',
    ];
}