<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductSize extends Model
{
    protected $table = 'product_size_tbl';
    public $timestamps = false;

    protected $fillable = [
        'type',
        'unit',
        'category',
        'created_at'
    ];
}
