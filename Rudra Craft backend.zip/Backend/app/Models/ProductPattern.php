<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductPattern extends Model
{
    protected $table = 'product_pattern_tbl';
    public $timestamps = false;

    protected $fillable = [
        'pattern',
        'created_at'
    ];
}
