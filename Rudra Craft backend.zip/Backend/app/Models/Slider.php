<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    protected $table = 'slider_tbl';
    public $timestamps = false;

    protected $fillable = [
        'key',
        'category_id',
        'image',
        'created_at'
    ];
}
