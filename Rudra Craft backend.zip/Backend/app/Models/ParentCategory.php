<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ParentCategory extends Model
{
    protected $table = 'parent_category_tbl';

    public $timestamps = false;

    protected $fillable = [
        'name',
        'created_at'
    ];
}