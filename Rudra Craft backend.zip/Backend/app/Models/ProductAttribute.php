<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductAttribute extends Model
{
    protected $table = 'product_attributes_tbl';
    public $timestamps = false;

    protected $fillable = [
        'product_id',
        'unit',
        'category',
        'product_color',
        'product_pattern',
        'length',
        'width',
        'height'
    ];
}