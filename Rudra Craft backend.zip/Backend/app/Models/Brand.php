<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    protected $table = 'brand_tbl';

    public $timestamps = false;

    protected $fillable = [
        'manufacturer_name',
        'brand_name',
        'created_at'
    ];
}