<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductDescription extends Model
{
    protected $table = 'product_description_tbl';
    public $timestamps = false;

    protected $fillable = [
        'product_id',
        'overview',
        'disclaimer',
        'specifications',
        'created_at'
    ];

    protected $casts = [
        'specifications' => 'array'
    ];
}


