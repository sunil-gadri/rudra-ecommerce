<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductMeta extends Model
{
    protected $table = 'product_meta_tbl';
    public $timestamps = false;

    protected $fillable = [
        'product_id',
        'meta_title',
        'meta_keywords',
        'meta_description'
    ];
}