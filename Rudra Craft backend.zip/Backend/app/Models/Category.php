<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'category_tbl';

    public $timestamps = false;

    protected $fillable = [
        'name',
        'description',
        'parent_category',
        'status',
        'image',
        'created_at'
    ];

    public function parent()
    {
        return $this->belongsTo(ParentCategory::class, 'parent_category');
    }
}