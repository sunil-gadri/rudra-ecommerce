<?php

namespace App\Services;

use TCPDF;

class InvoicePdfService
{
    public function generateInvoicePdf(array $orderData): string
    {
        $pdf = new TCPDF('P', 'pt', 'A4', true, 'UTF-8', false);

        $pdf->SetCreator('Rudra Crafts');
        $pdf->SetAuthor('Rudra Crafts');
        $pdf->SetTitle('Invoice - ' . ($orderData['invoice_number'] ?? ''));
        $pdf->SetSubject('Tax Invoice');

        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

        $pdf->AddPage();

        $width  = $pdf->getPageWidth();
        $height = $pdf->getPageHeight();

        $margin_left = 40;
        $margin_top  = $height - 50;
        $line_height = 18;

        $safe = fn($val) => $val !== null ? (string)$val : '';

        $shipping = &$orderData['shipping_address'];
        $billing  = &$orderData['billing_address'];

        foreach (['building', 'street_address', 'city', 'state', 'postal_code', 'country'] as $key) {
            $shipping[$key] = $safe($shipping[$key] ?? '');
            $billing[$key]  = $safe($billing[$key] ?? '');
        }

        $orderData['customer_name'] = $safe($orderData['customer_name'] ?? '');

        // Header
        $pdf->SetFont('helvetica', 'B', 14);
        $pdf->SetXY($width - 40 - 250, $margin_top);
        $pdf->Cell(250, 0, 'Invoice - ' . $safe($orderData['invoice_number'] ?? ''), 0, 1, 'R');

        $pdf->SetFont('helvetica', '', 10);
        $pdf->SetXY($width - 40 - 250, $pdf->GetY() + 2);
        $pdf->Cell(250, 0, 'Invoice Date: ' . $safe($orderData['invoice_date'] ?? ''), 0, 1, 'R');

        $pdf->SetXY($width - 40 - 250, $pdf->GetY() + 2);
        $pdf->Cell(250, 0, 'Order ID: ' . $safe($orderData['order_id'] ?? ''), 0, 1, 'R');

        // From / To
        $y_addr = $margin_top - 130;

        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->SetXY($margin_left, $y_addr);
        $pdf->Cell(0, 0, 'From:');

        $pdf->SetXY(400, $y_addr);
        $pdf->Cell(0, 0, 'To:');

        $pdf->SetFont('helvetica', '', 10);

        // From
        $pdf->SetXY($margin_left, $y_addr - $line_height);
        $pdf->Cell(0, 0, $billing['building']);

        $pdf->SetXY($margin_left, $pdf->GetY() - $line_height);
        $pdf->Cell(0, 0, $billing['street_address']);

        $pdf->SetXY($margin_left, $pdf->GetY() - $line_height);
        $pdf->Cell(0, 0, $billing['city'] . ', ' . $billing['state']);

        // To
        $pdf->SetXY(400, $y_addr - $line_height);
        $pdf->Cell(0, 0, $orderData['customer_name']);

        $pdf->SetXY(400, $pdf->GetY() - $line_height);
        $pdf->Cell(0, 0, $shipping['building']);

        $pdf->SetXY(400, $pdf->GetY() - $line_height);
        $pdf->Cell(0, 0, $shipping['street_address']);

        $pdf->SetXY(400, $pdf->GetY() - $line_height);
        $pdf->Cell(0, 0, $shipping['city'] . ', ' . $shipping['state']);

        // Table Header
        $y_table = $y_addr - 150;

        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->SetXY($margin_left, $y_table);
        $pdf->Cell(0, 0, 'Product');

        $pdf->SetXY($margin_left + 130, $y_table);
        $pdf->Cell(0, 0, 'Qty', 0, 0, 'R');

        $pdf->SetXY($margin_left + 270, $y_table);
        $pdf->Cell(0, 0, 'Size Details', 0, 0, 'R');

        $pdf->SetXY($margin_left + 400, $y_table);
        $pdf->Cell(0, 0, 'Product Color', 0, 0, 'R');

        $pdf->SetXY($margin_left + 490, $y_table);
        $pdf->Cell(0, 0, 'Price', 0, 0, 'R');

        $pdf->SetFont('helvetica', '', 10);
        $y_table -= $line_height + 10;

        foreach ($orderData['items'] ?? [] as $item) {
            $price = (float) ($item['price'] ?? 0);

            $pdf->SetXY($margin_left, $y_table);
            $pdf->Cell(0, 0, $safe($item['product_name'] ?? ''));

            $pdf->SetXY($margin_left + 130, $y_table);
            $pdf->Cell(0, 0, (string)($item['quantity'] ?? 0), 0, 0, 'R');

            $size = trim(($item['product_size'] ?? '') . ', ' . ($item['category'] ?? ''), ', ');
            $pdf->SetXY($margin_left + 270, $y_table);
            $pdf->Cell(0, 0, $size, 0, 0, 'R');

            $pdf->SetXY($margin_left + 380, $y_table);
            $pdf->Cell(0, 0, $safe($item['product_color'] ?? ''), 0, 0, 'R');

            $pdf->SetXY($margin_left + 490, $y_table);
            $pdf->Cell(0, 0, number_format($price, 2), 0, 0, 'R');

            $y_table -= $line_height;
        }

        // Totals
        $y_totals = $y_table - 60;

        $pdf->SetFont('helvetica', '', 10);

        $pdf->SetXY($margin_left + 300, $y_totals);
        $pdf->Cell(0, 0, 'Base Price:');

        $pdf->SetXY($width - 40 - 100, $y_totals);
        $pdf->Cell(100, 0, number_format((float)($orderData['base_price'] ?? 0), 2), 0, 0, 'R');

        $pdf->SetXY($margin_left + 300, $y_totals - $line_height);
        $pdf->Cell(0, 0, 'Tax:');

        $pdf->SetXY($width - 40 - 100, $y_totals - $line_height);
        $pdf->Cell(100, 0, number_format((float)($orderData['tax'] ?? 0), 2), 0, 0, 'R');

        $pdf->SetXY($margin_left + 300, $y_totals - ($line_height * 2));
        $pdf->Cell(0, 0, 'Discount:');

        $pdf->SetXY($width - 40 - 100, $y_totals - ($line_height * 2));
        $pdf->Cell(100, 0, number_format((float)($orderData['discount'] ?? 0), 2), 0, 0, 'R');

        $coupon_code     = $orderData['coupon_code'] ?? null;
        $coupon_discount = (float)($orderData['coupon_discount'] ?? 0);

        $offset = 3;

        if ($coupon_code && $coupon_discount > 0) {
            $pdf->SetXY($margin_left + 300, $y_totals - ($line_height * 3));
            $pdf->Cell(0, 0, "Coupon Discount ({$coupon_code}):");

            $pdf->SetXY($width - 40 - 100, $y_totals - ($line_height * 3));
            $pdf->Cell(100, 0, '-' . number_format($coupon_discount, 2), 0, 0, 'R');

            $offset = 4;
        }

        $pdf->SetXY($margin_left + 300, $y_totals - ($line_height * $offset));
        $pdf->Cell(0, 0, 'Shipping:');

        $pdf->SetXY($width - 40 - 100, $y_totals - ($line_height * $offset));
        $pdf->Cell(100, 0, number_format((float)($orderData['shipping_cost'] ?? 0), 2), 0, 0, 'R');

        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->SetXY($margin_left + 300, $y_totals - ($line_height * ($offset + 2)));
        $pdf->Cell(0, 0, 'Total Amount:');

        $pdf->SetXY($width - 40 - 100, $y_totals - ($line_height * ($offset + 2)));
        $pdf->Cell(100, 0, number_format((float)($orderData['total_amount'] ?? 0), 2), 0, 0, 'R');

        // Bottom Section
        $bottom_margin = 100;

        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->SetXY($margin_left, $bottom_margin + 60);
        $pdf->Cell(0, 0, 'PAYMENT DETAILS');

        $pdf->SetFont('helvetica', '', 10);
        $pdf->SetXY($margin_left, $bottom_margin + 45);
        $pdf->Cell(0, 0, 'Bank of Name');

        $pdf->SetXY($margin_left, $bottom_margin + 30);
        $pdf->Cell(0, 0, 'Account Number: 123456678');

        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->SetXY($margin_left, $bottom_margin - 10);
        $pdf->Cell(0, 0, 'Terms & Condition');

        $pdf->SetFont('helvetica', '', 9);
        $pdf->SetXY($margin_left, $bottom_margin - 30);
        $pdf->MultiCell(0, 0, 'Contrary to popular belief, Lorem Ipsum is not simply random text.');

        $pdf->SetXY($margin_left, $bottom_margin - 45);
        $pdf->MultiCell(0, 0, 'It has roots in a piece of classical Latin literature from 45 BC, making it over.');

        $pdf->lastPage();

        return $pdf->Output('', 'S');
    }
}