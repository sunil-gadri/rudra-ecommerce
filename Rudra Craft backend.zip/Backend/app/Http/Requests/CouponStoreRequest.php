<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CouponStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules()
{
    return [
        'coupon_code'    => 'required|string|unique:coupon_tbl,coupon_code',
        'status'         => 'sometimes|in:active,expired,inactive',
        'start_date'     => 'required|date',
        'end_date'       => 'required|date|after_or_equal:start_date',
        'coupon_type'    => 'required|in:percentage,fixed',
        'discount_value' => 'required|numeric|min:0',
        'min_price'      => 'nullable|numeric|min:0',
        'max_price'      => 'nullable|numeric|min:0',
        'coupon_title'   => 'nullable|string|max:255',
    ];
}
}
