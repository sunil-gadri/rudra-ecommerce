<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CouponUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules()
{
    return [
        'coupon_code'    => 'sometimes|required|string|unique:coupon_tbl,coupon_code,' . $this->id,
        'status'         => 'sometimes|in:active,expired,inactive',
        'start_date'     => 'sometimes|date',
        'end_date'       => 'sometimes|date|after_or_equal:start_date',
        'coupon_type'    => 'sometimes|in:percentage,fixed',
        'discount_value' => 'sometimes|numeric|min:0',
        'min_price'      => 'nullable|numeric|min:0',
        'max_price'      => 'nullable|numeric|min:0',
        'coupon_title'   => 'nullable|string|max:255',
    ];
}
}
