<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Customer;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;

class CustomerAuthController extends Controller
{
    /**
     * Register a new customer
     */
    public function register(Request $request)
    {
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name'  => 'required|string|max:255',
            'email'      => 'required|string|email|max:255|unique:customer_tbl,email',
            'phone'      => 'required|string|digits:10|unique:customer_tbl,phone',
            'gender'     => 'nullable|string|in:male,female,other',
            'password'   => 'required|string|min:6',
            'profile_image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
        ]);

        // Handle profile image upload
        $profileImage = null;
        if ($request->hasFile('profile_image')) {
            $uploadPath = public_path('uploads/customers');
            if (!File::exists($uploadPath)) {
                File::makeDirectory($uploadPath, 0755, true);
            }
            
            $file = $request->file('profile_image');
            if ($file->isValid()) {
                $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move($uploadPath, $filename);
                $profileImage = $filename;
            }
        }

        $customer = Customer::create([
            'first_name' => $validated['first_name'],
            'last_name'  => $validated['last_name'],
            'email'      => $validated['email'],
            'phone'      => $validated['phone'],
            'gender'     => $validated['gender'] ?? null,
            'password'   => Hash::make($validated['password']),
            'profile_image' => $profileImage,
            'status'     => 'active', // Default status
        ]);

        $token = Auth::guard('api')->login($customer);

        return response()->json([
            'message' => 'Registration successful',
            'token'   => $token,
            'user'    => [
                'id'          => $customer->id,
                'first_name'  => $customer->first_name,
                'last_name'   => $customer->last_name,
                'email'       => $customer->email,
                'phone'       => (int) $customer->phone,
                'image_url'   => $profileImage ? asset('uploads/customers/' . $profileImage) : null,
            ]
        ], 201);
    }

    /**
     * Login customer and return token
     */
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);

        if (! $token = Auth::guard('api')->attempt($credentials)) {
            return response()->json([
                'message' => 'Invalid credentials'
            ], 401);
        }

        $user = Auth::guard('api')->user();

        return response()->json([
            'message' => 'Login successful',
            'token'   => $token,
            'user'    => [
                'id'          => $user->id,
                'first_name'  => $user->first_name,
                'last_name'   => $user->last_name,
                'email'       => $user->email,
                'phone'       => (int) $user->phone,
                'image_url'   => $user->profile_image ? asset('uploads/customers/' . $user->profile_image) : null,
            ]
        ]);
    }

    /**
     * Logout (invalidate current token)
     */
    public function logout()
    {
        Auth::guard('api')->logout();

        return response()->json([
            'message' => 'Logged out successfully'
        ]);
    }

    /**
     * Get currently authenticated user
     */
    public function me()
    {
        $user = Auth::guard('api')->user();

        if (!$user) {
            return response()->json(['message' => 'Unauthenticated'], 401);
        }

        return response()->json([
            'message' => 'User retrieved successfully',
            'user'    => [
                'id'          => $user->id,
                'first_name'  => $user->first_name,
                'last_name'   => $user->last_name,
                'email'       => $user->email,
                'phone'       => (int) $user->phone,
                'image_url'   => $user->profile_image ? asset('uploads/customers/' . $user->profile_image) : null,
            ]
        ]);
    }
}
