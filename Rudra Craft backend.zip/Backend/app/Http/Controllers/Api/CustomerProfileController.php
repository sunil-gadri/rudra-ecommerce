<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;


class CustomerProfileController extends Controller
{
protected $uploadPath = 'uploads/customers'; 

    // GET ALL - GET /customer-profile?page=X&limit=Y
    public function index(Request $request)
    {
        $page = $request->get('page', 1);
        $limit = $request->get('limit', 10);

        $customers = Customer::orderBy('created_at', 'desc')
            ->paginate($limit, ['*'], 'page', $page);

        $customers->getCollection()->transform(function ($customer) {
        $customer->image_url = $customer->profile_image ? asset($this->uploadPath . '/' . $customer->profile_image): null;
        $customer->name = $customer->first_name . ' ' . $customer->last_name;
        $customer->status = lcfirst($customer->status);
        $customer->gender = lcfirst($customer->gender);
        $customer->joinDate = $customer->created_at->format('Y-m-d');
        $customer->totalOrders = 0;
        $customer->totalSpent = 0;
        return $customer;
        });

        return response()->json([
            "profiles" => $customers->items(),
            "pagination" => [
                "current_page" => $customers->currentPage(),
                "total_pages" => $customers->lastPage(),
                "total" => $customers->total(),
                "per_page" => $customers->perPage(),
                "limit" => $limit
            ]
        ], 200);
    }

    // CREATE - POST /customer-profile
    public function store(Request $request)
    {
        $first_name = $request->input('first_name');
        $last_name = $request->input('last_name');
        $email = $request->input('email');
        $phone = $request->input('phone');
        $password = $request->input('password');
        $gender = $request->input('gender');
        $status = $request->input('status');

        if (!$first_name || !$last_name || !$email || !$phone || !$password) {
            return response()->json(["error" => "All fields are required"], 400);
        }

        if (Customer::where('email', $email)->exists()) {
            return response()->json(["error" => "Email already exists"], 409);
        }

        if (Customer::where('phone', $phone)->exists()) {
            return response()->json(["error" => "Phone number already exists"], 409);
        }

        $profileImage = null;

       if ($request->hasFile('profile_image')) {
    $uploadPath = public_path($this->uploadPath);
    if (!File::exists($uploadPath)) {
        File::makeDirectory($uploadPath, 0755, true);
    }
    
    $file = $request->file('profile_image');
    if ($file->isValid() && in_array($file->extension(), ['png', 'jpg', 'jpeg', 'gif'])) {
        $filename = time() . '_' . uniqid() . '.' . $file->extension();
        $file->move($uploadPath, $filename);
        $profileImage = $filename;
    }
}
        Customer::create([
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'phone' => $phone,
            'password' => Hash::make($password),
            'gender' => strtolower($gender),
            'status' => strtolower($status),
            'profile_image' => $profileImage,
            'created_at' => now()
        ]);

        return response()->json(["message" => "Customer added successfully"], 201);
    }

    // GET SINGLE - GET /customer-profile/{id}
    public function show($id)
    {
        $customer = Customer::find($id);

        if (!$customer) {
            return response()->json(["error" => "Customer not found"], 404);
        }

       $customer->image_url = $customer->profile_image ? asset($this->uploadPath . '/' . $customer->profile_image): null;

        return response()->json($customer, 200);
    }

public function adminUpdate(Request $request, $id)
{
    DB::beginTransaction();

    try {
        $customer = Customer::find($id);

        if (!$customer) {
            return response()->json([
                'message' => 'Customer not found'
            ], 404);
        }

        // Normalize inputs BEFORE validation
        $request->merge([
            'gender' => strtolower($request->gender),
            'status' => strtolower($request->status),
        ]);

        // Validation (PASSWORD NOT INCLUDED)
        $validator = Validator::make($request->all(), [
            'first_name'     => 'required|string|max:255',
            'last_name'      => 'required|string|max:255',
            'email'          => 'required|email|unique:customer_tbl,email,' . $id,
            'phone'          => 'required|unique:customer_tbl,phone,' . $id,
            'gender'         => 'required',
            'status'         => 'required|in:active,inactive',
            'profile_image'  => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(),
                'errors'  => $validator->errors()
            ], 422);
        }

        /* ───────── IMAGE UPDATE ───────── */
        if ($request->hasFile('profile_image')) {

$uploadPath = public_path('uploads/customers');

            if (!File::exists($uploadPath)) {
                File::makeDirectory($uploadPath, 0777, true);
            }

            // Delete old image
            if ($customer->profile_image) {
                $oldImagePath = public_path('uploads/customers/' . $customer->profile_image);
                if (File::exists($oldImagePath)) {
                    File::delete($oldImagePath);
                }
            }

            // Save new image
            $image = $request->file('profile_image');
            $imageName = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move($uploadPath, $imageName);

            $customer->profile_image = $imageName;
        }

        /* ───────── UPDATE CUSTOMER DATA ───────── */
        $customer->update([
            'first_name' => $request->first_name,
            'last_name'  => $request->last_name,
            'email'      => $request->email,
            'phone'      => $request->phone,
            'gender'     => $request->gender,
            'status'     => $request->status,
        ]);

        DB::commit();

        return response()->json([
            'message' => 'Customer updated successfully',
            'data'    => $customer
        ], 200);

    } catch (\Exception $e) {
        DB::rollBack();

        return response()->json([
            'message' => 'Something went wrong',
            'error'   => $e->getMessage()
        ], 500);
    }
}

public function updateProfile(Request $request, $id)
{
    DB::beginTransaction();

    try {
        $customer = Customer::find($id);

        if (!$customer) {
            return response()->json([
                'message' => 'Customer not found'
            ], 404);
        }

        // Normalize inputs BEFORE validation
        $request->merge([
            'gender' => strtolower($request->gender),
        ]);

        // Validation (NO STATUS, NO PASSWORD)
        $validator = Validator::make($request->all(), [
            'first_name'     => 'required|string|max:255',
            'last_name'      => 'required|string|max:255',
            'email'          => 'required|email|unique:customer_tbl,email,' . $id,
            'phone'          => 'required|unique:customer_tbl,phone,' . $id,
            'gender'         => 'required',
            'profile_image'  => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(),
                'errors'  => $validator->errors()
            ], 422);
        }

        /* ───────── IMAGE UPDATE ───────── */
        if ($request->hasFile('profile_image')) {

             $uploadPath = public_path('uploads/customers');

            if (!File::exists($uploadPath)) {
                File::makeDirectory($uploadPath, 0777, true);
            }

            // Delete old image
            if ($customer->profile_image) {
                $oldImagePath = $uploadPath . '/' . $customer->profile_image;
                if (File::exists($oldImagePath)) {
                    File::delete($oldImagePath);
                }
            }

            // Save new image
            $image = $request->file('profile_image');
            $imageName = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move($uploadPath, $imageName);

            $customer->profile_image = $imageName;
        }

        /* ───────── UPDATE CUSTOMER DATA ───────── */
        $customer->update([
            'first_name' => $request->first_name,
            'last_name'  => $request->last_name,
            'email'      => $request->email,
            'phone'      => $request->phone,
            'gender'     => $request->gender,
        ]);

        DB::commit();

        return response()->json([
            'message' => 'Customer updated successfully',
            'data'    => $customer
        ], 200);

    } catch (\Exception $e) {
        DB::rollBack();

        return response()->json([
            'message' => 'Something went wrong',
            'error'   => $e->getMessage()
        ], 500);
    }
}

    // DELETE - DELETE /customer-profile/{id}
    public function destroy($id)
    {
        $customer = Customer::find($id);

        if (!$customer) {
            return response()->json(["error" => "Customer not found"], 404);
        }

       if ($customer->profile_image && File::exists(public_path($this->uploadPath . '/' . $customer->profile_image))) {
    File::delete(public_path($this->uploadPath . '/' . $customer->profile_image));
}

        $customer->delete();

        return response()->json(["message" => "Customer deleted successfully"], 200);
    }
}
