<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductGeneralInfo;
use App\Models\ProductMeta;
use App\Models\ProductImage;
use App\Models\ParentCategory;
use App\Models\Category as ProductCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;


class ProductController extends Controller
{
    protected $uploadPath = 'uploads/products';

    public function __construct()
    {
        // Ensure upload folder exists
        if (!File::exists(public_path($this->uploadPath))) {
            File::makeDirectory(public_path($this->uploadPath), 0755, true);
        }
    }

    // POST /products - Add Product
   public function store(Request $request)
{
    DB::beginTransaction();

    try {
        if (!$request->product_title || !$request->price) {
            return response()->json(["error" => "Product title and price are required"], 400);
        }

        $price = floatval($request->price);
        $gst = floatval($request->gst ?? 0);
        $discount = floatval($request->discount ?? 0);

        $base_price = round($price / (1 + $gst / 100), 2);
        $discounted_price = round($price * (1 - $discount / 100), 2);
        $gst_amount = round($price - $base_price, 2);

        // PRODUCT
        $product = Product::create([
            'product_title' => $request->product_title,
            'product_parent_category_id' => $request->product_parent_category_id,
            'product_category_id' => $request->product_category_id,
            'product_tags' => $request->product_tags,
            'product_status' => $request->product_status,
            'product_description' => $request->product_description,
            'created_at' => now()
        ]);

        // ATTRIBUTES
        ProductAttribute::create([
            'product_id' => $product->id,
            'unit' => $request->unit,
            'category' => $request->category,
            'product_color' => $request->product_color,
            'product_pattern' => $request->product_pattern,
            'length' => $request->length,
            'width' => $request->width,
            'height' => $request->height,
        ]);

        // GENERAL INFO
        ProductGeneralInfo::create([
            'product_id' => $product->id,
            'manufacturer_name' => $request->manufacturer_name,
            'manufacturer_brand' => $request->manufacturer_brand,
            'stock' => $request->stock ?? 0,
            'price' => $price,
            'gst' => $gst,
            'discount' => $discount,
            'base_price' => $base_price,
            'discounted_price' => $discounted_price,
            'gst_amount' => $gst_amount
        ]);

        // META
        ProductMeta::create([
            'product_id' => $product->id,
            'meta_title' => $request->meta_title,
            'meta_keywords' => $request->meta_keywords,
            'meta_description' => $request->meta_description
        ]);

        // IMAGES (🔥 FIXED)
       if ($request->hasFile('images')) {

    $images = $request->file('images');

    // Force array (handles single + multiple uploads)
    if (!is_array($images)) {
        $images = [$images];
    }

    foreach ($images as $image) {

        if (!$image instanceof \Illuminate\Http\UploadedFile) {
            continue;
        }

        if (!$image->isValid()) {
            continue;
        }

        $ext = strtolower($image->getClientOriginalExtension());

        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            continue;
        }

        $fileName = \Illuminate\Support\Str::uuid() . '.' . $ext;

        $image->move(public_path('uploads/products'), $fileName);

        ProductImage::create([
            'product_id' => $product->id,
            'image' => $fileName
        ]);
    }
}


        DB::commit();
        return response()->json([
            "message" => "Product added successfully",
            "product_id" => $product->id
        ], 200);

    } catch (\Throwable $e) {
        DB::rollBack();
        return response()->json(["error" => $e->getMessage()], 500);
    }
}


    public function show($product_id)
    {
        $product = Product::find($product_id);

        if (!$product) {
            return response()->json(["error" => "Product not found"], 404);
        }

        $parent_category_name = null;
        if ($product->product_parent_category_id) {
            $parent = ParentCategory::find($product->product_parent_category_id);
            $parent_category_name = $parent ? $parent->name : null;
        }

        $product_category_name = null;
        if ($product->product_category_id) {
            $cat = ProductCategory::find($product->product_category_id);
            $product_category_name = $cat ? $cat->name : null;
        }

        $images = ProductImage::where('product_id', $product_id)->pluck('image')->toArray();
        $image_urls = array_map(fn($img) => asset($this->uploadPath . '/' . $img), $images);

        $attributes = ProductAttribute::where('product_id', $product_id)->first();

        $general_info = ProductGeneralInfo::where('product_id', $product_id)->first();
        $stock = $general_info?->stock ?? 0;
        $in_stock = $stock > 0;

        $meta_info = ProductMeta::where('product_id', $product_id)->first();

        $result = [
            "id" => $product->id,
            "title" => $product->product_title,
            "parent_category" => $parent_category_name,
            "product_category" => $product_category_name,
            "tags" => $product->product_tags,
            "status" => $product->product_status,
            "description" => $product->product_description,
            "created_at" => $product->created_at? Carbon::parse($product->created_at)->toDateTimeString(): null,
            "images" => $image_urls,

            "attributes" => [
                "unit" => $attributes?->unit,
                "size_category" => $attributes?->category,
                "color" => $attributes?->product_color,
                "pattern" => $attributes?->product_pattern,
                "length" => $attributes?->length,
                "width" => $attributes?->width,
                "height" => $attributes?->height,
            ],

            "general_info" => [
                "manufacturer_name" => $general_info?->manufacturer_name,
                "manufacturer_brand" => $general_info?->manufacturer_brand,
                "stock" => $general_info?->stock,
                "price" => $general_info?->price ? floatval($general_info->price) : 0.0,
                "gst" => $general_info?->gst ? floatval($general_info->gst) : 0.0,
                "discount" => $general_info?->discount,
                "base_price" => $general_info?->base_price ? floatval($general_info->base_price) : 0.0,
                "discounted_price" => $general_info?->discounted_price ? floatval($general_info->discounted_price) : 0.0,
                "gst_amount" => $general_info?->gst_amount ? floatval($general_info->gst_amount) : 0.0,
                "in_stock" => $in_stock
            ],

            "meta" => [
                "title" => $meta_info?->meta_title,
                "keywords" => $meta_info?->meta_keywords,
                "description" => $meta_info?->meta_description
            ]
        ];

        return response()->json($result, 200);
    }

public function update(Request $request, $product_id)
{
    // Debug: log exactly what frontend sent (check storage/logs/laravel.log)
    \Log::info('Product update request received', [
        'product_id' => $product_id,
        'form_data'  => $request->except('images'), // exclude files for log size
        'files_count' => $request->hasFile('images') ? count($request->file('images')) : 0,
    ]);

    DB::beginTransaction();

    try {
        $product = Product::find($product_id);
        if (!$product) {
            return response()->json(["error" => "Product not found"], 404);
        }

        $general    = $product->generalInfo;
        $attributes = $product->attributes;

        // ── Numeric fields ──────────────────────────────────────────────────────
        // Only update if explicitly sent, otherwise keep old value
        $price    = $request->has('price')    ? floatval($request->price)    : ($general?->price    ?? 0);
        $gst      = $request->has('gst')      ? floatval($request->gst)      : ($general?->gst      ?? 0);
        $discount = $request->has('discount') ? floatval($request->discount) : ($general?->discount ?? 0);

        if ($request->has('price') && $price <= 0) {
            return response()->json(["error" => "Price must be greater than 0"], 422);
        }

        $base_price       = round($price / (1 + $gst / 100), 2);
        $discounted_price = round($price * (1 - $discount / 100), 2);
        $gst_amount       = round($price - $base_price, 2);

        // ── PRODUCT TABLE ───────────────────────────────────────────────────────
        $productData = $request->only([
            'product_title',
            'product_parent_category_id',
            'product_category_id',
            'product_tags',
            'product_status',
            'product_description',
        ]);

        if (!empty($productData)) {
            $product->update($productData);
        }

        // ── ATTRIBUTES ──────────────────────────────────────────────────────────
        $attrData = $request->only([
            'unit',
            'category',
            'product_color',
            'product_pattern',
            'length',
            'width',
            'height'
        ]);

        if (!empty($attrData)) {
            $product->attributes()->updateOrCreate(
                ['product_id' => $product->id],
                $attrData
            );
        }

        // ── GENERAL INFO ────────────────────────────────────────────────────────
        $generalData = [];

        // Only update if field was sent
        if ($request->has('manufacturer_name')) {
            $generalData['manufacturer_name'] = $request->manufacturer_name;
        }
        if ($request->has('manufacturer_brand')) {
            $generalData['manufacturer_brand'] = $request->manufacturer_brand;
        }
        if ($request->has('stock')) {
            $generalData['stock'] = (int) $request->stock;
        }

        // Recalculate prices only if any price field changed
        if ($request->has('price') || $request->has('gst') || $request->has('discount')) {
            $generalData['price']            = $price;
            $generalData['gst']              = $gst;
            $generalData['discount']         = $discount;
            $generalData['base_price']       = $base_price;
            $generalData['discounted_price'] = $discounted_price;
            $generalData['gst_amount']       = $gst_amount;
        }

        if (!empty($generalData)) {
            $product->generalInfo()->updateOrCreate(
                ['product_id' => $product->id],
                $generalData
            );
        }

        // ── META ────────────────────────────────────────────────────────────────
        $metaData = $request->only([
            'meta_title',
            'meta_keywords',
            'meta_description',
        ]);

        if (!empty($metaData)) {
            $product->meta()->updateOrCreate(
                ['product_id' => $product->id],
                $metaData
            );
        }

        // ── IMAGES ──────────────────────────────────────────────────────────────
        if ($request->hasFile('images')) {
            $files = $request->file('images');
            $validFiles = [];

            foreach ((array)$files as $file) {
                if ($file instanceof \Illuminate\Http\UploadedFile &&
                    $file->isValid() &&
                    in_array(strtolower($file->getClientOriginalExtension()), ['jpg','jpeg','png','gif','webp'])) {
                    $validFiles[] = $file;
                }
            }

            if (!empty($validFiles)) {
                // Delete old images
                $oldImages = ProductImage::where('product_id', $product_id)->get();
                foreach ($oldImages as $img) {
                    $path = public_path('uploads/products/' . $img->image);
                    if (File::exists($path)) {
                        File::delete($path);
                    }
                    $img->delete();
                }

                // Add new images
                foreach ($validFiles as $file) {
                    $ext = strtolower($file->getClientOriginalExtension());
                    $fileName = Str::uuid() . '.' . $ext;
                    $file->move(public_path('uploads/products'), $fileName);

                    ProductImage::create([
                        'product_id' => $product_id,
                        'image'      => $fileName,
                    ]);
                }
            }
        }

        DB::commit();

        return response()->json(["message" => "Product updated successfully"], 200);

    } catch (\Throwable $e) {
        DB::rollBack();
        \Log::error('Product update failed', ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
        return response()->json(["error" => $e->getMessage()], 500);
    }
}


    // DELETE /products/{id}
    public function destroy($product_id)
    {
        $product = Product::find($product_id);

        if (!$product) {
            return response()->json(["error" => "Product not found"], 404);
        }

        // Delete images from disk
        $images = ProductImage::where('product_id', $product_id)->pluck('image')->toArray();
        foreach ($images as $img) {
            $path = public_path($this->uploadPath . '/' . $img);
            if (File::exists($path)) {
                File::delete($path);
            }
        }

        // Delete related records
        ProductImage::where('product_id', $product_id)->delete();
        ProductAttribute::where('product_id', $product_id)->delete();
        ProductGeneralInfo::where('product_id', $product_id)->delete();
        ProductMeta::where('product_id', $product_id)->delete();

        $product->delete();

        return response()->json(["message" => "Product and related data deleted successfully"], 200);
    }

    // GET /product/count
    public function count()
    {
        return response()->json(["product_count" => Product::count()], 200);
    }

    // GET /products/search
    public function search(Request $request)
    {
        $query_text = $request->query('q');
        if (!$query_text || strlen(trim($query_text)) < 3) {
            return response()->json(["error" => "Please enter at least 3 characters"], 400);
        }

        $page = max(1, (int)$request->query('page', 1));
        $limit = max(1, min(50, (int)$request->query('limit', 10)));
        $offset = ($page - 1) * $limit;

        $like = '%' . strtolower($query_text) . '%';

        // Search query
        $searchQuery = Product::query()
            ->leftJoin('category_tbl as c', 'product_tbl.product_category_id', '=', 'c.id')
            ->leftJoin('product_attributes_tbl as pa', 'product_tbl.id', '=', 'pa.product_id')
            ->whereRaw('LOWER(product_tbl.product_title) LIKE ?', [$like])
            ->orWhereRaw('LOWER(c.name) LIKE ?', [$like])
            ->orWhereRaw('LOWER(pa.product_color) LIKE ?', [$like]);

        $total_items = (clone $searchQuery)->count();

        $products = $searchQuery
            ->select('product_tbl.*')
            ->offset($offset)
            ->limit($limit)
            ->orderByDesc('product_tbl.id')
            ->get();

        if ($products->isEmpty()) {
            // Fallback to latest products
            $total_items = Product::count();
            $products = Product::orderByDesc('id')->offset($offset)->limit($limit)->get();
            $message = "No match found for '{$query_text}', showing latest products instead";
        } else {
            $message = "Products matching '{$query_text}' retrieved successfully";
        }

        $total_pages = ceil($total_items / $limit);

        return response()->json([
            "message" => $message,
            "pagination" => [
                "current_page" => $page,
                "limit" => $limit,
                "total_pages" => $total_pages,
                "total_products" => $total_items
            ],
            "products" => $products->map(function ($p) {
                $img = ProductImage::where('product_id', $p->id)->first();
                return [
                    "id" => $p->id,
                    "title" => $p->product_title,
                    "image_url" => $img ? asset($this->uploadPath . '/' . $img->image) : null,
                    // Add other fields as needed
                ];
            })
        ], 200);
    }

    // GET /product_title
    public function titles()
    {
        $products = Product::select('id', 'product_title as title')->get();

        return response()->json(["products" => $products], 200);
    }

    // GET /products - All products with pagination and filters
public function index(Request $request)
{
    $page  = max(1, (int) $request->query('page', 1));
    $limit = max(1, min(100, (int) $request->query('limit', 10)));
    $offset = ($page - 1) * $limit;

    // Handle category filter (single or array)
    $categoryIds = $request->query('category');
    if (!is_array($categoryIds)) {
        $categoryIds = $categoryIds ? explode(',', $categoryIds) : [];
    }
    $categoryIds = array_filter(array_map('intval', $categoryIds));

    $minPrice = $request->query('min_price');
    $maxPrice = $request->query('max_price');
    $inStock  = $request->query('in_stock');

    // Main query – select all needed fields including manufacturer & brand
    $query = DB::table('product_tbl as p')
        ->leftJoin('product_general_info_tbl as pg', 'p.id', '=', 'pg.product_id')
        ->select(
            'p.*',
            'pg.manufacturer_name',
            'pg.manufacturer_brand',
            'pg.stock',
            'pg.price',
            'pg.gst',
            'pg.discount',
            'pg.base_price',
            'pg.discounted_price',
            'pg.gst_amount'
        )
        ->where('p.product_status', 'Active');

    // Filters
    if (!empty($categoryIds)) {
        $query->whereIn('p.product_category_id', $categoryIds);
    }

    if ($minPrice !== null) {
        $query->where('pg.price', '>=', (float) $minPrice);
    }
    if ($maxPrice !== null) {
        $query->where('pg.price', '<=', (float) $maxPrice);
    }

    if ($inStock === 'true') {
        $query->where('pg.stock', '>', 0);
    } elseif ($inStock === 'false') {
        $query->where('pg.stock', '=', 0);
    }

    $total_products = (clone $query)->count();

    $products = $query->orderByDesc('p.id')
        ->offset($offset)
        ->limit($limit)
        ->get();

    $result = $products->map(function ($p) {
        // Parent & Product category names
        $parent_name = null;
        if ($p->product_parent_category_id) {
            $parent_name = ParentCategory::find($p->product_parent_category_id)?->name;
        }

        $cat_name = null;
        if ($p->product_category_id) {
            $cat_name = ProductCategory::find($p->product_category_id)?->name;
        }

        // All product images
        $images = ProductImage::where('product_id', $p->id)
            ->pluck('image')
            ->map(fn($img) => asset('uploads/products/' . $img))
            ->toArray();

        // Attributes & Meta
        $attributes = ProductAttribute::where('product_id', $p->id)->first();
        $meta       = ProductMeta::where('product_id', $p->id)->first();

        $stock = (int) ($p->stock ?? 0);

        return [
            "id"               => $p->id,
            "title"            => $p->product_title,
            "parent_category"  => $parent_name,
            "product_category" => $cat_name,
            "tags"             => $p->product_tags,
            "status"           => $p->product_status,
            "description"      => $p->product_description,
            "created_at"       => $p->created_at ? Carbon::parse($p->created_at)->toDateTimeString() : null,
            "images"           => $images,

            // ── Correct "overview" field – exactly like Flask ────────────────
            "overview"         => DB::table('product_description_tbl')
                                    ->where('product_id', $p->id)
                                    ->exists(),
            // ────────────────────────────────────────────────────────────────

            "attributes" => [
                "unit"          => $attributes?->unit          ?? null,
                "size_category" => $attributes?->category      ?? null,
                "color"         => $attributes?->product_color ?? null,
                "pattern"       => $attributes?->product_pattern ?? null,
                "length"        => $attributes?->length        ?? null,
                "width"         => $attributes?->width         ?? null,
                "height"        => $attributes?->height        ?? null,
            ],

            "general_info" => [
                "manufacturer_name"  => $p->manufacturer_name  ?? null,
                "manufacturer_brand" => $p->manufacturer_brand ?? null,
                "stock"              => $stock,
                "price"              => (float) ($p->price ?? 0.0),
                "gst"                => (float) ($p->gst ?? 0.0),
                "discount"           => $p->discount           ?? null,
                "base_price"         => (float) ($p->base_price ?? 0.0),
                "discounted_price"   => (float) ($p->discounted_price ?? 0.0),
                "gst_amount"         => (float) ($p->gst_amount ?? 0.0),
                "in_stock"           => $stock > 0
            ],

            "meta" => [
                "title"       => $meta?->meta_title       ?? null,
                "keywords"    => $meta?->meta_keywords    ?? null,
                "description" => $meta?->meta_description ?? null
            ]
        ];
    })->values();

    return response()->json([
        "current_page"    => $page,
        "limit"           => $limit,
        "total_products"  => $total_products,
        "total_pages"     => (int) ceil($total_products / $limit),
        "products"        => $result
    ], 200);
}
}