<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductColor;
use Carbon\Carbon;

class ProductColorController extends Controller
{
    // CREATE COLOR
    public function store(Request $request)
    {
        if (!$request->color_name || !$request->hex_value) {
            return response()->json([
                "error" => "color_name and hex_value are required"
            ], 400);
        }

        if (ProductColor::where('color_name', $request->color_name)->exists()) {
            return response()->json(["error" => "Color name already exists"], 400);
        }

        if (ProductColor::where('hex_value', $request->hex_value)->exists()) {
            return response()->json(["error" => "Hex value already exists"], 400);
        }

        $color = ProductColor::create([
            'color_name' => $request->color_name,
            'hex_value' => $request->hex_value,
            'created_at' => Carbon::now()
        ]);

        return response()->json([
            "message" => "Product color created successfully",
            "id" => $color->id
        ], 200);
    }

    // GET ALL COLORS
    public function index()
    {
        return response()->json(ProductColor::all(), 200);
    }

    // GET SINGLE COLOR
    public function show($id)
    {
        $color = ProductColor::find($id);

        if (!$color) {
            return response()->json(["error" => "Product color not found"], 404);
        }

        return response()->json($color, 200);
    }

    public function update(Request $request, $id)
{
    $color = ProductColor::find($id);

    if (!$color) {
        return response()->json(["error" => "Product color not found"], 404);
    }

    // Get raw request body (multipart/form-data content)
    $raw = $request->getContent();

    // Simple but effective parsing for most cases
    $data = [];
    preg_match_all('/name="([^"]+)"[\s\S]*?[\r\n]{2}([^\r\n]+)/', $raw, $matches, PREG_SET_ORDER);

    foreach ($matches as $match) {
        $field = $match[1];
        $value = trim($match[2]);
        $data[$field] = $value;
    }

    // If we got no data at all → something is wrong with request
    if (empty($data)) {
        return response()->json([
            "error" => "No data received in request"
        ], 400);
    }

    // Validation & uniqueness check (same logic as before)
    if (isset($data['color_name'])) {
        if (
            ProductColor::where('color_name', $data['color_name'])
                ->where('id', '!=', $id)
                ->exists()
        ) {
            return response()->json(["error" => "Color name already exists"], 400);
        }
    }

    if (isset($data['hex_value'])) {
        if (
            ProductColor::where('hex_value', $data['hex_value'])
                ->where('id', '!=', $id)
                ->exists()
        ) {
            return response()->json(["error" => "Hex value already exists"], 400);
        }
    }

    // Update only fields that were sent
    if (isset($data['color_name'])) {
        $color->color_name = $data['color_name'];
    }

    if (isset($data['hex_value'])) {
        $color->hex_value = $data['hex_value'];
    }

    $color->save();

    return response()->json([
        "message" => "Product color updated successfully",
        "data" => $color->fresh()
    ], 200);
}

    // DELETE COLOR
    public function destroy($id)
    {
        ProductColor::where('id', $id)->delete();

        return response()->json([
            "message" => "Product color deleted successfully"
        ], 200);
    }
}
