<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ParentCategory;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ParentCategoryController extends Controller
{
    // CREATE - POST /parent-categories
    public function store(Request $request)
    {
        $name = $request->input('name');

        if (!$name) {
            return response()->json(["error" => "Name is required"], 400);
        }

        if (ParentCategory::whereRaw('LOWER(name) = LOWER(?)', [$name])->exists()) {
            return response()->json(["error" => "Category already exists"], 409);
        }

        $category = ParentCategory::create([
            'name' => $name,
            'created_at' => Carbon::now()
        ]);

        return response()->json([
            "message" => "Parent category created successfully",
            "id" => $category->id
        ], 200);
    }

    // GET ALL - GET /parent-categories
    public function index()
    {
        return response()->json(ParentCategory::all(), 200);
    }

    // GET SINGLE - GET /parent-categories/{id}
    public function show($id)
    {
        $category = ParentCategory::find($id);

        if (!$category) {
            return response()->json(["error" => "Parent category not found"], 404);
        }

        return response()->json($category, 200);
    }

  public function update(Request $request, $id)
{
    $category = ParentCategory::find($id);

    if (!$category) {
        return response()->json(["error" => "Parent category not found"], 404);
    }

    // Manual parsing for FormData + PUT
    $raw = $request->getContent();

    preg_match('/name="name"[\s\S]*?\r?\n\r?\n([^\r\n]+)/', $raw, $matches);

    $name = trim($matches[1] ?? '');

    if ($name === '') {
        return response()->json(["error" => "Name is required"], 400);
    }

    // Check uniqueness (case-insensitive)
    if (strtolower($name) !== strtolower($category->name)) {
        if (ParentCategory::whereRaw('LOWER(name) = LOWER(?)', [$name])
                ->where('id', '!=', $id)
                ->exists()) {
            return response()->json(["error" => "Category name already exists"], 409);
        }
    }

    $category->name = $name;
    $category->save();

    return response()->json(["message" => "Parent category updated successfully"], 200);
}

    // DELETE - DELETE /parent-categories/{id}
    public function destroy($id)
    {
        $category = ParentCategory::find($id);

        if (!$category) {
            return response()->json(["error" => "Parent category not found"], 404);
        }

        $category->delete();

        return response()->json(["message" => "Parent category deleted successfully"], 200);
    }
}