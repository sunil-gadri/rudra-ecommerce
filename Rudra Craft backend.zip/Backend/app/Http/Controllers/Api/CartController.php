<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CartController extends Controller
{
    public function addToCart(Request $request, $customer_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $product_id = $request->input('product_id');
        $quantity   = $request->input('quantity', 1);

        if (!$product_id) {
            return response()->json(['error' => 'product_id is required'], 400);
        }

        if (!is_numeric($quantity) || $quantity < 1) {
            return response()->json(['error' => 'Quantity must be a positive integer'], 400);
        }

        $product = DB::table('product_general_info_tbl')
            ->where('product_id', $product_id)
            ->first();

        if (!$product) {
            return response()->json(['error' => 'Product not found'], 404);
        }

        $current_stock = $product->stock ?? 0;
        if ($current_stock < $quantity) {
            return response()->json([
                'message'         => 'Insufficient stock',
                'available_stock' => $current_stock
            ], 400);
        }

        $existing = DB::table('cart_tbl')
            ->where('customer_id', $customer_id)
            ->where('product_id', $product_id)
            ->first();

        try {
            if ($existing) {
                $new_quantity = $existing->quantity + $quantity;

                if ($new_quantity > $current_stock) {
                    return response()->json([
                        'message'         => 'Not enough stock for updated quantity',
                        'available_stock' => $current_stock
                    ], 200);
                }

                DB::table('cart_tbl')
                    ->where('customer_id', $customer_id)
                    ->where('product_id', $product_id)
                    ->update(['quantity' => $new_quantity]);
            } else {
                DB::table('cart_tbl')->insert([
                    'customer_id' => $customer_id,
                    'product_id'  => $product_id,
                    'quantity'    => $quantity,
                    'created_at'  => now(),
                ]);
            }

            return response()->json(['message' => 'Product added to cart successfully'], 200);
        } catch (\Exception $e) {
            Log::error('Add to cart failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }


    public function incrementQuantity(Request $request, $customer_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $product_id = $request->input('product_id');
        if (!$product_id) {
            return response()->json(['error' => 'product_id is required'], 400);
        }

        $cartItem = DB::table('cart_tbl')
            ->where('customer_id', $customer_id)
            ->where('product_id', $product_id)
            ->first();

        if (!$cartItem) {
            return response()->json(['error' => 'Product not in cart'], 404);
        }

        $stock = DB::table('product_general_info_tbl')
            ->where('product_id', $product_id)
            ->value('stock') ?? 0;

        if ($cartItem->quantity >= $stock) {
            return response()->json(['error' => 'Cannot increment quantity beyond available stock'], 400);
        }

        DB::table('cart_tbl')
            ->where('customer_id', $customer_id)
            ->where('product_id', $product_id)
            ->increment('quantity');

        return response()->json(['message' => 'Quantity incremented'], 200);
    }


    public function decrementQuantity(Request $request, $customer_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $product_id = $request->input('product_id');
        if (!$product_id) {
            return response()->json(['error' => 'product_id is required'], 400);
        }

        $cartItem = DB::table('cart_tbl')
            ->where('customer_id', $customer_id)
            ->where('product_id', $product_id)
            ->first();

        if (!$cartItem) {
            return response()->json(['error' => 'Product not in cart'], 404);
        }

        if ($cartItem->quantity <= 1) {
            DB::table('cart_tbl')
                ->where('customer_id', $customer_id)
                ->where('product_id', $product_id)
                ->delete();
            $message = 'Product removed from cart';
        } else {
            DB::table('cart_tbl')
                ->where('customer_id', $customer_id)
                ->where('product_id', $product_id)
                ->decrement('quantity');
            $message = 'Quantity decremented';
        }

        return response()->json(['message' => $message], 200);
    }


    public function getCart($customer_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $coupon_code = DB::table('cart_tbl')
            ->where('customer_id', $customer_id)
            ->value('coupon_code');

        $cartItems = DB::table('cart_tbl')
            ->where('customer_id', $customer_id)
            ->get(['product_id', 'quantity']);

        $result = [];
        $total_price = 0.0;
        $total_discount = 0.0;
        $total_gst = 0.0;
        $total_amount = 0.0;
        $order_amount = 0.0;

        foreach ($cartItems as $item) {
            $product = DB::table('product_tbl')->where('id', $item->product_id)->first();
            if (!$product) continue;

            $images = DB::table('product_images_tbl')
                ->where('product_id', $item->product_id)
                ->pluck('image')
                ->map(fn($img) => asset('uploads/products/' . $img))
                ->toArray();

            $color = DB::table('product_attributes_tbl')
                ->where('product_id', $item->product_id)
                ->value('product_color');

            $general = DB::table('product_general_info_tbl')
                ->where('product_id', $item->product_id)
                ->first();

            $price           = (float) ($general->price ?? 0);
            $base_price      = (float) ($general->base_price ?? $price);
            $discounted_price = (float) ($general->discounted_price ?? $price);
            $gst_amount      = (float) ($general->gst_amount ?? 0);
            $gst             = (float) ($general->gst ?? 0);
            $discount        = $general->discount ?? null;
            $stock           = $general->stock ?? 0;
            $in_stock        = $stock > 0;

            $base_total      = $base_price * $item->quantity;
            $discount_total  = ($price - $discounted_price) * $item->quantity;
            $gst_total       = $gst_amount * $item->quantity;
            $final_total     = $discounted_price * $item->quantity;

            $total_price    += $base_total;
            $total_discount += $discount_total;
            $total_gst      += $gst_total;
            $total_amount   += $final_total;
            $order_amount   += $price * $item->quantity;

            $result[] = [
                'id'               => $product->id,
                'title'            => $product->product_title,
                'description'      => $product->product_description,
                'created_at'       => (string) $product->created_at,
                'images'           => $images,
                'price'            => $price,
                'gst'              => $gst,
                'discount'         => $discount,
                'base_price'       => $base_price,
                'discounted_price' => $discounted_price,
                'gst_amount'       => $gst_amount,
                'quantity'         => $item->quantity,
                'color'            => $color,
                'in_stock'         => $in_stock,
                'item_total'       => round($final_total, 2),
            ];
        }

        $shipping_cost = $total_amount < 1000 ? 100.0 : 0.0;

        $coupon_discount = 0.0;
        $applied_coupon = null;

        if ($coupon_code) {
            $coupon = DB::table('coupon_tbl')
                ->where('coupon_code', $coupon_code)
                ->where('status', 'active')
                ->first();

            if ($coupon) {
                $applied_coupon = $coupon_code;

                if ($coupon->coupon_type === 'fixed') {
                    $coupon_discount = (float) $coupon->discount_value;
                } elseif ($coupon->coupon_type === 'percentage') {
                    $coupon_discount = ($total_amount * $coupon->discount_value) / 100;
                }

                if ($coupon_discount > $total_amount) {
                    $coupon_discount = $total_amount;
                }
            }
        }

        $payable_amount = $total_amount - $coupon_discount + $shipping_cost;

        return response()->json([
            'message' => 'Cart products retrieved successfully',
            'cart'    => $result,
            'summary' => [
                'total_price'           => round($total_price, 2),
                'total_discount'        => round($total_discount, 2),
                'total_gst'             => round($total_gst, 2),
                'payable_amount'        => round($payable_amount, 2),
                'shipping_cost'         => round($shipping_cost, 2),
                'order_amount'          => round($order_amount, 2),
                'coupon_code'           => $applied_coupon,
                'coupon_discount'       => round($coupon_discount, 2),
                'total_amount_before_coupon' => round($total_amount, 2),
            ]
        ], 200);
    }


    public function applyCoupon(Request $request)
    {
        $user = auth('api')->user();

        $data = $request->validate([
            'customer_id' => 'required|integer|exists:customer_tbl,id',
            'coupon_code' => 'required|string',
            'cart_total'  => 'required|numeric|min:0',
        ]);

        if ($user->id != $data['customer_id']) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $coupon = DB::table('coupon_tbl')
            ->where('coupon_code', $data['coupon_code'])
            ->where('status', 'active')
            ->where(function ($q) {
                $q->whereNull('end_date')->orWhere('end_date', '>=', DB::raw('CURDATE()'));
            })
            ->first();

        if (!$coupon) {
            return response()->json(['error' => 'Invalid or expired coupon'], 400);
        }

        if ($data['cart_total'] < $coupon->min_price) {
            return response()->json([
                'error'     => 'Cart total does not meet coupon minimum price',
                'min_price' => $coupon->min_price,
                'cart_total'=> $data['cart_total']
            ], 400);
        }

        $hasCart = DB::table('cart_tbl')
            ->where('customer_id', $data['customer_id'])
            ->exists();

        if (!$hasCart) {
            return response()->json(['error' => 'Cart not found for customer'], 404);
        }

        $currentCoupon = DB::table('cart_tbl')
            ->where('customer_id', $data['customer_id'])
            ->value('coupon_code');

        if ($currentCoupon === $data['coupon_code']) {
            return response()->json(['message' => 'Coupon already applied'], 200);
        }

        DB::table('cart_tbl')
            ->where('customer_id', $data['customer_id'])
            ->update(['coupon_code' => $data['coupon_code']]);

        return response()->json(['message' => 'Coupon applied successfully'], 200);
    }


    public function removeCoupon(Request $request)
    {
        $data = $request->validate([
            'customer_id' => 'required|integer|exists:customer_tbl,id',
        ]);

        $user = auth('api')->user();
        if ($user->id != $data['customer_id']) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        DB::table('cart_tbl')
            ->where('customer_id', $data['customer_id'])
            ->update(['coupon_code' => null]);

        return response()->json(['message' => 'Coupon removed successfully'], 200);
    }


    public function removeProduct(Request $request, $customer_id, $product_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $exists = DB::table('cart_tbl')
            ->where('customer_id', $customer_id)
            ->where('product_id', $product_id)
            ->exists();

        if (!$exists) {
            return response()->json(['error' => 'Product not found in cart'], 404);
        }

        DB::table('cart_tbl')
            ->where('customer_id', $customer_id)
            ->where('product_id', $product_id)
            ->delete();

        return response()->json(['message' => 'Product removed from cart'], 200);
    }
}