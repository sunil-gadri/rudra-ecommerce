<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Illuminate\Http\Request;
use Carbon\Carbon;

class BrandController extends Controller
{
    // CREATE - POST /brands
    public function store(Request $request)
    {
        $manufacturer_name = $request->input('manufacturer_name');
        $brand_name = $request->input('brand_name');

        if (!$manufacturer_name || !$brand_name) {
            return response()->json([
                "error" => "Manufacturer name and Brand name are required"
            ], 400);
        }

        if (Brand::where('brand_name', $brand_name)->exists()) {
            return response()->json([
                "error" => "Brand name already exists"
            ], 409);
        }

        Brand::create([
            'manufacturer_name' => $manufacturer_name,
            'brand_name' => $brand_name,
            'created_at' => Carbon::now()
        ]);

        return response()->json([
            "message" => "Brand added successfully"
        ], 200);
    }

    // GET ALL - GET /brands
    public function index()
    {
        return response()->json(Brand::all(), 200);
    }

    // GET SINGLE - GET /brands/{id}
    public function show($id)
    {
        $brand = Brand::find($id);

        if (!$brand) {
            return response()->json(["error" => "Brand not found"], 404);
        }

        return response()->json($brand, 200);
    }

    // UPDATE - PUT /brands/{id} (with manual parsing for FormData + PUT)
    public function update(Request $request, $id)
    {
        $brand = Brand::find($id);

        if (!$brand) {
            return response()->json(["error" => "Brand not found"], 404);
        }

        $raw = $request->getContent();

        $data = [];

        // Extract both fields using boundary parsing (more reliable)
        preg_match('/boundary=(.*)$/', $request->header('Content-Type', ''), $matches);
        $boundary = '--' . ($matches[1] ?? '');

        if (strlen($boundary) > 4) {
            $blocks = explode($boundary, $raw);
            array_shift($blocks);
            array_pop($blocks);

            foreach ($blocks as $block) {
                $block = trim($block);
                if ($block === '' || $block === '--') continue;

                if (preg_match('/name="([^"]+)"/', $block, $nameMatch) &&
                    preg_match('/\r?\n\r?\n(.*)$/s', $block, $valueMatch)) {
                    $field = $nameMatch[1];
                    $value = rtrim($valueMatch[1], "\r\n");
                    $data[$field] = trim($value);
                }
            }
        }

        $manufacturer_name = $data['manufacturer_name'] ?? $brand->manufacturer_name;
        $brand_name = $data['brand_name'] ?? $brand->brand_name;

        if ($data['brand_name'] ?? false) {
            if (Brand::where('brand_name', $brand_name)
                    ->where('id', '!=', $id)
                    ->exists()) {
                return response()->json([
                    "error" => "Brand name already exists"
                ], 409);
            }
        }

        $brand->manufacturer_name = $manufacturer_name;
        $brand->brand_name = $brand_name;
        $brand->save();

        return response()->json([
            "message" => "Brand updated successfully"
        ], 200);
    }

    // DELETE - DELETE /brands/{id}
    public function destroy($id)
    {
        $brand = Brand::find($id);

        if (!$brand) {
            return response()->json(["error" => "Brand not found"], 404);
        }

        $brand->delete();

        return response()->json([
            "message" => "Brand deleted successfully"
        ], 200);
    }
}