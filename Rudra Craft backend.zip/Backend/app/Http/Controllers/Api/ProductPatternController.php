<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductPattern;
use Carbon\Carbon;

class ProductPatternController extends Controller
{
    // CREATE
    public function store(Request $request)
    {
        if (!$request->pattern) {
            return response()->json(["error" => "pattern is required"], 400);
        }

        if (ProductPattern::where('pattern', $request->pattern)->exists()) {
            return response()->json(["error" => "Pattern already exists"], 400);
        }

        $pattern = ProductPattern::create([
            'pattern' => $request->pattern,
            'created_at' => Carbon::now()
        ]);

        return response()->json([
            "message" => "Product pattern created successfully",
            "id" => $pattern->id
        ], 200);
    }

    // GET ALL
    public function index()
    {
        return response()->json(ProductPattern::all(), 200);
    }

    // GET SINGLE
    public function show($id)
    {
        $pattern = ProductPattern::find($id);

        if (!$pattern) {
            return response()->json(["error" => "Product pattern not found"], 404);
        }

        return response()->json($pattern, 200);
    }

   public function update(Request $request, $id)
{
    $pattern = ProductPattern::find($id);

    if (!$pattern) {
        return response()->json(['error' => 'Product pattern not found'], 404);
    }

    $raw = $request->getContent();

    // Very simple pattern matching for the 'pattern' field
    preg_match_all('/name="pattern"[\s\S]*?[\r\n]{2}([^\r\n]+)/', $raw, $matches);

    if (empty($matches[1])) {
        return response()->json(['error' => 'Pattern field is missing or empty'], 400);
    }

    $newPattern = trim($matches[1][0]);

    if (empty($newPattern)) {
        return response()->json(['error' => 'Pattern cannot be empty'], 400);
    }

    // Check uniqueness (exclude current record)
    if (ProductPattern::where('pattern', $newPattern)
        ->where('id', '!=', $id)
        ->exists()) {
        return response()->json(['error' => 'Pattern already exists'], 400);
    }

    $pattern->pattern = $newPattern;
    $pattern->save();

    return response()->json([
        'message' => 'Product pattern updated successfully',
        'data' => $pattern
    ]);
}

    // DELETE
    public function destroy($id)
    {
        ProductPattern::where('id', $id)->delete();

        return response()->json([
            "message" => "Product pattern deleted successfully"
        ], 200);
    }
}
