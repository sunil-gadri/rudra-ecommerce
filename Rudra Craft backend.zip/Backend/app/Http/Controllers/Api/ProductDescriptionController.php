<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ProductDescription;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductDescriptionController extends Controller
{
    // CREATE
    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|integer',
            'specifications' => 'required|array'
        ]);

        if (ProductDescription::where('product_id', $request->product_id)->exists()) {
            return response()->json([
                "error" => "Description for this product already exists"
            ], 400);
        }

        $desc = ProductDescription::create([
            'product_id' => $request->product_id,
            'overview' => $request->overview,
            'disclaimer' => $request->disclaimer,
            'specifications' => $request->specifications,
            'created_at' => now()
        ]);

        return response()->json([
            "message" => "Product description created successfully",
            "id" => $desc->id
        ], 200);
    }

    // GET ALL
    public function index()
    {
        $data = ProductDescription::leftJoin(
            'product_tbl',
            'product_description_tbl.product_id',
            '=',
            'product_tbl.id'
        )
        ->select(
            'product_description_tbl.*',
            'product_tbl.product_title'
        )
        ->orderByDesc('created_at')
        ->get();

        return response()->json([
            "count" => $data->count(),
            "data" => $data
        ], 200);
    }

    // GET BY ID
    public function show($id)
    {
        $desc = ProductDescription::find($id);

        if (!$desc) {
            return response()->json(["error" => "Product description not found"], 404);
        }

        return response()->json($desc, 200);
    }

    public function showByProduct($product_id)
    {
        $desc = ProductDescription::where('product_id', $product_id)->first();

        if (!$desc) {
            return response()->json([
                "error" => "Product description not found for this product_id"
            ], 200);
        }

        return response()->json($desc, 200);
    }

    public function update(Request $request, $id)
    {
        $desc = ProductDescription::find($id);

        if (!$desc) {
            return response()->json(["error" => "Product description not found"], 404);
        }

        $updateData = [];

        if ($request->has('product_id')) {
            $updateData['product_id'] = $request->product_id;
        }

        if ($request->has('overview')) {
            $updateData['overview'] = $request->overview;
        }

        if ($request->has('disclaimer')) {
            $updateData['disclaimer'] = $request->disclaimer;
        }

        if ($request->has('specifications')) {
            if (!is_array($request->specifications)) {
                return response()->json([
                    "error" => "specifications must be a JSON object"
                ], 400);
            }
            $updateData['specifications'] = $request->specifications;
        }

        if (empty($updateData)) {
            return response()->json([
                "error" => "No fields provided to update"
            ], 400);
        }

        $desc->update($updateData);

        return response()->json([
            "message" => "Product description updated successfully",
            "data" => $desc
        ], 200);
    }

    // DELETE
    public function destroy($id)
    {
        $desc = ProductDescription::find($id);

        if (!$desc) {
            return response()->json(["error" => "Product description not found"], 404);
        }

        $desc->delete();

        return response()->json([
            "message" => "Product description deleted successfully",
            "deleted_id" => $id
        ], 200);
    }
}
