<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class WishlistController extends Controller
{
    public function addToWishlist(Request $request, $customer_id)
    {
        try {
            $user = auth('api')->user();

            if (!$user || $user->id != $customer_id) {
                return response()->json(['error' => 'Unauthorized access'], 403);
            }

            $product_id = $request->input('product_id');

            if (!$product_id) {
                return response()->json(['error' => 'Product ID is required'], 400);
            }

            if (!DB::table('customer_tbl')->where('id', $customer_id)->exists()) {
                return response()->json(['error' => 'Customer not found'], 404);
            }

            if (!DB::table('product_tbl')->where('id', $product_id)->exists()) {
                return response()->json(['error' => 'Product not found'], 404);
            }

            $exists = DB::table('wishlist_tbl')
                ->where('customer_id', $customer_id)
                ->where('product_id', $product_id)
                ->exists();

            if ($exists) {
                return response()->json(['message' => 'Product already in wishlist'], 200);
            }

            DB::table('wishlist_tbl')->insert([
                'customer_id' => $customer_id,
                'product_id'  => $product_id,
                'created_at'  => now(),
            ]);

            return response()->json(['message' => 'Product added to wishlist'], 201);

        } catch (\Exception $e) {
            Log::error('Add to wishlist failed: ' . $e->getMessage());
            return response()->json(['error' => 'Something went wrong'], 500);
        }
    }

    public function getWishlist($customer_id)
    {
        try {
            $user = auth('api')->user();

            if (!$user || $user->id != $customer_id) {
                return response()->json(['error' => 'Unauthorized access'], 403);
            }

            if (!DB::table('customer_tbl')->where('id', $customer_id)->exists()) {
                return response()->json(['error' => 'Customer not found'], 404);
            }

            $productIds = DB::table('wishlist_tbl')
                ->where('customer_id', $customer_id)
                ->pluck('product_id')
                ->toArray();

            if (empty($productIds)) {
                return response()->json([
                    'message'  => 'Wishlist is empty',
                    'products' => []
                ], 200);
            }

            $products = [];

            foreach ($productIds as $product_id) {
                $product = DB::table('product_tbl')->where('id', $product_id)->first();
                if (!$product) continue;

                $images = DB::table('product_images_tbl')
                    ->where('product_id', $product_id)
                    ->pluck('image')
                    ->map(fn($img) => asset('uploads/products/' . $img))
                    ->toArray();

                $general = DB::table('product_general_info_tbl')
                    ->where('product_id', $product_id)
                    ->first();

                $products[] = [
                    'id'               => $product->id,
                    'title'            => $product->product_title,
                    'description'      => $product->product_description,
                    'created_at'       => (string) $product->created_at,
                    'images'           => $images,
                    'price'            => (float) ($general->price ?? 0),
                    'gst'              => (float) ($general->gst ?? 0),
                    'discount'         => $general->discount ?? null,
                    'base_price'       => (float) ($general->base_price ?? 0),
                    'discounted_price' => (float) ($general->discounted_price ?? 0),
                    'gst_amount'       => (float) ($general->gst_amount ?? 0),
                    'in_stock'         => ($general->stock ?? 0) > 0,
                ];
            }

            return response()->json([
                'message'  => 'Wishlist fetched successfully',
                'products' => $products
            ], 200);

        } catch (\Exception $e) {
            Log::error('Get wishlist failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }

    public function removeFromWishlist($customer_id, $product_id)
    {
        try {
            $user = auth('api')->user();

            if (!$user || $user->id != $customer_id) {
                return response()->json(['error' => 'Unauthorized access'], 403);
            }

            $deleted = DB::table('wishlist_tbl')
                ->where('customer_id', $customer_id)
                ->where('product_id', $product_id)
                ->delete();

            if ($deleted === 0) {
                return response()->json(['error' => 'Product not found in wishlist'], 404);
            }

            return response()->json(['message' => 'Product removed from wishlist'], 200);

        } catch (\Exception $e) {
            Log::error('Remove from wishlist failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }
}