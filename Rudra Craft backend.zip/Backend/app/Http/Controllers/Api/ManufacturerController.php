<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Manufacturer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ManufacturerController extends Controller
{
    protected $uploadPath = 'uploads/manufacturer';

    // CREATE - POST /manufacturer
    public function store(Request $request)
    {
        $manufacturer_name = $request->input('manufacturer_name');

        if (!$manufacturer_name) {
            return response()->json(["error" => "Manufacturer name is required"], 400);
        }

        if (Manufacturer::where('manufacturer_name', $manufacturer_name)->exists()) {
            return response()->json(["error" => "Manufacturer name already exists"], 409);
        }

        $imageName = null;

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            if ($file->isValid() && in_array($file->extension(), ['png', 'jpg', 'jpeg', 'gif'])) {
                $sanitized = Str::slug($manufacturer_name);
                $filename = $sanitized . '_' . time() . '.' . $file->extension();
                $file->move(public_path($this->uploadPath), $filename);
                $imageName = $filename;
            }
        }

        Manufacturer::create([
            'manufacturer_name' => $manufacturer_name,
            'image' => $imageName,
            'created_at' => now()
        ]);

        return response()->json(["message" => "Manufacturer added successfully"], 200);
    }

    // GET ALL - GET /manufacturer
    public function index()
    {
        $manufacturers = Manufacturer::all();

        $manufacturers->transform(function ($m) {
            $m->image_url = $m->image 
                ? asset($this->uploadPath . '/' . $m->image)
                : null;
            return $m;
        });

        return response()->json($manufacturers, 200);
    }

    // GET SINGLE - GET /manufacturer/{id}
    public function show($id)
    {
        $manufacturer = Manufacturer::find($id);

        if (!$manufacturer) {
            return response()->json(["error" => "Manufacturer not found"], 404);
        }

        $manufacturer->image_url = $manufacturer->image 
            ? asset($this->uploadPath . '/' . $manufacturer->image)
            : null;

        return response()->json($manufacturer, 200);
    }

  public function update(Request $request, $id)
{
    $manufacturer = Manufacturer::find($id);

    if (!$manufacturer) {
        return response()->json(["error" => "Manufacturer not found"], 404);
    }

    $raw = $request->getContent();

    $manufacturer_name = $manufacturer->manufacturer_name;
    $imageName = $manufacturer->image;

    // Parse only the fields we need
    preg_match_all('/name="([^"]+)"[\s\S]*?\r?\n\r?\n([^\r\n]*)/', $raw, $matches, PREG_SET_ORDER);

    foreach ($matches as $match) {
        $field = $match[1];
        $value = trim($match[2]);

        if ($field === 'manufacturer_name' && $value !== '') {
            $manufacturer_name = $value;
        }
    }

    // Handle image upload (if sent)
    if (preg_match('/name="image"; filename="([^"]+)".*?\r?\n\r?\n(.*)$/s', $raw, $fileMatch)) {
        $originalFilename = $fileMatch[1];
        $fileContent = $fileMatch[2];

        $extension = strtolower(pathinfo($originalFilename, PATHINFO_EXTENSION));
        if (in_array($extension, ['png', 'jpg', 'jpeg', 'gif'])) {
            // Delete old image
            if ($imageName && file_exists(public_path("uploads/manufacturer/{$imageName}"))) {
                unlink(public_path("uploads/manufacturer/{$imageName}"));
            }

            $sanitized = Str::slug($manufacturer_name);
            $newFilename = $sanitized . '_' . time() . '.' . $extension;
            file_put_contents(public_path("uploads/manufacturer/{$newFilename}"), $fileContent);

            $imageName = $newFilename;
        }
    }

    // Uniqueness check for name
    if ($manufacturer_name !== $manufacturer->manufacturer_name) {
        if (Manufacturer::where('manufacturer_name', $manufacturer_name)
                ->where('id', '!=', $id)
                ->exists()) {
            return response()->json(["error" => "Manufacturer name already exists"], 409);
        }
    }

    // Save
    $manufacturer->manufacturer_name = $manufacturer_name;
    $manufacturer->image = $imageName;
    $manufacturer->save();

    return response()->json(["message" => "Manufacturer updated successfully"], 200);
}

    // DELETE - DELETE /manufacturer/{id}
    public function destroy($id)
    {
        $manufacturer = Manufacturer::find($id);

        if (!$manufacturer) {
            return response()->json(["error" => "Manufacturer not found"], 404);
        }

        // Delete image file
        if ($manufacturer->image && file_exists(public_path($this->uploadPath . '/' . $manufacturer->image))) {
            unlink(public_path($this->uploadPath . '/' . $manufacturer->image));
        }

        $manufacturer->delete();

        return response()->json(["message" => "Manufacturer deleted successfully"], 200);
    }
}