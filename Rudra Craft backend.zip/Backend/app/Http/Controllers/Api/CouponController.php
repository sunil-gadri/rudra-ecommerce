<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\CouponStoreRequest;
use App\Http\Requests\CouponUpdateRequest;
use App\Http\Requests\CouponAvailableRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CouponController extends Controller
{
    /**
     * Automatically update expired coupons to 'expired' status
     */
    private function updateCouponStatusAutomatically()
    {
        $today = Carbon::today();

        DB::table('coupon_tbl')
            ->where('status', 'active')
            ->where('end_date', '<', $today)
            ->update(['status' => 'expired']);
    }

    // POST /api/coupon
    public function store(CouponStoreRequest $request)
    {
        $data = $request->validated();

        $exists = DB::table('coupon_tbl')
            ->where('coupon_code', $data['coupon_code'])
            ->exists();

        if ($exists) {
            return response()->json(['message' => 'Coupon code already exists'], 400);
        }

        DB::table('coupon_tbl')->insert([
            'coupon_code'    => $data['coupon_code'],
            'status'         => $data['status'] ?? 'active',
            'start_date'     => $data['start_date'],
            'end_date'       => $data['end_date'],
            'coupon_type'    => $data['coupon_type'],
            'discount_value' => $data['discount_value'],
            'min_price'      => $data['min_price'] ?? 0,
            'max_price'      => $data['max_price'] ?? 0,
            'coupon_title'   => $data['coupon_title'] ?? null,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        return response()->json(['message' => 'Coupon created successfully'], 201);
    }

    // GET /api/coupon
    public function index(Request $request)
    {
        $this->updateCouponStatusAutomatically();

        $coupons = DB::table('coupon_tbl')
            ->orderByDesc('id')
            ->get();

        return response()->json($coupons);
    }

    // GET /api/coupon/{id}
    public function show($id)
    {
        $this->updateCouponStatusAutomatically();

        $coupon = DB::table('coupon_tbl')->where('id', $id)->first();

        if (!$coupon) {
            return response()->json(['error' => 'Coupon not found'], 404);
        }

        return response()->json($coupon);
    }

    // PUT /api/coupon/{id}
    public function update(CouponUpdateRequest $request, $id)
    {
        $data = $request->validated();

        $coupon = DB::table('coupon_tbl')->where('id', $id)->first();

        if (!$coupon) {
            return response()->json(['error' => 'Coupon not found'], 404);
        }

        // Check duplicate code (excluding current record)
        $duplicate = DB::table('coupon_tbl')
            ->where('coupon_code', $data['coupon_code'])
            ->where('id', '!=', $id)
            ->exists();

        if ($duplicate) {
            return response()->json(['error' => 'Coupon code already exists'], 400);
        }

        DB::table('coupon_tbl')
            ->where('id', $id)
            ->update([
                'coupon_code'    => $data['coupon_code'],
                'status'         => $data['status'] ?? $coupon->status,
                'start_date'     => $data['start_date'] ?? $coupon->start_date,
                'end_date'       => $data['end_date'] ?? $coupon->end_date,
                'coupon_type'    => $data['coupon_type'] ?? $coupon->coupon_type,
                'discount_value' => $data['discount_value'] ?? $coupon->discount_value,
                'min_price'      => $data['min_price'] ?? $coupon->min_price,
                'max_price'      => $data['max_price'] ?? $coupon->max_price,
                'coupon_title'   => $data['coupon_title'] ?? $coupon->coupon_title,
                'updated_at'     => now(),
            ]);

        return response()->json(['message' => 'Coupon updated successfully']);
    }

    // DELETE /api/coupon/{id}
    public function destroy($id)
    {
        $deleted = DB::table('coupon_tbl')->where('id', $id)->delete();

        if (!$deleted) {
            return response()->json(['error' => 'Coupon not found'], 404);
        }

        return response()->json(['message' => 'Coupon deleted successfully']);
    }

    // POST /api/coupon/available
    public function availableCoupons(CouponAvailableRequest $request)
    {
        $this->updateCouponStatusAutomatically();

        $cart_total = (float) $request->input('cart_total');
        $today = Carbon::today();

        $coupons = DB::table('coupon_tbl')
            ->where('status', 'active')
            ->where('start_date', '<=', $today)
            ->where('end_date', '>=', $today)
            ->get();

        $available = [];

        foreach ($coupons as $coupon) {
            $min_price = (float) $coupon->min_price;
            $max_price = (float) $coupon->max_price;

            if ($max_price == 0) {
                // Only min_price check
                if ($cart_total >= $min_price) {
                    $available[] = $coupon;
                }
            } else {
                // min_price <= cart_total (max_price not used in your original logic)
                if ($min_price <= $cart_total) {
                    $available[] = $coupon;
                }
            }
        }

        return response()->json([
            'cart_total'       => $cart_total,
            'available_coupons' => $available,
        ]);
    }
}