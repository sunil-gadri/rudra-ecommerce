<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Razorpay\Api\Api as RazorpayClient;
use Illuminate\Support\Str;
use Carbon\Carbon;

class OrderController extends Controller
{
    protected $razorpay;

    public function __construct()
    {
        $this->razorpay = new RazorpayClient(
            env('RAZORPAY_KEY_ID'),
            env('RAZORPAY_KEY_SECRET')
        );
    }

    // Create Order + Razorpay Order + Invoice
    public function createOrder(Request $request)
    {
        $user = auth('api')->user();

       $data = $request->validate([
    'customer_id' => 'required|integer|exists:customer_tbl,id',

    'items' => 'required|array|min:1',
    'items.*.product_id' => 'required|integer|exists:product_tbl,id',
    'items.*.quantity' => 'required|integer|min:1',
    'items.*.base_price' => 'required|numeric|min:0',
    'items.*.discounted_price' => 'required|numeric|min:0',
    'items.*.discount' => 'nullable|numeric|min:0',
    'items.*.tax' => 'nullable|numeric|min:0',

    'shipping_details' => 'required|array',

    'shipping_details.shipping_name' => 'required|string',
    'shipping_details.shipping_phone' => 'required|string',
    'shipping_details.shipping_email' => 'nullable|email',

    'shipping_details.building' => 'nullable|string',
    'shipping_details.street_address' => 'nullable|string',
    'shipping_details.city' => 'nullable|string',
    'shipping_details.state' => 'nullable|string',
    'shipping_details.postal_code' => 'nullable|string',
    'shipping_details.country' => 'nullable|string',
    'shipping_details.address_type' => 'nullable|string',

    'total_amount' => 'required|numeric|gt:0',
    'total_discount' => 'nullable|numeric|min:0',
    'order_amount' => 'nullable|numeric|min:0',
    'coupon_code' => 'nullable|string|max:50',
    'coupon_discount' => 'nullable|numeric|min:0',
    'shipping_cost' => 'nullable|numeric|min:0',
]);


        if ($user->id != $data['customer_id']) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        try {
            DB::beginTransaction();

            // Get customer info
            $customer = DB::table('customer_tbl')
                ->where('id', $data['customer_id'])
                ->select('first_name', 'last_name', 'email', 'phone')
                ->first();

            if (!$customer) {
                throw new \Exception('Customer not found');
            }

            $shipping = $data['shipping_details'];

            // Create order
            $orderId = DB::table('order_tbl')->insertGetId([
                'customer_id'        => $data['customer_id'],
                'total_amount'       => $data['total_amount'],
                'total_discount'     => $data['total_discount'] ?? 0,
                'order_amount'       => $data['order_amount'] ?? $data['total_amount'],
                'coupon_code'        => $data['coupon_code'] ?? null,
                'coupon_discount'    => $data['coupon_discount'] ?? 0,
                'status'             => 'pending',
                'payment_status'     => 'unpaid',
                'order_at'           => now(),
                'updated_at'         => now(),
                'shipping_name'      => $shipping['shipping_name'] ?? null,
                'shipping_phone'     => $shipping['shipping_phone'] ?? null,
                'shipping_email'     => $shipping['shipping_email'] ?? null,
                'building'           => $shipping['building'] ?? null,
                'street_address'     => $shipping['street_address'] ?? null,
                'city'               => $shipping['city'] ?? null,
                'state'              => $shipping['state'] ?? null,
                'postal_code'        => $shipping['postal_code'] ?? null,
                'country'            => $shipping['country'] ?? null,
                'address_type'       => $shipping['address_type'] ?? null,
                'shipping_cost'      => $data['shipping_cost'] ?? 0,
            ]);

            // Generate invoice number
            $invoiceNumber = "RUDRA-" . str_pad($orderId, 5, '0', STR_PAD_LEFT);

            $invoiceId = DB::table('invoice_tbl')->insertGetId([
                'order_id'       => $orderId,
                'invoice_number' => $invoiceNumber,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);

            // Process each item
            foreach ($data['items'] as $item) {
                $product = DB::table('product_tbl as p')
                    ->join('product_general_info_tbl as g', 'p.id', '=', 'g.product_id')
                    ->where('p.id', $item['product_id'])
                    ->select('p.product_title', 'p.product_description', 'g.price as catalog_price', 'g.stock')
                    ->first();

                if (!$product) {
                    throw new \Exception("Product {$item['product_id']} not found");
                }

                if ($item['quantity'] > $product->stock) {
                    throw new \Exception("Only {$product->stock} items left for product {$item['product_id']}");
                }

                $attr = DB::table('product_attributes_tbl')
                    ->where('product_id', $item['product_id'])
                    ->first();

                $productSize = null;
                if ($attr && $attr->length && $attr->width && $attr->height) {
                    $productSize = "{$attr->length} x {$attr->width} x {$attr->height}";
                    if ($attr->unit) $productSize .= " {$attr->unit}";
                }

                DB::table('order_item_tbl')->insert([
                    'order_id'           => $orderId,
                    'product_id'         => $item['product_id'],
                    'product_name'       => $product->product_title,
                    'product_description'=> $product->product_description ?? '',
                    'price'              => $product->catalog_price,
                    'base_price'         => $item['base_price'],
                    'discount'           => $item['discount'] ?? 0,
                    'discounted_price'   => $item['discounted_price'],
                    'tax'                => $item['tax'] ?? 0,
                    'quantity'           => $item['quantity'],
                    'product_size'       => $productSize,
                    'category'           => $attr->category ?? null,
                    'product_color'      => $attr->product_color ?? null,
                    'product_pattern'    => $attr->product_pattern ?? null,
                    'created_at'         => now(),
                    'updated_at'         => now(),
                ]);

                // Decrease stock - FIXED: Use product_id not id
                DB::table('product_general_info_tbl')
                    ->where('product_id', $item['product_id'])
                    ->decrement('stock', $item['quantity']);
            }

            // Create Razorpay order
            $amountInPaise = (int) (round($data['total_amount'], 2) * 100);

            $razorpayOrder = $this->razorpay->order->create([
                'amount'          => $amountInPaise,
                'currency'        => 'INR',
                'payment_capture' => 1
            ]);

            $razorpayOrderId = $razorpayOrder['id'];

            DB::table('order_tbl')
                ->where('id', $orderId)
                ->update(['razorpay_order_id' => $razorpayOrderId]);

            // Clear cart items
            $productIds = collect($data['items'])->pluck('product_id')->toArray();
            if (!empty($productIds)) {
                DB::table('cart_tbl')
                    ->where('customer_id', $data['customer_id'])
                    ->whereIn('product_id', $productIds)
                    ->delete();
            }

            DB::commit();

            return response()->json([
                'message'            => 'Order and Invoice created successfully',
                'order_id'           => $orderId,
                'invoice_id'         => $invoiceId,
                'invoice_number'     => $invoiceNumber,
                'razorpay_order_id'  => $razorpayOrderId,
                'razorpay_key'       => env('RAZORPAY_KEY_ID'),
                'currency'           => 'INR'
            ], 200);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Order creation failed: ' . $e->getMessage());
            return response()->json([
                'error'    => $e->getMessage()
            ], 400);
        }
    }

    // Verify Razorpay Payment
    public function verifyPayment(Request $request)
    {
        $data = $request->validate([
            'razorpay_order_id'   => 'required|string',
            'razorpay_payment_id' => 'required|string',
            'razorpay_signature'  => 'required|string',
        ]);

        try {
            $this->razorpay->utility->verifyPaymentSignature([
                'razorpay_order_id'   => $data['razorpay_order_id'],
                'razorpay_payment_id' => $data['razorpay_payment_id'],
                'razorpay_signature'  => $data['razorpay_signature'],
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Payment verification failed'], 400);
        }

        try {
            $affected = DB::table('order_tbl')
                ->where('razorpay_order_id', $data['razorpay_order_id'])
                ->update([
                    'razorpay_payment_id' => $data['razorpay_payment_id'],
                    'razorpay_signature'  => $data['razorpay_signature'],
                    'payment_status'      => 'paid',
                    'status'              => 'confirmed',
                    'updated_at'          => now(),
                ]);

            if ($affected == 0) {
                return response()->json(['error' => 'No matching order found for this Razorpay Order ID'], 400);
            }

            $order = DB::table('order_tbl')
                ->where('razorpay_order_id', $data['razorpay_order_id'])
                ->select('id')
                ->first();

            return response()->json([
                'message'              => 'Payment verified and order updated successfully',
                'order_id'             => $order->id,
                'razorpay_order_id'    => $data['razorpay_order_id'],
                'razorpay_payment_id'  => $data['razorpay_payment_id'],
                'razorpay_signature'   => $data['razorpay_signature'],
                'status'               => 'confirmed',
                'payment_status'       => 'paid'
            ], 200);

        } catch (\Exception $e) {
            Log::error('Payment verification update failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }

    // FIXED: Get all orders (admin view - paginated)
    public function getAllOrders(Request $request)
    {
        $page = $request->query('page', 1);
        $limit = $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $totalOrders = DB::table('order_tbl')->count();

        $orders = DB::table('order_tbl as o')
            ->join('customer_tbl as c', 'o.customer_id', '=', 'c.id')
            ->leftJoin('order_item_tbl as oi', 'o.id', '=', 'oi.order_id')
            ->selectRaw("
                o.id,
                CONCAT(c.first_name, ' ', c.last_name) as customer_name,
                o.order_at,
                o.status,
                o.payment_status,
                o.total_amount,
                o.total_discount,
                COALESCE(SUM(oi.quantity), 0) as no_of_items
            ")
            ->groupBy('o.id', 'c.first_name', 'c.last_name', 'o.order_at', 'o.status', 'o.payment_status', 'o.total_amount', 'o.total_discount')
            ->orderByDesc('o.order_at')
            ->limit($limit)
            ->offset($offset)
            ->get();

        return response()->json([
            'orders' => $orders,
            'pagination' => [
                'current_page' => (int)$page,
                'limit'        => (int)$limit,
                'total_orders' => $totalOrders,
                'total_pages'  => ceil($totalOrders / $limit)
            ]
        ], 200);
    }

    public function getOrder($order_id)
    {
        $order = DB::table('order_tbl as o')
            ->leftJoin('customer_tbl as c', 'o.customer_id', '=', 'c.id')
            ->where('o.id', $order_id)
            ->select([
                'o.id as order_id',
                'o.customer_id',
                DB::raw("CONCAT(c.first_name, ' ', c.last_name) as customer_name"),
                'c.email as customer_email',
                'c.phone as customer_contact',
                'o.total_amount',
                'o.total_discount',
                'o.order_amount',
                'o.coupon_code',
                'o.coupon_discount',
                'o.shipping_cost',
                'o.status',
                'o.payment_status',
                'o.order_at',
                'o.updated_at',
                'o.shipping_name',
                'o.shipping_phone',
                'o.shipping_email',
                'o.building',
                'o.street_address',
                'o.city',
                'o.state',
                'o.postal_code',
                'o.country',
                'o.address_type'
            ])
            ->first();

        if (!$order) {
            return response()->json(['error' => 'Order not found'], 404);
        }

        $items = DB::table('order_item_tbl as oi')
            ->where('oi.order_id', $order_id)
            ->select([
                'oi.id as order_item_id',
                'oi.product_id',
                'oi.product_name',
                'oi.product_description',
                'oi.price',
                'oi.base_price',
                'oi.tax',
                'oi.discount',
                'oi.discounted_price',
                'oi.quantity',
                DB::raw('(oi.discounted_price * oi.quantity) as item_total'),
                'oi.product_size',
                'oi.category',
                'oi.product_color',
                'oi.product_pattern'
            ])
            ->get();

        foreach ($items as $item) {
            $image = DB::table('product_images_tbl')
                ->where('product_id', $item->product_id)
                ->orderBy('id')
                ->value('image');

            $item->product_image_url = $image ? '/static/uploads/products/' . $image : null;
        }

        $billing_address = [
            'street_address' => 'Rudra Crafts Pvt Ltd, 520 Mansarovar Plaza, Mansarovar',
            'city'           => 'Jaipur',
            'state'          => 'Rajasthan',
            'postal_code'    => '302020',
            'country'        => 'India'
        ];

        return response()->json([
            'order_id'          => $order->order_id,
            'customer_id'       => $order->customer_id,
            'customer_name'     => $order->customer_name,
            'customer_email'    => $order->customer_email,
            'customer_contact'  => $order->customer_contact,
            'total_amount'      => $order->total_amount,
            'total_discount'    => $order->total_discount,
            'order_amount'      => $order->order_amount,
            'coupon_code'       => $order->coupon_code,
            'coupon_discount'   => $order->coupon_discount,
            'shipping_cost'     => $order->shipping_cost,
            'status'            => $order->status,
            'payment_status'    => $order->payment_status,
            'order_at'          => $order->order_at,
            'updated_at'        => $order->updated_at,
            'shipping_details'  => [
                'shipping_name'   => $order->shipping_name,
                'shipping_phone'  => $order->shipping_phone,
                'shipping_email'  => $order->shipping_email,
                'building'        => $order->building,
                'street_address'  => $order->street_address,
                'city'            => $order->city,
                'state'           => $order->state,
                'postal_code'     => $order->postal_code,
                'country'         => $order->country,
                'address_type'    => $order->address_type,
            ],
            'billing_details'   => $billing_address,
            'items'             => $items
        ], 200);
    }

    // Get customer's orders (simple list with pagination)
    public function getCustomerOrders(Request $request, $customer_id)
    {
        $user = auth('api')->user();
        if ($user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $page   = $request->query('page', 1);
        $limit  = $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $totalItems = DB::table('order_item_tbl as oi')
            ->join('order_tbl as o', 'o.id', '=', 'oi.order_id')
            ->where('o.customer_id', $customer_id)
            ->count();

        $orders = DB::table('order_item_tbl as oi')
            ->join('order_tbl as o', 'o.id', '=', 'oi.order_id')
            ->where('o.customer_id', $customer_id)
            ->selectRaw("
                o.id as order_id,
                o.order_at,
                o.status,
                oi.product_id,
                oi.product_name,
                oi.product_description,
                (SELECT pi.image FROM product_images_tbl pi 
                 WHERE pi.product_id = oi.product_id 
                 ORDER BY pi.id ASC LIMIT 1) as product_image
            ")
            ->orderByDesc('o.order_at')
            ->limit($limit)
            ->offset($offset)
            ->get();

        $results = $orders->map(function ($row) {
            return [
                'order_id'           => $row->order_id,
                'order_at'           => $row->order_at,
                'status'             => $row->status,
                'product_id'         => $row->product_id,
                'product_name'       => $row->product_name,
                'product_description'=> $row->product_description,
                'product_image'      => $row->product_image ? '/static/uploads/products/' . $row->product_image : null,
            ];
        });

        return response()->json([
            'orders' => $results,
            'pagination' => [
                'current_page'   => (int)$page,
                'limit'          => (int)$limit,
                'total_products' => $totalItems,
                'total_pages'    => ceil($totalItems / $limit)
            ]
        ], 200);
    }

    // Update order status (admin / allowed transitions)
    public function updateOrderStatus(Request $request, $order_id)
    {
        $newStatus = $request->input('status');

        if (!$newStatus) {
            return response()->json(['error' => 'Status is required'], 400);
        }

        $allowedTransitions = [
            'pending'   => ['confirmed', 'cancelled'],
            'confirmed' => ['shipped', 'cancelled'],
            'shipped'   => ['delivered'],
            'delivered' => [],
            'cancelled' => [],
        ];

        $order = DB::table('order_tbl')->where('id', $order_id)->select('status')->first();
        if (!$order) {
            return response()->json(['error' => 'Order not found'], 404);
        }

        $current = $order->status;

        if (!in_array($newStatus, $allowedTransitions[$current] ?? [])) {
            return response()->json([
                'error'              => "Invalid status transition from '$current' to '$newStatus'",
                'allowed_transitions'=> $allowedTransitions[$current] ?? []
            ], 400);
        }

        try {
            DB::beginTransaction();

            if ($newStatus === 'cancelled') {
                $items = DB::table('order_item_tbl')
                    ->where('order_id', $order_id)
                    ->select('product_id', 'quantity')
                    ->get();

                foreach ($items as $item) {
                    DB::table('product_general_info_tbl')
                        ->where('product_id', $item->product_id)
                        ->increment('stock', $item->quantity);
                }
            }

            DB::table('order_tbl')
                ->where('id', $order_id)
                ->update([
                    'status'     => $newStatus,
                    'updated_at' => now()
                ]);

            DB::commit();

            return response()->json([
                'message'     => "Order status updated successfully from '$current' to '$newStatus'",
                'order_id'    => $order_id,
                'new_status'  => $newStatus
            ], 200);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Status update failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }

    // Cancel order & restore stock
    public function cancelOrder($order_id)
    {
        $order = DB::table('order_tbl')->where('id', $order_id)->select('status')->first();
        if (!$order) {
            return response()->json(['error' => 'Order not found'], 404);
        }

        if (in_array($order->status, ['delivered', 'cancelled'])) {
            return response()->json([
                'error' => "Cannot cancel order with status '{$order->status}'"
            ], 400);
        }

        try {
            DB::beginTransaction();

            $items = DB::table('order_item_tbl')
                ->where('order_id', $order_id)
                ->select('product_id', 'quantity')
                ->get();

            foreach ($items as $item) {
                DB::table('product_general_info_tbl')
                    ->where('product_id', $item->product_id)
                    ->increment('stock', $item->quantity);
            }

            DB::table('order_tbl')
                ->where('id', $order_id)
                ->update([
                    'status'     => 'cancelled',
                    'updated_at' => now()
                ]);

            DB::commit();

            return response()->json([
                'message'   => 'Order cancelled successfully, stock restored',
                'order_id'  => $order_id
            ], 200);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Cancel order failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }

   public function updateStatus(Request $request, $order_id)
{
    $validated = $request->validate([
        'status' => ['required', 'string', 'in:pending,confirmed,shipped,delivered,cancelled'],
    ]);

    // your existing logic here...
    $current = DB::table('order_tbl')->where('id', $order_id)->value('status');

    if (!$current) {
        return response()->json(['error' => 'Order not found'], 404);
    }

    // transition check, stock restore if cancelled, etc.

    DB::table('order_tbl')
        ->where('id', $order_id)
        ->update([
            'status'     => $validated['status'],
            'updated_at' => now(),
        ]);

    return response()->json([
        'message'    => "Status updated to {$validated['status']}",
        'order_id'   => $order_id,
        'new_status' => $validated['status']
    ]);
}
}
