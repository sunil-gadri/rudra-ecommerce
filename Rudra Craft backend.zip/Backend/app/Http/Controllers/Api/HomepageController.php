<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomepageController extends Controller
{
    // GET /api/products/latest
    public function latestProducts()
    {
        $products = DB::table('product_tbl')
            ->where('product_status', 'active')
            ->orderByDesc('id')
            ->limit(4)
            ->get();

        $result = $this->formatProducts($products);

        return response()->json([
            'message'  => 'Latest products retrieved successfully',
            'products' => $result
        ]);
    }

    // GET /api/products/by-category/{category_id}?page=1&limit=10
    public function productsByCategory($category_id, Request $request)
    {
        $page  = (int) $request->query('page', 1);
        $limit = (int) $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $total = DB::table('product_tbl')
            ->where('product_category_id', $category_id)
            ->where('product_status', 'active')
            ->count();

        $products = DB::table('product_tbl')
            ->where('product_category_id', $category_id)
            ->where('product_status', 'active')
            ->orderByDesc('created_at')
            ->limit($limit)
            ->offset($offset)
            ->get();

        $result = $this->formatProducts($products);

        return response()->json([
            'message'    => $result ? 'Products retrieved successfully' : 'No products found in this category',
            'products'   => $result,
            'pagination' => [
                'current_page'   => $page,
                'limit'          => $limit,
                'total_products' => $total,
                'total_pages'    => (int) ceil($total / $limit),
            ]
        ]);
    }

    // GET /api/products/latest_all?page=1&limit=10
    public function latestProductsAll(Request $request)
    {
        $page  = (int) $request->query('page', 1);
        $limit = (int) $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $total = DB::table('product_tbl')
            ->where('product_status', 'active')
            ->count();

        $products = DB::table('product_tbl')
            ->where('product_status', 'active')
            ->orderByDesc('id')
            ->limit($limit)
            ->offset($offset)
            ->get();

        $result = $this->formatProducts($products);

        return response()->json([
            'message'    => 'Latest products retrieved successfully',
            'products'   => $result,
            'pagination' => [
                'current_page'   => $page,
                'limit'          => $limit,
                'total_products' => $total,
                'total_pages'    => (int) ceil($total / $limit),
            ]
        ]);
    }

    // GET /api/products/best_selling_all?page=1&limit=10
    public function bestSellingAll(Request $request)
    {
        $page  = (int) $request->query('page', 1);
        $limit = (int) $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $bestSelling = DB::table('order_item_tbl as oi')
            ->join('product_tbl as p', 'oi.product_id', '=', 'p.id')
            ->where('p.product_status', 'active')
            ->select('oi.product_id', DB::raw('SUM(oi.quantity) as total_sold'))
            ->groupBy('oi.product_id')
            ->orderByDesc('total_sold')
            ->get();

        $totalItems = $bestSelling->count();

        $paginated = $bestSelling->slice($offset, $limit);

        $result = $this->formatBestSelling($paginated);

        return response()->json([
            'message'    => $result ? 'Best selling products retrieved successfully' : 'No products found for this page',
            'products'   => $result,
            'pagination' => [
                'total_products' => $totalItems,
                'total_pages'    => (int) ceil($totalItems / $limit),
                'current_page'   => $page,
                'limit'          => $limit,
            ]
        ]);
    }

    // GET /api/products/best_selling (top 5)
    public function bestSelling()
    {
        $bestSelling = DB::table('order_item_tbl')
            ->select('product_id', DB::raw('SUM(quantity) as total_sold'))
            ->groupBy('product_id')
            ->orderByDesc('total_sold')
            ->limit(5)
            ->get();

        if ($bestSelling->isEmpty()) {
            return response()->json([
                'message'  => 'No products sold yet',
                'products' => []
            ]);
        }

        $result = $this->formatBestSelling($bestSelling);

        return response()->json([
            'message'  => 'Best selling products retrieved successfully',
            'products' => $result
        ]);
    }

    // POST /api/products/by_discount
    public function productsByDiscount(Request $request)
    {
        $data = $request->json()->all();

        if (empty($data)) {
            return response()->json(['error' => 'JSON body is required'], 400);
        }

        $discount    = $data['discount'] ?? null;
        $category_id = $data['category_id'] ?? null;

        if ($discount === null || $category_id === null) {
            return response()->json(['error' => "Both 'discount' and 'category_id' required"], 400);
        }

        $category_ids = is_array($category_id) ? $category_id : [$category_id];

        $page   = (int) $request->query('page', 1);
        $limit  = (int) $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $total = DB::table('product_general_info_tbl as pgi')
            ->join('product_tbl as pt', 'pgi.product_id', '=', 'pt.id')
            ->where('pgi.discount', $discount)
            ->whereIn('pt.product_category_id', $category_ids)
            ->count();

        $data = DB::table('product_general_info_tbl as pgi')
            ->join('product_tbl as pt', 'pgi.product_id', '=', 'pt.id')
            ->where('pgi.discount', $discount)
            ->whereIn('pt.product_category_id', $category_ids)
            ->select('pgi.*', 'pt.*')
            ->limit($limit)
            ->offset($offset)
            ->get();

        $result = $this->formatProductsFromGeneral($data);

        return response()->json([
            'message'    => $result ? "Products with {$discount}% discount retrieved" : "No products found",
            'products'   => $result,
            'pagination' => [
                'total_products' => $total,
                'total_pages'    => (int) ceil($total / $limit),
                'current_page'   => $page,
                'limit'          => $limit,
            ]
        ]);
    }

    // POST /api/products/by_upto_discount
    public function productsByUptoDiscount(Request $request)
    {
        $data = $request->json()->all();

        if (empty($data)) {
            return response()->json(['error' => 'JSON body is required'], 400);
        }

        $max_discount = $data['discount'] ?? null;
        $category_id  = $data['category_id'] ?? null;

        if ($max_discount === null || $category_id === null) {
            return response()->json(['error' => "Both 'discount' and 'category_id' required"], 400);
        }

        $page   = (int) $request->query('page', 1);
        $limit  = (int) $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $total = DB::table('product_general_info_tbl as pgi')
            ->join('product_tbl as pt', 'pgi.product_id', '=', 'pt.id')
            ->where('pgi.discount', '<=', $max_discount)
            ->where('pt.product_category_id', $category_id)
            ->count();

        $data = DB::table('product_general_info_tbl as pgi')
            ->join('product_tbl as pt', 'pgi.product_id', '=', 'pt.id')
            ->where('pgi.discount', '<=', $max_discount)
            ->where('pt.product_category_id', $category_id)
            ->select('pgi.*', 'pt.*')
            ->orderByDesc('pgi.discount')
            ->limit($limit)
            ->offset($offset)
            ->get();

        $result = $this->formatProducts($data);

        return response()->json([
            'message'    => $result ? "Products with discount ≤ {$max_discount}% retrieved" : "No products found",
            'products'   => $result,
            'pagination' => [
                'total_products' => $total,
                'total_pages'    => (int) ceil($total / $limit),
                'current_page'   => $page,
                'limit'          => $limit,
            ]
        ]);
    }

    // POST /api/products/by_category_price
    public function productsByCategoryAndPrice(Request $request)
    {
        $data = $request->json()->all();

        if (empty($data)) {
            return response()->json(['error' => 'JSON body is required'], 400);
        }

        $category_id = $data['category_id'] ?? null;
        $max_price   = $data['price'] ?? null;

        if ($category_id === null || $max_price === null) {
            return response()->json(['error' => "Both 'category_id' and 'price' required"], 400);
        }

        $page   = (int) $request->query('page', 1);
        $limit  = (int) $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $total = DB::table('product_general_info_tbl as pgi')
            ->join('product_tbl as pt', 'pgi.product_id', '=', 'pt.id')
            ->where('pt.product_category_id', $category_id)
            ->where('pgi.price', '<=', $max_price)
            ->count();

        $data = DB::table('product_general_info_tbl as pgi')
            ->join('product_tbl as pt', 'pgi.product_id', '=', 'pt.id')
            ->where('pt.product_category_id', $category_id)
            ->where('pgi.price', '<=', $max_price)
            ->select('pgi.*', 'pt.*')
            ->orderBy('pgi.price')
            ->limit($limit)
            ->offset($offset)
            ->get();

        $result = $this->formatProducts($data);

        return response()->json([
            'message'    => $result ? "Products ≤ ₹{$max_price} in category retrieved" : "No products found",
            'products'   => $result,
            'pagination' => [
                'total_products' => $total,
                'total_pages'    => (int) ceil($total / $limit),
                'current_page'   => $page,
                'limit'          => $limit,
            ]
        ]);
    }

    // GET /api/homepage
    public function homepage()
    {
        // Sliders - home
        $sliders = DB::table('slider_tbl')
            ->where('key', 'home')
            ->get()
            ->map(fn($s) => (object) [
                ... (array) $s,
                'image_url' => $s->image ? "/static/uploads/sliders/{$s->image}" : null
            ]);

        // Categories
        $categories = DB::table('category_tbl')
            ->get()
            ->map(fn($c) => (object) [
                ... (array) $c,
                'image_url' => $c->image ? "/static/uploads/categories/{$c->image}" : null
            ]);

        // Latest 4 products
        $latestRaw = DB::table('product_tbl')
            ->where('product_status', 'active')
            ->orderByDesc('id')
            ->limit(4)
            ->get();
        $latest = $this->formatProducts($latestRaw);

        // Best selling 5
        $bestRaw = DB::table('order_item_tbl as oi')
            ->join('product_tbl as p', 'oi.product_id', '=', 'p.id')
            ->where('p.product_status', 'active')
            ->select('oi.product_id', DB::raw('SUM(oi.quantity) as total_sold'))
            ->groupBy('oi.product_id')
            ->orderByDesc('total_sold')
            ->limit(5)
            ->get();

        $bestSelling = $this->formatBestSelling($bestRaw);

        // Best seller slider
        $bestSellerSlider = DB::table('slider_tbl')
            ->where('key', 'best seller')
            ->get()
            ->map(fn($s) => (object) [
                ... (array) $s,
                'image_url' => $s->image ? "/static/uploads/sliders/{$s->image}" : null,
                'key' => 'best seller'
            ]);

        // Offers
        $offers = DB::table('offers_tbl')->get();
        $offersResult = [];

        foreach ($offers as $offer) {
            $details = DB::table('offer_detail_tbl')
                ->where('offer_id', $offer->id)
                ->get();

            $offerDetails = $details->map(function ($d) {
                $catIds = $d->product_category_ids ? explode(',', $d->product_category_ids) : [];
                $cats = $catIds ? DB::table('category_tbl')
                    ->whereIn('id', $catIds)
                    ->select('id', 'name')
                    ->get() : collect();

                return [
                    'id'              => $d->id,
                    'text1'           => $d->text1,
                    'text2'           => $d->text2,
                    'categories'      => $cats,
                    'image'           => $d->image,
                    'image_url'       => $d->image ? "/static/uploads/offers/{$d->image}" : null,
                    'details_heading' => $d->details_heading,
                ];
            });

            $offersResult[] = [
                'id'       => $offer->id,
                'heading'  => $offer->heading,
                'key'      => $offer->key,
                'price'    => $offer->price,
                'discount' => $offer->discount,
                'details'  => $offerDetails,
            ];
        }

        return response()->json([
            'status' => true,
            'homecontent' => [
                'sliders'               => $sliders,
                'best_seller_slider'    => $bestSellerSlider,
                'categories'            => $categories,
                'latest_products'       => $latest,
                'best_selling_products' => $bestSelling,
                'offers'                => $offersResult,
            ]
        ]);
    }

    // ─── Helpers ────────────────────────────────────────────────────────────────

    private function formatProducts($products)
    {
        $result = [];

        foreach ($products as $p) {
            $images = DB::table('product_images_tbl')
                ->where('product_id', $p->id)
                ->pluck('image')
                ->map(fn($img) => "/static/uploads/products/{$img}")
                ->toArray();

            $g = DB::table('product_general_info_tbl')
                ->where('product_id', $p->id)
                ->first();

            $result[] = [
                'id'               => $p->id,
                'title'            => $p->product_title,
                'description'      => $p->product_description,
                'created_at'       => $p->created_at,
                'images'           => $images,
                'price'            => $g ? (float)$g->price : 0.0,
                'gst'              => $g ? (float)$g->gst : 0.0,
                'discount'         => $g ? $g->discount : null,
                'base_price'       => $g ? (float)$g->base_price : 0.0,
                'discounted_price' => $g ? (float)$g->discounted_price : 0.0,
                'gst_amount'       => $g ? (float)$g->gst_amount : 0.0,
                'in_stock'         => ($g ? (int)$g->stock : 0) > 0,
            ];
        }

        return $result;
    }

    private function formatBestSelling($items)
    {
        $result = [];

        foreach ($items as $item) {
            $p = DB::table('product_tbl')
                ->where('id', $item->product_id)
                ->where('product_status', 'active')
                ->first();

            if (!$p) continue;

            $images = DB::table('product_images_tbl')
                ->where('product_id', $item->product_id)
                ->pluck('image')
                ->map(fn($img) => "/static/uploads/products/{$img}")
                ->toArray();

            $g = DB::table('product_general_info_tbl')
                ->where('product_id', $item->product_id)
                ->first();

            $result[] = [
                'id'               => $p->id,
                'title'            => $p->product_title,
                'description'      => $p->product_description,
                'created_at'       => $p->created_at,
                'images'           => $images,
                'price'            => $g ? (float)$g->price : 0.0,
                'gst'              => $g ? (float)$g->gst : 0.0,
                'discount'         => $g ? $g->discount : null,
                'base_price'       => $g ? (float)$g->base_price : 0.0,
                'discounted_price' => $g ? (float)$g->discounted_price : 0.0,
                'gst_amount'       => $g ? (float)$g->gst_amount : 0.0,
                'in_stock'         => ($g ? (int)$g->stock : 0) > 0,
                'total_sold'       => $item->total_sold,
            ];
        }

        return $result;
    }

    private function formatProductsFromGeneral($generalData)
    {
        $result = [];

        foreach ($generalData as $g) {
            $p = DB::table('product_tbl')
                ->where('id', $g->product_id)
                ->first();

            if (!$p) continue;

            $images = DB::table('product_images_tbl')
                ->where('product_id', $g->product_id)
                ->pluck('image')
                ->map(fn($img) => "/static/uploads/products/{$img}")
                ->toArray();

            $stock = (int)($g->stock ?? 0);

            $result[] = [
                'id'               => $p->id,
                'title'            => $p->product_title,
                'description'      => $p->product_description,
                'created_at'       => $p->created_at,
                'images'           => $images,
                'price'            => (float)($g->price ?? 0.0),
                'gst'              => (float)($g->gst ?? 0.0),
                'discount'         => $g->discount,
                'base_price'       => (float)($g->base_price ?? 0.0),
                'discounted_price' => (float)($g->discounted_price ?? 0.0),
                'gst_amount'       => (float)($g->gst_amount ?? 0.0),
                'in_stock'         => $stock > 0,
            ];
        }

        return $result;
    }
}