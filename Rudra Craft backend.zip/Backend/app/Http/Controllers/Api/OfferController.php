<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;

class OfferController extends Controller
{
    protected $uploadPath = 'uploads/offers'; // ✅ FIXED: Removed 'static/'

    public function createOffer(Request $request)
    {
        $heading  = $request->input('heading');
        $key      = $request->input('key');
        $price    = $request->input('price');
        $discount = $request->input('discount');
        $details  = $request->input('details');

        if (!$key) {
            return response()->json(["error" => "Missing data"], 400);
        }

        $detailsArray = json_decode($details, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return response()->json(["error" => "Invalid details JSON"], 400);
        }

        DB::beginTransaction();

        try {
            $offerId = DB::table('offers_tbl')->insertGetId([
                'heading'    => $heading,
                'key'        => $key,
                'price'      => $price,
                'discount'   => $discount,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            foreach ($detailsArray as $idx => $detail) {
                $text1               = $detail['text1'] ?? null;
                $text2               = $detail['text2'] ?? null;
                $product_category_ids = $detail['product_category_ids'] ?? null;
                $details_heading     = $detail['details_heading'] ?? null;

                $imageFilename = null;

                $imageKey = "image{$idx}";
                if ($request->hasFile($imageKey)) {
                    $file = $request->file($imageKey);
                    $ext = strtolower($file->getClientOriginalExtension());

                    if (in_array($ext, ['png', 'jpg', 'jpeg', 'gif'])) {
                        $imageFilename = Str::uuid() . '_' . time() . '.' . $ext;
                        $file->move(public_path($this->uploadPath), $imageFilename); // ✅ Fixed path
                    }
                }

                DB::table('offer_detail_tbl')->insert([
                    'offer_id'            => $offerId,
                    'text1'               => $text1,
                    'text2'               => $text2,
                    'product_category_ids'=> $product_category_ids,
                    'image'               => $imageFilename,
                    'details_heading'     => $details_heading,
                ]);
            }

            DB::commit();

            return response()->json([
                "message"   => "Offer created successfully",
                "offer_id"  => $offerId
            ], 200);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(["error" => $e->getMessage()], 500);
        }
    }

    public function getOffers() 
    {
        try {
            $offers = DB::table('offers_tbl')->get();
            $result = [];

            foreach ($offers as $offer) {
                $details = DB::table('offer_detail_tbl')
                    ->where('offer_id', $offer->id)
                    ->get();

                $offerDetails = $details->map(function ($detail) {
                    $categoryIds = $detail->product_category_ids 
                        ? array_filter(explode(',', $detail->product_category_ids))
                        : [];

                    $categories = [];
                    if (!empty($categoryIds)) {
                        $categories = DB::table('category_tbl')
                            ->whereIn('id', $categoryIds)
                            ->get(['id', 'name'])
                            ->keyBy('id')
                            ->toArray();
                        
                        $categories = array_map(function($cat) {
                            return ['id' => $cat->id, 'name' => $cat->name];
                        }, array_values($categories));
                    }

                    return [
                        'id' => $detail->id,
                        'text1' => $detail->text1,
                        'text2' => $detail->text2,
                        'categories' => $categories,
                        'image' => $detail->image,
                        'image_url' => $detail->image ? asset($this->uploadPath . '/' . $detail->image) : null, // ✅ Fixed path
                        'details_heading' => $detail->details_heading
                    ];
                });

                $result[] = [
                    'id' => $offer->id,
                    'heading' => $offer->heading,
                    'key' => $offer->key,
                    'price' => $offer->price,
                    'discount' => $offer->discount,
                    'details' => $offerDetails
                ];
            }

            return response()->json([
                "offers" => $result
            ], 200);

        } catch (\Exception $e) {
            return response()->json(["error" => $e->getMessage()], 500);
        }
    }

    public function updateOffer(Request $request, $offer_id)
    {
        $offer = DB::table('offers_tbl')->where('id', $offer_id)->first();

        if (!$offer) {
            return response()->json(["error" => "Offer not found"], 404);
        }

        DB::beginTransaction();

        try {
            if ($request->filled('heading')) {
                DB::table('offers_tbl')
                    ->where('id', $offer_id)
                    ->update(['heading' => $request->heading]);
            }
            if ($request->filled('key')) {
                DB::table('offers_tbl')
                    ->where('id', $offer_id)
                    ->update(['key' => $request->key]);
            }
            if ($request->filled('price')) {
                DB::table('offers_tbl')
                    ->where('id', $offer_id)
                    ->update(['price' => $request->price]);
            }
            if ($request->filled('discount')) {
                DB::table('offers_tbl')
                    ->where('id', $offer_id)
                    ->update(['discount' => $request->discount]);
            }

            $detailsJson = $request->input('details');
            if ($detailsJson) {
                $detailsArray = json_decode($detailsJson, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    throw new \Exception("Invalid details JSON");
                }

                foreach ($detailsArray as $idx => $detail) {
                    $detailId = $detail['id'] ?? null;
                    if (!$detailId) continue;

                    $check = DB::table('offer_detail_tbl')
                        ->where('id', $detailId)
                        ->where('offer_id', $offer_id)
                        ->exists();

                    if (!$check) continue;

                    $updateFields = [];
                    $updateValues = [];

                    if (array_key_exists('text1', $detail)) {
                        $updateFields[] = 'text1 = ?';
                        $updateValues[] = $detail['text1'];
                    }
                    if (array_key_exists('text2', $detail)) {
                        $updateFields[] = 'text2 = ?';
                        $updateValues[] = $detail['text2'];
                    }
                    if (array_key_exists('product_category_ids', $detail)) {
                        $updateFields[] = 'product_category_ids = ?';
                        $updateValues[] = $detail['product_category_ids'];
                    }
                    if (array_key_exists('details_heading', $detail)) {
                        $updateFields[] = 'details_heading = ?';
                        $updateValues[] = $detail['details_heading'];
                    }

                    $imageKey = "image{$idx}";
                    if ($request->hasFile($imageKey)) {
                        $file = $request->file($imageKey);
                        $ext = strtolower($file->getClientOriginalExtension());

                        if (in_array($ext, ['png', 'jpg', 'jpeg', 'gif'])) {
                            $oldImage = DB::table('offer_detail_tbl')
                                ->where('id', $detailId)
                                ->value('image');

                            if ($oldImage) {
                                $oldPath = public_path($this->uploadPath . '/' . $oldImage); // ✅ Fixed path
                                if (File::exists($oldPath)) {
                                    File::delete($oldPath);
                                }
                            }

                            $newFilename = Str::uuid() . '_' . time() . '.' . $ext;
                            $file->move(public_path($this->uploadPath), $newFilename); // ✅ Fixed path

                            $updateFields[] = 'image = ?';
                            $updateValues[] = $newFilename;
                        }
                    }

                    if (!empty($updateFields)) {
                        $query = "UPDATE offer_detail_tbl SET " . implode(', ', $updateFields) . " WHERE id = ?";
                        $updateValues[] = $detailId;
                        DB::update($query, $updateValues);
                    }
                }
            }

            DB::commit();

            return response()->json(["message" => "Offer updated successfully"], 200);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(["error" => $e->getMessage()], 500);
        }
    }

    public function getOfferById($offer_id)
    {
        $offer = DB::table('offers_tbl')->where('id', $offer_id)->first();

        if (!$offer) {
            return response()->json(["error" => "Offer not found"], 404);
        }

        $details = DB::table('offer_detail_tbl')
            ->where('offer_id', $offer_id)
            ->get();

        $offerDetails = [];

        foreach ($details as $detail) {
            $categoryIds = $detail->product_category_ids
                ? array_filter(explode(',', $detail->product_category_ids))
                : [];

            $categoryNames = [];
            if (!empty($categoryIds)) {
                $categoryNames = DB::table('category_tbl')
                    ->whereIn('id', $categoryIds)
                    ->pluck('name')
                    ->toArray();
            }

            $imageUrl = $detail->image
                ? asset($this->uploadPath . '/' . $detail->image) // ✅ Fixed path
                : null;

            $offerDetails[] = [
                'id'             => $detail->id,
                'text1'          => $detail->text1,
                'text2'          => $detail->text2,
                'categories'     => $categoryNames,
                'image'          => $detail->image,
                'image_url'      => $imageUrl,
                'details_heading'=> $detail->details_heading,
            ];
        }

        return response()->json([
            'id'        => $offer->id,
            'heading'   => $offer->heading,
            'key'       => $offer->key,
            'price'     => $offer->price,
            'discount'  => $offer->discount,
            'details'   => $offerDetails,
        ], 200);
    }

    public function deleteOffer($offer_id)
    {
        $offer = DB::table('offers_tbl')->where('id', $offer_id)->first();

        if (!$offer) {
            return response()->json(["error" => "Offer not found"], 404);
        }

        $details = DB::table('offer_detail_tbl')
            ->where('offer_id', $offer_id)
            ->get();

        foreach ($details as $detail) {
            if ($detail->image) {
                $path = public_path($this->uploadPath . '/' . $detail->image); // ✅ Fixed path
                if (File::exists($path)) {
                    File::delete($path);
                }
            }
        }

        DB::table('offer_detail_tbl')->where('offer_id', $offer_id)->delete();
        DB::table('offers_tbl')->where('id', $offer_id)->delete();

        return response()->json(["message" => "Offer and related details deleted successfully"], 200);
    }

    public function getOfferByKey($key)
    {
        $offer = DB::table('offers_tbl')->where('key', $key)->first();

        if (!$offer) {
            return response()->json(["error" => "Offer not found"], 404);
        }

        $details = DB::table('offer_detail_tbl')
            ->where('offer_id', $offer->id)
            ->get();

        $allCategoryIds = [];
        foreach ($details as $detail) {
            if ($detail->product_category_ids) {
                $ids = array_filter(explode(',', $detail->product_category_ids));
                $allCategoryIds = array_merge($allCategoryIds, $ids);
            }
        }

        $categoryMap = [];
        if (!empty($allCategoryIds)) {
            $categoryMap = DB::table('category_tbl')
                ->whereIn('id', array_unique($allCategoryIds))
                ->pluck('name', 'id')
                ->toArray();
        }

        $offerDetails = [];
        foreach ($details as $detail) {
            $ids = $detail->product_category_ids
                ? array_filter(explode(',', $detail->product_category_ids))
                : [];

            $categoryNames = [];
            foreach ($ids as $cid) {
                if (isset($categoryMap[$cid])) {
                    $categoryNames[] = $categoryMap[$cid];
                }
            }

            $imageUrl = $detail->image
                ? asset($this->uploadPath . '/' . $detail->image) // ✅ Fixed path
                : null;

            $offerDetails[] = [
                'id'             => $detail->id,
                'text1'          => $detail->text1,
                'text2'          => $detail->text2,
                'categories'     => $categoryNames,
                'image'          => $detail->image,
                'image_url'      => $imageUrl,
                'details_heading'=> $detail->details_heading,
            ];
        }

        return response()->json([
            'id'        => $offer->id,
            'heading'   => $offer->heading,
            'key'       => $offer->key,
            'price'     => $offer->price,
            'discount'  => $offer->discount,
            'details'   => $offerDetails,
        ], 200);
    }
}
