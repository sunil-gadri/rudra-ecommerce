<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Gst;
use Illuminate\Http\Request;
use Carbon\Carbon;

class GstController extends Controller
{
    // CREATE GST - POST /gst
    public function store(Request $request)
    {
        $gst = $request->input('gst');

        if (!$gst) {
            return response()->json(["error" => "gst is required"], 400);
        }

        if (Gst::where('gst', $gst)->exists()) {
            return response()->json(["error" => "GST already exists"], 400);
        }

        $gstRecord = Gst::create([
            'gst' => $gst,
            'created_at' => Carbon::now()
        ]);

        return response()->json([
            "message" => "GST created successfully",
            "id" => $gstRecord->id
        ], 200);
    }

    // GET ALL - GET /gst
    public function index()
    {
        return response()->json(Gst::all(), 200);
    }

    // GET SINGLE - GET /gst/{id}
    public function show($id)
    {
        $gst = Gst::find($id);

        if (!$gst) {
            return response()->json(["error" => "GST not found"], 404);
        }

        return response()->json($gst, 200);
    }

    // UPDATE - PUT /gst/{id}
   public function update(Request $request, $id)
{
    $gstRecord = Gst::find($id);

    if (!$gstRecord) {
        return response()->json(["error" => "GST not found"], 404);
    }

    // Get raw multipart body
    $raw = $request->getContent();

    // Simple & reliable regex for 'gst' field
    preg_match('/name="gst"[\s\S]*?[\r\n]{2}([^\r\n]+)/', $raw, $matches);

    $gst = trim($matches[1] ?? '');

    // Validation - same as Flask
    if ($gst === '') {
        return response()->json(["error" => "No fields to update"], 400);
    }

    // Uniqueness check (exclude current record)
    if (Gst::where('gst', $gst)
            ->where('id', '!=', $id)
            ->exists()) {
        return response()->json(["error" => "GST already exists"], 400);
    }

    // Update & save
    $gstRecord->gst = $gst;
    $gstRecord->save();

    return response()->json([
        "message" => "GST updated successfully"
    ], 200);
}

    // DELETE - DELETE /gst/{id}
    public function destroy($id)
    {
        $gst = Gst::find($id);

        if (!$gst) {
            return response()->json(["error" => "GST not found"], 404);
        }

        $gst->delete();

        return response()->json([
            "message" => "GST deleted successfully"
        ], 200);
    }
}