<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SpecificationHeading;
use Illuminate\Http\Request;
use Carbon\Carbon;

class SpecificationHeadingController extends Controller
{
    // CREATE - POST /specification_heading
    public function store(Request $request)
    {
        $heading = $request->input('specification_heading');

        if (!$heading) {
            return response()->json(["error" => "Specification Heading is required"], 400);
        }

        if (SpecificationHeading::where('specification_heading', $heading)->exists()) {
            return response()->json(["error" => "Specification already exists"], 400);
        }

        $record = SpecificationHeading::create([
            'specification_heading' => $heading,
            'created_at' => Carbon::now()
        ]);

        return response()->json([
            "message" => "Specification Heading created successfully",
            "id" => $record->id
        ], 200);
    }

    // GET ALL - GET /specification_heading
    public function index()
    {
        return response()->json(SpecificationHeading::all(), 200);
    }

    // GET SINGLE - GET /specification_heading/{id}
    public function show($id)
    {
        $heading = SpecificationHeading::find($id);

        if (!$heading) {
            return response()->json(["error" => "Specification Heading not found"], 404);
        }

        return response()->json($heading, 200);
    }

   public function update(Request $request, $id)
{
    $heading = SpecificationHeading::find($id);

    if (!$heading) {
        return response()->json(["error" => "Specification Heading not found"], 404);
    }

    // Get raw multipart/form-data body
    $raw = $request->getContent();

    // Extract boundary from Content-Type header
    preg_match('/boundary=(.*)$/', $request->header('Content-Type', ''), $matches);
    $boundary = '--' . ($matches[1] ?? '');

    if (strlen($boundary) < 5) {
        return response()->json(["error" => "Invalid request format"], 400);
    }

    $data = [];

    // Split into parts
    $blocks = explode($boundary, $raw);
    array_shift($blocks);
    array_pop($blocks);

    foreach ($blocks as $block) {
        $block = trim($block);
        if ($block === '' || $block === '--') continue;

        if (preg_match('/name="specification_heading"/', $block) &&
            preg_match('/\r?\n\r?\n(.*)$/s', $block, $valueMatch)) {
            
            $value = rtrim($valueMatch[1], "\r\n");
            $data['specification_heading'] = trim($value);
        }
    }

    // No field received
    if (!isset($data['specification_heading']) || $data['specification_heading'] === '') {
        return response()->json(["error" => "No fields to update"], 400);
    }

    $newValue = $data['specification_heading'];

    // Uniqueness check (exclude current record)
    if (SpecificationHeading::where('specification_heading', $newValue)
            ->where('id', '!=', $id)
            ->exists()) {
        return response()->json(["error" => "Specification already exists"], 400);
    }

    // Update
    $heading->specification_heading = $newValue;
    $heading->save();

    return response()->json([
        "message" => "specification heading updated successfully"
    ], 200);
}
    // DELETE - DELETE /specification_heading/{id}
    public function destroy($id)
    {
        $heading = SpecificationHeading::find($id);

        if (!$heading) {
            return response()->json(["error" => "Specification Heading not found"], 404);
        }

        $heading->delete();

        return response()->json([
            "message" => "specification heading deleted successfully"
        ], 200);
    }
}