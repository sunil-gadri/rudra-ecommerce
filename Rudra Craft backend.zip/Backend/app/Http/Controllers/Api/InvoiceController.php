<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\InvoicePdfService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class InvoiceController extends Controller
{
    private function fetchInvoiceData($invoiceId)
    {
        $invoice = DB::table('invoice_tbl as i')
            ->join('order_tbl as o', 'i.order_id', '=', 'o.id')
            ->leftJoin('customer_tbl as c', 'o.customer_id', '=', 'c.id')
            ->where('i.id', $invoiceId)
            ->select([
                'i.id as invoice_id',
                'i.invoice_number',
                'i.created_at as invoice_date',
                'i.updated_at',
                'o.id as order_id',
                'o.customer_id',
                'o.total_amount',
                'o.status as order_status',
                'o.payment_status',
                'o.order_at',
                'o.shipping_name',
                'o.shipping_phone',
                'o.shipping_email',
                'o.building',
                'o.street_address',
                'o.city',
                'o.state',
                'o.postal_code',
                'o.country',
                'o.address_type',
                'o.shipping_cost',
                'o.coupon_code',
                'o.coupon_discount',
                DB::raw("CONCAT(c.first_name, ' ', c.last_name) AS customer_name"),
                'c.email',
                'c.phone'
            ])
            ->first();

        if (!$invoice) {
            return null;
        }

        $items = DB::table('order_item_tbl as oi')
            ->where('oi.order_id', $invoice->order_id)
            ->select([
                'oi.id as order_item_id',
                'oi.product_name',
                'oi.quantity',
                'oi.base_price',
                'oi.tax',
                'oi.discount',
                'oi.price',
                'oi.product_color',
                'oi.product_size',
                'oi.category',
                'oi.product_pattern'
            ])
            ->get();

        $billing_address = [
            'building'       => 'Rudra Crafts Pvt Ltd, 520 Mansarovar Plaza',
            'street_address' => 'Mansarovar',
            'city'           => 'Jaipur',
            'state'          => 'Rajasthan',
            'postal_code'    => '302020',
            'country'        => 'India'
        ];

        $total_base_price = 0;
        $total_tax        = 0;
        $total_discount   = 0;

        $new_items = [];
        foreach ($items as $item) {
            $base = (float) ($item->base_price ?? 0);
            $tax  = (float) ($item->tax ?? 0);
            $discount = (float) ($item->discount ?? 0);

            $total_base_price += $base;
            $total_tax        += $tax;
            $total_discount   += $discount;

            $new_items[] = [
                'order_item_id'   => $item->order_item_id,
                'product_name'    => $item->product_name,
                'quantity'        => (int) $item->quantity,
                'base_price'      => number_format($base, 2, '.', ''),
                'tax'             => number_format($tax, 2, '.', ''),
                'discount'        => number_format($discount, 2, '.', ''),
                'price'           => number_format((float) $item->price, 2, '.', ''),
                'product_color'   => $item->product_color,
                'product_size'    => $item->product_size,
                'category'        => $item->category,
                'product_pattern' => $item->product_pattern,
            ];
        }

        $shipping_cost   = (float) ($invoice->shipping_cost ?? 0);
        $coupon_discount = (float) ($invoice->coupon_discount ?? 0);

        $total_amount = $total_base_price + $total_tax - $total_discount - $coupon_discount + $shipping_cost;

        return [
            'invoice_id'      => $invoice->invoice_id,
            'invoice_number'  => $invoice->invoice_number,
            'invoice_date'    => $invoice->invoice_date,
            'updated_at'      => $invoice->updated_at,
            'order_id'        => $invoice->order_id,
            'customer_name'   => $invoice->customer_name,
            'email'           => $invoice->email,
            'phone'           => $invoice->phone,
            'shipping_address' => [
                'name'          => $invoice->shipping_name,
                'phone'         => $invoice->shipping_phone,
                'email'         => $invoice->shipping_email,
                'building'      => $invoice->building,
                'street_address' => $invoice->street_address,
                'city'          => $invoice->city,
                'state'         => $invoice->state,
                'postal_code'   => $invoice->postal_code,
                'country'       => $invoice->country,
                'address_type'  => $invoice->address_type,
            ],
            'billing_address' => $billing_address,
            'items'           => $new_items,
            'base_price'      => number_format($total_base_price, 2, '.', ''),
            'tax'             => number_format($total_tax, 2, '.', ''),
            'discount'        => number_format($total_discount, 2, '.', ''),
            'coupon_code'     => $invoice->coupon_code,
            'coupon_discount' => number_format($coupon_discount, 2, '.', ''),
            'shipping_cost'   => number_format($shipping_cost, 2, '.', ''),
            'total_amount'    => number_format($total_amount, 2, '.', ''),
            'order_status'    => $invoice->order_status,
            'payment_status'  => $invoice->payment_status,
        ];
    }

    public function index(Request $request)
    {
        $page  = (int) $request->query('page', 1);
        $limit = (int) $request->query('limit', 10);
        $offset = ($page - 1) * $limit;

        $total = DB::table('invoice_tbl')->count();

        $invoices = DB::table('invoice_tbl as i')
            ->join('order_tbl as o', 'i.order_id', '=', 'o.id')
            ->join('customer_tbl as c', 'o.customer_id', '=', 'c.id')
            ->select([
                'i.id as invoice_id',
                'i.invoice_number',
                'i.created_at as invoice_date',
                'i.updated_at',
                'o.id as order_id',
                'o.total_amount',
                'o.status as order_status',
                'o.payment_status',
                DB::raw("CONCAT(c.first_name, ' ', c.last_name) AS customer_name"),
                'c.email',
                'c.phone'
            ])
            ->orderByDesc('i.created_at')
            ->limit($limit)
            ->offset($offset)
            ->get();

        return response()->json([
            'data' => $invoices,
            'pagination' => [
                'total'       => $total,
                'page'        => $page,
                'limit'       => $limit,
                'total_pages' => (int) ceil($total / $limit),
            ]
        ]);
    }

    public function show($invoice_id)
    {
        $data = $this->fetchInvoiceData($invoice_id);
        if (!$data) {
            return response()->json(['error' => 'Invoice not found'], 404);
        }
        return response()->json($data);
    }

    public function preview($invoice_id)
    {
        $data = $this->fetchInvoiceData($invoice_id);
        if (!$data) {
            return response()->json(['error' => 'Invoice not found'], 404);
        }

        $pdfService = new InvoicePdfService();
        $pdfContent = $pdfService->generateInvoicePdf($data);

        return Response::make($pdfContent, 200, [
            'Content-Type'        => 'application/pdf',
            'Content-Disposition' => 'inline; filename="invoice-preview-' . $invoice_id . '.pdf"',
        ]);
    }

    public function download($invoice_id)
    {
        $data = $this->fetchInvoiceData($invoice_id);
        if (!$data) {
            return response()->json(['error' => 'Invoice not found'], 404);
        }

        $pdfService = new InvoicePdfService();
        $pdfContent = $pdfService->generateInvoicePdf($data);

        return Response::make($pdfContent, 200, [
            'Content-Type'        => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="invoice-' . $invoice_id . '.pdf"',
        ]);
    }
}