<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class AddressController extends Controller
{
    public function addAddress(Request $request, $customer_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'full_name'      => 'required|string|max:255',
            'phone'          => 'required|string|max:20',
            'email'          => 'nullable|email|max:255',
            'building'       => 'nullable|string|max:255',
            'street_address' => 'required|string|max:255',
            'city'           => 'required|string|max:100',
            'state'          => 'required|string|max:100',
            'postal_code'    => 'required|string|max:20',
            'country'        => 'required|string|max:100',
            'address_type'   => 'required|string|max:50',
            'created_at'     => 'nullable|date',
        ]);

        try {
            DB::beginTransaction();

            // Check if this is the first address → make it default
            $hasAddress = DB::table('address_tbl')
                ->where('customer_id', $customer_id)
                ->exists();

            $is_default = !$hasAddress;

            // If setting as default, unset others
            if ($is_default) {
                DB::table('address_tbl')
                    ->where('customer_id', $customer_id)
                    ->update(['is_default' => false]);
            }

            $created_at = $request->filled('created_at')
                ? Carbon::parse($request->created_at)
                : now();

            DB::table('address_tbl')->insert([
                'customer_id'     => $customer_id,
                'full_name'       => $validated['full_name'],
                'phone'           => $validated['phone'],
                'email'           => $validated['email'] ?? null,
                'building'        => $validated['building'] ?? null,
                'street_address'  => $validated['street_address'],
                'city'            => $validated['city'],
                'state'           => $validated['state'],
                'postal_code'     => $validated['postal_code'],
                'country'         => $validated['country'],
                'address_type'    => $validated['address_type'],
                'is_default'      => $is_default,
                'created_at'      => $created_at,
                'updated_at'      => now(),
            ]);

            DB::commit();

            return response()->json(['message' => 'Address added successfully'], 200);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Add address failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }


    public function getAddresses($customer_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        try {
            $addresses = DB::table('address_tbl')
                ->where('customer_id', $customer_id)
                ->get();

            return response()->json(['addresses' => $addresses], 200);
        } catch (\Exception $e) {
            Log::error('Get addresses failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }


    public function updateAddress(Request $request, $customer_id, $address_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'full_name'      => 'sometimes|required|string|max:255',
            'phone'          => 'sometimes|required|string|max:20',
            'email'          => 'nullable|email|max:255',
            'building'       => 'nullable|string|max:255',
            'street_address' => 'sometimes|required|string|max:255',
            'city'           => 'sometimes|required|string|max:100',
            'state'          => 'sometimes|required|string|max:100',
            'postal_code'    => 'sometimes|required|string|max:20',
            'country'        => 'sometimes|required|string|max:100',
            'address_type'   => 'sometimes|required|string|max:50',
            'is_default'     => 'sometimes|boolean',
            'created_at'     => 'nullable|date',
        ]);

        try {
            DB::beginTransaction();

            $address = DB::table('address_tbl')
                ->where('id', $address_id)
                ->where('customer_id', $customer_id)
                ->first();

            if (!$address) {
                return response()->json(['error' => 'Address not found'], 404);
            }

            // If setting as default, unset others
            if ($request->boolean('is_default')) {
                DB::table('address_tbl')
                    ->where('customer_id', $customer_id)
                    ->where('id', '!=', $address_id)
                    ->update(['is_default' => false]);
            }

            $updateData = [
                'full_name'      => $validated['full_name']       ?? $address->full_name,
                'phone'          => $validated['phone']           ?? $address->phone,
                'email'          => $validated['email']           ?? $address->email,
                'building'       => $validated['building']        ?? $address->building,
                'street_address' => $validated['street_address']  ?? $address->street_address,
                'city'           => $validated['city']            ?? $address->city,
                'state'          => $validated['state']           ?? $address->state,
                'postal_code'    => $validated['postal_code']     ?? $address->postal_code,
                'country'        => $validated['country']         ?? $address->country,
                'address_type'   => $validated['address_type']    ?? $address->address_type,
                'is_default'     => $request->boolean('is_default', $address->is_default),
                'updated_at'     => now(),
            ];

            if ($request->filled('created_at')) {
                $updateData['created_at'] = Carbon::parse($request->created_at);
            }

            DB::table('address_tbl')
                ->where('id', $address_id)
                ->where('customer_id', $customer_id)
                ->update($updateData);

            DB::commit();

            return response()->json(['message' => 'Address updated successfully'], 200);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Update address failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }


    public function deleteAddress($customer_id, $address_id)
    {
        $user = auth('api')->user();
        if (!$user || $user->id != $customer_id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        try {
            $deleted = DB::table('address_tbl')
                ->where('id', $address_id)
                ->where('customer_id', $customer_id)
                ->delete();

            if ($deleted === 0) {
                return response()->json(['error' => 'Address not found'], 404);
            }

            return response()->json(['message' => 'Address deleted successfully'], 200);
        } catch (\Exception $e) {
            Log::error('Delete address failed: ' . $e->getMessage());
            return response()->json(['error' => 'Server error'], 500);
        }
    }
}