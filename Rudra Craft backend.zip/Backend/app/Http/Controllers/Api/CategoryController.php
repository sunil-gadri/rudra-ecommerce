<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    protected $uploadPath = 'uploads/categories';

    public function __construct()
    {
        if (!File::exists(public_path($this->uploadPath))) {
            File::makeDirectory(public_path($this->uploadPath), 0755, true);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name'            => 'required|string|max:255',
            'parent_category' => 'required|exists:category_tbl,id',
            'description'     => 'nullable|string',
            'status'          => 'nullable',
            'image'           => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()->first()], 400);
        }

        $name = $request->input('name');

        if (Category::whereRaw('LOWER(name) = ?', [strtolower($name)])->exists()) {
            return response()->json(['error' => 'Category name already exists'], 409);
        }

        $imageFilename = null;
        if ($request->hasFile('image') && $request->file('image')->isValid()) {
            $file = $request->file('image');
            $ext = $file->getClientOriginalExtension();
            $imageFilename = Str::uuid()->toString() . '.' . $ext;
            $file->move(public_path($this->uploadPath), $imageFilename);
        }

        $category = Category::create([
            'name'            => $name,
            'description'     => $request->input('description'),
            'parent_category' => $request->input('parent_category'),
            'status'          => $request->input('status', 'active'),
            'image'           => $imageFilename,
        ]);

        return response()->json([
            'message'   => 'Category created successfully',
            'id'        => $category->id,
            'image_url' => $imageFilename ? asset($this->uploadPath . '/' . $imageFilename) : null
        ], 201);
    }

    public function index()
    {
        $categories = Category::all()->map(function ($cat) {
            return [
                'id'             => $cat->id,
                'name'           => $cat->name,
                'description'    => $cat->description,
                'parent_category'=> $cat->parent_category,
                'status'         => $cat->status,
                'image'          => $cat->image,
                'image_url'      => $cat->image ? asset($this->uploadPath . '/' . $cat->image) : null,
                'created_at'     => $cat->created_at,
                'updated_at'     => $cat->updated_at,
            ];
        });

        return response()->json($categories);
    }

    public function show($id)
    {
        $category = Category::find($id);

        if (!$category) {
            return response()->json(['error' => 'Category not found'], 404);
        }

        return response()->json([
            'id'             => $category->id,
            'name'           => $category->name,
            'description'    => $category->description,
            'parent_category'=> $category->parent_category,
            'status'         => $category->status,
            'image'          => $category->image,
            'image_url'      => $category->image ? asset($this->uploadPath . '/' . $category->image) : null,
            'created_at'     => $category->created_at,
            'updated_at'     => $category->updated_at,
        ]);
    }

    public function update(Request $request, $id)
    {
        $category = Category::find($id);

        if (!$category) {
            return response()->json(['error' => 'Category not found'], 404);
        }

        $validator = Validator::make($request->all(), [
            'name'            => 'sometimes|required|string|max:255',
            'parent_category' => 'sometimes|exists:category_tbl,id',
            'description'     => 'nullable|string',
            'status'          => 'nullable',
            'image'           => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()->first()], 400);
        }

        if ($request->has('name') && strtolower($request->name) !== strtolower($category->name)) {
            if (Category::whereRaw('LOWER(name) = ?', [strtolower($request->name)])
                ->where('id', '!=', $id)
                ->exists()) {
                return response()->json(['error' => 'Category name already exists'], 409);
            }
        }

        $updateData = $request->only(['name', 'description', 'parent_category', 'status']);

        if ($request->hasFile('image') && $request->file('image')->isValid()) {
            $file = $request->file('image');
            $ext = $file->getClientOriginalExtension();
            $newFilename = Str::uuid()->toString() . '.' . $ext;

            if ($category->image && File::exists(public_path($this->uploadPath . '/' . $category->image))) {
                File::delete(public_path($this->uploadPath . '/' . $category->image));
            }

            $file->move(public_path($this->uploadPath), $newFilename);
            $updateData['image'] = $newFilename;
        }

        $category->update($updateData);

        return response()->json([
            'message'   => 'Category updated successfully',
            'image_url' => isset($updateData['image']) ? asset($this->uploadPath . '/' . $updateData['image']) : ($category->image ? asset($this->uploadPath . '/' . $category->image) : null)
        ]);
    }

    public function destroy($id)
    {
        $category = Category::find($id);

        if (!$category) {
            return response()->json(['error' => 'Category not found'], 404);
        }

        if ($category->image && File::exists(public_path($this->uploadPath . '/' . $category->image))) {
            File::delete(public_path($this->uploadPath . '/' . $category->image));
        }

        $category->delete();

        return response()->json(['message' => 'Category deleted successfully']);
    }

    public function count()
    {
        return response()->json(['category_count' => Category::count()]);
    }
}
