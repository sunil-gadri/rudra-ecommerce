<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Specification;
use Illuminate\Http\Request;
use Carbon\Carbon;

class SpecificationController extends Controller
{
    // CREATE - POST /specification
    public function store(Request $request)
    {
        $headingId = $request->input('specification_heading_id');
        $specValue = $request->input('specification');

        if (!$specValue || !$headingId) {
            return response()->json([
                "error" => "Specification and Specification Heading ID are required"
            ], 400);
        }

        $spec = Specification::create([
            'specification_heading_id' => $headingId,
            'specification' => $specValue,
            'created_at' => Carbon::now()
        ]);

        return response()->json([
            "message" => "Specification created successfully",
            "id" => $spec->id
        ], 200);
    }

    // GET ALL - GET /specification
    public function index()
    {
        return response()->json(Specification::all(), 200);
    }

    // GET by heading ID - GET /specification/{heading_id}
    public function show($heading_id)
    {
        $specifications = Specification::where('specification_heading_id', $heading_id)->get();

        if ($specifications->isEmpty()) {
            return response()->json(["error" => "Specification not found"], 404);
        }

        return response()->json($specifications, 200);
    }

    // UPDATE - PUT /specification/{id} (with manual parsing for FormData + PUT)
    public function update(Request $request, $id)
    {
        $spec = Specification::find($id);

        if (!$spec) {
            return response()->json(["error" => "Specification not found"], 404);
        }

        $raw = $request->getContent();

        // Simple regex parsing for 'specification' field
        preg_match('/name="specification"[\s\S]*?[\r\n]{2}([^\r\n]+)/', $raw, $matches);

        $specValue = trim($matches[1] ?? '');

        if ($specValue === '') {
            return response()->json(["error" => "No fields to update"], 400);
        }

        // Optional uniqueness check (uncomment if needed)
        // if (Specification::where('specification', $specValue)
        //         ->where('id', '!=', $id)
        //         ->exists()) {
        //     return response()->json(["error" => "Specification already exists"], 400);
        // }

        $spec->specification = $specValue;
        $spec->save();

        return response()->json([
            "message" => "specification updated successfully"
        ], 200);
    }

    // DELETE - DELETE /specification/{id}
    public function destroy($id)
    {
        $spec = Specification::find($id);

        if (!$spec) {
            return response()->json(["error" => "Specification not found"], 404);
        }

        $spec->delete();

        return response()->json([
            "message" => "specification deleted successfully"
        ], 200);
    }
}