<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductSize;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class ProductSizeController extends Controller
{
    // CREATE
    public function store(Request $request)
    {
        $type = $request->type;
        $unit = $request->unit;
        $category = $request->category;

        if (!$type) {
            return response()->json(["error" => "Field 'type' is required"], 400);
        }

        // uniqueness checks
        if ($unit && ProductSize::where('unit', $unit)->exists()) {
            return response()->json(["error" => "This unit already exists"], 409);
        }

        if ($category && ProductSize::where('category', $category)->exists()) {
            return response()->json(["error" => "This category already exists"], 409);
        }

        $size = ProductSize::create([
            'type' => $type,
            'unit' => $unit,
            'category' => $category,
            'created_at' => Carbon::now()
        ]);

        return response()->json([
            "message" => "Attribute added successfully",
            "id" => $size->id,
            "type" => $size->type,
            "unit" => $size->unit,
            "category" => $size->category,
            "created_at" => $size->created_at
        ], 200);
    }

    // GET ALL
    public function index()
    {
        return response()->json(ProductSize::all(), 200);
    }

    // GET SINGLE
    public function show($id)
    {
        $size = ProductSize::find($id);

        if (!$size) {
            return response()->json(["error" => "Product size not found"], 404);
        }

        return response()->json($size, 200);
    }

 public function update(Request $request, $id)
{
    $size = ProductSize::findOrFail($id);

    // Get raw body
    $raw = $request->getContent();

    // Very simple parsing - works for most common cases
    $data = [];
    preg_match_all('/name="([^"]+)"[\s\S]*?[\r\n]{2}([^\r\n]+)/', $raw, $matches, PREG_SET_ORDER);

    foreach ($matches as $match) {
        $field = $match[1];
        $value = trim($match[2]);
        $data[$field] = $value === '' ? null : $value;
    }

    // Set all fields — missing ones become null
    $size->type     = $data['type']     ?? null;
    $size->unit     = $data['unit']     ?? null;
    $size->category = $data['category'] ?? null;

    $size->save();

    return response()->json([
        'message' => 'Product size updated successfully',
        'data'    => $size
    ]);
}
    // DELETE
    public function destroy($id)
    {
        ProductSize::where('id', $id)->delete();
        return response()->json(["message" => "Product size deleted successfully"], 200);
    }
}
