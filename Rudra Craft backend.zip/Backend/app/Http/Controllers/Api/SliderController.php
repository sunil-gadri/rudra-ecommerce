<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Slider;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;

class SliderController extends Controller
{
    protected $uploadPath = 'uploads/sliders';

    public function __construct()
    {
        if (!File::exists(public_path($this->uploadPath))) {
            File::makeDirectory(public_path($this->uploadPath), 0755, true);
        }
    }

    // POST: Add Slider
    public function store(Request $request)
    {
        $key = $request->input('key');
        $category_id = $request->input('category_id');
        $image = $request->file('image');

        if (!$key || !$image) {
            return response()->json(["error" => "Key and image are required"], 400);
        }

        if (!$image->isValid()) {
            return response()->json(["error" => "Invalid image"], 400);
        }

        $ext = $image->getClientOriginalExtension();
        $filename = Str::uuid()->toString() . '.' . $ext;
        $image->move(public_path($this->uploadPath), $filename);

        $slider = Slider::create([
            'key' => $key,
            'category_id' => $category_id,
            'image' => $filename,
            'created_at' => now()
        ]);

        return response()->json([
            "id" => $slider->id,
            "key" => $key,
            "category_id" => $category_id,
            "image" => $filename,
            "image_url" => asset($this->uploadPath . '/' . $filename),
            "message" => "Slider added successfully"
        ], 200);
    }

    // GET: All Sliders
    public function index()
    {
        $sliders = Slider::leftJoin('category_tbl as c', 'slider_tbl.category_id', '=', 'c.id')
            ->select('slider_tbl.*', 'c.name as category_name')
            ->orderByDesc('slider_tbl.created_at')
            ->get();

        return response()->json(
            $sliders->map(function ($s) {
                return [
                    ...$s->toArray(),
                    "image_url" => $s->image ? asset($this->uploadPath . '/' . $s->image) : null
                ];
            })
        );
    }

    // GET: Sliders by Key
    public function getByKey($key)
    {
        $sliders = Slider::leftJoin('category_tbl as c', 'slider_tbl.category_id', '=', 'c.id')
            ->select('slider_tbl.*', 'c.name as category_name')
            ->where('slider_tbl.key', $key)
            ->orderByDesc('slider_tbl.created_at')
            ->get();

        if ($sliders->isEmpty()) {
            return response()->json(["error" => "No sliders found for the given key"], 404);
        }

        return response()->json(
            $sliders->map(function ($s) {
                return [
                    ...$s->toArray(),
                    "image_url" => $s->image ? asset($this->uploadPath . '/' . $s->image) : null
                ];
            })
        );
    }

    public function update(Request $request, $id)
    {
        $slider = Slider::find($id);

        if (!$slider) {
            return response()->json(["error" => "Slider not found"], 404);
        }

        // Validate
        $request->validate([
            'key' => 'sometimes|required|string|max:255',
            'category_id' => 'sometimes|nullable|exists:category_tbl,id',
            'image' => 'sometimes|nullable|image|mimes:jpg,jpeg,png,webp,gif|max:2048',
        ]);

        // Update text fields
        if ($request->has('key')) {
            $slider->key = $request->key;
        }

        if ($request->has('category_id')) {
            $slider->category_id = $request->category_id;
        }

        // IMAGE UPDATE
        if ($request->hasFile('image')) {
            // Delete old image
            $oldPath = public_path($this->uploadPath . '/' . $slider->image);
            if ($slider->image && File::exists($oldPath)) {
                File::delete($oldPath);
            }

            $file = $request->file('image');
            $filename = Str::uuid()->toString() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path($this->uploadPath), $filename);
            $slider->image = $filename;
        }

        $slider->save();

        return response()->json([
            "message" => "Slider updated successfully",
            "data" => [
                "id" => $slider->id,
                "key" => $slider->key,
                "category_id" => $slider->category_id,
                "image_url" => $slider->image ? asset($this->uploadPath . '/' . $slider->image) : null,
                "category_name" => $slider->category_name ?? null
            ]
        ]);
    }

    public function destroy($id)
    {
        $slider = Slider::find($id);

        if (!$slider) {
            return response()->json(["error" => "Slider not found"], 404);
        }

        $path = public_path($this->uploadPath . '/' . $slider->image);
        if ($slider->image && File::exists($path)) {
            File::delete($path);
        }

        $slider->delete();

        return response()->json(["message" => "Slider deleted successfully"], 200);
    }
}
