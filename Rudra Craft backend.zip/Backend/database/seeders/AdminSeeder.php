<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('user_tbl')->insert([
            'username' => 'admin@gmail.com',
            'password' => Hash::make('admin@123'),
            'created_at' => now(),
        ]);
    }
}
