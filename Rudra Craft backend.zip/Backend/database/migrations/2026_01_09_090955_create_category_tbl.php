<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('category_tbl', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->text('description')->nullable();
            $table->unsignedBigInteger('parent_category')->nullable();
            $table->string('status')->default('active');
            $table->string('image')->nullable();
            $table->timestamp('created_at')->useCurrent();

            // Foreign key to parent_category_tbl (assuming you have it)
            $table->foreign('parent_category')
                  ->references('id')
                  ->on('parent_category_tbl')
                  ->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('category_tbl');
    }
};