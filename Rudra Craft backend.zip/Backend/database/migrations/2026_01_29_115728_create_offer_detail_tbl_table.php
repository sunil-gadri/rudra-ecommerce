<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('offer_detail_tbl', function (Blueprint $table) {
            $table->id();
            $table->foreignId('offer_id')->constrained('offers_tbl')->onDelete('cascade');
            $table->string('text1')->nullable();
            $table->string('text2')->nullable();
            $table->string('product_category_ids')->nullable(); // comma separated string
            $table->string('image')->nullable();
            $table->string('details_heading')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('offer_detail_tbl');
    }
};