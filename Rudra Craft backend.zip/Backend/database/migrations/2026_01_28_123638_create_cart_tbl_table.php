<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
       Schema::create('cart_tbl', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('customer_id');
    $table->unsignedBigInteger('product_id');
    $table->unsignedInteger('quantity')->default(1);
    $table->string('coupon_code')->nullable();
    $table->timestamp('created_at')->useCurrent();

    $table->foreign('customer_id')->references('id')->on('customer_tbl')->onDelete('cascade');
    $table->foreign('product_id')->references('id')->on('product_tbl')->onDelete('cascade');
    $table->unique(['customer_id', 'product_id']);
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cart_tbl');
    }
};
