<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_attributes_tbl', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('product_tbl')->onDelete('cascade');
            $table->string('unit')->nullable();
            $table->string('category')->nullable();
            $table->string('product_color')->nullable();
            $table->string('product_pattern')->nullable();
            $table->string('length')->nullable();
            $table->string('width')->nullable();
            $table->string('height')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_attributes_tbl');
    }
};