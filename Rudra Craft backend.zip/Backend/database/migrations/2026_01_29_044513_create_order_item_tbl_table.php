<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('order_item_tbl', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('order_id');
            $table->unsignedBigInteger('product_id');
            $table->string('product_name');
            $table->text('product_description')->nullable();
            $table->decimal('price', 15, 2);
            $table->decimal('base_price', 15, 2);
            $table->decimal('discount', 15, 2)->default(0);
            $table->decimal('discounted_price', 15, 2);
            $table->decimal('tax', 15, 2)->default(0);
            $table->unsignedInteger('quantity');
            $table->string('product_size')->nullable();
            $table->string('category')->nullable();
            $table->string('product_color')->nullable();
            $table->string('product_pattern')->nullable();
            $table->timestamps();

            $table->foreign('order_id')->references('id')->on('order_tbl')->onDelete('cascade');
            $table->foreign('product_id')->references('id')->on('product_tbl')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_item_tbl');
    }
};