<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('coupon_tbl', function (Blueprint $table) {
            $table->id();
            $table->string('coupon_code')->unique();
            $table->string('status')->default('active'); // active, expired, inactive
            $table->date('start_date');
            $table->date('end_date');
            $table->string('coupon_type'); // percentage, fixed
            $table->decimal('discount_value', 10, 2);
            $table->decimal('min_price', 10, 2)->default(0.00);
            $table->decimal('max_price', 10, 2)->default(0.00);
            $table->string('coupon_title')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('coupon_tbl');
    }
};