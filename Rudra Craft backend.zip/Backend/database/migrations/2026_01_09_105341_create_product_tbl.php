<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_tbl', function (Blueprint $table) {
            $table->id();
            $table->string('product_title');
            $table->unsignedBigInteger('product_parent_category_id')->nullable();
            $table->unsignedBigInteger('product_category_id')->nullable();
            $table->text('product_tags')->nullable();
            $table->string('product_status')->default('active');
            $table->text('product_description')->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->foreign('product_parent_category_id')
                  ->references('id')
                  ->on('parent_category_tbl')
                  ->onDelete('set null');
            $table->foreign('product_category_id')
                  ->references('id')
                  ->on('category_tbl')
                  ->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_tbl');
    }
};