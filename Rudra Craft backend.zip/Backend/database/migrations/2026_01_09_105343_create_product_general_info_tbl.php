<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_general_info_tbl', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('product_tbl')->onDelete('cascade');
            $table->string('manufacturer_name')->nullable();
            $table->string('manufacturer_brand')->nullable();
            $table->integer('stock')->default(0);
            $table->decimal('price', 10, 2);
            $table->decimal('gst', 5, 2)->default(0);
            $table->decimal('discount', 5, 2)->default(0);
            $table->decimal('base_price', 10, 2);
            $table->decimal('discounted_price', 10, 2);
            $table->decimal('gst_amount', 10, 2);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_general_info_tbl');
    }
};