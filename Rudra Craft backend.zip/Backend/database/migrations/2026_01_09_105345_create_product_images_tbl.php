<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_images_tbl', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('product_tbl')->onDelete('cascade');
            $table->string('image');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_images_tbl');
    }
};