<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('specification_tbl', function (Blueprint $table) {
            $table->id();
            $table->foreignId('specification_heading_id')
                  ->constrained('specification_heading_tbl')
                  ->onDelete('cascade');
            $table->string('specification');
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('specification_tbl');
    }
};