<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('slider_tbl', function (Blueprint $table) {
            $table->id();
            $table->string('key');
            $table->unsignedBigInteger('category_id')->nullable();
            $table->string('image');
            $table->timestamp('created_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('slider_tbl');
    }
};
