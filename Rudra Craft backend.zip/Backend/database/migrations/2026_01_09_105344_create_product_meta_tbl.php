<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_meta_tbl', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('product_tbl')->onDelete('cascade');
            $table->string('meta_title')->nullable();
            $table->string('meta_keywords')->nullable();
            $table->text('meta_description')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_meta_tbl');
    }
};