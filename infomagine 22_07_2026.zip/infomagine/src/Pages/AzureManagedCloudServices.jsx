import React from "react";
import Layout from "../Components/Layout";
import { Link } from "react-router-dom";
import azureinfoimg from "../assets/azureinfoimg.png";
import azuresolutionimg from "../assets/azuresolutionimg.png";
import azureheader from "../assets/azureheader.jpg";
import cloudnetwork from "../assets/cloudnetwork.jpg";
import ScalableCloudResources from "../assets/ScalableCloudResources.jpg";
import AdvancedSecurityFramework from "../assets/Advanced Security Framework.jpg";
import azureservices from "../assets/azureservices.png";
import azurelogo from "../assets/azurelogo.png";
import { useState } from "react";
import { ChevronDown } from "lucide-react";

import {
  FaServer,
  FaCloud,
  FaExchangeAlt,
  FaTachometerAlt,
  FaShieldAlt,
  FaChartLine,
  FaHeadset,
} from "react-icons/fa";

const faqs = [
  {
    question: "What are Azure Managed Cloud Services?",
    answer:
      "Azure Managed Cloud Services involve professional management of cloud infrastructure, applications and resources on Microsoft Azure. These services include cloud migration, infrastructure setup, monitoring, security management and performance optimization to ensure efficient cloud operations.",
  },
  {
    question: "Why should businesses choose Azure for cloud infrastructure?",
    answer:
      "Azure offers scalable cloud resources, enterprise-grade security, global data centers and seamless integration with Microsoft technologies. Businesses can deploy applications faster, scale resources easily and improve reliability while reducing infrastructure costs.",
  },
  {
    question: "What services are included in Azure cloud management?",
    answer:
      "Azure cloud management typically includes infrastructure setup, application hosting, DevOps automation, performance monitoring, security implementation, backup management, disaster recovery and cost optimization.",
  },
  {
    question: "Can Infomagine help migrate my existing servers to Azure?",
    answer:
      "Yes. Infomagine provides secure cloud migration services that transfer your existing applications, databases and infrastructure to Azure with minimal downtime and full data integrity.",
  },
  {
    question: "Is Azure suitable for startups and small businesses?",
    answer:
      "Yes. Azure provides flexible pricing models and scalable infrastructure, making it suitable for startups, growing businesses and large enterprises alike.",
  },
  {
    question: "How secure is Microsoft Azure?",
    answer:
      "Azure provides enterprise-level security features including encryption, identity management, threat detection and compliance with international security standards to protect data and applications.",
  },
  {
    question: "What industries benefit most from Azure cloud solutions?",
    answer:
      "Industries such as fintech, healthcare, eCommerce, education, logistics and SaaS companies benefit from Azure due to its scalability, reliability and secure infrastructure.",
  },
];

const AzureManagedCloudServices = () => {
  const [active, setActive] = useState(null);

  const toggle = (i) => {
    setActive(active === i ? null : i);
  };

  return (
    <Layout>
      {/* Hero Section */}
      <header className="relative w-full h-screen">
        <img
          src={azureheader}
          alt="Azure Managed Cloud"
          className="object-cover w-full h-full"
        />

        <div className="absolute inset-0 bg-black/60 flex items-center px-6 md:px-20">
          <div className="text-white max-w-2xl space-y-6">
            <img
              width={100}
              src={azurelogo}
              alt="DevOps automation logo"
              className="float"
              loading="lazy"
            />
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Azure Managed Cloud Services
            </h1>

            <Link
              to="/contact-us"
              className="inline-block bg-[#FF5722] text-white px-7 py-3 rounded-md font-semibold hover:bg-orange-600 transition"
            >
              Let’s Talk
            </Link>
          </div>
        </div>
      </header>

      {/* Why Azure (TEXT ONLY) */}
      <section className="py-20 px-6 md:px-20">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-5xl font-bold mb-6 text-gray-800">Why Azure?</h2>

          <p className="text-gray-600 mb-6 leading-relaxed">
            Choosing Microsoft Azure gives businesses access to a powerful,
            scalable and secure cloud platform built for modern digital
            applications. Azure provides flexible cloud infrastructure that
            allows companies to deploy applications, manage data and scale
            systems quickly without heavy upfront investments.
          </p>

          <p className="text-gray-600 leading-relaxed">
            At Infomagine, we help businesses harness Azure’s capabilities to
            build reliable, high-performance cloud environments. Our team
            ensures seamless migration, optimized architecture and ongoing
            management so your cloud infrastructure supports long-term business
            growth
          </p>
        </div>
      </section>
      {/* Key Highlights */}
      <section className="py-24 px-6 md:px-20 bg-gray-100">
        <div className="max-w-6xl mx-auto">
          {/* Title */}
          <div className="text-center mb-20">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-800">
              Key Highlights
            </h2>
            <p className="text-gray-600 mt-4">
              Powerful Azure capabilities that help businesses scale securely.
            </p>
          </div>

          <div className="space-y-12">
            {/* 1 */}
            <div className="grid md:grid-cols-2 gap-10 items-center border border-gray-300 rounded-xl p-8  hover:shadow-lg transition">
              <div>
                <h3 className="text-2xl font-semibold mb-3 text-gray-800">
                  Enterprise-Grade Infrastructure
                </h3>
                <p className="text-gray-600">
                  Azure offers reliable infrastructure with global data centers
                  designed for high availability and business continuity.
                </p>
              </div>

              <img
                src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31"
                className="w-full h-64 object-cover rounded-lg"
                alt="Infrastructure"
              />
            </div>

            {/* 2 */}
            <div className="grid md:grid-cols-2 gap-10 items-center border border-gray-300 rounded-xl p-8  hover:shadow-lg transition">
              <img
                src={ScalableCloudResources}
                className="w-full h-64 object-cover rounded-lg md:order-1 order-2"
                alt="Scalable Cloud"
              />

              <div className="md:order-2 order-1">
                <h3 className="text-2xl font-semibold mb-3 text-gray-800">
                  Scalable Cloud Resources
                </h3>
                <p className="text-gray-600">
                  Businesses can easily scale computing power, storage and
                  networking resources as demand grows without infrastructure
                  limitations.
                </p>
              </div>
            </div>

            {/* 3 */}
            <div className="grid md:grid-cols-2 gap-10 items-center border border-gray-300 rounded-xl p-8  hover:shadow-lg transition">
              <div>
                <h3 className="text-2xl font-semibold mb-3 text-gray-800">
                  Microsoft Ecosystem Integration
                </h3>
                <p className="text-gray-600">
                  Azure integrates seamlessly with Microsoft technologies such
                  as Windows Server, SQL Server and enterprise tools.
                </p>
              </div>

              <img
                src="https://images.unsplash.com/photo-1518770660439-4636190af475"
                className="w-full h-64 object-cover rounded-lg"
                alt="Integration"
              />
            </div>

            {/* 4 */}
            <div className="grid md:grid-cols-2 gap-10 items-center border border-gray-300 rounded-xl p-8  hover:shadow-lg transition">
              <img
                src={AdvancedSecurityFramework}
                className="w-full h-64 object-cover rounded-lg md:order-1 order-2"
                alt="Security"
              />

              <div className="md:order-2 order-1">
                <h3 className="text-2xl font-semibold mb-3 text-gray-800">
                  Advanced Security Framework
                </h3>
                <p className="text-gray-600">
                  Built-in security tools and compliance standards help protect
                  applications and business data from cyber threats.
                </p>
              </div>
            </div>

            {/* 5 */}
            <div className="grid md:grid-cols-2 gap-10 items-center border border-gray-300 rounded-xl p-8  hover:shadow-lg transition">
              <div>
                <h3 className="text-2xl font-semibold mb-3 text-gray-800">
                  Global Cloud Network
                </h3>
                <p className="text-gray-600">
                  Azure’s worldwide data centers ensure faster performance and
                  low latency for users across different regions.
                </p>
              </div>

              <img
                src={cloudnetwork}
                className="w-full h-64 object-cover rounded-lg"
                alt="Global Network"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-6 md:px-20 bg-[#030615]">
        <div className="max-w-6xl mx-auto">
          {/* Title */}
          <div className="text-center mb-20">
            <h2 className="text-3xl md:text-5xl font-bold text-white">
              Azure Benefits
            </h2>
            <p className="text-gray-400 w-[90%] text-center mt-4">
              Azure provides organizations with a flexible and intelligent cloud
              platform that accelerates innovation while reducing infrastructure
              complexity. Businesses can deploy applications faster, improve
              reliability and optimize costs through Azure’s scalable services.
            </p>
          </div>
        </div>

        <div>
          <img src={azureinfoimg} alt="" />
        </div>
      </section>

      <section className="py-24 px-6 md:px-20 bg-gray-100">
        <div className="max-w-6xl mx-auto">
          {/* Title */}
          <div className="text-center mb-20">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-800">
              Solutions We Deliver on Azure
            </h2>
            <p className="text-gray-600 mt-4">
              Infomagine offers comprehensive Azure cloud solutions designed to
              support modern business infrastructure. Our team designs scalable
              cloud environments, migrates applications and manages Azure
              resources to ensure performance, security and efficiency.
            </p>

            <p className="text-gray-600 mt-4">
              We help organizations leverage Azure for application hosting,
              DevOps automation, data management and enterprise cloud platforms.
            </p>
          </div>
        </div>
        <div>
          <img src={azuresolutionimg} alt="" />
        </div>
      </section>

      <section className="py-28 relative px-6 md:px-20 bg-gray-100  shadow-2xl rounded-xl">
        <div className="absolute -top-10 -left-32 w-96 h-96 bg-[#FF5722] rounded-full blur-3xl opacity-10"></div>
        <div className="max-w-7xl mx-auto">
          {/* Title */}
          <div className="text-center mb-20">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-800">
              Azure Cloud Management Services
            </h2>
            <p className="text-gray-600 mt-4">
              From deployment to optimization, we handle your Azure environment
              so you can focus on growing your business.
            </p>
          </div>

          <div>
            <img src={azureservices} alt="" />
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 px-6 md:px-16 bg-[#030615] text-white">
        <div className="max-w-6xl mx-auto">
          {/* Title */}
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">
              Process – How We Work with Azure
            </h2>
            <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
              Our structured Azure implementation process ensures secure and
              scalable cloud adoption.
            </p>
          </div>

          {/* Steps */}
          <div className="grid md:grid-cols-2 gap-8">
            {/* Step 1 */}
            <div className="flex items-center gap-4 bg-[#0b0f25] p-6 rounded-full border border-gray-800">
              <FaServer className="text-[#FF4100] text-2xl" />
              <div>
                <h3 className="font-semibold">Infrastructure Assessment</h3>
                <p className="text-sm text-gray-400">
                  Analyze existing systems and identify the most efficient
                  migration strategy.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-center gap-4 bg-[#0b0f25] p-6 rounded-full border border-gray-800">
              <FaCloud className="text-[#FF4100] text-2xl" />
              <div>
                <h3 className="font-semibold">Cloud Architecture Design</h3>
                <p className="text-sm text-gray-400">
                  Develop a scalable Azure architecture aligned with business
                  needs.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-center gap-4 bg-[#0b0f25] p-6 rounded-full border border-gray-800">
              <FaExchangeAlt className="text-[#FF4100] text-2xl" />
              <div>
                <h3 className="font-semibold">Migration & Deployment</h3>
                <p className="text-sm text-gray-400">
                  Move applications and databases to Azure with minimal
                  downtime.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-center gap-4 bg-[#0b0f25] p-6 rounded-full border border-gray-800">
              <FaTachometerAlt className="text-[#FF4100] text-2xl" />
              <div>
                <h3 className="font-semibold">Performance Optimization</h3>
                <p className="text-sm text-gray-400">
                  Configure scaling, caching and resource optimization.
                </p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex items-center gap-4 bg-[#0b0f25] p-6 rounded-full border border-gray-800">
              <FaShieldAlt className="text-[#FF4100] text-2xl" />
              <div>
                <h3 className="font-semibold">Security Implementation</h3>
                <p className="text-sm text-gray-400">
                  Deploy secure network configurations and data protection.
                </p>
              </div>
            </div>

            {/* Step 6 */}
            <div className="flex items-center gap-4 bg-[#0b0f25] p-6 rounded-full border border-gray-800">
              <FaHeadset className="text-[#FF4100] text-2xl" />
              <div>
                <h3 className="font-semibold">
                  Continuous Monitoring & Support
                </h3>
                <p className="text-sm text-gray-400">
                  Ensure long-term stability through proactive monitoring and
                  maintenance.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Industries Section */}
      <section className="py-28 px-6 md:px-20 bg-gray-100">
        <div className="max-w-7xl mx-auto">
          {/* Title */}
          <div className="text-center mb-20">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-800">
              Industries We Serve
            </h2>
            <p className="text-gray-600 mt-4 max-w-3xl mx-auto">
              Our Azure cloud infrastructure solutions power organizations
              across multiple industries requiring scalable, secure platforms.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
            {/* Card */}
            <div className="group bg-white rounded-2xl p-8 border border-gray-200 hover:border-[#FF0000] hover:shadow-xl transition">
              <div className="text-blue-600 text-4xl mb-5">💳</div>
              <h3 className="text-xl font-semibold mb-3">FinTech Platforms</h3>
              <p className="text-gray-600">
                Secure infrastructure for payment systems, analytics platforms
                and financial applications.
              </p>
            </div>

            <div className="group bg-white rounded-2xl p-8 border border-gray-200 hover:border-[#FF0000] hover:shadow-xl transition">
              <div className="text-blue-600 text-4xl mb-5">🎓</div>
              <h3 className="text-xl font-semibold mb-3">EdTech Solutions</h3>
              <p className="text-gray-600">
                Cloud platforms for online learning, virtual classrooms and
                digital education systems.
              </p>
            </div>

            <div className="group bg-white rounded-2xl p-8 border border-gray-200 hover:border-[#FF0000] hover:shadow-xl transition">
              <div className="text-blue-600 text-4xl mb-5">🏥</div>
              <h3 className="text-xl font-semibold mb-3">Healthcare Systems</h3>
              <p className="text-gray-600">
                Secure environments for patient platforms, health analytics and
                telemedicine services.
              </p>
            </div>

            <div className="group bg-white rounded-2xl p-8 border border-gray-200 hover:border-[#FF0000] hover:shadow-xl transition">
              <div className="text-blue-600 text-4xl mb-5">🛒</div>
              <h3 className="text-xl font-semibold mb-3">
                eCommerce Platforms
              </h3>
              <p className="text-gray-600">
                High-performance cloud infrastructure for large-scale online
                commerce systems.
              </p>
            </div>

            <div className="group bg-white rounded-2xl p-8 border border-gray-200 hover:border-[#FF0000] hover:shadow-xl transition">
              <div className="text-blue-600 text-4xl mb-5">🏢</div>
              <h3 className="text-xl font-semibold mb-3">
                Real Estate Platforms
              </h3>
              <p className="text-gray-600">
                Digital property management platforms and listing infrastructure
                powered by Azure.
              </p>
            </div>

            <div className="group bg-white rounded-2xl p-8 border border-gray-200 hover:border-[#FF0000] hover:shadow-xl transition">
              <div className="text-blue-600 text-4xl mb-5">⚙️</div>
              <h3 className="text-xl font-semibold mb-3">SaaS Applications</h3>
              <p className="text-gray-600">
                Multi-tenant scalable architectures designed for SaaS platforms
                and enterprise software.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="relative py-24 px-6 bg-[#0F172B] overflow-hidden">
        {/* Background decoration */}
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-[#FF5722] rounded-full blur-3xl opacity-20"></div>

        <div className="max-w-4xl mx-auto relative">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white">
              Azure Cloud Services FAQ
            </h2>

            <p className="mt-4 text-gray-300 text-lg">
              Everything you need to know about Azure managed cloud solutions.
            </p>

            <div className="mt-6 h-1 w-24 bg-[#FF5722] mx-auto rounded"></div>
          </div>

          {/* FAQ */}
          <div className="space-y-5">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="group bg-white backdrop-blur-lg border border-gray-200 rounded-2xl shadow-sm hover:shadow-xl transition duration-300"
              >
                <button
                  onClick={() => toggle(i)}
                  className="w-full flex justify-between items-center text-left px-8 py-6"
                >
                  <h3 className="text-lg md:text-xl font-semibold text-gray-800 group-hover:text-[#FF5722] transition">
                    {faq.question}
                  </h3>

                  <ChevronDown
                    className={`transition-transform duration-300 text-[#FF5722] ${
                      active === i ? "rotate-180" : ""
                    }`}
                  />
                </button>

                <div
                  className={`grid transition-all duration-300 ease-in-out ${
                    active === i
                      ? "grid-rows-[1fr] opacity-100 px-8 pb-6"
                      : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="overflow-hidden text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default AzureManagedCloudServices;
