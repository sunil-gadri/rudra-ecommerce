import React from "react";
import headerhire from "../assets/headerhire.jpeg";
import section3img from "../assets/section3img.png";
import section5img from "../assets/section5img.png";
import Layout from "../Components/Layout";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import {
  FaUserTie,
  FaGlobe,
  FaRocket,
  FaLock,
  FaChartLine,
} from "react-icons/fa";
import {
  FaDesktop,
  FaCogs,
  FaFileAlt,
  FaMobileAlt,
  FaUsers,
   FaChevronLeft,
  FaChevronRight,
} from "react-icons/fa";
import { useState } from "react";
import { FaServer, FaRobot, FaShoppingCart, FaTools } from "react-icons/fa";

const DedicatedHiring = () => {

  const [index, setIndex] = useState(0);
const cardWidth = 400;
const cardsPerView = 3;
const totalCards = 6;
const maxIndex = Math.ceil(totalCards / cardsPerView) - 1;

const next = () => {
  if (index < maxIndex) setIndex(index + 1);
};

const prev = () => {
  if (index > 0) setIndex(index - 1);
};

  return (
    <>
      <Layout>

        <Helmet>
  <title>Hire Dedicated Developers | IT Outsourcing & Remote Tech Talent | Infomagine</title>

  <meta
    name="description"
    content="Hire dedicated developers, designers, and IT experts from Infomagine. Scale your business with skilled remote teams, faster development, cost-effective outsourcing, and flexible hiring models."
  />

  <meta
    name="keywords"
    content="hire dedicated developers, IT outsourcing services, hire remote developers, dedicated development team, offshore developers, hire web developers, mobile app developers, AI developers, DevOps engineers"
  />

  <link
    rel="canonical"
    href="https://www.infomagine.com/hire-dedicated-developers"
  />

  {/* Open Graph */}
  <meta property="og:title" content="Hire Dedicated Developers | Infomagine" />
  <meta
    property="og:description"
    content="Build your remote team with hand-picked developers, designers and digital experts. Scale faster with Infomagine’s dedicated hiring model."
  />
  <meta
    property="og:image"
    content="https://www.infomagine.com/assets/headerhire.jpeg"
  />
  <meta
    property="og:url"
    content="https://www.infomagine.com/hire-dedicated-developers"
  />
  <meta property="og:type" content="website" />

  {/* Twitter */}
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="Hire Dedicated Developers | Infomagine" />
  <meta
    name="twitter:description"
    content="Scale your business faster with dedicated developers, designers and IT experts from Infomagine."
  />
  <meta
    name="twitter:image"
    content="https://www.infomagine.com/assets/headerhire.jpeg"
  />
</Helmet>

        <div className="relative w-full h-screen">
          <img
            src={headerhire}
            alt="iOS App"
            className="object-cover w-full h-full"
          />

          <div className="absolute inset-0 bg-black/50 flex items-center px-10 md:px-20">
            <div
              data-aos="fade-right"
              className="text-white max-w-2xl space-y-5"
            >
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                Hire Dedicated Tech Talent Scale Faster
              </h1>
              <p className="text-lg">
                Build your remote team with hand-picked developers, designers
                and digital experts—fully aligned with your business goals.
              </p>
              <Link
                to="/contact-us"
                className="inline-block bg-[#FF5722] text-white px-6 py-3 rounded-md font-semibold hover:bg-orange-600 transition"
              >
                Let’s Talk
              </Link>
            </div>
          </div>

          <div></div>
        </div>

        <div className="w-full bg-white py-16 px-6 md:px-20 flex flex-col items-center">
          {/* Heading */}
          <h1 className="text-3xl md:text-4xl text-center leading-12 font-bold text-gray-900">
            Accelerate Growth with Smart IT Outsourcing
          </h1>

          <p className="text-gray-500 text-center mt-4 ">
            By strategically outsourcing your IT development to Infomagine,
            you’re not just hiring resources—you’re extending your core team
            with the right expertise.
          </p>

          <p className="text-gray-500 text-center mt-4 ">
            Our dedicated hiring model ensures you get skilled, pre-vetted
            professionals who work exclusively on your projects, understand your
            business objectives and seamlessly align with your workflows.
            Whether you need a single expert or a full-fledged remote team, we
            help you scale faster without the burden of long hiring cycles or
            operational overhead.
          </p>

          <p className="text-gray-500 text-center mt-4">
            With Infomagine as your outsourcing partner, you gain flexibility,
            cost efficiency and complete control—while we take care of talent
            sourcing, management and continuity.
          </p>

          {/* Square Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 mt-10 w-[1300px]">
            {/* Card */}
            <div className="border border-gray-300 rounded-xl p-6 flex flex-col justify-center items-center gap-4 hover:shadow-lg transition aspect-square">
              <FaDesktop className="text-4xl" style={{ color: "#F54900" }} />
              <h3 className="font-medium text-lg text-center">
                Faster project execution & reduced time-to-market{" "}
              </h3>
            </div>

            <div className="border border-gray-300 rounded-xl p-6 flex flex-col justify-center items-center gap-4 hover:shadow-lg transition aspect-square">
              <FaCogs className="text-4xl" style={{ color: "#F54900" }} />
              <h3 className="font-medium text-lg text-center">
                Dedicated professionals working only for you{" "}
              </h3>
            </div>

            <div className="border border-gray-300 rounded-xl p-6 flex flex-col justify-center items-center gap-4 hover:shadow-lg transition aspect-square">
              <FaFileAlt className="text-4xl" style={{ color: "#F54900" }} />
              <h3 className="font-medium text-lg text-center">
                Easy scaling up or down as per business needs{" "}
              </h3>
            </div>

            <div className="border border-gray-300 rounded-xl p-6 flex flex-col justify-center items-center gap-4 hover:shadow-lg transition aspect-square">
              <FaMobileAlt className="text-4xl" style={{ color: "#F54900" }} />
              <h3 className="font-medium text-lg text-center">
                Significant cost savings compared to in-house hiring{" "}
              </h3>
            </div>

            <div className="border border-gray-300 rounded-xl p-6 flex flex-col justify-center items-center gap-4 hover:shadow-lg transition aspect-square">
              <FaUsers className="text-4xl" style={{ color: "#F54900" }} />
              <h3 className="font-medium text-lg text-center">
                Seamless collaboration & transparent communication{" "}
              </h3>
            </div>
          </div>
        </div>

        <div className="w-full bg-gray-100 py-20">
          <div className="max-w-6xl mx-auto flex flex-col gap-6 px-6">
            {/* Heading */}
            <h1 className="text-4xl text-center font-bold leading-12">
              Build your remote team with hand-picked developers, designers and
              digital experts—fully aligned with your business goals.
            </h1>

            {/* Main Flex */}
            <div className="flex flex-col md:flex-row gap-10 mt-10">
              {/* Left Image */}
              <div className="md:w-1/2 h-[500px]">
                <img
                  src="https://images.unsplash.com/photo-1519389950473-47ba0277781c"
                  className="rounded-2xl w-full h-full object-cover"
                />
              </div>

              {/* Right Content */}
              <div className=" flex flex-col border border-gray-400 px-20 rounded-2xl justify-center gap-9">
                <div className="flex items-center gap-3">
                  <FaUserTie className="text-[#F54900] text-xl" />
                  <h3 className="font-semibold">
                    Dedicated & Full-Time Resources
                  </h3>
                </div>
                <div className="flex items-center gap-3">
                  <FaGlobe className="text-[#F54900] text-xl" />
                  <h3 className="font-semibold">Remote / Offshore Hiring</h3>
                </div>

                <div className="flex items-center gap-3">
                  <FaRocket className="text-[#F54900] text-xl" />
                  <h3 className="font-semibold">Quick Onboarding</h3>
                </div>

                <div className="flex items-center gap-3">
                  <FaLock className="text-[#F54900] text-xl" />
                  <h3 className="font-semibold">100% Confidential & Secure</h3>
                </div>

                <div className="flex items-center gap-3">
                  <FaChartLine className="text-[#F54900] text-xl" />
                  <h3 className="font-semibold">Cost-Effective Scaling</h3>
                </div>

                <div className="w-50 text-center rounded-md text-white mt-8 p-2 bg-[#F54900]">
                  Hire Dedicated Talent
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="w-full bg-[#030615] text-white py-20">
          <div className="max-w-6xl mx-auto flex flex-col gap-6 px-6">
            {/* Heading */}
            <h1 className="text-4xl text-center font-bold leading-12">
              Our IT Outsourcing Services for Your Unique Requirements{" "}
            </h1>

            <p className="text-gray-500 text-center ">
              As a trusted IT outsourcing partner, Infomagine offers a
              comprehensive range of customizable services designed to solve
              complex business challenges, optimize costs and accelerate
              digital growth. Our solutions are built to adapt to your business
              needs—whether you require strategic guidance, technical expertise
              or a fully dedicated team.
    
            </p>

            <div className="mt-10">
              <img src={section3img} alt="" />
            </div>
          </div>
        </div>

       <div className="w-full bg-[#f7f7f7] py-20 flex flex-col items-center overflow-hidden">
      {/* Heading */}
      <h1 className="text-4xl font-bold text-center mb-8">
        Hire Dedicated Web Developers & Build Your Dream Team
      </h1>

      <p className="text-gray-500 w-[70%] text-center">
        Stop struggling with talent shortages or long hiring cycles. Infomagine
        helps you hire dedicated, experienced developers who work as an
        extension of your in-house team. Our professionals integrate seamlessly
        into your workflow, follow your processes and stay fully committed to
        your project goals—so you can focus on innovation and growth
      </p>

      {/* Carousel */}
      <div className="relative w-full mt-14 px-20">
        {/* Left Arrow */}
        <button
          onClick={prev}
          disabled={index === 0}
          className="absolute left-6 top-1/2 -translate-y-1/2 bg-white shadow-lg p-3 rounded-full hover:bg-orange-500 hover:text-white transition z-10 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <FaChevronLeft size={20}/>
        </button>

        {/* Right Arrow */}
        <button
          onClick={next}
          disabled={index === maxIndex}
          className="absolute right-6 top-1/2 -translate-y-1/2 bg-white shadow-lg p-3 rounded-full hover:bg-orange-500 hover:text-white transition z-10 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <FaChevronRight size={20}/>
        </button>

        {/* Track */}
        <div className="overflow-hidden">
          <div
            className="flex gap-6 transition-transform duration-500"
            style={{
              transform: `translateX(-${
                index * cardWidth * cardsPerView
              }px)`,
            }}
          >
            {/* Card 1 */}
            <div className="min-w-[400px] h-[400px] bg-white rounded-2xl p-8 shadow">
              <FaServer className="text-orange-500 text-3xl mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                Hire Backend Developers
              </h3>
              <p className="text-gray-500">
                Our backend developers build secure, scalable and
                high-performance systems that power your applications. They
                specialize in databases, APIs, server-side logic and
                integrations. With expertise in modern frameworks and cloud
                environments, they ensure stability and efficiency. Perfect for
                startups and enterprises needing robust backend architecture.
              </p>
            </div>

            {/* Card 2 */}
            <div className="min-w-[400px] h-[400px] bg-white rounded-2xl p-8 shadow">
              <FaDesktop className="text-orange-500 text-3xl mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                Hire Frontend Developers
              </h3>
              <p className="text-gray-500">
                Create engaging, fast and responsive user interfaces with our
                dedicated frontend developers. They focus on clean UI, smooth UX
                and cross-browser compatibility. Skilled in modern frameworks,
                they turn designs into interactive experiences. Your users get
                visually appealing and performance-driven applications.
              </p>
            </div>

            {/* Card 3 */}
            <div className="min-w-[400px] h-[400px] bg-white rounded-2xl p-8 shadow">
              <FaMobileAlt className="text-orange-500 text-3xl mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                Hire Mobile App Developers
              </h3>
              <p className="text-gray-500">
                Bring your app ideas to life with our skilled mobile app
                developers. We build secure, scalable and high-performing apps
                for Android, iOS and cross-platform solutions. Our developers
                ensure seamless user experiences and smooth app performance.
                Ideal for businesses looking to grow through mobile-first
                strategies.
              </p>
            </div>

            {/* Card 4 */}
            <div className="min-w-[400px] h-[400px] bg-white rounded-2xl p-8 shadow">
              <FaRobot className="text-orange-500 text-3xl mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                Hire AI Developers
              </h3>
              <p className="text-gray-500">
                Leverage the power of artificial intelligence to automate
                processes and gain smarter insights. Our AI developers build
                intelligent systems using machine learning, data analytics and
                automation technologies. From chatbots to predictive models, we
                help you stay ahead of the curve. Transform data into actionable
                business intelligence.
              </p>
            </div>

            {/* Card 5 */}
            <div className="min-w-[400px] h-[400px] bg-white rounded-2xl p-8 shadow">
              <FaShoppingCart className="text-orange-500 text-3xl mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                Hire eCommerce Developers
              </h3>
              <p className="text-gray-500">
                Scale your online business with our experienced eCommerce
                developers. We create secure, conversion-focused and
                user-friendly online stores. Our experts work with leading
                platforms and custom solutions. Drive sales, improve customer
                experience and manage growth effortlessly.
              </p>
            </div>

            {/* Card 6 */}
            <div className="min-w-[400px] h-[400px] bg-white rounded-2xl p-8 shadow">
              <FaTools className="text-orange-500 text-3xl mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                Hire DevOps Engineers 
              </h3>
              <p className="text-gray-500">
                Ensure faster deployments and reliable system performance with
                our DevOps engineers. They streamline CI/CD pipelines, automate
                infrastructure and enhance system monitoring. Our DevOps
                experts improve collaboration between development and
                operations teams. Achieve speed, stability and scalability with
                confidence.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

        <div className="w-full  bg-white text-black py-20">
          <div className="max-w-6xl mx-auto flex flex-col gap-6 px-6">
            {/* Heading */}
            <h1 className="text-4xl text-center font-bold leading-12">
              Hire Developers in 4 Simple Steps
            </h1>

            <p className="text-gray-500 text-center ">
              Finding the right developers shouldn’t slow down your growth. At
              Infomagine, we follow a proven and streamlined hiring process that
              connects you with the right talent—quickly, efficiently and with
              complete transparency. From understanding your vision to seamless
              onboarding, we ensure a smooth experience at every stage.
            </p>

            <div className="mt-10">
              <img src={section5img} alt="" />
            </div>
          </div>
        </div>

      </Layout>
    </>
  );
};

export default DedicatedHiring;
