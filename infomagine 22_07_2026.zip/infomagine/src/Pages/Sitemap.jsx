import React from "react";
import { Link } from "react-router-dom";
import Layout from "../Components/Layout";
import {
  FaHome,
  FaLaptopCode,
  FaMobileAlt,
  FaServer,
  FaGlobe,
  FaCloud,
  FaBuilding,
  FaBriefcase,
} from "react-icons/fa";

const Sitemap = () => {
  const sections = [
    {
      title: "Main Pages",
      icon: <FaHome />,
      links: [
        { name: "Home", path: "/" },
        { name: "Hire Developer", path: "/hire-developer" },
        { name: "Portfolio", path: "/portfolio" },
        { name: "Blog", path: "/blogs" },
        { name: "Contact Us", path: "/contact-us" },
        { name: "Sitemap", path: "/sitemap" },
      ],
    },
    {
      title: "IT Services",
      icon: <FaLaptopCode />,
      links: [
        { name: "Custom Software", path: "/services/custom-software" },
        {
          name: "Full-Stack Development",
          path: "/services/full-stack-development",
        },
        {
          name: "IT Consulting Services",
          path: "/services/it-consulting-services",
        },
        {
          name: "Software Testing & QA",
          path: "/services/software-testing-and-qa",
        },
        { name: "Digital Marketing", path: "/services/digital-marketing" },
      ],
    },
    {
      title: "Mobile Development",
      icon: <FaMobileAlt />,
      links: [
        { name: "iOS", path: "/services/ios" },
        { name: "Android", path: "/services/android" },
        { name: "React Native", path: "/services/react-native" },
        { name: "Hybrid", path: "/services/hybrid" },
        { name: "Flutter", path: "/services/flutter" },
      ],
    },
    {
      title: "Web Development",
      icon: <FaGlobe />,
      links: [
        { name: "Angular", path: "/services/angular" },
        { name: "ReactJS", path: "/services/reactjs" },
        { name: "VueJS", path: "/services/vuejs" },
        { name: "CMS", path: "/services/content-management-system" },
        { name: "WordPress", path: "/services/wordpress" },
      ],
    },
    {
      title: "Server Side",
      icon: <FaServer />,
      links: [
        { name: "PHP", path: "/services/php" },
        { name: "Laravel", path: "/services/laravel" },
        { name: "CodeIgniter", path: "/services/codeigniter" },
        { name: "Python", path: "/services/python-development-services" },
      ],
    },
    {
      title: "Cloud & DevOps",
      icon: <FaCloud />,
      links: [
        { name: "AWS Services", path: "/services/aws-services" },
        { name: "DevOps Services", path: "/services/devops-services" },
      ],
    },
    {
      title: "Company",
      icon: <FaBuilding />,
      links: [
        { name: "About Us", path: "/about-us" },
        { name: "Career", path: "/career" },
        { name: "IT Staffing", path: "/it-staffing" },
        { name: "IT Consulting", path: "/it-consulting" },
      ],
    },
    {
      title: "Custom Services",
      icon: <FaBriefcase />,
      links: [
        {
          name: "Dedicated Hiring",
          path: "/services/outsourcing-dedicated-hiring",
        }, // ✅ fixed path
      ],
    },

    {
      title: "Linux & Server Management",
      icon: <FaServer />,
      links: [
        {
          name: "Linux & Web Hosting Services",
          path: "/services/linux-&-web-hosting-services",
        },
      ],
    },
  ];

  return (
    <Layout>
      <section className="relative bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white py-24 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          {/* Heading */}
          <div className="text-center mb-20">
            <h2 className="text-5xl font-extrabold">
              Explore Our <span className="text-[#FF5722]">Sitemap</span>
            </h2>
            <p className="text-gray-400 mt-6 text-lg">
              Quickly navigate through all our services and pages
            </p>
          </div>

          {/* Grid */}
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-10">
            {sections.map((section, index) => (
              <div
                key={index}
                className="group bg-white/5 backdrop-blur-xl border border-white/10 
                rounded-3xl p-8 transition duration-500 
                hover:-translate-y-3 hover:border-[#FF5722] 
                hover:shadow-[0_0_40px_rgba(255,87,34,0.4)]"
              >
                {/* Icon + Title */}
                <div className="flex items-center gap-4 mb-6">
                  <div className="text-2xl text-[#FF5722] group-hover:scale-110 transition">
                    {section.icon}
                  </div>
                  <h3 className="text-xl font-semibold relative">
                    {section.title}
                    <span className="block h-[2px] w-0 bg-[#FF5722] transition-all duration-500 group-hover:w-full mt-2"></span>
                  </h3>
                </div>

                {/* Links */}
                <ul className="space-y-3">
                  {section.links.map((link, i) => (
                    <li key={i}>
                      <Link
                        to={link.path}
                        className="text-gray-300 hover:text-[#FF5722] transition duration-300 flex items-center gap-3 hover:translate-x-2"
                      >
                        <span className="w-2 h-2 bg-[#FF5722] rounded-full"></span>
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Glow Effects */}
      </section>
    </Layout>
  );
};

export default Sitemap;
