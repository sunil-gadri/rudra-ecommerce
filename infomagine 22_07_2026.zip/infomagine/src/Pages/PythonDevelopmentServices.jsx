import React, { useState, useEffect } from "react"; // Added useState for the FAQ logic
import { Link } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";
import {
  ShieldCheck,
  Activity,
  ShoppingCart,
  BookOpen,
  Truck,
  Cloud,
  ChevronDown, // Added for the FAQ accordion
} from "lucide-react";
import headerpthon from "../assets/headerpthon.jpg";
import Layout from "../Components/Layout";
import pythonlogo from "../assets/pythonlogo.png";
import pythontechimg from "../assets/pythontechimg.png";
import pythonprocess from "../assets/pythonprocess.png";
import pythonbenefits from "../assets/pythonbenefits.png";
import whypythonimg from "../assets/whypythonimg.jpg";
import {
  CheckCircle,
  FileText,
  Code,
  ArrowUpRight,
  Database,
  Headphones,
} from "lucide-react";

import { Code2, Rocket, Users, LifeBuoy } from "lucide-react";

// --- FAQ Item Sub-component ---
const FAQItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-slate-200 dark:border-slate-700">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex w-full items-center justify-between py-6 text-left transition-all hover:text-[#ff3f00]"
      >
        <span className="text-lg font-medium text-slate-900 dark:text-white">
          {question}
        </span>
        <ChevronDown
          className={`h-5 w-5 text-slate-500 transition-transform duration-300 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ease-in-out ${
          isOpen ? "max-h-96 pb-6 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <p className="text-base text-slate-600 dark:text-slate-400 leading-relaxed">
          {answer}
        </p>
      </div>
    </div>
  );
};

const features = [
  {
    title: "Experienced Python Developers",
    description:
      "Our skilled team brings deep expertise in modern frameworks like Django, FastAPI, and Flask.",
    icon: <Users className="w-8 h-8 text-[#ff3f00]" />,
  },
  {
    title: "Custom & Scalable Solutions",
    description:
      "Tailored applications designed to handle your business growth without breaking a sweat.",
    icon: <Rocket className="w-8 h-8 text-[#ff3f00]" />,
  },
  {
    title: "Agile Development Approach",
    description:
      "We iterate quickly, ensuring faster delivery cycles with continuous and visible improvements.",
    icon: <Code2 className="w-8 h-8 text-[#ff3f00]" />,
  },
  {
    title: "Secure & Optimized Code",
    description:
      "Performance and security aren't afterthoughts; they are baked into our development DNA.",
    icon: <ShieldCheck className="w-8 h-8 text-[#ff3f00]" />,
  },
  {
    title: "Ongoing Support & Maintenance",
    description:
      "We ensure your applications stay reliable with regular updates, performance monitoring, and quick issue resolution after deployment.",
    icon: <LifeBuoy className="w-8 h-8 text-[#ff3f00]" />,
  },
];

const industries = [
  {
    title: "FinTech",
    desc: "Secure financial applications and analytics platforms.",
    icon: <ShieldCheck className="w-8 h-8 text-[#ff3f00]" />,
    gradient: "from-blue-500/10 to-transparent",
  },
  {
    title: "Healthcare",
    desc: "Data-driven healthcare and telemedicine solutions.",
    icon: <Activity className="w-8 h-8 text-[#ff3f00]" />,
    gradient: "from-emerald-500/10 to-transparent",
  },
  {
    title: "eCommerce",
    desc: "Scalable online stores and backend systems.",
    icon: <ShoppingCart className="w-8 h-8 text-[#ff3f00]" />,
    gradient: "from-orange-500/10 to-transparent",
  },
  {
    title: "EdTech",
    desc: "Learning platforms and student management systems.",
    icon: <BookOpen className="w-8 h-8 text-[#ff3f00]" />,
    gradient: "from-purple-500/10 to-transparent",
  },
  {
    title: "Logistics",
    desc: "Automation and tracking systems.",
    icon: <Truck className="w-8 h-8 text-[#ff3f00]" />,
    gradient: "from-cyan-500/10 to-transparent",
  },
  {
    title: "SaaS Platforms",
    desc: "Multi-tenant cloud-based applications.",
    icon: <Cloud className="w-8 h-8 text-[#ff3f00]" />,
    gradient: "from-indigo-500/10 to-transparent",
  },
];

const faqs = [
  {
    question: "What are Python development services?",
    answer:
      "Python development services include building web applications, custom software, APIs, automation tools, and AI-based solutions using Python. These services help businesses create scalable, secure, and high-performance digital products.",
  },
  {
    question: "Why is Python preferred for web development?",
    answer:
      "Python is preferred because of its simple syntax, rapid development capabilities, and powerful frameworks like Django and Flask. It allows developers to build scalable and secure applications faster compared to many other programming languages.",
  },
  {
    question: "Which frameworks are used in Python development?",
    answer:
      "Popular Python frameworks include Django, Flask, and FastAPI. These frameworks help in building web apps, APIs, and high-performance backend systems efficiently.",
  },
  {
    question: "Is Python suitable for large-scale applications?", 
    answer:
      "Yes, Python is highly scalable and used by large enterprises for building complex applications. With proper architecture and cloud integration, Python can handle high traffic and large datasets efficiently.",
  },
  {
    question: "What industries use Python development services?", 
    answer:
      "Python is widely used in industries like FinTech, Healthcare, EdTech, eCommerce, Logistics, and SaaS. It is especially popular for data-driven applications and automation systems.",
  },
  {
    question: "Can Python be used for AI and machine learning projects?",
    answer:
      "Yes, Python is one of the leading languages for AI and machine learning. Libraries like TensorFlow, PyTorch, and Scikit-learn make it ideal for building intelligent systems and predictive models.",
  },
  {
    question: "How much does Python development cost?",
    answer:
      "The cost depends on project complexity, features, and development time. Simple applications cost less, while enterprise-level or AI-based solutions require higher investment. Many companies offer hourly, monthly, or fixed pricing models.",
  },
  {
    question: "How long does it take to develop a Python application?",
    answer:
      "Development time depends on project scope and requirements. A basic application may take a few weeks, while complex platforms or SaaS products can take several months.",
  },
  {
    question: "Is Python good for API development?",
    answer:
      "Yes, Python is excellent for API development. Frameworks like FastAPI and Django REST Framework allow developers to build secure and high-performance APIs quickly.",
  },
  {
    question: "What are the advantages of hiring dedicated Python developers?",
    answer:
      "Hiring dedicated Python developers gives you full control, faster development, and access to specialized expertise. It also helps reduce hiring costs and improves project efficiency.",
  },
  {
    question: "Does Infomagine provide ongoing support after development?",
    answer:
      "Yes, Infomagine offers complete post-development support including maintenance, updates, performance optimization, and security enhancements.",
  },
  {
    question: "Can existing applications be migrated to Python?",
    answer:
      "Yes, legacy systems can be migrated to Python for better scalability, performance, and maintainability. Proper planning ensures smooth transition without data loss.",
  },
  {
    question: "Is Python secure for web application development?",
    answer:
      "Python provides strong security features and supports best practices like encryption, authentication, and secure coding standards, making it suitable for secure application development.",
  },
  {
    question: "Why choose Infomagine for Python development services?",
    answer:
      "Infomagine offers experienced developers, scalable solutions, modern frameworks, and end-to-end support to ensure successful project delivery aligned with your business goals.",
  },
];
const services = [
  {
    title: "Web Application Development",
    description:
      "Build scalable and secure web applications using Python frameworks like Django and Flask.",
    icon: <Code className="w-15 h-15 text-[#FF5722]" />,
  },
  {
    title: "Custom Software Development",
    description:
      "Develop tailored business solutions to meet specific operational needs.",
    icon: <FileText className="w-15 h-15 text-[#FF5722]" />,
  },
  {
    title: "API Development & Integration",
    description:
      "Create and integrate RESTful APIs for seamless system communication.",
    icon: <ArrowUpRight className="w-15 h-15 text-[#FF5722]" />,
  },
  {
    title: "AI & Machine Learning Solutions",
    description:
      "Develop intelligent systems using data analytics and machine learning models.",
    icon: <Database className="w-15 h-15 text-[#FF5722]" />,
  },
  {
    title: "Automation & Scripting",
    description:
      "Automate repetitive tasks and workflows to improve efficiency.",
    icon: <CheckCircle className="w-15 h-15 text-[#FF5722]" />,
  },
  {
    title: "Data Analytics & Processing",
    description:
      "Build data-driven solutions for insights and business intelligence.",
    icon: <Headphones className="w-15 h-15 text-[#FF5722]" />,
  },
];

const PythonDevelopmentServices = () => {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true,
      easing: "ease-in-out",
    });
  }, []);

  return (
    <>
      <Layout>
        {/* HERO SECTION */}
        <header className="relative w-full h-screen">
          <img
            src={headerpthon}
            alt=""
            className="object-cover w-full h-full"
            data-aos="fade-in"
          />

          <div className="absolute inset-0 bg-black/60 flex items-center px-6 md:px-20">
            <div className="text-white max-w-2xl space-y-6">
              <img
                width={100}
                src={pythonlogo}
                alt="Python logo"
                className="float"
                loading="lazy"
                data-aos="zoom-in"
              />

              <h1
                className="text-4xl md:text-5xl font-bold leading-tight"
                data-aos="fade-up"
              >
                Python
              </h1>

              <Link
                to="/contact-us"
                className="inline-block bg-[#FF5722] text-white px-7 py-3 rounded-md font-semibold hover:bg-orange-600 transition"
                data-aos="fade-up"
                data-aos-delay="200"
              >
                Let’s Talk
              </Link>
            </div>
          </div>
        </header>
        {/* CONTENT SECTION */}
        <section className="w-full">
          <div className="grid justify-center items-center md:grid-cols-2">
            {/* LEFT SIDE IMAGE */}
            <div className="text-white flex flex-col justify-center px-8 md:px-16 py-20">
              <img
                src={whypythonimg}
                alt="Python services"
                className="w-full h-auto"
                data-aos="fade-right"
              />
            </div>

            {/* RIGHT SIDE CONTENT */}
            <div className="bg-gray-50 px-6 md:px-12 py-16">
              <h2
                className="text-2xl md:text-3xl font-bold mb-4"
                data-aos="fade-left"
              >
                Build Scalable & Powerful Applications with Python
              </h2>

              <p
                className="text-gray-600 leading-relaxed mb-4"
                data-aos="fade-left"
                data-aos-delay="100"
              >
                Python is one of the most versatile and widely used programming
                languages for modern software development. Known for its
                simplicity, flexibility, and strong community support, Python is
                ideal for building web applications, automation tools, AI
                solutions, and enterprise systems.
              </p>

              <p
                className="text-gray-600 leading-relaxed mb-6"
                data-aos="fade-left"
                data-aos-delay="200"
              >
                At Infomagine, we leverage Python to develop secure, scalable,
                and high-performance applications tailored to your business
                needs. Whether you are building a startup product or scaling
                enterprise systems, Python enables faster development with
                reliable performance.
              </p>

              <h3 className="text-xl font-semibold mb-4" data-aos="fade-up">
                Key Highlights
              </h3>

              <ul className="space-y-3">
                <li
                  className="flex items-start"
                  data-aos="fade-up"
                  data-aos-delay="100"
                >
                  <span className="text-orange-500 mr-2">✔</span>
                  <span>
                    <strong>Easy & Fast Development:</strong> Python’s simple
                    syntax enables faster coding and quicker project delivery.
                  </span>
                </li>

                <li
                  className="flex items-start"
                  data-aos="fade-up"
                  data-aos-delay="200"
                >
                  <span className="text-orange-500 mr-2">✔</span>
                  <span>
                    <strong>Highly Scalable:</strong> Perfect for building
                    applications that can grow with your business.
                  </span>
                </li>

                <li
                  className="flex items-start"
                  data-aos="fade-up"
                  data-aos-delay="300"
                >
                  <span className="text-orange-500 mr-2">✔</span>
                  <span>
                    <strong>Versatile Technology:</strong> Used for web, AI,
                    automation, data analytics, and more.
                  </span>
                </li>

                <li
                  className="flex items-start"
                  data-aos="fade-up"
                  data-aos-delay="400"
                >
                  <span className="text-orange-500 mr-2">✔</span>
                  <span>
                    <strong>Strong Community Support:</strong> Access to a vast
                    ecosystem of libraries and frameworks.
                  </span>
                </li>

                <li
                  className="flex items-start"
                  data-aos="fade-up"
                  data-aos-delay="500"
                >
                  <span className="text-orange-500 mr-2">✔</span>
                  <span>
                    <strong>Cost-Effective Development:</strong> Reduced
                    development time leads to lower project costs.
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </section>

     <section className="bg-[#030615] py-16">
  <div className="container mx-auto px-6 md:px-12">
    {/* Heading */}
    <h2
      className="text-4xl font-bold text-white text-center mb-8"
      data-aos="fade-down"
      data-aos-duration="1000"
      data-aos-easing="ease-in-out"
    >
      Why Businesses Choose Python for Development
    </h2>

    {/* Content Card */}
    <div
      className="md:p-4 text-center max-w-6xl mx-auto"
      data-aos="fade-up"
      data-aos-duration="1200"
      data-aos-delay="200"
      data-aos-easing="ease-out-cubic"
    >
      <p className="text-gray-400 text-lg leading-relaxed">
        Python offers{" "}
        <span className="font-semibold">flexibility, speed, and reliability</span>, making it a preferred choice for startups and enterprises. It supports{" "}
        <span className="font-semibold">rapid development, seamless integrations, and scalable architectures</span>{" "}
        that help businesses innovate faster.
      </p>
    </div>
  </div>

  <div className="mt-10 relative inline-block">
    <img 
      src={pythonbenefits} 
      alt="" 
      className="rounded-xl shadow-lg"
      data-aos="zoom-in"
      data-aos-duration="1000"
      data-aos-delay="400"
      data-aos-easing="ease-in-out"
    />

    <img
      src={pythonlogo}
      alt="Python Logo"
      className="w-32 h-32 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-float"
      data-aos="flip-left"
      data-aos-duration="1200"
      data-aos-delay="600"
      data-aos-easing="ease-in-out"
    />
  </div>
</section>
        
      <section className="bg-gray-50 py-16 px-6 md:px-12">
  <div
    className="max-w-6xl mx-auto text-center mb-12"
    data-aos="fade-down"
    data-aos-duration="1000"
    data-aos-easing="ease-in-out"
  >
    <h2 className="text-4xl font-bold text-gray-900 mb-4">
      <span>Python Development Services We Offer</span>
    </h2>
    <p className="text-gray-600 max-w-3xl mx-auto">
      End-to-End Python Development Solutions
    </p>
  </div>

  <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
    {services.map((service, index) => (
      <div
        key={index}
        className="border border-orange-300 rounded-xl  
                   hover:shadow-lg transition duration-300 
                   aspect-square p-6 flex flex-col justify-center text-center"
        data-aos="fade-up"
        data-aos-duration="1000"
        data-aos-delay={`${index * 200}`} // stagger cards by 200ms
        data-aos-easing="ease-out-cubic"
      >
        <div className="flex justify-center mb-4">
          <div className="text-[#FF5722] text-4xl">{service.icon}</div>
        </div>

        <h3
          className="text-lg font-semibold mb-2"
          style={{ color: "#FF5722" }}
        >
          {service.title}
        </h3>

        <p className="text-gray-600 text-sm">{service.description}</p>
      </div>
    ))}
  </div>
</section>


        <section className="bg-[#030615] flex flex-col justify-center items-center py-16">
  <div className="container mx-auto px-6 md:px-12">
    {/* Heading */}
    <h2
      className="text-4xl font-bold text-white text-center mb-8"
      data-aos="fade-down"
      data-aos-duration="1000"
      data-aos-easing="ease-in-out"
    >
      Technologies & Frameworks We Use
    </h2>

    {/* Content Card */}
    <div
      className="md:p-4 flex flex-col justify-center items-center text-center mx-auto"
      data-aos="fade-up"
      data-aos-delay="200"
      data-aos-duration="1000"
      data-aos-easing="ease-out-cubic"
    >
      <p className="text-gray-400 text-lg leading-relaxed max-w-3xl">
        Modern Python Tech Stack that helps businesses innovate faster. From robust frameworks to efficient libraries, we leverage the best tools for scalable and reliable solutions.
      </p>
    </div>
  </div>

  {/* Image with animation */}
  <div
    className="mt-20 relative"
    data-aos="zoom-in"
    data-aos-duration="1200"
    data-aos-delay="400"
    data-aos-easing="ease-in-out"
  >
    <img
      width={700}
      src={pythontechimg}
      alt="Python Technologies"
      className="rounded-xl shadow-2xl transform transition-transform hover:scale-105"
    />
  </div>
</section>


       <section className="relative bg-[#fcfcfc] py-24 overflow-hidden">
  {/* Subtle background decoration */}
  <div className="absolute top-0 left-0 w-full h-full opacity-40 pointer-events-none">
    <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-blue-100 blur-[120px]" data-aos="zoom-in" data-aos-duration="2000"></div>
    <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-50 blur-[120px]" data-aos="zoom-in" data-aos-duration="2000" data-aos-delay="200"></div>
  </div>

  <div className="container relative z-10 mx-auto px-6 md:px-12">
    {/* Heading Section */}
    <div
      className="text-center max-w-3xl mx-auto mb-16"
      data-aos="fade-down"
      data-aos-duration="1200"
    >
      <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
        Our Python Development Process
      </h2>
      <div className="h-1.5 w-20 bg-[#ff3f00] mx-auto mb-6 rounded-full" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000"></div>
      <p className="text-slate-500 text-lg md:text-xl leading-relaxed" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
        Our modern Python tech stack is engineered to help businesses
        scale faster and innovate with precision.
      </p>
    </div>

    {/* The Visual Container */}
    <div
      className="relative bg-white border border-slate-100 rounded-[2rem] p-4 md:p-12 shadow-[0_20px_50px_rgba(0,0,0,0.05)] transition-transform hover:scale-[1.01] duration-500"
      data-aos="flip-up"
      data-aos-duration="1200"
      data-aos-delay="200"
    >
      {/* Image Wrapper with a "Paper" feel */}
      <div className="bg-slate-50/50 rounded-2xl p-4 md:p-8 border border-dashed border-slate-200" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="400">
        <img
          className="w-full h-auto max-w-4xl mx-auto drop-shadow-md"
          src={pythonprocess}
          alt="Python Technology Stack"
        />
      </div>

      {/* Modern Tag Cloud for extra context */}
      <div className="flex flex-wrap justify-center gap-3 mt-10">
        {[
          "Backend",
          "Data Science",
          "Automation",
          "Cloud Native",
          "API First",
        ].map((tag, index) => (
          <span
            key={tag}
            className="px-5 py-2 bg-slate-100 text-slate-600 font-medium rounded-full text-sm border border-slate-200/50"
            data-aos="fade-up"
            data-aos-delay={600 + index * 100} // staggered animation
            data-aos-duration="800"
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  </div>
</section>


        <section className="bg-[#0a0a0a] py-24 px-6 font-sans">
          <div className="max-w-7xl mx-auto">
            {/* Header Section */}
            <div className="mb-20">
              <div className="flex items-center gap-3 mb-4">
                <span className="h-px w-12 bg-[#ff3f00]"></span>
                <span className="text-[#ff3f00] font-bold tracking-[0.2em] uppercase text-xs">
                  06. Industries We Serve
                </span>
              </div>
              <h2 className="text-4xl md:text-6xl font-black text-white leading-tight">
                Industry-Focused <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff3f00] to-[#ff6a33]">
                  Python Solutions
                </span>
              </h2>
            </div>

            {/* Grid Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/10 border border-white/10">
              {industries.map((item, index) => (
                <div
                  key={index}
                  className="group relative bg-[#0a0a0a] p-10 transition-all duration-500 hover:bg-[#ff3f00]/5"
                >
                  {/* Animated Corner Accent */}
                  <div className="absolute top-0 left-0 w-0 h-1 bg-[#ff3f00] transition-all duration-500 group-hover:w-full" />

                  <div className="relative z-10">
                    <div className="mb-8 inline-flex items-center justify-center transition-transform duration-500 group-hover:scale-110">
                      {item.icon}
                    </div>

                    <h4 className="text-2xl font-bold text-white mb-4 group-hover:tracking-wider transition-all">
                      {item.title}
                    </h4>

                    <p className="text-gray-400 text-lg leading-relaxed mb-6 group-hover:text-gray-300">
                      {item.desc}
                    </p>

                    {/* Minimalist Arrow Link */}
                   <a href="/contact-us"> <div className="flex items-center gap-2 text-[#ff3f00] opacity-0 -translate-x-4 transition-all duration-500 group-hover:opacity-100 group-hover:translate-x-0 cursor-pointer font-bold text-sm uppercase">
                      Explore Solution <span>→</span>
                    </div></a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

       <section className="py-24 bg-white" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
  <div className="container mx-auto px-6">
    {/* Header */}
    <div
      className="text-center mb-16 max-w-3xl mx-auto"
      data-aos="zoom-in"
      data-aos-duration="1000"
      data-aos-once="true"
    >
      <h2 className="text-sm font-semibold tracking-widest text-[#ff3f00] uppercase mb-4">
        Why Choose Infomagine
      </h2>

      <h3 className="text-4xl md:text-5xl font-bold text-slate-900 leading-tight">
        A Reliable{" "}
        <span className="text-[#ff3f00]">Python Development</span>{" "}
        Partner
      </h3>

      <p className="text-slate-600 mt-5 text-lg leading-relaxed">
        We deliver scalable, high-performance Python solutions designed
        to align perfectly with your business objectives.
      </p>

      <div className="w-16 h-[2px] bg-[#ff3f00] mx-auto mt-6"></div>
    </div>

    {/* Features */}
    <div className="grid grid-cols-1 px-20 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {features.map((feature, index) => (
        <div
          key={index}
          className="group bg-white border border-slate-200 rounded-xl p-8 transition-all duration-300 hover:border-[#ff3f00]/40 hover:shadow-lg"
          data-aos="flip-left"
          data-aos-delay={`${index * 150}`}
          data-aos-duration="1000"
          data-aos-once="true"
        >
          {/* Icon */}
          <div className="mb-5 flex items-center justify-center w-12 h-12 rounded-lg bg-[#ff3f00]/10 text-[#ff3f00]">
            {feature.icon}
          </div>

          {/* Title */}
          <h4 className="text-lg font-semibold text-slate-900 mb-2 group-hover:text-[#ff3f00] transition-colors">
            {feature.title}
          </h4>

          {/* Description */}
          <p className="text-slate-600 text-sm leading-relaxed">
            {feature.description}
          </p>

          {/* Subtle divider */}
          <div className="mt-6 h-[1px] w-8 bg-slate-200 group-hover:bg-[#ff3f00] transition-all"></div>
        </div>
      ))}
    </div>
  </div>
</section>



        {/* --- UPDATED FAQ SECTION --- */}
        <section className="bg-slate-50 dark:bg-slate-900 py-20 px-4">
  <div
    className="mx-auto max-w-3xl rounded-2xl bg-white dark:bg-slate-800 p-8 shadow-xl shadow-slate-200/50 dark:shadow-none"
    data-aos="zoom-in-up" // updated animation
  >
    <div className="mb-10 text-center">
      <h2 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
        Frequently Asked Questions
      </h2>
      <p className="mt-4 text-slate-600 dark:text-slate-400">
        Everything you need to know about using Python for your next
        project.
      </p>
    </div>

    <div className="space-y-2">
      {faqs.map((faq, index) => (
        <FAQItem
          key={index}
          question={faq.question}
          answer={faq.answer}
        />
      ))}
    </div>
  </div>
</section>


      </Layout>
    </>
  );
};

export default PythonDevelopmentServices;
