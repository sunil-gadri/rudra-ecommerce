import React from "react";
import Layout from "../Components/Layout";
import headerdevops from "../assets/headerdevops.jpeg";
import devopssection3 from "../assets/devopssection3.png";
import stepsimg2 from "../assets/stepsimg2.png";
import devopslogoimg from "../assets/devopslogoimg.png";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";

import {
  FaCogs,
  FaDocker,
  FaCodeBranch,
  FaChartLine,
  FaRobot,
  FaCloud,
  FaRocket,
  FaShieldAlt,
  FaHeadset,
} from "react-icons/fa";

import { ArrowRight } from "lucide-react";

const DevopsServices = () => {

  const services = [
    {
      icon: <FaCodeBranch size={26} />,
      title: "CI/CD Pipeline Setup",
      description:
        "We design and implement CI/CD pipelines that enable rapid and reliable software delivery through automation.",
      highlights: [
        "Automated build & deployment",
        "Faster release cycles",
        "Cloud integration",
        "Environment workflows",
        "Improved code quality",
      ],
    },
    {
      icon: <FaDocker size={26} />,
      title: "Containerization & Orchestration",
      description:
        "We package applications into lightweight containers and orchestrate them for scalability, flexibility and simplified deployments.",
      highlights: [
        "Application containerization",
        "Microservices enablement",
        "High availability",
        "Faster setup",
        "Efficient resource usage",
      ],
    },
    {
      icon: <FaCogs size={26} />,
      title: "Infrastructure as Code (IaC)",
      description:
        "Manage and provision infrastructure using code for consistent, scalable and automated cloud environments.",
      highlights: [
        "Automated provisioning",
        "Version control",
        "Reduced errors",
        "Faster replication",
        "Scalable deployments",
      ],
    },
    {
      icon: <FaChartLine size={26} />,
      title: "Monitoring & Logging",
      description:
        "Gain full visibility into application performance and infrastructure health with proactive monitoring solutions.",
      highlights: [
        "Real-time monitoring",
        "Centralized logging",
        "Health dashboards",
        "Alert systems",
        "Improved incident response",
      ],
    },
    {
      icon: <FaRobot size={26} />,
      title: "Automation & Workflow Optimization",
      description:
        "Automate repetitive operational tasks and streamline development workflows to improve productivity.",
      highlights: [
        "Automated workflows",
        "Reduced manual effort",
        "Faster issue resolution",
        "Team collaboration",
        "Continuous improvement",
      ],
    },
  ];

  const highlights = [
    {
      icon: <FaCloud size={28} />,
      title: "Cloud-native DevOps Expertise",
      desc: "Modern DevOps solutions built for scalable cloud environments.",
    },
    {
      icon: <FaRocket size={28} />,
      title: "Faster Time-to-Market",
      desc: "Accelerate development cycles with automation and CI/CD pipelines.",
    },
    {
      icon: <FaShieldAlt size={28} />,
      title: "Secure & Scalable Infrastructure",
      desc: "Enterprise-grade security with future-ready scalability.",
    },
    {
      icon: <FaChartLine size={28} />,
      title: "Cost Optimization Strategies",
      desc: "Reduce infrastructure costs through smart automation and monitoring.",
    },
    {
      icon: <FaHeadset size={28} />,
      title: "Ongoing Monitoring & Support",
      desc: "Continuous performance monitoring and proactive issue resolution.",
    },
  ];

  return (
    <Layout>

      {/* ================= SEO ================= */}
      <Helmet>
        <title>
          DevOps Services | CI/CD, Cloud Automation & Infrastructure | Infomagine
        </title>

        <meta
          name="description"
          content="Infomagine provides professional DevOps services including CI/CD pipelines, containerization, infrastructure as code, monitoring and automation to accelerate software delivery."
        />

        <meta
          name="keywords"
          content="DevOps services, CI/CD pipeline, containerization, Kubernetes, infrastructure as code, cloud DevOps consulting, automation"
        />

        <link
          rel="canonical"
          href="https://yourdomain.com/devops-services"
        />

        {/* Open Graph */}
        <meta property="og:title" content="DevOps Services by Infomagine" />
        <meta
          property="og:description"
          content="Accelerate software delivery with modern DevOps automation and CI/CD pipelines."
        />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="/devops-preview.jpg" />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />

        {/* Schema Structured Data */}
        <script type="application/ld+json">
          {`
          {
            "@context": "https://schema.org",
            "@type": "Service",
            "serviceType": "DevOps Services",
            "provider": {
              "@type": "Organization",
              "name": "Infomagine"
            },
            "description": "Professional DevOps services including CI/CD pipelines, containerization, monitoring and infrastructure automation."
          }
        `}
        </script>
      </Helmet>

      {/* ================= HERO SECTION ================= */}
      <header className="relative w-full h-screen">
        <img
          src={headerdevops}
          alt="DevOps services including CI/CD pipelines and cloud automation"
          className="object-cover w-full h-full"
        />

        <div className="absolute inset-0 bg-black/60 flex items-center px-10 md:px-20">
          <div className="text-white max-w-2xl space-y-5">

            <img
              width={200}
              src={devopslogoimg}
              alt="DevOps automation logo"
              className="float"
              loading="lazy"
            />

            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Accelerate Software Delivery with DevOps Excellence
            </h1>

            <p className="text-lg text-gray-200">
              Infomagine’s DevOps services help businesses streamline development,
              deployment and operations using modern automation and cloud-native practices.
            </p>

            <Link
              to="/contact-us"
              className="inline-block bg-[#FF5722] text-white px-6 py-3 rounded-md font-semibold hover:bg-orange-600 transition"
            >
              Let’s Talk
            </Link>

          </div>
        </div>
      </header>

      {/* ================= SERVICES ================= */}
      <section className="w-full bg-gray-100 py-20 px-6 md:px-16">

        <div className="max-w-7xl mx-auto">

          <h2 className="text-4xl font-bold text-center mb-16">
            DevOps Services by Infomagine
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">

            {services.map((service, index) => (
              <article
                key={index}
                className="group relative bg-white border border-gray-200 rounded-3xl p-8 transition duration-500 hover:shadow-xl hover:-translate-y-2"
              >

                <div className="w-12 h-1 bg-[#FF5722] mb-6 rounded-full"></div>

                <div className="text-[#FF5722] mb-4">{service.icon}</div>

                <h3 className="text-xl font-semibold mb-4">
                  {service.title}
                </h3>

                <p className="text-gray-600 text-sm leading-relaxed mb-6">
                  {service.description}
                </p>

                <div className="flex flex-wrap gap-3 mb-12">
                  {service.highlights.map((item, i) => (
                    <span
                      key={i}
                      className="bg-orange-50 text-orange-500 text-xs px-4 py-2 rounded-full"
                    >
                      {item}
                    </span>
                  ))}
                </div>

                <div className="absolute bottom-6 right-6 w-10 h-10 flex items-center justify-center border border-gray-400 rounded-full group-hover:bg-[#FF5722] group-hover:text-white transition">
                  <ArrowRight size={18} />
                </div>

              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ================= ENGAGEMENT MODEL ================= */}
      <section className="w-full py-20 px-6 md:px-16">

        <div className="text-center mx-auto mb-16">

          <h2 className="text-4xl md:text-5xl font-semibold mb-6">
            Flexible DevOps Engagement Models
          </h2>

          <p className="text-lg leading-relaxed">
            Every organization has different DevOps maturity levels. Infomagine
            offers flexible engagement models tailored to your business needs.
          </p>

        </div>

        <img
          src={devopssection3}
          alt="DevOps engagement models for consulting and managed services"
          loading="lazy"
        />

      </section>

      {/* ================= WORKFLOW ================= */}
      <section className="w-full bg-[#030615] text-white py-20 px-6 md:px-16">

        <div className="text-center mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-semibold">
            Our DevOps Workflow
          </h2>
        </div>

        <img
          src={stepsimg2}
          alt="DevOps workflow from development to deployment and monitoring"
          loading="lazy"
        />

      </section>

      {/* ================= WHY CHOOSE ================= */}
      <section className="w-full bg-gray-100 py-24 px-6 md:px-20">

        <div className="max-w-7xl mx-auto">

          <div className="text-center mb-16">

            <h2 className="text-4xl md:text-5xl font-bold">
              Why Choose <span className="text-[#FF5722]">Infomagine</span> for DevOps?
            </h2>

            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Empower your development lifecycle with scalable and secure DevOps solutions.
            </p>

          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-10">

            {highlights.map((item, index) => (
              <article
                key={index}
                className="group bg-white border border-gray-200 rounded-3xl p-8 hover:border-[#FF5722] transition duration-500 hover:shadow-xl"
              >

                <div className="text-[#FF5722] mb-4 group-hover:scale-110 transition">
                  {item.icon}
                </div>

                <h3 className="text-xl font-semibold mb-3">
                  {item.title}
                </h3>

                <p className="text-gray-600 text-sm">
                  {item.desc}
                </p>

              </article>
            ))}

          </div>

        </div>
      </section>

    </Layout>
  );
};

export default DevopsServices;  