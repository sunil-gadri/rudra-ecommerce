import React from "react";
import Layout from "../Components/Layout";
import awsimgbg from "../assets/awsimgbg.jpg";
import awssectionimg from "../assets/awssectionimg.png";
import awssectionimg2 from "../assets/awssectionimg2.png";
import awslogopng from "../assets/awslogopng.png";
import { Link } from "react-router-dom";
import { HiOutlineSparkles } from "react-icons/hi";
import { FaTruck, FaTaxi, FaShoppingCart, FaTint } from "react-icons/fa";
import { MdLocalLaundryService } from "react-icons/md";
import { Helmet } from "react-helmet-async";

import {
  FaMoneyBillWave,
  FaGraduationCap,
  FaHeartbeat,
  FaHome,
  FaRocket,
} from "react-icons/fa";
import { RiCloudFill } from "react-icons/ri";

const AwsServices = () => {
  return (
    <Layout>

            <Helmet>
        <title>AWS Cloud Services | Scalable & Secure AWS Solutions</title>

        <meta
          name="description"
          content="Explore professional AWS cloud services including cloud migration, DevOps, serverless architecture, infrastructure setup, and secure application hosting with scalable AWS solutions."
        />

        <meta
          name="keywords"
          content="AWS services, Amazon Web Services, AWS cloud solutions, cloud migration, AWS DevOps, serverless architecture, AWS infrastructure setup, AWS hosting, scalable cloud solutions"
        />

        <meta name="robots" content="index, follow" />

        <link
          rel="canonical"
          href="https://yourdomain.com/aws-services"
        />

        {/* OpenGraph for Social */}
        <meta property="og:title" content="AWS Cloud Services | Scalable & Secure AWS Solutions" />
        <meta
          property="og:description"
          content="Launch, scale and secure your applications with professional AWS cloud services including migration, DevOps automation, serverless infrastructure and high-performance hosting."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://yourdomain.com/aws-services" />
        <meta property="og:image" content={awsimgbg} />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="AWS Cloud Services | Scalable & Secure AWS Solutions" />
        <meta
          name="twitter:description"
          content="Professional AWS cloud services for scalable infrastructure, cloud migration, DevOps automation and secure application hosting."
        />
        <meta name="twitter:image" content={awsimgbg} />

        {/* Structured Data */}
        <script type="application/ld+json">
          {`
          {
            "@context": "https://schema.org",
            "@type": "Service",
            "name": "AWS Cloud Services",
            "provider": {
              "@type": "Organization",
              "name": "Infomagine"
            },
            "description": "Professional AWS cloud services including infrastructure setup, cloud migration, DevOps automation, serverless architecture and secure application hosting.",
            "areaServed": "Worldwide",
            "serviceType": "Cloud Computing Services"
          }
        `}
        </script>
      </Helmet>

      <div className="relative w-full h-screen">
        <img
          src={awsimgbg}
          alt="iOS App"
          className="object-cover w-full h-full"
        />

        <div className="absolute inset-0 bg-black/10 flex items-center px-10 md:px-20">
          <div data-aos="fade-right" className="text-white max-w-2xl space-y-5">
<img 
  width={100} 
  src={awslogopng} 
  alt="AWS Logo"
  className="float"
/>
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              AWS Services
            </h1>
            <p className="text-lg">Faster, Safer, Smarter with AWS and INT.</p>
            <Link
              to="/contact-us"
              className="inline-block bg-[#FF5722] text-white px-6 py-3 rounded-md font-semibold hover:bg-orange-600 transition"
            >
              Let’s Talk
            </Link>
          </div>
        </div>

        <div></div>
      </div>

      <div className="w-full flex items-center justify-center bg-[#f5f6f8] py-20 px-6 md:px-20">
        <div className="max-w-7xl mx-auto flex flex-col g:flex-row gap-16">
          <div>
            <h1 className="text-5xl font-semibold text-black mb-6">Why AWS?</h1>

            <p className="text-gray-600 text-lg leading-relaxed">
              Choosing Amazon Web Services (AWS) means building your digital
              infrastructure on one of the world’s most reliable and scalable
              cloud platforms. AWS enables businesses to launch applications
              faster, store data securely and scale resources instantly based
              on demand. At Infomagine, we leverage AWS to design
              high-performance architectures that reduce downtime, improve
              security and support rapid innovation. Whether you’re a startup
              or enterprise, AWS provides the flexibility to experiment, grow
              and modernize without heavy upfront investments. Our team ensures
              your cloud journey is smooth, cost-optimized and future-ready.
            </p>
          </div>

          <div className="flex flex-col gap-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-[#e9edf2] rounded-2xl p-6 flex items-start gap-4">
                <HiOutlineSparkles className="text-gray-700 text-2xl mt-1" />
                <p className="text-gray-700 text-lg">
                  High Scalability – Instantly scale infrastructure up or down
                  based on business demand.
                </p>
              </div>

              <div className="bg-[#e9edf2] rounded-2xl p-6 flex items-start gap-4">
                <HiOutlineSparkles className="text-gray-700 text-2xl mt-1" />
                <p className="text-gray-700 text-lg">
                  Enterprise-Grade Security – Advanced security controls,
                  encryption and compliance standards.
                </p>
              </div>

              <div className="bg-[#e9edf2] rounded-2xl p-6 flex items-start gap-4">
                <HiOutlineSparkles className="text-gray-700 text-2xl mt-1" />
                <p className="text-gray-700 text-lg">
                  Cost-Effective Model – Pay only for the resources you use with
                  no upfront hardware investment.
                </p>
              </div>

              <div className="bg-[#e9edf2] rounded-2xl p-6 flex items-start gap-4">
                <HiOutlineSparkles className="text-gray-700 text-2xl mt-1" />
                <p className="text-gray-700 text-lg">
                  Global Infrastructure – Reliable performance with worldwide
                  data centers and low latency.
                </p>
              </div>

              <div className="bg-[#e9edf2] rounded-2xl p-6 flex items-start gap-4">
                <HiOutlineSparkles className="text-gray-700 text-2xl mt-1" />
                <p className="text-gray-700 text-lg">
                  Faster Deployment – Launch applications and environments in
                  minutes, not weeks.
                </p>
              </div>

              <div className="bg-[#e9edf2] rounded-2xl p-6 flex items-start gap-4">
                <HiOutlineSparkles className="text-gray-700 text-2xl mt-1" />
                <p className="text-gray-700 text-lg">
                  High Availability – Built-in redundancy and disaster recovery
                  capabilities.
                </p>
              </div>
            </div>

            <p className="text-gray-800 font-semibold text-lg mt-2">
              Supports Modern Tech – Built for AI, analytics, serverless and
              cloud-native development.
            </p>
          </div>
        </div>
      </div>

      <section className="w-full bg-[#F54900] text-white py-20 px-6 md:px-20">
        <div className="max-w-7xl mx-auto">
          {/* Top Content */}
          <div className="text-center  mx-auto mb-16">
            <h1 className="text-4xl md:text-5xl font-semibold leading-tight mb-6">
              AWS Benefits
            </h1>

            <p className="text-lg leading-relaxed">
              AWS offers powerful advantages that help businesses move faster
              while maintaining security and performance. With on-demand
              infrastructure, you pay only for what you use, making it highly
              cost-efficient. Its global data centers ensure reliability, low
              latency and business continuity. Key benefits include improved
              scalability, enterprise-grade security, automated backups and
              faster deployment cycles.
            </p>
          </div>

          {/* Cards Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Card 1 */}
            <div className="bg-white text-gray-800 rounded-2xl p-6 h-[220px] flex flex-col justify-center gap-5">
              <h4 className="font-semibold text-2xl">
                On-Demand Infrastructure
              </h4>
              <p className="text-gray-600 text-md">
                Provision servers, storage and services instantly.
              </p>
            </div>

            {/* Card 2 */}
            <div className="bg-white text-gray-800 rounded-2xl p-6 h-[220px] flex flex-col justify-center gap-5">
              <h4 className="font-semibold w-50 text-2xl">
                Pay-As-You-Go Pricing
              </h4>
              <p className="text-gray-600 text-md">
                Optimize costs by paying only for actual usage.
              </p>
            </div>

            {/* Card 3 */}
            <div className="bg-white text-gray-800 rounded-2xl p-6 h-[220px] flex flex-col justify-center gap-5">
              <h4 className="font-semibold text-2xl">
                Advanced Security & Compliance
              </h4>
              <p className="text-gray-600 text-md">
                Multi-layer security with global compliance standards.
              </p>
            </div>

            {/* Card 4 */}
            <div className="bg-white text-gray-800 rounded-2xl p-6 h-[220px] flex flex-col justify-center gap-5">
              <h4 className="font-semibold text-2xl">
                Built-in Monitoring & Analytics
              </h4>
              <p className="text-gray-600 text-md">
                Real-time insights to improve performance and decision-making.
              </p>
            </div>

            {/* Card 5 */}
            <div className="bg-white text-gray-800 rounded-2xl p-6 h-[220px] flex flex-col justify-center gap-5">
              <h4 className="font-semibold text-2xl">
                Automated Backup & Disaster Recovery
              </h4>
              <p className="text-gray-600 text-md">
                Ensure business continuity with automated data protection.
              </p>
            </div>

            {/* Card 6 */}
            <div className="bg-white text-gray-800 rounded-2xl p-6 h-[220px] flex flex-col justify-center gap-5">
              <h4 className="font-semibold text-2xl">
                Faster Development Cycles
              </h4>
              <p className="text-gray-600 text-md">
                Speed up testing, deployment and product releases.
              </p>
            </div>

            {/* Card 7 */}
            <div className="bg-white text-gray-800 rounded-2xl p-6 h-[220px] flex flex-col justify-center gap-5">
              <h4 className="font-semibold w-50 text-2xl">
                AI & Serverless Ready
              </h4>
              <p className="text-gray-600 text-md">
                Easily build intelligent and event-driven applications.
              </p>
            </div>

            {/* Card 8 */}
            <div className="bg-white text-gray-800 rounded-2xl p-6 h-[220px] flex flex-col justify-center gap-5">
              <h4 className="font-semibold text-2xl">
                High Reliability & Uptime
              </h4>
              <p className="text-gray-600 text-md">
                Multi-region infrastructure for consistent performance.
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="py-20 bg-gray-100 px-30">
        <div>
          <h1 className="text-5xl font-semibold text-black mb-6">
            Solutions We Deliver on AWS
          </h1>

          <p className="text-gray-600 text-lg leading-relaxed">
            Infomagine provides end-to-end AWS cloud solutions tailored to your
            business goals. We design, deploy and manage cloud environments
            that support high availability and performance. Our AWS solutions
            include cloud migration, infrastructure setup, application hosting,
            DevOps automation, serverless architecture and data backup &
            disaster recovery. We also build scalable SaaS platforms, eCommerce
            infrastructure and mobile backend systems on AWS. Every solution is
            optimized for security, speed and cost efficiency.
          </p>

          <div className="mt-10">
            <img src={awssectionimg} alt="" />
          </div>
        </div>
      </div>

      <div className="py-20 bg-[#030615] px-30">
        <div>
          <h1 className="text-5xl font-semibold text-white mb-6">
            Process: How We Work with{" "}
            <span className="text-[#F54900]"> AWS</span>
          </h1>

          <p className="text-gray-500 text-lg leading-relaxed">
            Our AWS engagement follows a structured and transparent approach to
            ensure successful implementation. We start by analyzing your current
            infrastructure, business requirements and growth plans. Based on
            this, we design a scalable cloud architecture aligned with best
            practices. Next, we handle migration or deployment with minimal
            disruption, followed by performance optimization and security
            configuration. Post-deployment, we provide monitoring, cost
            optimization and ongoing support. This ensures your AWS environment
            remains stable, efficient and ready to scale.
          </p>

          <div className="mt-15">
            <img src={awssectionimg2} alt="" />
          </div>
        </div>
      </div>
      <section className="w-full bg-gray-100 py-20 px-6 md:px-20">
        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-12 items-center">
          {/* LEFT SIDE - 4 CARDS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl shadow-md p-6 text-center hover:shadow-xl transition hover:-translate-y-2 duration-300">
              <FaMoneyBillWave className="text-4xl text-orange-500 mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">FinTech</h3>
              <p className="text-gray-500 text-sm">
                Secure and scalable infrastructure for financial apps.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 text-center hover:shadow-xl transition hover:-translate-y-2 duration-300">
              <FaGraduationCap className="text-4xl text-orange-500 mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">EdTech</h3>
              <p className="text-gray-500 text-sm">
                Reliable cloud environments for e-learning platforms.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 text-center hover:shadow-xl transition hover:-translate-y-2 duration-300">
              <FaHeartbeat className="text-4xl text-orange-500 mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">Healthcare</h3>
              <p className="text-gray-500 text-sm">
                Secure data storage & telemedicine solutions.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 text-center hover:shadow-xl transition hover:-translate-y-2 duration-300">
              <FaShoppingCart className="text-4xl text-orange-500 mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">eCommerce</h3>
              <p className="text-gray-500 text-sm">
                High-performance infrastructure for traffic spikes.
              </p>
            </div>
          </div>

          {/* CENTER CONTENT */}
          <div className="text-center px-6">
            <h2 className="text-4xl font-bold mb-6 relative inline-block">
              Industries We Serve
            </h2>

            <p
              style={{ textAlignLast: "center" }}
              className="text-gray-600 text-justify leading-relaxed mb-6"
            >
              Our AWS solutions are designed to support diverse industries with
              unique technology needs. We help startups launch quickly,
              enterprises modernize legacy systems and agencies scale client
              projects efficiently. Industries we serve include FinTech, EdTech,
              Healthcare, eCommerce, Real Estate, Logistics and SaaS platforms.
              By leveraging AWS cloud capabilities, we enable faster innovation,
              secure data management and improved customer experiences. No
              matter your industry, we build cloud solutions that drive
              measurable growth.
            </p>
          </div>

          {/* RIGHT SIDE - 4 CARDS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl shadow-md p-6 text-center hover:shadow-xl transition hover:-translate-y-2 duration-300">
              <FaHome className="text-4xl text-orange-500 mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">Real Estate</h3>
              <p className="text-gray-500 text-sm">
                Cloud solutions for property portals & CRM systems.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 text-center hover:shadow-xl transition hover:-translate-y-2 duration-300">
              <FaTruck className="text-4xl text-orange-500 mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">Logistics</h3>
              <p className="text-gray-500 text-sm">
                Real-time tracking & scalable operations.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 text-center hover:shadow-xl transition hover:-translate-y-2 duration-300">
              <RiCloudFill className="text-4xl text-orange-500 mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">SaaS Platforms</h3>
              <p className="text-gray-500 text-sm">
                Multi-tenant scalable cloud architectures.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 text-center hover:shadow-xl transition hover:-translate-y-2 duration-300">
              <FaRocket className="text-4xl text-orange-500 mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">Startups</h3>
              <p className="text-gray-500 text-sm">
                Flexible cloud setups for rapid growth.
              </p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default AwsServices;
