import React from "react";
import Layout from "../Components/Layout";
import headerlinuximg from "../assets/headerlinuximg.jpg";
import linuximg1 from "../assets/linuximg1.png";
import linuxsection2img from "../assets/linuxsection2img.png";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import {
  ServerStackIcon,
  PhoneIcon,
  EnvelopeIcon,
} from "@heroicons/react/24/outline";

const LinuxAndWebHostingServices = () => {
  return (
    <>
      <Layout>

         <Helmet>
        <title>
          Linux Hosting & Server Management Services | Infomagine
        </title>

        <meta
          name="description"
          content="Infomagine provides secure and scalable Linux hosting, server management, web hosting infrastructure, monitoring, and performance optimization for businesses and applications."
        />

        <meta
          name="keywords"
          content="Linux hosting services, managed Linux server, web hosting management, Linux server management, VPS hosting, cloud hosting, server monitoring, Infomagine hosting"
        />

        <link
          rel="canonical"
          href="https://www.infomagine.com/linux-web-hosting-services"
        />

        {/* Open Graph */}
        <meta property="og:title" content="Linux Hosting & Server Solutions | Infomagine" />
        <meta
          property="og:description"
          content="Secure, scalable and fully managed Linux server and hosting solutions for businesses."
        />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.infomagine.com/linux-web-hosting-services"
        />
        <meta property="og:image" content={headerlinuximg} />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta
          name="twitter:title"
          content="Linux Hosting & Server Solutions | Infomagine"
        />
        <meta
          name="twitter:description"
          content="Reliable Linux hosting, server management and infrastructure services."
        />
        <meta name="twitter:image" content={headerlinuximg} />
      </Helmet>
      
        <div className="relative w-full h-screen">
          <img
            src={headerlinuximg}
            alt="DevOps Services"
            className="object-cover w-full h-full"
          />

          <div className="absolute inset-0 bg-black/60 flex items-center px-10 md:px-20">
            <div className="text-white max-w-2xl space-y-5">
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                Reliable Linux Hosting & Server Solutions
              </h1>
              <p className="text-lg text-gray-200">
                Experience hassle-free Linux hosting with Infomagine, where
                performance, security, and reliability come first. Our team
                manages everything from server configuration and optimization to
                continuous monitoring and security updates, so your websites and
                applications run seamlessly. Designed for businesses of all
                sizes, our hosting solutions offer scalability, high uptime, and
                robust infrastructure, empowering your online presence to grow
                without limits.
              </p>
              <Link
                to="/contact-us"
                className="inline-block bg-[#FF5722] text-white px-6 py-3 rounded-md font-semibold hover:bg-orange-600 transition"
              >
                Let’s Talk
              </Link>
            </div>
          </div>
        </div>

        <section className="w-full py-20 px-6 md:px-16">
          <div className="text-center  mx-auto mb-16">
            <h1 className="text-4xl md:text-5xl font-semibold leading-tight mb-6">
              Linux & Web Hosting Services
            </h1>

            <p className="text-lg  leading-relaxed">
              At Infomagine, we provide secure, scalable, fully managed Linux
              server and web hosting solutions tailored to your business needs.
              From server setup to ongoing monitoring and maintenance, our
              experts ensure your website and applications run smoothly with
              maximum uptime and security. Whether you’re running a business
              website, eCommerce store, SaaS platform, or enterprise system, we
              deliver stable hosting environments built for performance and
              growth.
            </p>
          </div>

          <div>
            <img src={linuximg1} alt="" />
          </div>
        </section>

        <section className="w-full text-white bg-[#030615] py-20 px-6 md:px-16">
          <div className="text-center  mx-auto mb-16">
            <h1 className="text-4xl md:text-5xl font-semibold leading-tight mb-6">
              Why Choose Infomagine for Web Hosting Management
            </h1>

            <p className="text-lg  leading-relaxed">
              At Infomagine, we deliver reliable and fully managed web hosting
              solutions to keep your websites running smoothly. Our experts
              handle server setup, security, monitoring, and performance
              optimization to ensure maximum uptime, speed, and stability, so
              you can focus on growing your business.
            </p>
          </div>

          <div>
            <img src={linuxsection2img} alt="" />
          </div>
        </section>

        <section className="w-full py-20 px-6 md:px-16 bg-gradient-to-r from-[#FF5722] to-orange-600 text-white">
          <div className="max-w-6xl mx-auto text-center space-y-8">
            <h2 className="text-3xl md:text-4xl font-bold">
              Looking for a Reliable Linux & Hosting Partner?
            </h2>

            <p className="text-lg text-orange-100 max-w-3xl mx-auto">
              Our experts help businesses manage Linux servers, hosting
              infrastructure, security, and performance optimization so your
              applications run smoothly with maximum uptime.
            </p>

            <div className="grid md:grid-cols-3 gap-8 mt-12">
              {/* Card 1 */}
              <div className="bg-white text-gray-800 rounded-xl p-8 shadow-lg hover:-translate-y-2 hover:shadow-2xl transition">
                <ServerStackIcon className="w-12 h-12 text-[#FF5722] mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">
                  Get Expert Server Support
                </h3>
                <p className="text-gray-600 text-sm">
                  Professional Linux server setup, configuration and ongoing
                  maintenance from experienced engineers.
                </p>
              </div>

              {/* Card 2 */}
              <div className="bg-white text-gray-800 rounded-xl p-8 shadow-lg hover:-translate-y-2 hover:shadow-2xl transition">
                <PhoneIcon className="w-12 h-12 text-[#FF5722] mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">
                  Speak with Our Team
                </h3>
                <p className="text-gray-600 text-sm">
                  Connect with our specialists to discuss your hosting,
                  infrastructure and cloud requirements.
                </p>
              </div>

              {/* Card 3 */}
              <div className="bg-white text-gray-800 rounded-xl p-8 shadow-lg hover:-translate-y-2 hover:shadow-2xl transition">
                <EnvelopeIcon className="w-12 h-12 text-[#FF5722] mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">
                  Request a Consultation
                </h3>
                <p className="text-gray-600 text-sm">
                  Schedule a consultation and receive a tailored hosting
                  strategy for your business.
                </p>
              </div>
            </div>

            <div className="pt-8">
              <a href="/contact-us">
                {" "}
                <div className="bg-white text-[#FF5722] px-8 py-3 rounded-md font-semibold hover:bg-gray-100 transition">
                  Contact Our Experts
                </div>
              </a>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default LinuxAndWebHostingServices;
