import Layout from "../../Components/Layout";
import { Link } from "react-router-dom";
import fullstackdeveloperimg from "../../assets/fullstackdeveloperimg.jpg";
import { Phone, Mail } from "lucide-react";
import React, { useRef, useState } from "react";
import { Briefcase, MapPin, FileText } from "lucide-react";

const FullStackDeveloper = () => {
  const fileInputRef = useRef(null);
  const [fileName, setFileName] = useState("");

  const handleClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileName(file.name);
    }
  };

  return (
    <Layout>
      <div className="relative w-full h-[70vh]">
        <img
          src={fullstackdeveloperimg}
          alt="WordPress"
          className="object-cover w-full h-full"
        />
        <div className="absolute inset-0 bg-black/50 flex items-center px-10 md:px-20">
          <div data-aos="fade-right" className="text-white max-w-2xl space-y-5">
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Sr. PHP Laravel Developer
            </h1>
            <p className="text-lg">Experience : 4+ Years</p>

            <div className="relative mt-10 flex items-start justify-start ">
              {/* Card */}
              <div className=" border border-white/60 text-white py-6 px-8 backdrop-blur-sm bg-white/10 rounded-md shadow-lg">
                {/* Title */}
                <h2 className="text-2xl font-semibold mb-6">
                  HR Contact Details
                </h2>

                {/* Phone */}
                <div className="flex items-center gap-3 mb-4">
                  <Phone className="w-5 h-5 text-white" />
                  <span className="text-md tracking-wide">+91-9468629248</span>
                </div>

                {/* Email */}
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-white" />
                  <span className="text-md tracking-wide">
                    hr@infomagine.in
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-100 min-h-screen p-6 flex justify-center">
        <div className="max-w-7xl w-full grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* LEFT SECTION */}
          <div className="lg:col-span-2 bg-white p-6 rounded shadow-sm"> 
  <div className="flex gap-4 mb-8 mt-5 rounded-xl w-fit">
    {/* Full-Time */}
    <div className="flex items-center gap-2 border-gray-300 border px-4 py-2 rounded-lg">
      <Briefcase className="w-5 h-6 text-gray-500" />
      <span className="text-gray-700 text-sm font-medium">Full-Time</span>
    </div>

    {/* Location */}
    <div className="flex items-center gap-2 border-gray-300 border px-4 py-2 rounded-lg">
      <MapPin className="w-5 h-6 text-gray-500" />
      <span className="text-gray-700 text-sm font-medium">Jaipur</span>
    </div>

    {/* Experience */}
    <div className="flex items-center gap-2 border-gray-300 border px-4 py-2 rounded-lg">
      <FileText className="w-5 h-6 text-gray-500" />
      <span className="text-gray-700 text-sm font-medium">2–4 Years</span>
    </div>
  </div>

  {/* About Role */}
  <h2 className="text-orange-600 text-xl font-semibold mb-4">
    About the Role
  </h2>
  <p className="text-sm text-gray-700">
    We are seeking an experienced PHP Developer who can contribute to all phases of the development lifecycle. The candidate should be proficient in PHP frameworks, database management, API development, and modern web technologies.
  </p>

  {/* Experience Requirements */}
  <h2 className="text-orange-600 text-xl font-semibold mt-8 mb-4">
    Experience Requirements
  </h2>
  <ul className="space-y-3 text-sm text-gray-700">
    {[
      "Minimum: 2–4 years of hands-on experience in PHP development.",
      "Proven experience in Core PHP, OOPs and at least one PHP framework (preferably Laravel).",
      "Strong experience in REST API development and integration.",
      "Experience working on live production projects.",
      "Experience with MySQL, query optimization and database schema design.",
      "Demonstrated ability to handle end-to-end module development.",
      "Exposure to Git, deployment pipelines and basic server handling.",
      "Experience working in team environments with agile or sprint-based development.",
    ].map((item, i) => (
      <li key={i} className="flex items-start gap-2">
        <span className="text-orange-500 mt-1">✔</span>
        <span>{item}</span>
      </li>
    ))}
  </ul>

  {/* Key Responsibilities */}
  <h2 className="text-orange-600 text-xl font-semibold mt-8 mb-4">
  Key Responsibilities
  </h2>
  <ul className="space-y-3 text-sm text-gray-700">
    {[
      "Develop, test, and maintain high-quality web applications.",
      "Write efficient and reusable code following best practices.",
      "Integrate front-end elements with server-side logic.",
      "Develop and maintain RESTful APIs for web and mobile apps.",
      "Optimize performance, troubleshoot issues, and debug errors.",
      "Collaborate with UI/UX, frontend, QA, and project teams.",
      "Ensure application security and data protection.",
      "Maintain proper code documentation.",
    ].map((item, i) => (
      <li key={i} className="flex items-start gap-2">
        <span className="text-orange-500 mt-1">✔</span>
        <span>{item}</span>
      </li>
    ))}
  </ul>

  {/* Required Skills */}
  <h2 className="text-orange-600 text-xl font-semibold mt-8 mb-4">
    Required Skills & Qualifications
  </h2>
  <ul className="space-y-3 text-sm text-gray-700">
    {[
      "Strong knowledge of Core PHP and OOP concepts.",
      "Experience with frameworks such as Laravel / CodeIgniter / Symfony / Yii.",
      "Proficiency in MySQL, database design, and query optimization.",
      "Good understanding of HTML, CSS, JavaScript, jQuery.",
      "Hands-on experience with API creation/integration.",
      "Familiar with Git, GitHub, or Bitbucket.",
      "Understanding of MVC architecture.",
      "Knowledge of third-party integrations (Payment Gateways, SMS, Email APIs).",
    ].map((item, i) => (
      <li key={i} className="flex items-start gap-2">
        <span className="text-orange-500 mt-1">✔</span>
        <span>{item}</span>
      </li>
    ))}
  </ul>

  {/* Preferred Skills */}
  <h2 className="text-orange-600 text-xl font-semibold mt-8 mb-4">
    Preferred Skills 
  </h2>
  <ul className="space-y-3 text-sm text-gray-700">
    {[
      "Strong experience with Laravel.",
      "Knowledge of AWS / DigitalOcean.",
      "Experience with Docker or CI/CD tools.",
      "Understanding of Agile methodologies.",
    ].map((item, i) => (
      <li key={i} className="flex items-start gap-2">
        <span className="text-orange-500 mt-1">✔</span>
        <span>{item}</span>
      </li>
    ))}
  </ul> 



  {/* Education */}
  <h2 className="text-orange-600 text-xl font-semibold mt-8 mb-4">
    Education
  </h2>
  <ul className="space-y-3 text-sm text-gray-700">
    {[
      "Bachelor’s degree in Computer Science / IT / Engineering or equivalent.",
      "Relevant technical certifications are an advantage.",
    ].map((item, i) => (
      <li key={i} className="flex items-start gap-2">
        <span className="text-orange-500 mt-1">✔</span>
        <span>{item}</span>
      </li>
    ))}
  </ul>

  {/* Salary */}
  <h2 className="text-orange-600 text-xl font-semibold mt-8 mb-4">
    Salary Range
  </h2>
  <p className="text-sm text-gray-700">[Insert your salary range here]</p>

  {/* Benefits */}
  <h2 className="text-orange-600 text-xl font-semibold mt-8 mb-4">
    Benefits
  </h2>
  <ul className="space-y-3 text-sm text-gray-700">
    {[
      "Flexible working hours",
      "Performance-based bonuses",
      "Paid leaves",
      "Learning & skill development support",
    ].map((item, i) => (
      <li key={i} className="flex items-start gap-2">
        <span className="text-orange-500 mt-1">✔</span>
        <span>{item}</span>
      </li>
    ))}
  </ul>
</div>

          {/* RIGHT SECTION (FORM) */}
          <div className="bg-white p-6 rounded shadow-sm">
            <h2 className="text-xl font-semibold mb-4"> Apply Now</h2>

            <div className="space-y-4">
              <input
                type="text"
                placeholder="Name"
                className="w-full border-gray-400 border p-2 rounded text-sm"
              />

              <input
                type="text"
                placeholder="Contact No."
                className="w-full border-gray-400 border p-2 rounded text-sm"
              />

              <input
                type="email"
                placeholder="Email ID"
                className="w-full border-gray-400 border p-2 rounded text-sm"
              />

              <textarea
                placeholder="Message"
                rows={4}
                className="w-full border-gray-400 border p-2 rounded text-sm"
              />

              <div className="w-full max-w-md mx-auto">
                <div
                  onClick={handleClick}
                  className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center bg-white hover:border-orange-600 hover:bg-orange-50 transition cursor-pointer"
                >
                  {/* Icon */}
                  <div className="flex justify-center mb-3">
                    <svg
                      className="w-10 h-10 text-orange-600"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M12 16V4m0 0l-4 4m4-4l4 4M4 20h16"
                      />
                    </svg>
                  </div>

                  {/* Text */}
                  <p className="text-gray-700 font-medium">
                    Click to upload your resume
                  </p>
                  <p className="text-sm text-gray-500 mt-1">     
                    PDF, DOC, DOCX (Max 5MB)
                  </p>

                  {/* File Name */}
                  {fileName && (
                    <p className="mt-3 text-sm text-green-600 font-medium">
                      ✔ {fileName}
                    </p>
                  )}
                </div>

                {/* Hidden Input */}
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>

              {/* Captcha */}
              <div>
                <p className="text-sm mb-2">Please Enter Captcha</p>
                <div className="flex items-center gap-2">
                  <div className="bg-gray-200 px-4 py-2 tracking-widest font-mono">
                    r54AI8
                  </div>
                  <input
                    type="text"
                    className="flex-1 border p-2 rounded text-sm"
                  />
                </div>
              </div>

              {/* Submit */}
              <button className="w-full mt-5 bg-orange-600 cursor-pointer text-white py-3 rounded ">
                Apply Now !
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default FullStackDeveloper;
