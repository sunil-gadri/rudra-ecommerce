import { BrowserRouter, Routes, Route } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";

// FRONTEND
import FrontendLayout from "./../src/Frontend/FrontendLayout";

// AUTH
import Login from "./auth/Login";
// import Signup from "./auth/Signup";

// PROTECTED
import AdminProtectedRoute from "./components/routes/AdminProtectedRoute";
import CustomerProtectedRoute from "./components/routes/CustomerProtectedRoute";

// ADMIN LAYOUT
import { AdminLayout } from "./components/AdminLayout";

import Index from "./pages/Index";
import Users from "./pages/Users";
import Customers from "./pages/Customers";
import Products from "./pages/Products";
import ProductsCreate from "./pages/ProductsCreate";
import ProductsEdit from "./pages/ProductEdit";
import Categories from "./pages/Categories";
import ParentCategory from "./pages/ParentCategory";
import AdsManagement from "./pages/AdsManagement";
import Offers from "./pages/Offers";
import OfferCreate from "./pages/OfferCreate";
import OfferEdit from "./pages/OfferEdit";
import Orders from "./pages/Orders";
import OrderDetails from "./pages/OrdersDetails";
import Payments from "./pages/Payments";
import Invoice from "./pages/Invoice";
import InvoiceView from "./pages/InvoiceView";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import Lists from "./pages/Lists";
import CustomerLists from "./pages/CustomerLists";

// MASTERS
import MasterSize from "./masters/MasterSize";
import MasterColor from "./masters/MasterColor";
import MasterPattern from "./masters/MasterPattern";
import MasterGst from "./masters/MasterGst";
import MasterSpecificationHeading from "./masters/MasterSpecificationHeading";
import MasterSpecification from "./masters/MasterSpecification";

// OTHER
import Manufacturers from "./pages/Manufacturers";
import Brands from "./pages/Brands";
import Profile from "./pages/Profile";
import ProductOverview from "./pages/ProductOveriew";
import ProductOverviewCreate from "./pages/ProductOverviewCreate";
import ProductOverviewEdit from "./pages/ProductOverviewEdit";
import ProductOverviewView from "./pages/ProductOverviewView";
import CuponList from "./pages/CouponList";
import Coupon from "./pages/Coupon";
import NotFound from "./pages/NotFound";

import HomePage from "./Frontend/Pages/HomePage";
import { About } from "./Frontend/Pages/About";
import { AllShopProduct } from "./Frontend/Pages/AllShopProduct";
import { Collection } from "./Frontend/Pages/Collection";
import { CheckOut } from "./Frontend/Components/CheckOut";
import { Cart } from "./Frontend/Components/Cart";
import { ResetPasswordPage } from "./Frontend/Pages/ResetPasswordPage";
import { WishList } from "./Frontend/Pages/WishList";
import { PrivacyPolicyPage } from "./Frontend/Pages/PrivacyPolicyPage";
import { RefundPolicyPage } from "./Frontend/Pages/RefundPolicyPage";
import { TermsAndConditions } from "./Frontend/Pages/TermsAndConditions";
import ShippingPolicy from "./Frontend/Pages/ShippingPolicy";
import { BlogsPage } from "./Frontend/Pages/BlogsPage";
import { BlogReadMorePage } from "./Frontend/Pages/BlogReadMorePage";
import { FaqsPage } from "./Frontend/Pages/FaqsPage";
import ContactUs from "./Frontend/Pages/ContactUs";
import { Disclaimer } from "./Frontend/Pages/Disclaimer";
import { ProductNew } from "./Frontend/Components/ProductNew";
import EditCoupon from "./pages/EditCupon";
import MyOrders from "./Frontend/Account/MyOrders";
import ProfileUser from "./Frontend/Account/ProfileUser";
import PageNotFoundUser from "./Frontend/Pages/PageNotFoundUser";
import AddressBook from "./Frontend/Account/AddressBook";
import OrderDetailsUser from "./Frontend/Account/OrderDetailsUser";

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route element={<FrontendLayout />}>
              <Route path="/" element={<HomePage />} />
              <Route path="/about" element={<About />} />
              <Route path="/shop" element={<AllShopProduct />} />
              <Route path="/collections" element={<Collection />} />
              <Route path="/product/:id" element={<ProductNew />} />
              <Route path="/checkout" element={<CheckOut />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/reset" element={<ResetPasswordPage />} />
              <Route path="/wishlist" element={<WishList />} />
              <Route path="/privacypolicy" element={<PrivacyPolicyPage />} />
              <Route path="/refundpolicy" element={<RefundPolicyPage />} />
              <Route path="/termsandconditions" element={<TermsAndConditions />} />
              <Route path="/shipping-policy" element={<ShippingPolicy />} />
              <Route path="/blogs" element={<BlogsPage />} />
              <Route path="/blogs/readmore" element={<BlogReadMorePage />} />
              <Route path="/about" element={<About />} />
              <Route path="/FAQs" element={<FaqsPage />} />
              <Route path="/contact-us" element={<ContactUs />} />
              <Route path="/disclaimer" element={<Disclaimer />} />
              <Route path="*" element={<PageNotFoundUser />} />
            </Route>
<Route element={<CustomerProtectedRoute />}>
              <Route path="/my-orders" element={<MyOrders />} />
              <Route path="/my-profile" element={<ProfileUser />} />
              <Route path="/my-address" element={<AddressBook />} />
              <Route path="/customers/:customerId/orders/:orderId" element={<OrderDetailsUser />} />
            </Route>


       {/* ==================== ADMIN SECTION ==================== */}
<Route path="/admin-login" element={<Login />} />

<Route path="/admin" element={<AdminProtectedRoute><Index /></AdminProtectedRoute>} />

{/* Ye pura AdminLayout wala block replace kar do */}
<Route path="/admin/*" element={<AdminProtectedRoute><AdminLayout /></AdminProtectedRoute>}>
  <Route path="profile" element={<Profile />} />
  <Route path="users" element={<Users />} />
  <Route path="customers" element={<Customers />} />
  <Route path="products" element={<Products />} />
  <Route path="products/create" element={<ProductsCreate />} />
  <Route path="products/edit/:id" element={<ProductsEdit />} />
  <Route path="product/overview" element={<ProductOverview />} />
  <Route path="product/overview/create" element={<ProductOverviewCreate />} />
  <Route path="product/overview/edit/:id" element={<ProductOverviewEdit />} />
  <Route path="product/overview/view/:id" element={<ProductOverviewView />} />
  <Route path="categories" element={<Categories />} />
  <Route path="parent_categories" element={<ParentCategory />} />
  <Route path="ads" element={<AdsManagement />} />
  <Route path="offers" element={<Offers />} />
  <Route path="offers/create" element={<OfferCreate />} />
  <Route path="offers/edit/:id" element={<OfferEdit />} />
  <Route path="coupon" element={<CuponList />} />
  <Route path="coupon/create" element={<Coupon />} />
  <Route path="edit-coupon/:id" element={<EditCoupon />} />
  <Route path="orders" element={<Orders />} />
  <Route path="orders/:id" element={<OrderDetails />} />
  <Route path="payments" element={<Payments />} />
  <Route path="invoice" element={<Invoice />} />
  <Route path="invoice/view/:id" element={<InvoiceView />} />
  <Route path="reports" element={<Reports />} />
  <Route path="dashboard" element={<Reports />} />
  <Route path="lists" element={<Lists />} />
  <Route path="customer-lists" element={<CustomerLists />} />
  <Route path="settings" element={<Settings />} />
  <Route path="masters-size" element={<MasterSize />} />
  <Route path="masters-color" element={<MasterColor />} />
  <Route path="masters-pattern" element={<MasterPattern />} />
  <Route path="masters-gst" element={<MasterGst />} />
  <Route path="masters-specification-heading" element={<MasterSpecificationHeading />} />
  <Route path="masters-specifications" element={<MasterSpecification />} />
  <Route path="manufacturers" element={<Manufacturers />} />
  <Route path="brands" element={<Brands />} />

  {/* Ye sabse neeche - admin ke andar koi bhi unknown route */}
  <Route path="*" element={<NotFound />} />
</Route>
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
