// src/redux/wishlistSlice.js (Only for navbar count)
import { createSlice } from '@reduxjs/toolkit';

const wishlistSlice = createSlice({
  name: 'wishlist',
  initialState: {
    count: 0,
  },
  reducers: {
    setWishlistCount: (state, action) => {
      state.count = action.payload;
    },
  },
});

export const { setWishlistCount } = wishlistSlice.actions;
export default wishlistSlice.reducer;