import React, { useState } from "react";
import { ArrowLeft, Tag, Calendar, Zap, DollarSign, Check } from "lucide-react";
import axiosInstance from "../utils/axios";
import { toast } from "sonner";

export default function CouponForm() {
  const [couponStatus, setCouponStatus] = useState("active");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [couponCode, setCouponCode] = useState("");
  const [couponTitle, setCouponTitle] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [couponType, setCouponType] = useState("");
  const [discountValue, setDiscountValue] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const inputClasses = `
    w-full px-4 py-3 rounded-xl border bg-white text-gray-900 
    placeholder-gray-400 focus:outline-none focus:ring-2 
    transition-all duration-200
  `;

  const labelClasses = "block text-sm font-semibold text-gray-700 mb-2";

  // Real-time date validation (same as Edit form)
  const validateDates = () => {
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      if (end < start) {
        setErrors((prev) => ({
          ...prev,
          endDate: "End date cannot be before start date",
        }));
      } else {
        setErrors((prev) => {
          const { endDate, ...rest } = prev;
          return rest;
        });
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newErrors = {};

    // REQUIRED FIELD VALIDATION
    if (!startDate) newErrors.startDate = "Start date is required";
    if (!endDate) newErrors.endDate = "End date is required";
    if (!couponCode.trim()) newErrors.couponCode = "Coupon code is required";
    if (!couponTitle.trim()) newErrors.couponTitle = "Coupon title is required";
    if (!minPrice) newErrors.minPrice = "Minimum price is required";
    if (!couponType) newErrors.couponType = "Select a coupon type";
    if (!discountValue) newErrors.discountValue = "Discount value is required";

    // DATE VALIDATION (same as Edit)
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      if (end < start) {
        newErrors.endDate = "End date cannot be before start date";
      }
    }

    // PRICE VALIDATION
    if (minPrice && maxPrice) {
      if (parseFloat(maxPrice) < parseFloat(minPrice)) {
        newErrors.maxPrice = "Maximum price cannot be less than minimum price";
      }
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      Object.values(newErrors).forEach((msg) => toast.error(msg));
      return;
    }

    try {
      const payload = {
        status: couponStatus,
        start_date: startDate,
        end_date: endDate,
        coupon_code: couponCode.trim().toUpperCase(),
        coupon_title: couponTitle.trim(),
        min_price: Number(minPrice),
        max_price: maxPrice ? Number(maxPrice) : null,
        coupon_type: couponType,
        discount_value: Number(discountValue),
      };

      const response = await axiosInstance.post("coupon", payload, {
        headers: { "Content-Type": "application/json" },
      });

      toast.success(response.data.message || "Coupon created successfully!");

      // RESET FORM
      setCouponCode("");
      setCouponTitle("");
      setStartDate("");
      setEndDate("");
      setMinPrice("");
      setMaxPrice("");
      setCouponType("");
      setDiscountValue("");
      setErrors({});
      setSubmitted(true);
    } catch (error) {
      toast.error(error.response?.data?.message || "Something went wrong");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* HEADER */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Create New Coupon</h1>
            <p className="text-gray-500 mt-1">Set up a powerful discount to boost your sales</p>
          </div>
          <button className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
            <ArrowLeft className="w-5 h-5" />
            <a href="/admin/coupon">All Coupons</a>
          </button>
        </div>
      </div>

      {/* MAIN LAYOUT */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-3 gap-6">
          {/* LEFT SIDE */}
          <div className="col-span-2 space-y-6">
            {/* STATUS */}
            <div className="bg-white rounded-2xl border p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Coupon Status
              </h2>
              <div className="flex gap-6">
                {["active", "inactive"].map((s) => (
                  <label key={s} className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value={s}
                      checked={couponStatus === s}
                      onChange={() => setCouponStatus(s)}
                      className="w-5 h-5 accent-orange-500"
                    />
                    <span className="text-gray-700 capitalize">{s}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* DATES - with proper validation */}
            <div className="bg-white rounded-2xl border p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Schedule Dates
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelClasses}>Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => {
                      setStartDate(e.target.value);
                      setErrors((prev) => ({ ...prev, startDate: undefined }));
                      validateDates(); // real-time check
                    }}
                    className={`${inputClasses} border-gray-200 focus:ring-orange-500 ${
                      errors.startDate ? "border-red-500" : ""
                    }`}
                  />
                  {errors.startDate && (
                    <p className="text-red-600 text-sm mt-1">{errors.startDate}</p>
                  )}
                </div>

                <div>
                  <label className={labelClasses}>End Date</label>
                  <input
                    type="date"
                    value={endDate}
                    min={startDate || undefined} // ← Browser block dates before start date
                    onChange={(e) => {
                      setEndDate(e.target.value);
                      setErrors((prev) => ({ ...prev, endDate: undefined }));
                      validateDates(); // real-time check
                    }}
                    className={`${inputClasses} border-gray-200 focus:ring-orange-500 ${
                      errors.endDate ? "border-red-500" : ""
                    }`}
                  />
                  {errors.endDate && (
                    <p className="text-red-600 text-sm mt-1">{errors.endDate}</p>
                  )}
                </div>
              </div>
            </div>

            {/* COUPON DETAILS */}
            <div className="bg-white rounded-2xl border p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Tag className="w-5 h-5" />
                Coupon Details
              </h2>
              <label className={labelClasses}>Coupon Code</label>
              <input
                type="text"
                placeholder="Enter coupon code"
                value={couponCode}
                onChange={(e) => {
                  setCouponCode(e.target.value.toUpperCase());
                  setErrors((prev) => ({ ...prev, couponCode: undefined }));
                }}
                className={`${inputClasses} border-gray-200 focus:ring-orange-500 ${
                  errors.couponCode ? "border-red-500" : ""
                }`}
              />
              {errors.couponCode && (
                <p className="text-red-600 text-sm mt-1">{errors.couponCode}</p>
              )}

              <label className={labelClasses} style={{ marginTop: "1.5rem" }}>
                Coupon Title
              </label>
              <input
                type="text"
                placeholder="Enter coupon title"
                value={couponTitle}
                onChange={(e) => {
                  setCouponTitle(e.target.value);
                  setErrors((prev) => ({ ...prev, couponTitle: undefined }));
                }}
                className={`${inputClasses} border-gray-200 focus:ring-orange-500 ${
                  errors.couponTitle ? "border-red-500" : ""
                }`}
              />
              {errors.couponTitle && (
                <p className="text-red-600 text-sm mt-1">{errors.couponTitle}</p>
              )}
            </div>
          </div>

          {/* RIGHT SIDE */}
          <div className="space-y-6">
            {/* PRICE RANGE */}
            <div className="bg-white rounded-2xl border p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Price Range
              </h2>
              <div className="space-y-4">
                <div>
                  <label className={labelClasses}>Minimum Price</label>
                  <input
                    type="number"
                    value={minPrice}
                    onChange={(e) => {
                      setMinPrice(e.target.value);
                      setErrors((prev) => ({ ...prev, minPrice: undefined, maxPrice: undefined }));
                    }}
                    className={`${inputClasses} border-gray-200 focus:ring-orange-500 ${
                      errors.minPrice ? "border-red-500" : ""
                    }`}
                  />
                  {errors.minPrice && (
                    <p className="text-red-600 text-sm mt-1">{errors.minPrice}</p>
                  )}
                </div>

                <div>
                  <label className={labelClasses}>Maximum Price</label>
                  <input
                    type="number"
                    value={maxPrice}
                    onChange={(e) => {
                      setMaxPrice(e.target.value);
                      setErrors((prev) => ({ ...prev, maxPrice: undefined }));
                    }}
                    className={`${inputClasses} border-gray-200 focus:ring-orange-500 ${
                      errors.maxPrice ? "border-red-500" : ""
                    }`}
                  />
                  {errors.maxPrice && (
                    <p className="text-red-600 text-sm mt-1">{errors.maxPrice}</p>
                  )}
                </div>
              </div>
            </div>

            {/* DISCOUNT TYPE */}
            <div className="bg-white rounded-2xl border p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Tag className="w-5 h-5" />
                Discount Type
              </h2>
              <div className="space-y-3">
                {[
                  { value: "percentage", label: "Percentage (%)" },
                  { value: "fixed", label: "Fixed Amount (₹)" },
                ].map((type) => (
                  <label key={type.value} className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="radio"
                      name="couponType"
                      value={type.value}
                      checked={couponType === type.value}
                      onChange={(e) => {
                        setCouponType(e.target.value);
                        setErrors((prev) => ({ ...prev, couponType: undefined, discountValue: undefined }));
                      }}
                      className="w-5 h-5 accent-orange-500"
                    />
                    <span className="text-gray-700">{type.label}</span>
                    {couponType === type.value && (
                      <Check className="w-4 h-4 text-orange-500 ml-auto" />
                    )}
                  </label>
                ))}
              </div>
              {errors.couponType && (
                <p className="text-red-600 text-sm mt-2">{errors.couponType}</p>
              )}
            </div>

            {/* DISCOUNT VALUE */}
            {couponType && (
              <div className="bg-white rounded-2xl border p-6">
                <h2 className="text-lg font-semibold mb-4">Discount Value</h2>
                <div className="relative">
                  <input
                    type="number"
                    placeholder="0.00"
                    value={discountValue}
                    onChange={(e) => {
                      setDiscountValue(e.target.value);
                      setErrors((prev) => ({ ...prev, discountValue: undefined }));
                    }}
                    className={`${inputClasses} border-gray-200 focus:ring-orange-500 ${
                      errors.discountValue ? "border-red-500" : ""
                    }`}
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 font-semibold">
                    {couponType === "percentage" ? "%" : "₹"}
                  </span>
                </div>
                {errors.discountValue && (
                  <p className="text-red-600 text-sm mt-1">{errors.discountValue}</p>
                )}
              </div>
            )}

            {/* SUBMIT BUTTON */}
            <button
              onClick={handleSubmit}
              className="w-full py-3 px-4 rounded-xl font-semibold flex items-center justify-center gap-2 bg-orange-500 text-white hover:bg-orange-600 transition-colors"
            >
              {submitted ? (
                <>
                  <Check className="w-5 h-5" />
                  Coupon Created!
                </>
              ) : (
                <>
                  <Tag className="w-5 h-5" />
                  Create Coupon
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}