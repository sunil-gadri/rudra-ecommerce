import React, { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Image, Plus, Edit, Trash2, MoreHorizontal } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import axiosInstance from "../utils/axios";

// Image Compression Library
import imageCompression from "browser-image-compression";

export default function SliderManagement() {
  const { toast } = useToast();

  // Base URL for images
  const IMAGE_BASE_URL = "http://192.168.0.9:5000";

  const [sliders, setSliders] = useState([]);
  const [categories, setCategories] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSlider, setEditingSlider] = useState(null);
  const [imageFile, setImageFile] = useState(null);        // Compressed file
  const [imagePreview, setImagePreview] = useState("");    // For instant preview
  const [keyValue, setKeyValue] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [isCompressing, setIsCompressing] = useState(false);

  // Helper to get full image URL
  const getImageUrl = (path) => {
    if (!path) return "";
    if (path.startsWith("http")) return path;
    return IMAGE_BASE_URL + path;
  };

  // Fetch Sliders
  const fetchSliders = async () => {
    try {
      const res = await axiosInstance.get("/slider");
      setSliders(res.data?.data || res.data || []);
    } catch (err) {
      console.error("Error fetching sliders:", err);
      toast({
        title: "Error",
        description: "Failed to fetch sliders.",
        variant: "destructive",
      });
    }
  };

  // Fetch Categories
  const fetchCategories = async () => {
    try {
      const res = await axiosInstance.get("/categories");
      setCategories(res.data?.data || res.data || []);
    } catch (err) {
      console.error("Error fetching categories:", err);
      toast({
        title: "Error",
        description: "Failed to load categories.",
        variant: "destructive",
      });
    }
  };

  // Compress Image Function
  const compressImage = async (file) => {
    if (!file) return null;

    setIsCompressing(true);

    const options = {
      maxSizeMB: 0.05,        
      maxWidthOrHeight: 1200,       
      useWebWorker: true,
      fileType: "image/webp",       
      initialQuality: 0.85,
    };

    try {
      const compressedFile = await imageCompression(file, options);

      // Rename to .webp
      const webpFile = new File(
        [compressedFile],
        file.name.split('.').slice(0, -1).join('.') + ".webp",
        { type: "image/webp" }
      );

      console.log(`Compressed: ${(webpFile.size / 1024).toFixed(1)} KB`);
      return webpFile;
    } catch (error) {
      console.error("Compression failed:", error);
      toast({
        title: "Compression Failed",
        description: "Using original image.",
        variant: "destructive",
      });
      return file;
    } finally {
      setIsCompressing(false);
    }
  };

  // Handle Image Selection + Auto Compression
  const handleImageChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast({ title: "Invalid", description: "Please select an image file.", variant: "destructive" });
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      toast({ title: "Too Large", description: "Image must be under 15MB.", variant: "destructive" });
      return;
    }

    // Show instant preview
    setImagePreview(URL.createObjectURL(file));
    setImageFile(null);

    // Compress in background
    const compressed = await compressImage(file);
    setImageFile(compressed);
  };

  // Open Dialog (Add or Edit)
  const handleOpenDialog = (slider = null) => {
    setEditingSlider(slider);
    setKeyValue(slider?.key || "");
    setCategoryId(slider?.category_id?.toString() || "");
    setImageFile(null);
    setImagePreview(slider?.image_url ? getImageUrl(slider.image_url) : "");
    setIsDialogOpen(true);
  };

  // Close Dialog
  const closeDialog = () => {
    setIsDialogOpen(false);
    setEditingSlider(null);
    setKeyValue("");
    setCategoryId("");
    setImageFile(null);
    setImagePreview("");
    setIsCompressing(false);
  };

  // Save Slider
  const handleSaveSlider = async () => {
    if (!keyValue.trim()) {
      toast({ title: "Error", description: "Please enter a slider key.", variant: "destructive" });
      return;
    }

    if (!categoryId) {
      toast({ title: "Error", description: "Please select a category.", variant: "destructive" });
      return;
    }

    if (!editingSlider && !imageFile) {
      toast({ title: "Error", description: "Please upload an image.", variant: "destructive" });
      return;
    }

    const formData = new FormData();
    formData.append("key", keyValue.trim());
    formData.append("category_id", categoryId);
    if (imageFile) {
      formData.append("image", imageFile);
    }

    try {
      if (editingSlider) {
        await axiosInstance.put(`/slider/${editingSlider.id}`, formData);
        toast({ title: "Success", description: "Slider updated successfully." });
      } else {
        await axiosInstance.post("/slider", formData);
        toast({ title: "Success", description: "Slider created successfully." });
      }
      closeDialog();
      fetchSliders();
    } catch (err) {
      toast({
        title: "Error",
        description: err.response?.data?.message || "Failed to save slider.",
        variant: "destructive",
      });
    }
  };

  // Delete Slider
  const handleDeleteSlider = async (id) => {
    if (!window.confirm("Are you sure you want to delete this slider?")) return;

    try {
      await axiosInstance.delete(`/slider/${id}`);
      toast({ title: "Deleted", description: "Slider deleted successfully." });
      fetchSliders();
    } catch (err) {
      toast({ title: "Error", description: "Failed to delete slider.", variant: "destructive" });
    }
  };

  // Load data on mount
  useEffect(() => {
    fetchSliders();
    fetchCategories();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Slider Management</h1>
          <p className="text-muted-foreground">
            Manage homepage and section banners from here
          </p>
        </div>
        <Button onClick={() => handleOpenDialog()}>
          <Plus className="mr-2 h-4 w-4" />
          Add Slider
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Sliders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{sliders.length}</div>
            <p className="text-xs text-muted-foreground">Active on site</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Unique Keys</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {[...new Set(sliders.map((s) => s.key))].length}
            </div>
            <p className="text-xs text-muted-foreground">Different slider groups</p>
          </CardContent>
        </Card>
      </div>

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Sliders</CardTitle>
          <CardDescription>Manage all uploaded slider images</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-center w-16">ID</TableHead>
                  <TableHead className="text-center">Preview</TableHead>
                  <TableHead className="text-center">Key</TableHead>
                  <TableHead className="text-center">Category</TableHead>
                  <TableHead className="text-center">Created At</TableHead>
                  <TableHead className="text-center w-24">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sliders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No sliders found. Click "Add Slider" to get started.
                    </TableCell>
                  </TableRow>
                ) : (
                  sliders.map((slider) => (
                    <TableRow key={slider.id} className="hover:bg-gray-50">
                      <TableCell className="text-center font-medium">{slider.id}</TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center">
                          <img
                            src={getImageUrl(slider.image_url)}
                            alt={slider.key}
                            className="h-16 w-28 rounded-lg object-cover border shadow-sm"
                          />
                        </div>
                      </TableCell>
                      <TableCell className="text-center font-medium text-gray-800">
                        {slider.key}
                      </TableCell>
                      <TableCell className="text-center text-sm">
                        {slider.category_name ?? "-"}
                      </TableCell>
                      <TableCell className="text-center text-sm text-muted-foreground">
                        {new Date(slider.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleOpenDialog(slider)}>
                              <Edit className="mr-2 h-4 w-4" /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDeleteSlider(slider.id)}
                              className="text-red-600 focus:text-red-600"
                            >
                              <Trash2 className="mr-2 h-4 w-4" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingSlider ? "Edit Slider" : "Add New Slider"}</DialogTitle>
            <DialogDescription>
              {editingSlider
                ? "Update key, category, or replace image (automatically compressed)."
                : "Upload image (will be auto-compressed to ~50KB WebP)."}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Key */}
            <div className="space-y-2">
              <Label htmlFor="key">Slider Key</Label>
              <Input
                id="key"
                placeholder="e.g. home, banner-1, promo"
                value={keyValue}
                onChange={(e) => setKeyValue(e.target.value)}
              />
            </div>

            {/* Category */}
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id.toString()}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Image Upload */}
            <div className="space-y-2">
              <Label htmlFor="image">Image {isCompressing && "(compressing...)"}</Label>
              <Input
                id="image"
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                disabled={isCompressing}
              />

              {/* Current or Preview Image */}
              {(imagePreview || (editingSlider?.image_url && !imageFile)) && (
                <div className="mt-3">
                  <p className="text-sm text-muted-foreground mb-2">
                    {imageFile ? "Preview:" : "Current Image:"}
                  </p>
                  <img
                    src={imagePreview || getImageUrl(editingSlider.image_url)}
                    alt="Slider"
                    className="h-32 w-full rounded-md border object-cover shadow-sm"
                  />
                  {imageFile && !isCompressing && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Size: {(imageFile.size / 1024).toFixed(1)} KB • Format: WebP
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={closeDialog}>
              Cancel
            </Button>
            <Button onClick={handleSaveSlider} disabled={isCompressing}>
              {editingSlider ? "Update Slider" : "Add Slider"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
