import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, MoreHorizontal, Package, DollarSign, TrendingUp, AlertTriangle, Plus, Edit, Trash2, Filter } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,} from "@/components/ui/tooltip";
import { IMAGE_BASE_URL } from '../utils/imagesUrl.jsx';

export default function Products() {
  const [products, setProducts] = useState([]);
  const [pagination, setPagination] = useState({
    current_page: 1,
    total_pages: 1,
    limit: 10,
    total_products: 0,
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [categories, setCategories] = useState([]);
  const [parentCategories, setParentCategories] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [brands, setBrands] = useState([]);
  const [colorOptions, setColorOptions] = useState([]);
  const [patternOptions, setPatternOptions] = useState([]);
  const [unitOptions, setUnitOptions] = useState([]);
  const [colorNameById, setColorNameById] = useState({});
  const [patternNameById, setPatternNameById] = useState({});
  const [imageViewerOpen, setImageViewerOpen] = useState(false);
  const [imageViewerImages, setImageViewerImages] = useState([]);
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedParents, setSelectedParents] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedManufacturers, setSelectedManufacturers] = useState([]);
  const [selectedBrands, setSelectedBrands] = useState([]);

  const navigate = useNavigate();
  const { toast } = useToast();

  const fetchProducts = async (page = 1, limit = 10) => {
    try {
      const res = await axiosInstance.get(`/products?page=${page}&limit=${limit}`);
      const { products, total_pages, total_products } = res.data;
      setProducts(products);
      setPagination({
        current_page: page,
        total_pages: total_pages || 1,
        limit,
        total_products: total_products || products.length,
      });
    } catch (error) {
      console.error("Failed to fetch products:", error);
      toast({
        title: "Error",
        description: "Failed to fetch products.",
        variant: "destructive",
      });
      setProducts([]);
      setPagination((prev) => ({
        ...prev,
        total_pages: 1,
        total_products: 0,
      }));
    }
  };

  useEffect(() => {
    fetchProducts(pagination.current_page, pagination.limit);
  }, [pagination.current_page, pagination.limit]);

  useEffect(() => {
    const fetchData = async () => {
      const endpoints = [
        { url: "/parent-categories", setter: setParentCategories },
        { url: "/categories", setter: setCategories },
        { url: "/manufacturer", setter: setManufacturers },
        { url: "/brands", setter: setBrands },
        {
          url: "/product_colors",
          setter: setColorOptions,
          transform: (data) =>
            data.map((it) => ({
              id: String(it.id ?? it._id ?? it.color_id ?? ""),
              name: String(it.color_name ?? it.name ?? it.label ?? it.color ?? ""),
            })),
        },
        {
          url: "/product_pattern",
          setter: setPatternOptions,
          transform: (data) =>
            data.map((it) => ({
              id: String(it.id ?? it._id ?? ""),
              name: String(it.pattern ?? it.name ?? it.label ?? it.value ?? ""),
            })),
        },
        {
          url: "/product_sizes",
          setter: setUnitOptions,
          transform: (data) =>
            data.map((it) => ({
              id: String(it.id ?? it._id ?? it.size_id ?? ""),
              name: String(it.unit ?? it.size_name ?? it.label ?? it.value ?? ""),
            })),
        },
      ];

      const fetchPromises = endpoints.map(async ({ url, setter, transform }) => {
        try {
          const res = await axiosInstance.get(url);
          let data = res.data?.success ? res.data.data : Array.isArray(res.data) ? res.data : [];
          if (transform) data = transform(data);
          setter(data);
        } catch (error) {
          console.error(`Failed to fetch ${url}:`, error);
          setter([]);
        }
      });

      await Promise.all(fetchPromises);
    };

    fetchData();
  }, []);

  useEffect(() => {
    setColorNameById(colorOptions.reduce((acc, c) => ({ ...acc, [c.id]: c.name }), {}));
    setPatternNameById(patternOptions.reduce((acc, p) => ({ ...acc, [p.id]: p.name }), {}));
  }, [colorOptions, patternOptions]);

  const stripHtml = (html) => {
    if (!html) return "";
    const el = document.createElement("div");
    el.innerHTML = html;
    return el.textContent || el.innerText || "";
  };

  const splitTags = (tags) =>
    (tags || "")
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);

  const formatDimensions = (attrs) => {
    if (!attrs) return "-";
    const L = attrs.length ?? "-";
    const W = attrs.width ?? "-";
    const H = attrs.height ?? "-";
    const U = attrs.unit ?? "";
    if (L === "-" && W === "-" && H === "-") return "-";
    return `${L} × ${W} × ${H} ${U}`.trim();
  };

  const toggleParent = (id) => {
    const strId = String(id);
    setSelectedParents((prev) =>
      prev.includes(strId) ? prev.filter((p) => p !== strId) : [...prev, strId]
    );
  };

  const toggleCategory = (id) => {
    const strId = String(id);
    setSelectedCategories((prev) =>
      prev.includes(strId) ? prev.filter((c) => c !== strId) : [...prev, strId]
    );
  };

  const toggleManufacturer = (name) => {
    setSelectedManufacturers((prev) =>
      prev.includes(name) ? prev.filter((m) => m !== name) : [...prev, name]
    );
  };

  const toggleBrand = (name) => {
    setSelectedBrands((prev) =>
      prev.includes(name) ? prev.filter((b) => b !== name) : [...prev, name]
    );
  };

  const filteredProducts = products.filter((product) => {
    const id = (product.id || "").toString().toLowerCase();
    const title = (product.title || "").toString().toLowerCase();
    const tags = (product.tags || "").toString().toLowerCase();
    const desc = stripHtml(product.description || "").toString().toLowerCase();

    const matchesSearch =
      id.includes(searchTerm.toLowerCase()) ||
      title.includes(searchTerm.toLowerCase()) ||
      tags.includes(searchTerm.toLowerCase()) ||
      desc.includes(searchTerm.toLowerCase());

    const matchesParent =
      selectedParents.length === 0 ||
      selectedParents.includes(String(product.parent_category));
    const matchesCategory =
      selectedCategories.length === 0 ||
      selectedCategories.includes(String(product.product_category));
    const matchesManufacturer =
      selectedManufacturers.length === 0 ||
      selectedManufacturers.includes(product.general_info?.manufacturer_name);
    const matchesBrand =
      selectedBrands.length === 0 ||
      selectedBrands.includes(product.general_info?.manufacturer_brand);

    return (
      matchesSearch &&
      matchesParent &&
      matchesCategory &&
      matchesManufacturer &&
      matchesBrand
    );
  });

  const handleAddProduct = () => navigate("/products/create");

  const handleEditProduct = (product) => {
    const id = product.id ?? product._id;
    navigate(`/products/edit/${id}`);
  };

  const handleDeleteProduct = async (productId) => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;

    try {
      await axiosInstance.delete(`/products/${productId}`);
      setProducts((prev) => prev.filter((p) => (p.id ?? p._id) !== productId));

      if (filteredProducts.length === 1 && pagination.current_page > 1) {
        setPagination((prev) => ({ ...prev, current_page: prev.current_page - 1 }));
      } else {
        fetchProducts(pagination.current_page, pagination.limit);
      }

      toast({ title: "Product deleted", description: "Product has been successfully deleted." });
    } catch (error) {
      console.error("Failed to delete product:", error);
      toast({
        title: "Error",
        description: "Something went wrong while deleting the product.",
        variant: "destructive",
      });
    }
  };

  const totalProducts = pagination.total_products;
  const totalValue = products.reduce((sum, p) => {
    const price = parseFloat(p.general_info?.price ?? 0);
    const stock = parseInt(p.general_info?.stock ?? 0);
    return sum + price * stock;
  }, 0);

  const lowStockCount = products.filter((p) => parseInt(p.general_info?.stock ?? 0) > 0).length;
  const outOfStockCount = products.filter((p) => parseInt(p.general_info?.stock ?? 0) === 0).length;

  const getImageUrl = (path) => (path?.startsWith("http") ? path : `${IMAGE_BASE_URL}${path}`);

  const getStatusBadge = (status) =>
    status === "Inactive" ? (
      <Badge variant="destructive">Inactive</Badge>
    ) : (
      <Badge variant="default" className="bg-green-500 text-white">
        Active
      </Badge>
    );

  const truncateText = (text, maxLength = 30) =>
    !text ? "" : text.length > maxLength ? text.substring(0, maxLength) + "..." : text;
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Products</h1>
          <p className="text-muted-foreground">Manage your product inventory and catalog</p>
        </div>
        <Button onClick={handleAddProduct}>
          <Plus className="mr-2 h-4 w-4" />
          Add Product
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
  <Card>
    <CardContent className="p-3 flex items-center gap-2">
      <div className="p-2 rounded-full bg-gray-200 border">
        <Package className="h-4 w-4 text-muted-foreground" />
      </div>
      <div>
        <p className="text-xs font-medium text-muted-foreground">Total Products</p>
        <p className="text-lg font-bold">{totalProducts}</p>
      </div>
    </CardContent>
  </Card>

  <Card>
    <CardContent className="p-3 flex items-center gap-2">
      <div className="p-2 rounded-full bg-gray-200 border">
        <DollarSign className="h-4 w-4 text-muted-foreground" />
      </div>
      <div>
        <p className="text-xs font-medium text-muted-foreground">Inventory Value</p>
        <p className="text-lg font-bold">${totalValue.toLocaleString()}</p>
      </div>
    </CardContent>
  </Card>

  <Card>
    <CardContent className="p-3 flex items-center gap-2">
      <div className="p-2 rounded-full bg-gray-200 border">
        <TrendingUp className="h-4 w-4 text-muted-foreground" />
      </div>
      <div>
        <p className="text-xs font-medium text-muted-foreground">In Stock</p>
        <p className="text-lg font-bold">{lowStockCount}</p>
      </div>
    </CardContent>
  </Card>

  <Card>
    <CardContent className="p-3 flex items-center gap-2">
      <div className="p-2 rounded-full bg-gray-200 border">
        <AlertTriangle className="h-4 w-4 text-muted-foreground" />
      </div>
      <div>
        <p className="text-xs font-medium text-muted-foreground">Out of Stock</p>
        <p className="text-lg font-bold">{outOfStockCount}</p>
      </div>
    </CardContent>
  </Card>
</div>

      <Card>
        <CardHeader>
          <CardTitle>All Products</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative w-full max-w-md mb-4">
            <Input
              placeholder="Search by Name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10"
            />
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-0 top-0"
              onClick={() => setFilterOpen(true)}
            >
              <Filter className="h-4 w-4" />
            </Button>
          </div>

         <div className="border rounded-md">
            {/* Scrollable Container */}
            <div className="max-h-[600px] overflow-y-auto overflow-x-auto">
              <table className="table-fixed min-w-[250%] border-collapse w-full text-xs">
                <thead className="sticky top-0 z-30 bg-gray-50">
                  <tr className="text-gray-700 text-center text-xs">
                    <th className="w-[10%] sticky left-0 bg-gray-50 z-20 border-b py-3 text-xs">Id</th>
                    <th className="w-[35%] border-b py-3 text-xs">Product Title</th>
                    <th className="w-[35%] border-b py-3 text-xs">Description</th>
                    <th className="w-[15%] border-b py-3 text-xs">Parent Category</th>
                    <th className="w-[20%] border-b py-3 text-xs">Product Category</th>
                    <th className="w-[20%] border-b py-3 text-xs">Product Tags</th>
                    <th className="w-[16%] border-b py-3 text-xs">Product Images</th>
                    <th className="w-[16%] border-b py-3 text-xs">Size Dimensions</th>
                    <th className="w-[16%] border-b py-3 text-xs">Size Category</th>
                    <th className="w-[20%] border-b py-3 text-xs">Manufacturer Name</th>
                    <th className="w-[15%] border-b py-3 text-xs">Brand Name</th>
                    <th className="w-[10%] border-b py-3 text-xs">Color</th>
                    <th className="w-[15%] border-b py-3 text-xs">Pattern</th>
                    <th className="w-[8%] border-b py-3 text-xs">Stock</th>
                    <th className="w-[12%] border-b py-3 text-xs">Price</th>
                    <th className="w-[20%] border-b py-3 text-xs">Base Price</th>
                    <th className="w-[12%] border-b py-3 text-xs">Discount</th>
                    <th className="w-[25%] border-b py-3 text-xs">Discounted Price</th>
                    <th className="w-[10%] border-b py-3 text-xs">Gst</th>
                    <th className="w-[25%] border-b py-3 text-xs">Gst Amount</th>
                    <th className="w-[12%] border-b py-3 text-xs">Status</th>
                    <th className="w-[12%] border-b py-3 text-xs">Overview</th>
                    <th className="w-[10%] border-b py-3 text-xs">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product) => {
                    const id = product.id ?? product._id;
                    return (
                      <tr
                        key={id}
                        className="hover:bg-gray-50 transition duration-150 text-center text-xs"
                      >
                        <td className="sticky left-0 bg-white z-10 font-medium text-muted-foreground border-b py-3 text-xs">
                          {id}
                        </td>
                        <td className="text-gray-800 font-medium border-b py-3 text-xs">{product.title}</td>
                        <td className="border-b py-3 text-xs">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="cursor-pointer">
                                  {truncateText(stripHtml(product.description), 30)}
                                </span>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-sm whitespace-pre-wrap text-xs text-gray-800 p-4">
                                {stripHtml(product.description)}
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </td>
                        <td className="border-b py-3 text-xs">{product.parent_category}</td>
                        <td className="border-b py-3 text-xs">{product.product_category}</td>
                        <td className="border-b py-3 text-xs">
                          <div className="flex flex-wrap justify-center gap-1">
                            {splitTags(product.tags).map((t, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {t}
                              </Badge>
                            ))}
                          </div>
                        </td>
                        <td className="border-b py-3 text-xs">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setImageViewerImages(product.images || []);
                              setImageViewerOpen(true);
                            }}
                            className="text-xs"
                          >
                            View ({(product.images || []).length})
                          </Button>
                        </td>
                        <td className="border-b py-3 text-xs">{formatDimensions(product.attributes)}</td>
                        <td className="border-b py-3 text-xs">{product.attributes?.size_category || "-"}</td>
                        <td className="border-b py-3 text-xs">{product.general_info?.manufacturer_name}</td>
                        <td className="border-b py-3 text-xs">{product.general_info?.manufacturer_brand}</td>
                        <td className="border-b py-3 text-xs">{product.attributes?.color || "-"}</td>
                        <td className="border-b py-3 text-xs">{product.attributes?.pattern || "-"}</td>
                        <td className="border-b py-3 text-xs">{product.general_info?.stock ?? ""}</td>
                        <td className="border-b py-3 text-xs">${product.general_info?.price ?? ""}</td>
                        <td className="border-b py-3 text-xs">${product.general_info?.base_price?.toFixed(2) ?? "0.00"}</td>
                        <td className="border-b py-3 text-xs">{product.general_info?.discount ?? ""}%</td>
                        <td className="border-b py-3 text-xs">${product.general_info?.discounted_price?.toFixed(2) ?? "0.00"}</td>
                        <td className="border-b py-3 text-xs">{product.general_info?.gst ?? ""}%</td>
                        <td className="border-b py-3 text-xs">${product.general_info?.gst_amount?.toFixed(2) ?? "0.00"}</td>
                        <td className="border-b py-3 text-xs">{getStatusBadge(product.status)}</td>
                        <td className="border-b py-3 text-xs">
                          {product.overview || product.specifications ? (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => navigate(`/admin/product/overview/view/${product.id ?? product._id}`)}
                              className="text-blue-600 hover:bg-blue-50 text-xs"
                            >
                              View
                            </Button>
                          ) : (
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() =>
                                navigate("/admin/product/overview/create", {
                                  state: {
                                    productId: product.id ?? product._id,
                                    productTitle: product.title,
                                  },
                                })
                              }
                              className="text-xs"
                            >
                              Add
                            </Button>
                          )}
                        </td>
                        <td className="border-b py-3 text-xs">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={() => handleEditProduct(product)}
                                className="gap-2 text-xs"
                              >
                                <Edit className="h-4 w-4" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleDeleteProduct(id)}
                                className="gap-2 text-red-600 text-xs"
                              >
                                <Trash2 className="h-4 w-4" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Image Viewer Dialog */}
            <Dialog open={imageViewerOpen} onOpenChange={setImageViewerOpen}>
              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle>Product Images</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {(imageViewerImages?.length ? imageViewerImages : []).map((src, i) => (
                    <img
                      key={i}
                      src={getImageUrl(src)}
                      alt={`Product ${i + 1}`}
                      className="w-full h-48 object-contain rounded border"
                    />
                  ))}
                </div>
              </DialogContent>
            </Dialog>

            {/* Filter Dialog */}
            <Dialog open={filterOpen} onOpenChange={setFilterOpen}>
              <DialogContent className="bg-white rounded-lg shadow-xl p-6 w-[40rem]">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Filter Products</h2>
                <div className="max-h-[70vh] overflow-y-auto space-y-6 pr-2">
                  <div>
                    <h3 className="text-sm font-medium capitalize">Parent Category</h3>
                    <div className="flex flex-wrap gap-3 mt-2">
                      {parentCategories.map((cat) => (
                        <label key={cat.id} className="flex items-center gap-2 text-xs">
                          <input
                            type="checkbox"
                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                            checked={selectedParents.includes(String(cat.id))}
                            onChange={() => toggleParent(cat.id)}
                          />
                          {cat.name}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium capitalize">Product Category</h3>
                    <div className="flex flex-wrap gap-3 mt-2">
                      {categories.map((cat) => (
                        <label key={cat.id} className="flex items-center gap-2 text-xs">
                          <input
                            type="checkbox"
                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                            checked={selectedCategories.includes(String(cat.id))}
                            onChange={() => toggleCategory(cat.id)}
                          />
                          {cat.name}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium capitalize">Manufacturer Name</h3>
                    <div className="flex flex-wrap gap-3 mt-2">
                      {manufacturers.map((man) => (
                        <label key={man.id} className="flex items-center gap-2 text-xs">
                          <input
                            type="checkbox"
                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                            checked={selectedManufacturers.includes(man.name)}
                            onChange={() => toggleManufacturer(man.name)}
                          />
                          {man.name}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium capitalize">Brand Name</h3>
                    <div className="flex flex-wrap gap-3 mt-2">
                      {brands.map((brand) => (
                        <label key={brand.id} className="flex items-center gap-2 text-xs">
                          <input
                            type="checkbox"
                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                            checked={selectedBrands.includes(brand.name)}
                            onChange={() => toggleBrand(brand.name)}
                          />
                          {brand.name}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-end gap-3">
                    <button
                      className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 text-xs"
                      onClick={() => setFilterOpen(false)}
                    >
                      Cancel
                    </button>
                    <button
                      className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-xs"
                      onClick={() => setFilterOpen(false)}
                    >
                      Apply
                    </button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="flex justify-end items-center gap-2 mt-4">
            <Button
              variant="outline"
              disabled={pagination.current_page === 1}
              onClick={() => setPagination(prev => ({ ...prev, current_page: prev.current_page - 1 }))}
            >
              Previous
            </Button>
            {Array.from({ length: pagination.total_pages }, (_, i) => i + 1).map(page => (
              <Button
                key={page}
                variant={page === pagination.current_page ? "default" : "outline"}
                onClick={() => setPagination(prev => ({ ...prev, current_page: page }))}
              >
                {page}
              </Button>
            ))}
            <Button
              variant="outline"
              disabled={pagination.current_page === pagination.total_pages}
              onClick={() => setPagination(prev => ({ ...prev, current_page: prev.current_page + 1 }))}
            >
              Next
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}