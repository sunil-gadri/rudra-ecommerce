import React, { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import imageCompression from "browser-image-compression";

export default function Manufacturer() {
  const [manufacturerTitle, setManufacturerTitle] = useState("");
  const [profileImage, setProfileImage] = useState(null);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [savedManufacturers, setSavedManufacturers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const IMAGE_BASE_URL = "http://192.168.0.9:5000";
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editFormData, setEditFormData] = useState({
    id: null,
    manufacturer_name: "",
    image: null,
    preview: undefined,
  });

  useEffect(() => {
    fetchManufacturers();
    return () => {
      if (editFormData?.preview) {
        URL.revokeObjectURL(editFormData.preview);
      }
    };
  }, [editFormData]);

  const fetchManufacturers = async () => {
    try {
      const res = await axiosInstance.get("/manufacturer");
      setSavedManufacturers(res.data);
      console.log("Manufacturers data:", res.data);
    } catch (error) {
      console.error("Failed to fetch manufacturers:", error);
    }
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    const preview = URL.createObjectURL(file);
    setProfileImage({ file, preview });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormSubmitted(true);

    if (!manufacturerTitle || !profileImage?.file) return;

    const formData = new FormData();
    formData.append("manufacturer_name", manufacturerTitle);
    formData.append("image", profileImage.file);

    try {
      setLoading(true);

      // compress image before sending
      const compressedImage = await compressImage(profileImage.file);
      formData.append("image", compressedImage, compressedImage.name);

      await axiosInstance.post("/manufacturer", formData);
      await fetchManufacturers();

      setManufacturerTitle("");
      setProfileImage(null);
      setFormSubmitted(false);
    } catch (error) {
      console.error("Failed to submit manufacturer:", error);
    } finally {
      setLoading(false);
    }
  };

  const getImageUrl = (path) => {
    if (path && path.startsWith("http")) {
      return path;
    } else {
      return IMAGE_BASE_URL + path;
    }
  };

  const startEdit = (manufacturer) => {
    setEditFormData({
      id: manufacturer.id,
      manufacturer_name: manufacturer.manufacturer_name,
      image: null,
      preview: manufacturer.image_url ? getImageUrl(manufacturer.image_url) : null,
    });
    setEditDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this manufacturer?")) return;

    try {
      await axiosInstance.delete(`/manufacturer/${id}`);
      await fetchManufacturers();
    } catch (error) {
      console.error("Error deleting manufacturer:", error);
      alert("Failed to delete manufacturer.");
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("manufacturer_name", editFormData.manufacturer_name);

    try {
      if (editFormData.image) {
        // compress image before sending
        const compressedImage = await compressImage(editFormData.image);
        formData.append("image", compressedImage, compressedImage.name);
      }

      await axiosInstance.put(`/manufacturer/${editFormData.id}`, formData);
      setEditDialogOpen(false);
      await fetchManufacturers();
    } catch (error) {
      console.error("Failed to update manufacturer:", error);
      alert("Update failed.");
    }
  };

  const handleEditImageUpload = (e) => {
    const file = e.target.files[0];
    const preview = URL.createObjectURL(file);
    setEditFormData((prev) => ({ ...prev, image: file, preview }));
  };

  const filteredManufacturers = savedManufacturers.filter((item) => {
    const term = searchTerm.toLowerCase();
    return (
      item.id?.toString().includes(term) ||
      (item.manufacturer_name?.toLowerCase().includes(term))
    );
  });

  useEffect(() => {
    return () => {
      if (profileImage?.preview) {
        URL.revokeObjectURL(profileImage.preview);
      }
      if (editFormData?.preview) {
        URL.revokeObjectURL(editFormData.preview);
      }
    };
  }, [profileImage, editFormData.preview]);

  const compressImage = async (file) => {
    try {
      const compressedFile = await imageCompression(file, {
        maxSizeMB: 0.03,
        maxWidthOrHeight: 1024,
        useWebWorker: true,
      });
      return compressedFile;
    }
    catch (error) {
      console.error("Image compression error:", error);
      return file;
    }
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Create Manufacturer</h1>
          <p className="text-muted-foreground">Manage your manufacturers</p>
        </div>
        <div className="bg-white p-6 rounded-lg border space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Manufacturer Title */}
            <div >
              <Label>Manufacturer Title</Label>
              <Input
                id="manufacturer-title"
                type="text"
                placeholder="Enter manufacturer title"
                value={manufacturerTitle}
                onChange={(e) => {
                  const value = e.target.value;
                  const formatted =
                    value.charAt(0).toUpperCase() + value.slice(1);
                  setManufacturerTitle(formatted);
                }}
              />
              {formSubmitted && !manufacturerTitle && (
                <p className="text-red-500 text-sm mt-1">
                  Please enter a manufacturer title.
                </p>
              )}
            </div>

            {/* Profile Image Upload */}
            <div>
              <Label
                htmlFor="profile-image"
              >
                Profile Image
              </Label>
              <Input
                id="profile-image"
                type="file"
                accept="image/*"
                // className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
                onChange={handleImageUpload}
              />
              {formSubmitted && !profileImage && (
                <p className="text-red-500 text-sm mt-1">
                  Please upload a profile image.
                </p>
              )}
            </div>

          </div>
          {/* Submit Button */}
          <div>
            <Button type="submit" disabled={loading}>
              {loading ? "Saving..." : "Save"}
            </Button>
          </div>
        </div>
      </form>

      <Card>
        <CardHeader>
          <CardTitle>All Manufacturers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search manufacturers..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {filteredManufacturers.length > 0 ? (
            <div className="border rounded-md">
              {/* Fixed Header */}
              <Table className="w-full table-fixed">
                <TableHeader>
                  <TableRow className="bg-gray-50 text-gray-700 text-center sticky top-0 z-10">
                    <TableHead className="text-center w-[20%]">ID</TableHead>
                    <TableHead className="text-center w-[30%]">Title</TableHead>
                    <TableHead className="text-center w-[30%]">Profile Image</TableHead>
                    <TableHead className="text-center w-[22%]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
              </Table>

              {/* Scrollable Body */}
              <div className="max-h-96 overflow-y-auto overflow-x-auto">
                <Table className="w-full table-fixed">
                  <TableBody>
                    {filteredManufacturers.map((item, index) => (
                      <TableRow key={item.id || index}>
                        <TableCell className="text-center align-middle text-muted-foreground w-[20%]">
                          {item.id}
                        </TableCell>
                        <TableCell className="text-center align-middle w-[30%]">
                          <span className="font-medium text-gray-800">
                            {item.manufacturer_name || item.title}
                          </span>
                        </TableCell>
                        <TableCell className="text-center align-middle w-[30%]">
                          {item.image && (
                            <img
                              src={getImageUrl(item.image_url)}
                              alt="Profile"
                              className="w-16 h-16 object-cover rounded mx-auto"
                            />
                          )}
                        </TableCell>
                        <TableCell className="text-center align-middle w-[20%]">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="icon" variant="ghost">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => startEdit(item)}>
                                <Edit className="w-4 h-4 mr-2" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => handleDelete(item.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 mr-2" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          ) : (
            <p className="text-gray-500 py-6 text-center">
              No manufacturers found.
            </p>
          )}
        </CardContent>
      </Card>

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Manufacturer</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div>
              <Label>Manufacturer Title</Label>
              <Input
                type="text"
                value={editFormData.manufacturer_name}
                onChange={(e) => {
                  const value = e.target.value;
                  const formatted =
                    value.charAt(0).toUpperCase() + value.slice(1);
                  setEditFormData({
                    ...editFormData,
                    manufacturer_name: formatted,
                  });
                }}
                required
              />
            </div>
            <div>
              <Label>Profile Image </Label>
              <input
                type="file"
                accept="image/*"
                onChange={handleEditImageUpload}
              />
              {editFormData.preview && (
                <img
                  src={editFormData.preview}
                  alt="Preview"
                  className="w-20 h-20 object-cover rounded mt-2"
                />
              )}
            </div>

            <DialogFooter className="pt-4">
              <Button
                variant="outline"
                onClick={() => setEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit">Update</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
