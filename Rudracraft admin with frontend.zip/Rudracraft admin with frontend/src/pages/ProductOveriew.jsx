import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, MoreHorizontal, Plus, Edit, Trash2, Filter, X } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";

export default function ProductOverview() {
    const navigate = useNavigate();
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [deletingId, setDeletingId] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [popupData, setPopupData] = useState(null); 
    const [popupPosition, setPopupPosition] = useState({ x: 0, y: 0 });
    const { toast } = useToast();

    useEffect(() => {
        const fetchProductDescriptions = async () => {
            try {
                setLoading(true);
                const response = await axiosInstance.get("/product-description");
                const items = response.data?.data || response.data || [];
                setData(Array.isArray(items) ? items : []);
            } catch (error) {
                console.error("Error fetching product descriptions:", error);
                toast({
                    title: "Error",
                    description: "Failed to load product overviews.",
                    variant: "destructive",
                });
                setData([]);
            } finally {
                setLoading(false);
            }
        };
        fetchProductDescriptions();
    }, [toast]);

    const handleDelete = async (id) => {
        if (!window.confirm("Are you sure you want to delete this product overview?")) return;
        setDeletingId(id);
        try {
            await axiosInstance.delete(`/product-description/${id}`);
            setData((prev) => prev.filter((i) => i.id !== id));
            toast({ title: "Success", description: "Product overview deleted successfully." });
        } catch (error) {
            console.error("Delete failed:", error);
            toast({
                title: "Error",
                description: error.response?.data?.message || "Failed to delete overview.",
                variant: "destructive",
            });
        } finally {
            setDeletingId(null);
        }
    };

    const handleAddOverview = () => navigate("/product/overview/create");

    const handleHover = (e, content, fieldName) => {
        setPopupData({ content, fieldName });
    };

    const handleMouseLeave = () => {
        setPopupData(null);
    };

    const filteredData = data.filter((item) => {
        const searchLower = searchTerm.toLowerCase();

        const matchesOverview = item.overview?.toLowerCase().includes(searchLower);
        const matchesDisclaimer = item.disclaimer?.toLowerCase().includes(searchLower);
        const matchesProductTitle = item.product_title?.toLowerCase().includes(searchLower);

        const matchesSpecs = Object.values(item.specifications || {}).some((group) =>
            Object.values(group).some((value) =>
                String(value).toLowerCase().includes(searchLower)
            )
        );
        return matchesOverview || matchesDisclaimer || matchesProductTitle || matchesSpecs;
    });

    const formatSpecifications = (specs) => {
        if (!specs || Object.keys(specs).length === 0) return "-";

        return Object.entries(specs)
            .map(([heading, values]) => {
                const formattedValues = Object.entries(values)
                    .map(([key, value]) => `${key}: ${value}`)
                    .join(" | ");
                return `${heading}: ${formattedValues}`;
            })
            .join(" || ");
    };

    const truncateText = (text, length = 20) => {
        if (!text) return "-";
        if (text.length <= length) return text;
        return text.substring(0, length) + "...";
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Product Overview</h1>
                    <p className="text-muted-foreground">Manage your product overview details</p>
                </div>
                <Button onClick={handleAddOverview}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Overview
                </Button>
            </div>

            <Card className="w-full">
                <CardHeader>
                    <CardTitle>All Product Overviews</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="relative w-full md:w-[40%] mb-4">
                        <Input
                            type="text"
                            placeholder="Search by overview, specs, disclaimer, or product title..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10 pr-10 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                        />
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                        <button className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700">
                            <Filter className="h-4 w-4" />
                        </button>
                    </div>

                    <div className="border rounded-md">
                        <div className="overflow-y-auto overflow-x-auto max-h-[600px]">
                            <table className="table-fixed w-full border-collapse">
                                <thead className="sticky top-0 bg-gray-50">
                                    <tr className="text-gray-700 text-center">
                                        <th className="sticky left-0 bg-gray-50 z-20 px-4 py-3 border-b">ID</th>
                                        <th className="w-[30%] px-4 py-3 border-b">Specifications</th>
                                        <th className="px-4 py-3 border-b">Disclaimer</th>
                                        <th className="px-4 py-3 border-b">Product Overview</th>
                                        <th className="px-4 py-3 border-b">Product Title</th>
                                        <th className="px-4 py-3 border-b text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr>
                                            <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                                                Loading...
                                            </td>
                                        </tr>
                                    ) : filteredData.length === 0 ? (
                                        <tr>
                                            <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                                                {searchTerm ? "No results found" : "No product overviews available"}
                                            </td>
                                        </tr>
                                    ) : (
                                        filteredData.map((item) => (
                                            <tr key={item.id} className="hover:bg-gray-50 transition duration-150 text-center">
                                                <td className="sticky left-0 bg-white z-10 font-medium text-muted-foreground border-b py-3">
                                                    {item.id}
                                                </td>
                                                <td className="text-gray-800 font-medium border-b py-3 text-left">
                                                    <div 
                                                        className="truncate max-w-md cursor-pointer hover:text-blue-600"
                                                        onMouseEnter={(e) => handleHover(e, formatSpecifications(item.specifications), "Specifications")}
                                                        onMouseLeave={handleMouseLeave}
                                                    >
                                                        {formatSpecifications(item.specifications)}
                                                    </div>
                                                </td>
                                                <td 
                                                    className="font-medium border-b py-3 cursor-pointer hover:text-blue-600"
                                                    onMouseEnter={(e) => handleHover(e, item.disclaimer || "-", "Disclaimer")}
                                                    onMouseLeave={handleMouseLeave}
                                                >
                                                    {truncateText(item.disclaimer, 20)}
                                                </td>
                                                <td className="text-gray-700 border-b max-w-md text-left">
                                                    <div 
                                                        className="truncate cursor-pointer hover:text-blue-600"
                                                        onMouseEnter={(e) => handleHover(e, item.overview || "-", "Overview")}
                                                        onMouseLeave={handleMouseLeave}
                                                    >
                                                        {item.overview || "-"}
                                                    </div>
                                                </td>
                                                <td className="px-4 py-3 text-sm border-b">
                                                    <Badge variant="secondary" className="text-xs">
                                                        {item.product_title ? item.product_title : `ID: ${item.product_id}`}
                                                    </Badge>
                                                </td>
                                                <td className="px-4 py-3 text-sm text-center border-b">
                                                    <DropdownMenu>
                                                        <DropdownMenuTrigger asChild>
                                                            <Button variant="ghost" size="sm" disabled={deletingId === item.id}>
                                                                {deletingId === item.id ? (
                                                                    <div className="h-4 w-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                                                                ) : (
                                                                    <MoreHorizontal className="h-4 w-4" />
                                                                )}
                                                            </Button>
                                                        </DropdownMenuTrigger>
                                                        <DropdownMenuContent align="end">
                                                            <DropdownMenuItem
                                                                onClick={() => navigate(`/product/overview/edit/${item.id}`)}
                                                                className="cursor-pointer"
                                                            >
                                                                <Edit className="mr-2 h-4 w-4" />
                                                                Edit
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem
                                                                onClick={() => handleDelete(item.id)}
                                                                className="text-red-600 cursor-pointer"
                                                            >
                                                                <Trash2 className="mr-2 h-4 w-4" />
                                                                Delete
                                                            </DropdownMenuItem>
                                                        </DropdownMenuContent>
                                                    </DropdownMenu>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* Hover Popup */}
                    {popupData && (
                        <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none">
                            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-indigo-200 rounded-xl shadow-2xl p-6 max-w-lg w-11/12">
                                <div className="text-center">
                                    <div className="font-bold text-lg text-indigo-700 mb-3">
                                        {popupData.fieldName}
                                    </div>
                                    <div className="text-sm text-gray-700 whitespace-pre-wrap break-words leading-relaxed">
                                        {popupData.content}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}