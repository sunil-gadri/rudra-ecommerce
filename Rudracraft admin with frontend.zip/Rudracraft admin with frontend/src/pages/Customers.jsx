import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  MoreHorizontal,
  Download,
  Filter,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";
import imageCompression from "browser-image-compression";

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [pagination, setPagination] = useState({
    current_page: 1,
    total_pages: 1,
    limit: 10,
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [addProfileImage, setAddProfileImage] = useState();
  const [addPreview, setAddPreview] = useState(null);
  const [editProfileImage, setEditProfileImage] = useState(null);
  const [editPreview, setEditPreview] = useState(null);

  const { toast } = useToast();

  // State for Add form
  const [addForm, setAddForm] = useState({
    first_name: "",
    last_name: "",
    // profile_image: "",
    email: "",
    phone: "",
    password: "",
    gender: "Male",
    status: "Active",
  });

  // State for Edit form
  const [editForm, setEditForm] = useState({
    first_name: "",
    last_name: "",
    profile_image: "",
    email: "",
    phone: "",
    gender: "Male",
    status: "Active",
  });

  const fetchCustomers = async (page = 1, limit = 10) => {
    try {
      const response = await axiosInstance.get(`customer-profile?page=${page}&limit=${limit}`);

      const { profiles, pagination } = response.data;

      const formatted = profiles.map((c) => ({
        id: c.id,
        name: `${c.first_name} ${c.last_name}`,
        email: c.email,
        phone: c.phone,
        profile_image: c.profile_image_url,
        status: c.status === "active" ? "Active" : "Inactive",
        joinDate: new Date(c.created_at).toISOString().split("T")[0],
        totalOrders: c.totalOrders || 0,
        totalSpent: c.totalSpent || 0,
        gender: c.gender?.toLowerCase() === "female" ? "Female" : "Male",
      }));

      setCustomers(formatted);
      setPagination(pagination);
    } catch (err) {
      console.error("Error fetching customers:", err);
      toast({
        title: "Error",
        description: "Failed to fetch customers",
        variant: "destructive",
      });
    }
  };


  useEffect(() => {
    fetchCustomers(pagination.current_page, pagination.limit);
  }, [pagination.current_page]);


  const validateCustomerForm = (form, isEdit = false) => {
    const errors = {};

    if (!form.first_name.trim()) errors.first_name = "First name is required.";
    if (!form.last_name.trim()) errors.last_name = "Last name is required.";

    if (!form.email.trim()) {
      errors.email = "Email is required.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errors.email = "Enter a valid email address.";
    }

    if (!form.phone.trim()) {
      errors.phone = "Phone number is required.";
    } else if (!/^\d{10}$/.test(form.phone)) {
      errors.phone = "Phone number must be 10 digits.";
    }

    if (!isEdit && !form.password.trim()) {
      errors.password = "Password is required.";
    }

    return errors;
  };

  // For Edit Customer
  const handleEditImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setEditProfileImage(file);
      setEditPreview(URL.createObjectURL(file));
      setEditForm({ ...editForm, profile_image: file });
    }
  };

  // For Add Customer
  const handleAddImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAddProfileImage(file);
      setAddPreview(URL.createObjectURL(file));
    }
  };

  const getServerErrorMessage = (err) => {
    const data = err?.response?.data;
    if (data?.message) return data.message;
    if (data?.error) return data.error;
    if (data?.errors && typeof data.errors === "object") {
      try {
        const arr = Object.values(data.errors).flat();
        return arr.join(", ");
      } catch (e) { /* fallthrough */ }
    }
    if (Array.isArray(data)) return data.join(", ");
    if (typeof data === "string") return data;
    return err?.message || "Something went wrong";
  };

  const handleAddSubmit = async (e) => {
    e.preventDefault();

    const errors = validateCustomerForm(addForm, false);
    if (Object.keys(errors).length > 0) {
      Object.values(errors).forEach((msg) =>
        toast({ title: "Validation Error", description: msg, variant: "destructive" })
      );
      return;
    }

    const formData = new FormData();
    formData.append("first_name", addForm.first_name);
    formData.append("last_name", addForm.last_name);
    if (addProfileImage) {
      const compressedImage = await compressImage(addProfileImage);
      formData.append("profile_image", compressedImage, compressedImage.name);
    }
    formData.append("email", addForm.email);
    formData.append("gender", addForm.gender);
    formData.append("phone", addForm.phone);
    formData.append("password", addForm.password);
    formData.append("status", addForm.status.toLowerCase());

    try {
      await axiosInstance.post("customer-profile", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      toast({ title: "Customer Created", description: "New customer added." });
      setAddDialogOpen(false);
      setAddForm({
        first_name: "",
        last_name: "",
        // profile_image: "",
        phone: "",
        email: "",
        password: "",
        gender: "Male",
        status: "Active",
      });
      setAddProfileImage(null);
      setAddPreview(null);
      fetchCustomers();
    } catch (err) {
      const errorMessage = getServerErrorMessage(err);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });

      console.error("Add customer error:", err.response?.data || err.message);
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();

    const errors = validateCustomerForm(editForm, true);
    if (Object.keys(errors).length > 0) {
      Object.values(errors).forEach((msg) =>
        toast({ title: "Validation Error", description: msg, variant: "destructive" })
      );
      return;
    }

    const formData = new FormData();
    formData.append("first_name", editForm.first_name);
    formData.append("last_name", editForm.last_name);
    if (editProfileImage instanceof File) {
      const compressedImage = await compressImage(editProfileImage);
      formData.append("profile_image", compressedImage, compressedImage.name);
    }
    formData.append("email", editForm.email);
    formData.append("gender", editForm.gender);
    formData.append("phone", editForm.phone);
    formData.append("status", editForm.status.toLowerCase());

    try {
      await axiosInstance.put(
        `customer-profile/${editingCustomer.id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      }
      );

      toast({ title: "Customer Updated", description: "Changes saved." });
      setEditDialogOpen(false);
      setEditingCustomer(null);
      setEditProfileImage(null);
      setEditPreview(null);
      await fetchCustomers();
    } catch (err) {
      console.error("Edit customer error:", err.response?.data || err.message);
      const errorMessage =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        JSON.stringify(err?.response?.data) ||
        "Could not update customer.";

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const handleEditClick = (customer) => {
    setEditingCustomer(customer);
    const [first_name, ...rest] = customer.name.trim().split(" ");
    setEditForm({
      first_name,
      last_name: rest.join(" "),
      profile_image: customer.profile_image,
      email: customer.email,
      phone: String(customer.phone || ""),
      gender: customer.gender,
      status: customer.status,
    });
    setEditPreview(customer.profile_image);
    setEditDialogOpen(true);
  };

  const handleDeleteCustomer = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this customer?"
    );
    if (!confirmDelete) return;

    const token = localStorage.getItem("token");

    try {
      await axiosInstance.delete(`customer-profile/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast({ title: "Customer Deleted", description: "Customer removed." });
      fetchCustomers();
    } catch (err) {
      console.error("Delete error:", err);
      toast({
        title: "Error",
        description: "Failed to delete customer.",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status) =>
    status === "Active" ? (
      <Badge variant="default" className="bg-success text-success-foreground">
        Active
      </Badge>
    ) : (
      <Badge variant="destructive">Inactive</Badge>
    );

  const filteredCustomers = customers.filter((customer) =>
    `${customer.name} ${customer.email} ${customer.phone}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  const compressImage = async (file) => {
    try {
      const compressedFile = await imageCompression(file, {
        maxSizeMB: 0.03,
        maxWidthOrHeight: 1024,
        useWebWorker: true,
      });
      return compressedFile;
    }
    catch (error) {
      console.error("Image compression error:", error);
      return file;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Customers</h1>
          <p className="text-muted-foreground">Manage your customers</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Customer
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add Customer</DialogTitle>
              </DialogHeader>
              {/* ---- Add Customer Form ---- */}
              <form onSubmit={handleAddSubmit} className="space-y-4">
                <div className="grid gap-1">
                  <Label htmlFor="first_name">First Name</Label>
                  <Input
                    id="first_name"
                    type="text"
                    value={addForm.first_name}
                    onChange={(e) => {
                      const value = e.target.value;
                      const formatted =
                        value.charAt(0).toUpperCase() + value.slice(1);
                      setAddForm({ ...addForm, first_name: formatted });
                    }}
                    required
                  />
                </div>

                <div className="grid gap-1">
                  <Label htmlFor="last_name">Last Name</Label>
                  <Input
                    id="last_name"
                    type="text"
                    value={addForm.last_name}
                    onChange={(e) => {
                      const value = e.target.value;
                      const formatted =
                        value.charAt(0).toUpperCase() + value.slice(1);
                      setAddForm({ ...addForm, last_name: formatted });
                    }}
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-gray-700">
                    Profile Image
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAddImageChange}
                    className="w-full text-sm text-gray-600"
                  />
                  {addPreview && (
                    <img
                      src={addPreview}
                      alt="Preview"
                      className="mt-2 w-20 h-20 rounded-full object-cover border"
                    />
                  )}
                </div>
                <div className="grid gap-1">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={addForm.email}
                    onChange={(e) =>
                      setAddForm({ ...addForm, email: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="grid gap-1">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    type="tel"
                    inputMode="numeric"
                    maxLength={10}
                    value={addForm.phone}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, "");
                      setAddForm({ ...addForm, phone: value });
                    }}
                    required
                  />
                </div>

                <div className="grid gap-1">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={addForm.password}
                    onChange={(e) =>
                      setAddForm({ ...addForm, password: e.target.value })
                    }
                    required
                  />
                </div>

                {/* Gender */}
                <div className="grid gap-1">
                  <Label>Gender</Label>
                  <Select
                    value={addForm.gender}
                    onValueChange={(value) =>
                      setAddForm({ ...addForm, gender: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Male">Male</SelectItem>
                      <SelectItem value="Female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Status */}
                <div className="grid gap-1">
                  <Label>Status</Label>
                  <Select
                    value={addForm.status}
                    onValueChange={(value) =>
                      setAddForm({ ...addForm, status: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <DialogFooter>
                  <Button type="submit">Create</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>

          {/* Edit Customer Dialog */}
          <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
            <DialogContent className="max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Edit Customer</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleEditSubmit} className="space-y-4">
                {/* First Name */}
                <div className="grid gap-1">
                  <Label htmlFor="edit_first_name">First Name</Label>
                  <Input
                    id="edit_first_name"
                    type="text"
                    value={editForm.first_name}
                    onChange={(e) => {
                      const value = e.target.value;
                      const formatted =
                        value.charAt(0).toUpperCase() + value.slice(1);
                      setEditForm({ ...editForm, first_name: formatted });
                    }}
                    required
                  />
                </div>

                {/* Last Name */}
                <div className="grid gap-1">
                  <Label htmlFor="edit_last_name">Last Name</Label>
                  <Input
                    id="edit_last_name"
                    type="text"
                    value={editForm.last_name}
                    onChange={(e) => {
                      const value = e.target.value;
                      const formatted =
                        value.charAt(0).toUpperCase() + value.slice(1);
                      setEditForm({ ...editForm, last_name: formatted });
                    }}
                    required
                  />
                </div>

                {/* Profile Image */}
                <div>
                  <label className="block font-semibold mb-1 text-gray-700">
                    Profile Image
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleEditImageChange}
                    className="w-full text-sm text-gray-600"
                  />
                  {editPreview && (
                    <img
                      src={editPreview}
                      alt="Preview"
                      className="mt-2 w-20 h-20 rounded-full object-cover border"
                    />
                  )}
                </div>

                {/* Email */}
                <div className="grid gap-1">
                  <Label htmlFor="edit_email">Email</Label>
                  <Input
                    id="edit_email"
                    type="email"
                    value={editForm.email}
                    onChange={(e) =>
                      setEditForm({ ...editForm, email: e.target.value })
                    }
                    required
                  />
                </div>

                {/* Phone */}
                <div className="grid gap-1">
                  <Label htmlFor="edit_phone">Phone</Label>
                  <Input
                    id="edit_phone"
                    type="tel"
                    inputMode="numeric"
                    maxLength={10}
                    value={editForm.phone}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, "");
                      setEditForm({ ...editForm, phone: value });
                    }}
                    required
                  />
                </div>

                {/* Gender */}
                <div className="grid gap-1">
                  <Label>Gender</Label>
                  <Select
                    value={editForm.gender}
                    onValueChange={(value) =>
                      setEditForm({ ...editForm, gender: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Male">Male</SelectItem>
                      <SelectItem value="Female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Status */}
                <div className="grid gap-1">
                  <Label>Status</Label>
                  <Select
                    value={editForm.status}
                    onValueChange={(value) =>
                      setEditForm({ ...editForm, status: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <DialogFooter>
                  <Button type="submit">Update</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Customers ({filteredCustomers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Search Bar */}
          <div className="relative max-w-sm mb-4">
            <div>
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search customers..."
                className="pl-10 w-64"
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          {/* Table Layout */}
          <div className="border rounded-md">
            {/* Fixed Header */}
            <table className="w-full table-fixed">
              <thead className="bg-gray-50">
                <tr className="text-center text-gray-700">
                  <th className="w-[8%] bg-gray-50 z-20 border-b py-3">Id</th>
                  <th className="border-b py-3 w-[12%]">Profile Image</th>
                  <th className="border-b py-3 w-[15%]">Name</th>
                  <th className="border-b py-3 w-[25%]">Email</th>
                  <th className="border-b py-3 w-[6%]">Gender</th>
                  <th className="border-b py-3 w-[18%]">Phone</th>
                  <th className="border-b py-3 w-[6%]">Status</th>
                  <th className="border-b py-3 w-[14%]">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((c) => (
                  <tr
                    key={c.id}
                    className="hover:bg-gray-50 transition duration-150 text-center"
                  >
                    <td className="text-center align-middle font-medium text-muted-foreground w-[8%] py-3 bg-white z-10 border-b">
                      {c.id}
                    </td>
                    <td className="text-center align-middle w-[12%] border-b py-3">
                      <div className="flex flex-col items-center">
                        <img
                          src={c.profile_image}
                          alt=""
                          className="w-10 h-10 rounded-full object-cover mx-auto"
                        />
                      </div>
                    </td>
                    <td className="w-[15%] border-b py-3 text-gray-700">
                      <span className="font-medium text-gray-800">{c.name}</span>
                    </td>
                    <td className="text-center align-middle w-[25%] border-b py-3">
                      {c.email}
                    </td>
                    <td className="text-center align-middle w-[10%] border-b py-3">
                      {c.gender}
                    </td>
                    <td className="text-center align-middle w-[15%] border-b py-3">
                      {c.phone}
                    </td>
                    <td className="text-center align-middle w-[10%] border-b py-3">
                      {getStatusBadge(c.status)}
                    </td>
                    <td className="text-center align-middle w-[10%] border-b py-3">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0 mx-auto">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Action</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => handleEditClick(c)}>
                            <Edit className="h-4 w-4 mr-2" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-red-600"
                            onClick={() => handleDeleteCustomer(c.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end items-center gap-2 mt-4">
            {/* Previous Button */}
            <Button
              variant="outline"
              disabled={pagination.current_page === 1}
              onClick={() =>
                setPagination((prev) => ({
                  ...prev,
                  current_page: prev.current_page - 1,
                }))
              }
            >
              Previous
            </Button>

            {/* Page Numbers */}
            {Array.from({ length: pagination.total_pages }, (_, i) => i + 1).map(
              (pageNum) => (
                <Button
                  key={pageNum}
                  variant={pageNum === pagination.current_page ? "default" : "outline"}
                  onClick={() =>
                    setPagination((prev) => ({
                      ...prev,
                      current_page: pageNum,
                    }))
                  }
                >
                  {pageNum}
                </Button>
              )
            )}

            {/* Next Button */}
            <Button
              variant="outline"
              disabled={pagination.current_page === pagination.total_pages}
              onClick={() =>
                setPagination((prev) => ({
                  ...prev,
                  current_page: prev.current_page + 1,
                }))
              }
            >
              Next
            </Button>
          </div>

        </CardContent>
      </Card>

    </div>
  );
}