import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import Select from "react-select";
import imageCompression from "browser-image-compression";

export default function CreateOffer() {
  const [productCategories, setProductCategories] = useState([]);
  const [heading, setHeading] = useState("");
  const [key, setKey] = useState("");
  const [discount, setDiscount] = useState("");
  const [price, setPrice] = useState("");

  // Each detail: text1, text2, product_category_ids[], details_heading
  const [details, setDetails] = useState([
    { text1: "", text2: "", product_category_ids: [], details_heading: "" },
  ]);
  const [images, setImages] = useState([null]); // Stores compressed File objects

  const navigate = useNavigate();
  const { toast } = useToast();

  /* ------------------------------------------------- FETCH CATEGORIES ------------------------------------------------- */
  const fetchProductCategories = async () => {
    try {
      const response = await axiosInstance.get("/categories");
      const categories = Array.isArray(response.data)
        ? response.data
        : response.data?.data || [];
      setProductCategories(categories);
    } catch (error) {
      console.error("Error fetching product categories:", error);
      toast({
        title: "Error",
        description: "Failed to fetch product categories.",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchProductCategories();
  }, []);

  /* ------------------------------------------------- DETAIL HELPERS ------------------------------------------------- */
  const addDetail = () => {
    setDetails((prev) => [
      ...prev,
      { text1: "", text2: "", product_category_ids: [], details_heading: "" },
    ]);
    setImages((prev) => [...prev, null]);
  };

  const removeDetail = (index) => {
    setDetails((prev) => prev.filter((_, i) => i !== index));
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const updateDetail = (index, field, value) => {
    const newDetails = [...details];
    newDetails[index] = { ...newDetails[index], [field]: value };
    setDetails(newDetails);
  };

  /* ------------------------------------------------- IMAGE COMPRESSION HANDLER ------------------------------------------------- */
  const handleImageChange = async (index, file) => {
    if (!file) {
      const newImages = [...images];
      newImages[index] = null;
      setImages(newImages);
      return;
    }

    toast({
      title: "Compressing image...",
      description: `Processing ${file.name}`,
    });

    try {
      const options = {
        maxSizeMB: 0.03,             // Target ≤30KB
        maxWidthOrHeight: 1024,
        useWebWorker: true,
        fileType: "image/jpeg",
        initialQuality: 0.8,
      };

      let compressedFile = await imageCompression(file, options);

      // Extra safety: if still >30KB, reduce quality further
      while (compressedFile.size > 30 * 1024 && options.initialQuality > 0.3) {
        options.initialQuality -= 0.1;
        compressedFile = await imageCompression(file, options);
      }

      // Preserve original name but force .jpg
      const finalFile = new File(
        [compressedFile],
        file.name.replace(/\.[^/.]+$/, ".jpg"),
        {
          type: "image/jpeg",
          lastModified: Date.now(),
        }
      );

      const newImages = [...images];
      newImages[index] = finalFile;
      setImages(newImages);

      toast({
        title: "Image ready!",
        description: `${finalFile.name} → ${(finalFile.size / 1024).toFixed(1)} KB`,
      });
    } catch (error) {
      console.error("Image compression failed:", error);
      toast({
        title: "Compression failed",
        description: "Using original image",
        variant: "destructive",
      });

      // Fallback to original
      const newImages = [...images];
      newImages[index] = file;
      setImages(newImages);
    }
  };

  const resetForm = () => {
    setHeading("");
    setKey("");
    setDiscount("");
    setPrice("");
    setDetails([{ text1: "", text2: "", product_category_ids: [], details_heading: "" }]);
    setImages([null]);
  };

  /* ------------------------------------------------- SUBMIT ------------------------------------------------- */
  const handleSubmit = async () => {
    if (!key.trim()) {
      toast({ title: "Error", description: "Key is required.", variant: "destructive" });
      return;
    }

    const invalid = details.some(
      (d) =>
        !d.text1.trim() ||
        !d.text2.trim() ||
        d.product_category_ids.length === 0 ||
        !d.details_heading.trim()
    );
    if (invalid) {
      toast({
        title: "Error",
        description: "All detail fields are required (including categories and heading).",
        variant: "destructive",
      });
      return;
    }

    if (images.some((i) => !i)) {
      toast({
        title: "Error",
        description: "An image is required for each detail.",
        variant: "destructive",
      });
      return;
    }

    try {
      const formData = new FormData();

      formData.append("heading", heading.trim());
      formData.append("key", key.trim());
      formData.append("discount", discount);
      formData.append("price", price);

      const formattedDetails = details.map((d) => ({
        text1: d.text1.trim(),
        text2: d.text2.trim(),
        product_category_ids: d.product_category_ids.length
          ? d.product_category_ids.join(",") + ","
          : "",
        details_heading: d.details_heading.trim(),
      }));

      formData.append("details", JSON.stringify(formattedDetails));

      images.forEach((img, idx) => {
        if (img) formData.append(`image${idx}`, img);
      });

      await axiosInstance.post("/offers", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      toast({ title: "Success", description: "Offer created successfully!" });
      resetForm();
      navigate("/offers");
    } catch (error) {
      console.error("Error submitting offer:", error);
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to create offer.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Create New Offer</h1>
          <p className="text-muted-foreground">Fill in the details to create a new offer</p>
        </div>
        <Button onClick={() => navigate("/offers")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Offers
        </Button>
      </div>

      {/* Form */}
      <div className="space-y-4 bg-white p-6 rounded-md shadow">
        {/* Heading & Key */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="heading">Heading</Label>
            <Input
              id="heading"
              value={heading}
              onChange={(e) => setHeading(e.target.value)}
              placeholder="Enter offer heading"
            />
          </div>
          <div>
            <Label htmlFor="key">Key <span className="text-red-500">*</span></Label>
            <Input
              id="key"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="Unique key (required)"
              required
            />
          </div>
        </div>

        {/* Discount & Price */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="discount">Discount (%)</Label>
            <Input
              id="discount"
              type="number"
              value={discount}
              onChange={(e) => setDiscount(e.target.value)}
              placeholder="e.g. 20"
            />
          </div>
          <div>
            <Label htmlFor="price">Price</Label>
            <Input
              id="price"
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="e.g. 999"
            />
          </div>
        </div>

        {/* Details */}
        {details.map((detail, index) => (
          <div key={index} className="border p-6 rounded-md space-y-4 bg-gray-50">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Detail {index + 1}</h3>
              {details.length > 1 && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => removeDetail(index)}
                >
                  <Trash2 className="h-4 w-4 mr-1" /> Remove
                </Button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Text 1 <span className="text-red-500">*</span></Label>
                <Input
                  value={detail.text1}
                  onChange={(e) => updateDetail(index, "text1", e.target.value)}
                  placeholder="e.g. Up to 50% Off"
                  required
                />
              </div>

              <div>
                <Label>Text 2 <span className="text-red-500">*</span></Label>
                <Input
                  value={detail.text2}
                  onChange={(e) => updateDetail(index, "text2", e.target.value)}
                  placeholder="e.g. On Fashion & Beauty"
                  required
                />
              </div>

              <div>
                <Label>Details Heading <span className="text-red-500">*</span></Label>
                <Input
                  value={detail.details_heading}
                  onChange={(e) => updateDetail(index, "details_heading", e.target.value)}
                  placeholder="e.g. Mega Sale"
                  required
                />
              </div>

              <div>
                <Label>Product Categories <span className="text-red-500">*</span></Label>
                <Select
                  isMulti
                  options={productCategories.map((c) => ({
                    value: c.id,
                    label: c.name,
                  }))}
                  value={detail.product_category_ids
                    .map((id) => {
                      const cat = productCategories.find((c) => c.id === id);
                      return cat ? { value: id, label: cat.name } : null;
                    })
                    .filter(Boolean)}
                  onChange={(selected) =>
                    updateDetail(
                      index,
                      "product_category_ids",
                      selected.map((o) => o.value)
                    )
                  }
                  placeholder="Select categories"
                />
              </div>

              {/* Image Upload */}
              <div className="md:col-span-2">
                <Label>Image {index + 1} <span className="text-red-500">*</span></Label>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleImageChange(index, file);
                  }}
                />
                {images[index] && (
                  <p className="text-sm text-green-600 mt-2">
                    Ready: {images[index].name} → {(images[index].size / 1024).toFixed(1)} KB
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}

        {/* Add Detail Button */}
        <Button variant="outline" onClick={addDetail} className="w-full">
          <Plus className="mr-2 h-4 w-4" /> Add Another Detail
        </Button>

        {/* Submit / Cancel */}
        <div className="flex justify-end gap-4 pt-4">
          <Button variant="outline" onClick={() => navigate("/offers")}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>Create Offer</Button>
        </div>
      </div>
    </div>
  );
}