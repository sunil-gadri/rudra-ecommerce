import { useState } from "react";
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Users,
  Mail,
  Download,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const mockCustomerLists = [
  {
    id: 1,
    name: "VIP Customers",
    description: "High-value customers with premium status",
    customerCount: 145,
    status: "Active",
    lastUpdated: "2024-01-15",
    createdBy: "Sales Team",
    criteria: "Order value > $5000",
    type: "Dynamic",
  },
  {
    id: 2,
    name: "Newsletter Subscribers",
    description: "Customers opted in for marketing emails",
    customerCount: 2341,
    status: "Active",
    lastUpdated: "2024-01-14",
    createdBy: "Marketing Team",
    criteria: "Email opt-in = true",
    type: "Dynamic",
  },
  {
    id: 3,
    name: "Inactive Customers",
    description: "Customers with no orders in 90+ days",
    customerCount: 567,
    status: "Active",
    lastUpdated: "2024-01-13",
    createdBy: "Retention Team",
    criteria: "Last order > 90 days",
    type: "Dynamic",
  },
  {
    id: 4,
    name: "Beta Testers",
    description: "Customers participating in product testing",
    customerCount: 89,
    status: "Draft",
    lastUpdated: "2024-01-12",
    createdBy: "Product Team",
    criteria: "Manual selection",
    type: "Static",
  },
  {
    id: 5,
    name: "Regional - West Coast",
    description: "Customers from western US states",
    customerCount: 1234,
    status: "Active",
    lastUpdated: "2024-01-11",
    createdBy: "Regional Manager",
    criteria: "State in (CA, OR, WA, NV)",
    type: "Dynamic",
  },
];

export default function CustomerLists() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");

  const filteredLists = mockCustomerLists.filter((list) => {
    const matchesSearch =
      list.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      list.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter =
      filterType === "all" ||
      list.type.toLowerCase() === filterType.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (status) => {
    const variant = status === "Active" ? "default" : "secondary";
    return <Badge variant={variant}>{status}</Badge>;
  };

  const getTypeBadge = (type) => {
    const variant = type === "Dynamic" ? "default" : "outline";
    return <Badge variant={variant}>{type}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center py-2">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Customer Lists</h1>
          <p className="text-muted-foreground">
            Manage customer segments and targeted lists
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Create List
          </Button>
        </div>
      </div>

      <div className="w-full overflow-x-auto pt-1 pb-4">
        <div className="flex w-full gap-4">
          {/* Total Lists */}
          <Card className="flex-1 basis-0 flex flex-col items-center text-center p-6 hover:shadow-md transition-shadow">
            <Users className="h-6 w-6 text-muted-foreground mb-2" />
            <CardTitle className="text-md font-semibold text-gray-800">
              Total Lists
            </CardTitle>
            <CardContent className="flex flex-col items-center mt-2">
              <div className="text-3xl font-bold text-gray-900">
                {mockCustomerLists.length}
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                +2 from last month
              </p>
            </CardContent>
          </Card>

          {/* Total Customers */}
          <Card className="flex-1 basis-0 flex flex-col items-center text-center p-6 hover:shadow-md transition-shadow">
            <Mail className="h-6 w-6 text-muted-foreground mb-2" />
            <CardTitle className="text-md font-semibold text-gray-800">
              Total Customers
            </CardTitle>
            <CardContent className="flex flex-col items-center mt-2">
              <div className="text-3xl font-bold text-gray-900">
                {mockCustomerLists
                  .reduce((sum, list) => sum + list.customerCount, 0)
                  .toLocaleString()}
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Across all lists
              </p>
            </CardContent>
          </Card>

          {/* Active Lists */}
          <Card className="flex-1 basis-0 flex flex-col items-center text-center p-6 hover:shadow-md transition-shadow">
            <Users className="h-6 w-6 text-muted-foreground mb-2" />
            <CardTitle className="text-md font-semibold text-gray-800">
              Active Lists
            </CardTitle>
            <CardContent className="flex flex-col items-center mt-2">
              <div className="text-3xl font-bold text-gray-900">
                {
                  mockCustomerLists.filter((list) => list.status === "Active")
                    .length
                }
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Currently active
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex gap-4 items-center pb-1">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search customer lists..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="h-4 w-4" />
          Filters
        </Button>
      </div>

      <Card className="mt-2">
        <CardHeader>
          <CardTitle>Customer Lists ({filteredLists.length})</CardTitle>
        </CardHeader>
        <CardContent>
         <Table className="text-xs">
  <TableHeader>
    <TableRow>
      <TableHead className="text-xs">List Name</TableHead>
      <TableHead className="text-xs">Type</TableHead>
      <TableHead className="text-xs">Customers</TableHead>
      <TableHead className="text-xs">Status</TableHead>
      <TableHead className="text-xs">Criteria</TableHead>
      <TableHead className="text-xs">Last Updated</TableHead>
      <TableHead className="w-[50px] text-xs"></TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    {filteredLists.map((list) => (
      <TableRow key={list.id} className="text-xs">
        <TableCell className="text-xs">
          <div>
            <div className="font-medium text-foreground text-xs">
              {list.name}
            </div>
            <div className="text-xs text-muted-foreground">
              {list.description}
            </div>
          </div>
        </TableCell>
        <TableCell className="text-xs">{getTypeBadge(list.type)}</TableCell>
        <TableCell className="font-medium text-xs">
          {list.customerCount.toLocaleString()}
        </TableCell>
        <TableCell className="text-xs">{getStatusBadge(list.status)}</TableCell>
        <TableCell className="text-xs">
          <div className="text-xs text-muted-foreground max-w-[200px] truncate">
            {list.criteria}
          </div>
        </TableCell>
        <TableCell className="text-muted-foreground text-xs">
          {list.lastUpdated}
        </TableCell>
        <TableCell className="text-xs">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel className="text-xs">Actions</DropdownMenuLabel>
              <DropdownMenuItem className="gap-2 text-xs">
                <Eye className="h-4 w-4" />
                View Customers
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2 text-xs">
                <Edit className="h-4 w-4" />
                Edit List
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2 text-xs">
                <Download className="h-4 w-4" />
                Export List
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="gap-2 text-destructive text-xs">
                <Trash2 className="h-4 w-4" />
                Delete List
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </TableCell>
      </TableRow>
    ))}
  </TableBody>
</Table>
        </CardContent>
      </Card>
    </div>
  );
}
