import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import axiosInstance from "../utils/axios";
import { useParams } from "react-router-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function InvoiceView() {
    const { id } = useParams();
    const [invoice, setInvoice] = useState(null);

    // Fetch invoice details by ID
    useEffect(() => {
        const fetchInvoice = async () => {
            try {
                const response = await axiosInstance.get(`/invoices/${id}`);
                setInvoice(response.data);
            } catch (error) {
                console.error("Error fetching invoice:", error);
            }
        };
        fetchInvoice();
    }, [id]);

    const getInvoicePDF = () => {
        const url = `http://192.168.0.9:5000/invoices/${id}/download`;
        window.open(url, "_blank");
    };

    if (!invoice) {
        return <div className="text-center py-10">Loading invoice...</div>;
    }

    return (
        <div className="space-y-6 h-[100vh]">
            {/* Header */}
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold">Invoice #{invoice.invoice_number}</h1>
                <div className="flex gap-2">
                    <Button onClick={getInvoicePDF}>
                        <Download className="h-5 w-5 mr-2" />
                        Download Invoice
                    </Button>
                </div>
            </div>

            {/* Invoice Card */}
            <div className="flex justify-center bg-gray-100 py-12 px-4 ">
                <div className="bg-white w-full max-w-4xl shadow-lg border rounded-lg p-5 md:p-10">

                    {/* Header: Logo + Invoice Info */}
                    <div className="flex justify-between items-center mb-4">
                        <img alt="Logo" className="w-16 h-auto" src="/assets/logo-BQc1GkuT.png" />
                        <div className="text-right text-sm">
                            <span className="block font-bold">
                                Invoice - {invoice.invoice_number}
                            </span>
                            <span className="block">
                                Invoice Date: {new Date(invoice.invoice_date).toLocaleDateString()}
                            </span>
                            <span className="block">
                                Order ID: {invoice.order_id}
                            </span>
                        </div>
                    </div>

                    {/* From / To Section */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-sm pt-10">
                        <div>
                            <p>
                                <span className="font-bold">From:</span><br />
                                {invoice.billing_address.building}<br/>
                                {invoice.billing_address.street_address}<br />
                                {invoice.billing_address.city}, {invoice.billing_address.state}
                                {/* {invoice.billing_address.postal_code} */}
                                 {/* ,{invoice.billing_address.state}, {invoice.billing_address.country}<br /> */}
                                {/* Phone: {invoice.phone} */}
                            </p>
                        </div>
                        <div>
                            <p>
                                <span className="font-bold">To:</span><br />
                                {invoice.customer_name}<br />
                                {invoice.shipping_address.building}<br/>
                                {invoice.shipping_address.street_address}<br />
                                {/* {invoice.shipping_address.address_type} */}
                                {/* {invoice.billing_address.postal_code} */}
                                {invoice.shipping_address.city}, {invoice.shipping_address.state}
                                {/* {invoice.billing_address.country}<br /> */}
                                {/* Phone: {invoice.shipping_address.phone} */}
                            </p>
                        </div>
                    </div>

                    {/* Items Table */}
                    <div className="pt-10 overflow-x-auto">
                        <Table className="w-full text-sm md:text-base">
                            <TableHeader>
                                <TableRow className="">
                                    <TableHead className="px-4 py-2 text-left">Product</TableHead>
                                    <TableHead className="px-4 py-2 text-center">Qty.</TableHead>
                                    <TableHead className="px-4 py-2 text-center">Size Details</TableHead>
                                    <TableHead className="px-4 py-2 text-center">Color</TableHead>
                                    <TableHead className="px-4 py-2 text-right">Price</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {invoice.items.map((item, index) => (
                                    <TableRow key={item.order_item_id} className="">
                                        <TableCell className="px-4 py-2 ">{item.product_name}<br /></TableCell>
                                        <TableCell className="px-4 py-2 text-center">{item.quantity}</TableCell>
                                        <TableCell className="px-4 py-2 text-center">{item.category} <br/> {item.product_size}</TableCell>
                                        <TableCell className="px-4 py-2 text-center">{item.product_color}</TableCell>
                                        <TableCell className="px-4 py-2 text-right">{item.price}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>

                    {/* Summary */}
                    <div className="grid grid-cols-1 md:grid-cols-6 mt-10 mb-10">
                        <div className="md:col-span-6 md:col-start-4 p-5 md:p-2">
                            <div className="grid grid-cols-2 text-sm">
                                <div className="py-2">Base Price:</div>
                                <div className="py-2 text-right mr-[11px]">{invoice.base_price}</div>
                                <div className="py-2">Tax:</div>
                                <div className="py-2 text-right mr-[11px]">{invoice.tax}</div>
                                <div className="py-2">Discount:</div>
                                <div className="py-2 text-right mr-[11px]">{invoice.discount}</div>
                                <div className="py-2">Shipping:</div>
                                <div className="py-2 text-right mr-[11px]">{invoice.shipping_cost}</div>
                                <div className="py-2 font-bold">Total Amount:</div>
                                <div className="py-2 text-right mr-[11px] font-bold">{invoice.total_amount}</div>
                            </div>
                        </div>
                    </div>

                    {/* Payment Details */}
                    <div className="mt-6 text-sm text-neutral-700">
                        <p className="font-bold mb-1">PAYMENT DETAILS</p>
                        <p>Name of Bank</p>
                        <p>Account Number: 123456678</p>
                        {/* {invoice.payment_status} */}
                    </div>

                    {/* Terms and Condition */}
                    <div className="pt-8 text-sm text-neutral-700">
                        <p className="font-bold mb-1">Terms & Conditions</p>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text</p>
                        <p>It has roots in a piece of classical Latin literature from 45 BC, making it over.</p>
                        {/* {invoice.payment_status} */}
                    </div>
                </div>
            </div>
        </div>
    );
}
