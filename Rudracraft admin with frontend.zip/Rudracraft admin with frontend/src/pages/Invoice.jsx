import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Download, Filter, Eye, ChevronLeft, ChevronRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../utils/axios";

export default function Invoice() {
  const [invoices, setInvoices] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [pagination, setPagination] = useState({
    current_page: 1,
    total_pages: 1,
    limit: 10,
    total_invoices: 0,
  });

  const navigate = useNavigate();
  const { toast } = useToast();

  const fetchInvoices = async (page = 1, limit = 10, search = "") => {
    setIsLoading(true);
    try {
      const response = await axiosInstance.get(
        `/invoices?page=${page}&limit=${limit}&search=${encodeURIComponent(search)}`
      );

      const { data: invoicesData, pagination: pagData } = response.data;

      const formatted = invoicesData.map((i) => ({
        id: i.invoice_id,
        invoice_number: i.invoice_number,
        customer_name: i.customer_name,
        email: i.email,
        phone: i.phone,
        invoice_date: i.invoice_date,
        order_status: i.order_status
          ? i.order_status.charAt(0).toUpperCase() + i.order_status.slice(1).toLowerCase()
          : "Unknown",
        payment_status: i.payment_status
          ? i.payment_status.charAt(0).toUpperCase() + i.payment_status.slice(1).toLowerCase()
          : "Unknown",
        total_amount: Number(i.total_amount) || 0,
      }));

      setInvoices(formatted);
      setPagination({
        current_page: pagData.page || 1,
        total_pages: pagData.total_pages || 1,
        limit: pagData.limit || 10,
        total_invoices: pagData.total || invoicesData.length,
      });
    } catch (error) {
      console.error("Error fetching invoices:", error);
      toast({
        title: "Error",
        description: "Failed to fetch invoices.",
        variant: "destructive",
      });
      setInvoices([]);
      setPagination({
        current_page: 1,
        total_pages: 1,
        limit: 10,
        total_invoices: 0,
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    setPagination((prev) => ({ ...prev, current_page: 1 }));
    fetchInvoices(1, pagination.limit, searchTerm);
  }, [searchTerm]);

  useEffect(() => {
    fetchInvoices(pagination.current_page, pagination.limit, searchTerm);
  }, [pagination.current_page]);

  const handleView = (id) => {
    navigate(`/admin/invoices/view/${id}`);
  };

  const getVisiblePages = () => {
    const { current_page, total_pages } = pagination;
    const pages = [];

    if (total_pages <= 5) {
      for (let i = 1; i <= total_pages; i++) pages.push(i);
    } else {
      pages.push(1);

      if (current_page > 3) pages.push("...");

      const start = Math.max(2, current_page - 1);
      const end = Math.min(total_pages - 1, current_page + 1);

      for (let i = start; i <= end; i++) pages.push(i);

      if (current_page < total_pages - 2) pages.push("...");
      pages.push(total_pages);
    }

    return pages;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Invoices</h1>
          <p className="text-muted-foreground">Manage your invoices</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Invoices ({pagination.total_invoices})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search invoices..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="w-full overflow-x-auto">
            <div className="border rounded-md">
              <div className="max-h-[600px] overflow-y-auto overflow-x-auto">
                <table className="table-fixed min-w-[150%] border-collapse w-full text-xs">
                  <thead className="sticky top-0 z-30 bg-gray-50">
                    <tr className="text-gray-700 text-center text-xs">
                      <th className="w-[5%] sticky left-0 bg-gray-50 z-20 border-b py-2 px-1 text-xs">
                        S.No
                      </th>
                      <th className="w-[12%] border-b py-2 px-1 text-xs">Invoice Number</th>
                      <th className="w-[12%] border-b py-2 px-1 text-xs">Customer Name</th>
                      <th className="w-[20%] border-b py-2 px-1 text-xs">Email</th>
                      <th className="w-[12%] border-b py-2 px-1 text-xs">Phone Number</th>
                      <th className="w-[12%] border-b py-2 px-1 text-xs">Invoice Date</th>
                      <th className="w-[10%] border-b py-2 px-1 text-xs">Order Status</th>
                      <th className="w-[10%] border-b py-2 px-1 text-xs">Payment Status</th>
                      <th className="w-[10%] border-b py-2 px-1 text-xs">Total Amount</th>
                      <th className="w-[7%] border-b py-2 px-1 text-xs">View</th>
                    </tr>
                  </thead>
                  <tbody>
                    {isLoading ? (
                      <tr>
                        <td colSpan={10} className="text-center py-10 text-gray-500">
                          Loading...
                        </td>
                      </tr>
                    ) : invoices.length > 0 ? (
                      invoices.map((item, index) => (
                        <tr
                          key={item.id}
                          className="hover:bg-gray-50 transition duration-150 text-center text-xs"
                        >
                          <td className="sticky left-0 bg-white z-10 font-medium text-muted-foreground border-b py-2 px-1 text-xs">
                            {(pagination.current_page - 1) * pagination.limit + index + 1}
                          </td>
                          <td className="border-b py-2 px-1 text-xs">
                            <span className="font-medium text-gray-800">
                              {item.invoice_number}
                            </span>
                          </td>
                          <td className="border-b py-2 px-1 text-xs">{item.customer_name}</td>
                          <td className="border-b py-2 px-1 text-xs">{item.email}</td>
                          <td className="border-b py-2 px-1 text-xs">{item.phone}</td>
                          <td className="border-b py-2 px-1 text-xs">
                            {item.invoice_date
                              ? new Date(item.invoice_date).toLocaleDateString("en-GB", {
                                  day: "2-digit",
                                  month: "short",
                                  year: "numeric",
                                })
                              : "-"}
                          </td>
                          <td className="border-b py-2 px-1 text-xs">{item.order_status}</td>
                          <td className="border-b py-2 px-1 text-xs">{item.payment_status}</td>
                          <td className="border-b py-2 px-1 text-xs">
                            ${item.total_amount.toLocaleString()}
                          </td>
                          <td className="border-b py-2 px-1 text-xs">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleView(item.id)}
                              className="text-xs h-7 px-2"
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          colSpan={10}
                          className="text-center py-4 text-gray-500 border-b text-xs"
                        >
                          No invoices found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Clean Pagination - max 3 numbers visible */}
          {pagination.total_pages > 1 && (
            <div className="flex flex-wrap justify-end items-center gap-2 mt-4">
              <Button
                variant="outline"
                size="sm"
                disabled={pagination.current_page === 1 || isLoading}
                onClick={() =>
                  setPagination((prev) => ({
                    ...prev,
                    current_page: prev.current_page - 1,
                  }))
                }
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Prev
              </Button>

              {getVisiblePages().map((page, idx) => (
                <Button
                  key={idx}
                  variant={page === pagination.current_page ? "default" : "outline"}
                  size="sm"
                  disabled={page === "..." || isLoading}
                  onClick={() => {
                    if (typeof page === "number") {
                      setPagination((prev) => ({ ...prev, current_page: page }));
                    }
                  }}
                  className={page === "..." ? "cursor-default bg-transparent border-none hover:bg-transparent" : ""}
                >
                  {page}
                </Button>
              ))}

              <Button
                variant="outline"
                size="sm"
                disabled={pagination.current_page === pagination.total_pages || isLoading}
                onClick={() =>
                  setPagination((prev) => ({
                    ...prev,
                    current_page: prev.current_page + 1,
                  }))
                }
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}