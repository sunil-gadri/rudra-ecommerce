import { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Brands() {
  const [brands, setBrands] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [formData, setFormData] = useState({
    manufacturer_id: "",
    brand_name: "",
  });
  const [editFormData, setEditFormData] = useState({
    manufacturer_id: "",
    brand_name: "",
  });
  const [editId, setEditId] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchBrands();
    fetchManufacturers();
  }, []);

  const fetchBrands = async () => {
    try {
      const res = await axiosInstance.get("/brands");
      setBrands(res.data);
    } catch (error) {
      console.error("Error fetching brands:", error);
    }
  };

  const fetchManufacturers = async () => {
    try {
      const res = await axiosInstance.get("/manufacturer");
      setManufacturers(res.data);
    } catch (error) {
      console.error("Error fetching manufacturers:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const { manufacturer_id, brand_name } = formData;

    if (!manufacturer_id || !brand_name.trim()) {
      return alert("Please fill all fields.");
    }

    const selectedManufacturer = manufacturers.find(
      (m) => m.id.toString() === manufacturer_id
    );

    if (!selectedManufacturer) {
      return alert("Selected manufacturer not found.");
    }

    const payload = new FormData();
    payload.append("manufacturer_name", selectedManufacturer.manufacturer_name);
    payload.append("brand_name", brand_name.trim());

    try {
      await axiosInstance.post("/brands", payload);
      setFormData({ manufacturer_id: "", brand_name: "" });
      fetchBrands();
    } catch (error) {
      console.error("Error saving brand:", error);
      alert("Failed to save brand.");
    }
  };

  const startEdit = (brand) => {
    const manufacturer = manufacturers.find(
      (m) => m.manufacturer_name === brand.manufacturer_name
    );

    setEditFormData({
      manufacturer_id: manufacturer ? manufacturer.id.toString() : "",
      brand_name: brand.brand_name || "",
    });
    setEditId(brand.id);
    setIsDialogOpen(true);
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();

    const { manufacturer_id, brand_name } = editFormData;

    if (!manufacturer_id || !brand_name.trim()) {
      return alert("Please fill all fields.");
    }

    const selectedManufacturer = manufacturers.find(
      (m) => m.id.toString() === manufacturer_id
    );

    if (!selectedManufacturer) {
      return alert("Selected manufacturer not found.");
    }

    const payload = new FormData();
    payload.append("manufacturer_name", selectedManufacturer.manufacturer_name);
    payload.append("brand_name", brand_name.trim());

    try {
      await axiosInstance.put(`/brands/${editId}`, payload);
      setIsDialogOpen(false);
      setEditId(null);
      fetchBrands();
    } catch (error) {
      console.error("Error updating brand:", error);
      alert("Failed to update brand.");
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this brand?")) return;
    try {
      await axiosInstance.delete(`/brands/${id}`);
      fetchBrands();
    } catch (error) {
      console.error("Error deleting brand:", error);
      alert("Failed to delete brand.");
    }
  };

  const filteredBrands = brands.filter((b) => {
    const term = searchTerm.toLowerCase();
    return (
      b.id?.toString().includes(term) ||
      b.brand_name.toLowerCase().includes(term) ||
      b.manufacturer_name.toLowerCase().includes(term)
    )
  });

  return (
    <div className="space-y-6">
      {/* Add Brand Form */}
      <form
        onSubmit={handleSubmit}
        className="space-y-6"
      >
        <div>
          <h1 className="text-3xl font-bold">Create Brand</h1>
          <p className="text-muted-foreground">
            Manage and link a brand to a manufacturer
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg border space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>Manufacturer</Label>
              <Select
                value={formData.manufacturer_id}
                onValueChange={(value) =>
                  setFormData({ ...formData, manufacturer_id: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select manufacturer" />
                </SelectTrigger>
                <SelectContent>
                  {manufacturers.map((m) => (
                    <SelectItem key={m.id} value={m.id.toString()}>
                      {m.manufacturer_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Brand Name</Label>
              <Input
                type="text"
                value={formData.brand_name}
                onChange={(e) => {
                  let value = e.target.value;
                  value = value.charAt(0).toUpperCase() + value.slice(1);
                  setFormData({ ...formData, brand_name: value });
                }}
                placeholder="Enter brand name"
                required
              />
            </div>
          </div>

          <Button type="submit">Save</Button>
        </div>
      </form>

      {/* Brand Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Brands</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search brands..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="border rounded-md">
  {/* Fixed Header */}
  <Table className="w-full table-fixed">
    <TableHeader>
      <TableRow className="bg-gray-50 text-gray-700 text-center sticky top-0 z-10">
        <TableHead className="text-center w-[20%]">ID</TableHead>
        <TableHead className="text-center w-[30%]">Manufacturer</TableHead>
        <TableHead className="text-center w-[30%]">Brand</TableHead>
        <TableHead className="text-center w-[22%]">Actions</TableHead>
      </TableRow>
    </TableHeader>
  </Table>

  {/* Scrollable Body */}
  <div className="max-h-96 overflow-y-auto overflow-x-auto">
    <Table className="w-full table-fixed">
      <TableBody>
        {filteredBrands.length > 0 ? (
          filteredBrands.map((b) => (
            <TableRow key={b.id}>
              <TableCell className="text-center align-middle font-medium text-muted-foreground w-[20%]">
                {b.id}
              </TableCell>
              <TableCell className="text-center align-middle w-[30%]">
                <div className="flex flex-col items-center">
                  <span className="font-medium text-gray-800">
                    {b.manufacturer_name}
                  </span>
                </div>
              </TableCell>
              <TableCell className="text-center align-middle w-[30%]">
                {b.brand_name}
              </TableCell>
              <TableCell className="text-center align-middle w-[20%]">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button size="icon" variant="ghost">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuItem onClick={() => startEdit(b)}>
                      <Edit className="w-4 h-4 mr-2" /> Edit
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={() => handleDelete(b.id)}
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4 mr-2" /> Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))
        ) : (
          <TableRow>
            <TableCell
              colSpan={4}
              className="text-center py-6 text-gray-500 w-full"
            >
              No brands found.
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  </div>
</div>
        </CardContent>
      </Card>

      {/* Edit Brand Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Brand</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div>
              <Label>Manufacturer</Label>
              <Select
                value={editFormData.manufacturer_id}
                onValueChange={(value) =>
                  setEditFormData({
                    ...editFormData,
                    manufacturer_id: value,
                  })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select manufacturer" />
                </SelectTrigger>
                <SelectContent>
                  {manufacturers.map((m) => (
                    <SelectItem key={m.id} value={m.id.toString()}>
                      {m.manufacturer_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Brand Name</Label>
              <Input
                type="text"
                value={editFormData.brand_name}
                onChange={(e) => {
                  let value = e.target.value;
                  // Capitalize first letter
                  value = value.charAt(0).toUpperCase() + value.slice(1);
                  setEditFormData({
                    ...editFormData,
                    brand_name: value,
                  });
                }}
                required
              />
            </div>
            <DialogFooter className="pt-4">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Update Brand</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
