import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Tag, Calendar, Zap, DollarSign, Check } from "lucide-react";
import axiosInstance from "../utils/axios";
import { toast } from "sonner";

export default function EditCoupon() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [couponStatus, setCouponStatus] = useState("active");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [couponCode, setCouponCode] = useState("");
  const [couponTitle, setCouponTitle] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [couponType, setCouponType] = useState("");
  const [discountValue, setDiscountValue] = useState("");
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(true);

  const inputClasses = `
    w-full px-5 py-3.5 rounded-xl border border-gray-300 
    bg-white text-gray-900 placeholder-gray-400 
    focus:outline-none focus:ring-2 focus:ring-orange-500/30 
    focus:border-orange-500 transition-all duration-200
    shadow-sm hover:border-gray-400
  `;

  const labelClasses = "block text-sm font-semibold text-gray-700 mb-2.5";

  const sectionClasses = 
    "bg-white p-7 rounded-2xl border border-gray-200 shadow-sm";

  const iconClasses = "text-orange-600";

  useEffect(() => {
    const fetchCoupon = async () => {
      try {
        const res = await axiosInstance.get(`coupon/${id}`);
        const c = res.data;
        const formatDate = (d) => new Date(d).toISOString().split("T")[0];

        setCouponStatus(c.status);
        setStartDate(formatDate(c.start_date));
        setEndDate(formatDate(c.end_date));
        setCouponCode(c.coupon_code);
        setCouponTitle(c.coupon_title);
        setMinPrice(c.min_price);
        setMaxPrice(c.max_price);
        setCouponType(c.coupon_type);
        setDiscountValue(c.discount_value);
      } catch {
        toast.error("Failed to load coupon");
      } finally {
        setLoading(false);
      }
    };
    fetchCoupon();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!startDate) newErrors.startDate = "Start date is required";
    if (!endDate) newErrors.endDate = "End date is required";
    if (!couponTitle) newErrors.couponTitle = "Coupon title is required";
    if (!minPrice) newErrors.minPrice = "Minimum price is required";
    if (!couponType) newErrors.couponType = "Select a coupon type";
    if (!discountValue) newErrors.discountValue = "Discount value is required";
    if (startDate && endDate) {
      if (new Date(endDate) <= new Date(startDate)) {
        newErrors.endDate = "End date must be after start date";
      }
    }
    if (minPrice && maxPrice) {
      if (Number(maxPrice) < Number(minPrice)) {
        newErrors.maxPrice =
          "Maximum price cannot be less than minimum price";
      }
    }
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) {
      Object.values(newErrors).forEach((m) => toast.error(m));
      return;
    }
    try {
      const payload = {
        status: couponStatus,
        start_date: startDate,
        end_date: endDate,
        coupon_code:couponCode,
        coupon_title: couponTitle,
        min_price: minPrice,
        max_price: maxPrice,
        coupon_type: couponType,
        discount_value: discountValue,
      };
      await axiosInstance.put(`coupon/${id}`, payload, {
        headers: { "Content-Type": "application/json" },
      });
      toast.success("Coupon updated successfully");
      navigate("/admin/coupon");
    } catch {
      toast.error("Failed to update coupon");
    }
  };

  if (loading) return <div className="p-10 text-center text-xl">Loading coupon data...</div>;

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      {/* HEADER */}
      <div className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-7 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Edit Coupon</h1>
            <p className="text-gray-500 mt-1">Update coupon details</p>
          </div>
          <button
            onClick={() => navigate("/admin/coupon")}
            className="flex items-center gap-2 px-5 py-2.5 
                     bg-gray-100 hover:bg-gray-200 
                     rounded-xl font-medium text-gray-700 transition-colors"
          >
            <ArrowLeft size={18} /> All Coupons
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* LEFT COLUMN - Main content */}
          <div className="lg:col-span-2 space-y-8">
            {/* STATUS */}
            <div className={sectionClasses}>
              <h2 className="flex items-center gap-3 font-semibold text-lg mb-5">
                <Zap className={iconClasses} size={22} /> Coupon Status
              </h2>
              <div className="flex gap-10">
                {["active", "inactive"].map((s) => (
                  <label
                    key={s}
                    className="flex items-center gap-3 cursor-pointer select-none"
                  >
                    <input
                      type="radio"
                      checked={couponStatus === s}
                      onChange={() => setCouponStatus(s)}
                      className="w-5 h-5 accent-orange-500"
                    />
                    <span className="capitalize font-medium">{s}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* DATES */}
            <div className={sectionClasses}>
              <h2 className="flex items-center gap-3 font-semibold text-lg mb-5">
                <Calendar className={iconClasses} size={22} /> Schedule Dates
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className={labelClasses}>Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className={inputClasses}
                  />
                </div>
                <div>
                  <label className={labelClasses}>End Date</label>
                  <input
                    type="date"
                    value={endDate}
                    min={startDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className={inputClasses}
                  />
                </div>
              </div>
            </div>

            {/* DETAILS */}
            <div className={sectionClasses}>
              <h2 className="flex items-center gap-3 font-semibold text-lg mb-5">
                <Tag className={iconClasses} size={22} /> Coupon Details
              </h2>

              <div className="space-y-6">
                <div>
                  <label className={labelClasses}>Coupon Code</label>
                  <input
                    value={couponCode}
                    onChange={(e)=>setCouponCode(e.target.value)  }
                    className={`${inputClasses} bg-gray-50 text-gray-500`}
                  />
                </div>

                <div>
                  <label className={labelClasses}>Coupon Title</label>
                  <input
                    value={couponTitle}
                    onChange={(e) => setCouponTitle(e.target.value)}
                    className={inputClasses}
                    placeholder="Enter coupon title"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN - Sidebar */}
          <div className="space-y-8">
            {/* PRICE */}
            <div className={sectionClasses}>
              <h2 className="flex items-center gap-3 font-semibold text-lg mb-5">
                <DollarSign className={iconClasses} size={22} /> Price Range
              </h2>
              <div className="space-y-6">
                <div>
                  <label className={labelClasses}>Minimum Price</label>
                  <input
                    type="number"
                    placeholder="0"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                    className={inputClasses}
                  />
                </div>
                <div>
                  <label className={labelClasses}>Maximum Price (optional)</label>
                  <input
                    type="number"
                    placeholder="No limit"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                    className={inputClasses}
                  />
                </div>
              </div>
            </div>

            {/* DISCOUNT TYPE */}
            <div className={sectionClasses}>
              <h2 className="font-semibold text-lg mb-5">Discount Type</h2>
              <div className="space-y-4">
                {["percentage", "fixed"].map((t) => (
                  <label
                    key={t}
                    className="flex items-center gap-3 cursor-pointer select-none"
                  >
                    <input
                      type="radio"
                      value={t}
                      checked={couponType === t}
                      onChange={(e) => setCouponType(e.target.value)}
                      className="w-5 h-5 accent-orange-500"
                    />
                    <span className="font-medium">
                      {t === "percentage" ? "Percentage (%)" : "Fixed Amount (₹)"}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* DISCOUNT VALUE */}
            {couponType && (
              <div className={sectionClasses}>
                <h2 className="font-semibold text-lg mb-5">Discount Value</h2>
                <div className="relative">
                  <input
                    type="number"
                    value={discountValue}
                    onChange={(e) => setDiscountValue(e.target.value)}
                    className={inputClasses}
                    placeholder="Enter value"
                    min="0"
                  />
                  <span className="absolute right-5 top-1/2 -translate-y-1/2 text-gray-500 font-medium">
                    {couponType === "percentage" ? "%" : "₹"}
                  </span>
                </div>
              </div>
            )}

            {/* SUBMIT BUTTON */}
            <button
              onClick={handleSubmit}
              className="w-full py-4 rounded-xl bg-orange-600 hover:bg-orange-700 
                       text-white font-medium text-lg shadow-md 
                       transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Check size={22} /> Update Coupon
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}