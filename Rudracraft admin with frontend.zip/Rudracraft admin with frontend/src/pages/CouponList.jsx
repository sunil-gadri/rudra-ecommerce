import React, { useEffect, useState } from 'react';
import { ChevronDown, Search, Plus, MoreHorizontal, Edit2, Trash2 } from 'lucide-react';
import axiosInstance from '../utils/axios';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const DropdownMenu = ({ coupon, onEdit, onDelete }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-600 hover:text-gray-900"
      >
        <MoreHorizontal className="w-4 h-4" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-40 bg-white border border-gray-200 rounded-lg shadow-md z-50">
          <button
            onClick={() => {
              onEdit(coupon);
              setIsOpen(false);
            }}
            className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
          >
            <Edit2 className="w-4 h-4" /> Edit
          </button>

          <button
            onClick={() => {
              onDelete(coupon);
              setIsOpen(false);
            }}
            className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
          >
            <Trash2 className="w-4 h-4" /> Delete
          </button>
        </div>
      )}
    </div>
  );
};

export default function CouponList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMonth, setFilterMonth] = useState('This Month');
  const [coupons, setCoupons] = useState([]);
  const [deleteCoupon, setDeleteCoupon] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCoupons = async () => {
      try {
        const response = await axiosInstance.get('coupon');
        setCoupons(response.data);
      } catch (error) {
        console.error('Error fetching coupons:', error);
      }
    };
    fetchCoupons();
  }, []);

  const formatDate = (dateString) => {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return date.toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour12: true
    });
  };

  const filteredCoupons = coupons.filter((coupon) =>
    coupon.coupon_code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleEditCoupon = (coupon) => {
    navigate(`/admin/edit-coupon/${coupon.id}`);
  };

  const handleDeleteCoupon = (coupon) => {
    setDeleteCoupon(coupon);
  };

  const confirmDelete = async () => {
    try {
      await axiosInstance.delete(`coupon/${deleteCoupon.id}`);
      setCoupons((prev) => prev.filter((c) => c.id !== deleteCoupon.id));
      toast.success(`Coupon "${deleteCoupon.coupon_title}" deleted successfully`);
      setDeleteCoupon(null);
    } catch (error) {
      console.error("Error deleting coupon:", error);
      toast.error("Failed to delete coupon. Please try again.");
    }
  };

  return (
    <div className="space-y-6 relative">
      {/* Header Section - unchanged */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">All Coupon List</h1>
          <p className="text-gray-500">Manage and track all coupons</p>
        </div>
        <button className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg flex items-center gap-2">
          <Plus className="w-5 h-5" /> 
          <a href="/admin/coupon/create"> Create Coupon </a>
        </button>
      </div>

      {/* Stats Cards - unchanged */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-6 border">
          <h6 className="text-sm font-medium text-gray-600 mb-1">Total Coupons</h6>
          <p className="text-2xl font-bold">{coupons.length}</p>
        </div>
        <div className="bg-white rounded-lg p-6 border">
          <h6 className="text-sm font-medium text-gray-600 mb-1">Active Coupons</h6>
          <p className="text-2xl font-bold">{coupons.filter((c) => c.status === 'active').length}</p>
        </div>
        <div className="bg-white rounded-lg p-6 border">
          <h6 className="text-sm font-medium text-gray-600 mb-1">Inactive Coupons</h6>
          <p className="text-2xl font-bold">{coupons.filter((c) => c.status !== 'active').length}</p>
        </div>
        <div className="bg-white rounded-lg p-6 border">
          <h6 className="text-sm font-medium text-gray-600 mb-1">This Month</h6>
          <p className="text-2xl font-bold">{coupons.length}</p>
        </div>
      </div>

      {/* Modern Table Design - ONLY THIS PART CHANGED */}
      <div className="border rounded-lg shadow-sm overflow-hidden">
        {/* Search & Filter - kept original structure */}
        <div className="p-6 border-b">
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <div className="relative max-w-sm w-full">
              <Search className="absolute left-3 top-2.5 text-gray-400 h-4 w-4" />
              <input
                placeholder="Search by coupon code..."
                className="pl-10 w-full px-4 py-2 border rounded-lg"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="relative">
              <select
                value={filterMonth}
                onChange={(e) => setFilterMonth(e.target.value)}
                className="px-4 py-2 border rounded-lg"
              >
                <option>This Month</option>
                <option>Last Month</option>
                <option>Last 3 Months</option>
                <option>This Year</option>
              </select>
              <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
            </div>
          </div>
        </div>

        {/* New Table Style */}
        <div className="max-h-[500px] overflow-y-auto overflow-x-auto">
          <table className="w-full table-fixed border-collapse">
            <thead className="sticky top-0 z-20 bg-gray-100">
              <tr className="text-gray-700 text-xs font-semibold">
                <th className="w-[6%] py-3 px-3 text-center">ID</th>
                <th className="w-[18%] py-3 px-3 text-left">Title</th>
                <th className="w-[10%] py-3 px-3 text-center">Type</th>
                <th className="w-[14%] py-3 px-3 text-center">Min–Max Price</th>
                <th className="w-[10%] py-3 px-3 text-center">Discount</th>
                <th className="w-[12%] py-3 px-3 text-center">Code</th>
                <th className="w-[14%] py-3 px-3 text-center">Start Date</th>
                <th className="w-[14%] py-3 px-3 text-center">End Date</th>
                <th className="w-[10%] py-3 px-3 text-center">Status</th>
                <th className="w-[8%] py-3 px-3 text-center">Action</th>
              </tr>
            </thead>

            <tbody>
              {filteredCoupons.length > 0 ? (
                filteredCoupons.map((coupon) => (
                  <tr
                    key={coupon.id}
                    className="hover:bg-gray-50 transition duration-150 border-b last:border-0 text-xs"
                  >
                    <td className="text-center py-3 px-3 font-medium text-gray-600">
                      {coupon.id}
                    </td>
                    <td className="py-3 px-3 font-medium text-gray-800">
                      {coupon.coupon_title}
                    </td>
                    <td className="text-center py-3 px-3 text-gray-700 capitalize">
                      {coupon.coupon_type}
                    </td>
                    <td className="text-center py-3 px-3 text-gray-700">
                      ₹{coupon.min_price} - ₹{coupon.max_price}
                    </td>
                    <td className="text-center py-3 px-3 font-medium">
                      {coupon.coupon_type === 'percentage'
                        ? `${coupon.discount_value}%`
                        : coupon.coupon_type === 'fixed'
                        ? `₹${coupon.discount_value}`
                        : '-'}
                    </td>
                    <td className="text-center py-3 px-3 font-mono text-gray-700">
                      {coupon.coupon_code}
                    </td>
                    <td className="text-center py-3 px-3 text-gray-600">
                      {formatDate(coupon.start_date)}
                    </td>
                    <td className="text-center py-3 px-3 text-gray-600">
                      {formatDate(coupon.end_date)}
                    </td>
                    <td className="text-center py-3 px-3">
                      {coupon.status === 'active' ? (
                        <span className="bg-green-100 text-green-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">
                          Active
                        </span>
                      ) : (
                        <span className="bg-red-100 text-red-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">
                          Inactive
                        </span>
                      )}
                    </td>
                    <td className="text-center py-3 px-3">
                      <DropdownMenu
                        coupon={coupon}
                        onEdit={handleEditCoupon}
                        onDelete={handleDeleteCoupon}
                      />
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="10" className="text-center py-12 text-gray-500">
                    No coupons found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Modal - unchanged */}
      {deleteCoupon && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-md p-6 w-96">
            <h2 className="text-lg font-semibold mb-4">Confirm Delete</h2>
            <p className="mb-6 text-gray-700">
              Are you sure you want to delete <span className="font-bold">{deleteCoupon.coupon_title}</span>?
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setDeleteCoupon(null)}
                className="px-4 py-2 rounded-lg border text-gray-700 hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}