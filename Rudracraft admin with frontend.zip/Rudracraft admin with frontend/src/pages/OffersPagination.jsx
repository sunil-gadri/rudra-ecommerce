import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Edit, Trash2, Plus, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Offers() {
  const [offers, setOffers] = useState([]);
  const [productCategories, setProductCategories] = useState([]);
  const [imageViewerOpen, setImageViewerOpen] = useState(false);
  const [imageViewerImages, setImageViewerImages] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [pagination, setPagination] = useState({
    current_page: 1,
    total_pages: 1,   
    limit: 10,
    total_offers: 0,
  });

  const navigate = useNavigate();
  const { toast } = useToast();
  const IMAGE_BASE_URL = "http://192.168.0.9:5000";

  const fetchProductCategories = async () => {
    try {
      const response = await axiosInstance.get("/categories");
      console.log("Product categories response:", response);
      const categories = response.data?.success
        ? response.data.data
        : Array.isArray(response.data)
        ? response.data
        : [];
      setProductCategories(categories);
    } catch (error) {
      console.error("Error fetching product categories:", error);
      toast({
        title: "Error",
        description: "Failed to fetch product categories.",
        variant: "destructive",
      });
    }
  };

  const fetchOffers = async (page = 1, limit = 10, search = "") => {
    try {
      const response = await axiosInstance.get(`/offers?page=${page}&limit=${limit}&search=${encodeURIComponent(search)}`);
      console.log("Offers API response:", response.data);
      const { offers, pagination } = response.data;

      const formatted = offers.map((o) => ({
        id: o.id,
        heading: o.heading,
        key: o.key,
        details: o.details || [],
        status: o.status ? o.status.charAt(0).toUpperCase() + o.status.slice(1).toLowerCase() : "Active",
      }));

      setOffers(formatted);
      setPagination({
        current_page: pagination.page || 1,
        total_pages: pagination.total_pages || 1,
        limit: pagination.limit || 10,
        total_offers: pagination.total_items || offers.length,
      });
    } catch (error) {
      console.error("Error fetching offers:", error);
      toast({
        title: "Error",
        description: "Failed to fetch offers.",
        variant: "destructive",
      });
      setOffers([]);
      setPagination({
        current_page: 1,
        total_pages: 1,
        limit: 10,
        total_offers: 0,
      });
    }
  };

  useEffect(() => {
    fetchProductCategories();
    fetchOffers(pagination.current_page, pagination.limit, searchTerm);
  }, [pagination.current_page, searchTerm]);

  const handleDeleteOffer = async (offerId) => {
    if (!window.confirm("Are you sure you want to delete this offer?")) return;
    try {
      const response = await axiosInstance.delete(`/offers/${offerId}`);
      if (response.data.success) {
        toast({
          title: "Success",
          description: "Offer deleted successfully.",
        });
        await fetchOffers(pagination.current_page, pagination.limit, searchTerm);
      } else {
        toast({
          title: "Error",
          description: response.data.message || "Failed to delete offer.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error deleting offer:", error);
      toast({
        title: "Error",
        description: error.response?.data?.message || "An error occurred while deleting the offer.",
        variant: "destructive",
      });
    }
  };

  // Get image URL
  const getImageUrl = (path) => {
    if (!path) return "";
    return path.startsWith("http") ? path : `${IMAGE_BASE_URL}${path}`;
  };

  // Get status badge
  const getStatusBadge = (status) => {
    if (status.toLowerCase() === "inactive") {
      return <Badge variant="destructive">Inactive</Badge>;
    }
    return <Badge variant="default" className="bg-green-500 text-white">Active</Badge>;
  };

  // Get category names from IDs
  const getCategoryNames = (categories) => {
    if (!categories || !Array.isArray(categories)) return "";
    return categories.join(", ");
  };

  // Get images from details array
  const getOfferImages = (details) => {
    return (details || [])
      .filter((detail) => detail.image_url)
      .map((detail) => detail.image_url);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Offers</h1>
          <p className="text-muted-foreground">Manage your offers here</p>
        </div>
        <Button onClick={() => navigate("/admin/offers/create")}>
          <Plus className="mr-2 h-4 w-4" />
          Add Offer
        </Button>
      </div>

      <Card className="w-full">
        <CardHeader>
          <CardTitle>Offer Information ({pagination.total_offers})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search offers..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="border rounded-md">
            <div className="max-h-[600px] overflow-y-auto overflow-x-auto">
              <table className="table-fixed min-w-[110%] border-collapse w-full">
                <thead className="sticky top-0 z-30 bg-gray-50">
                  <tr className="text-gray-700 text-center">
                    <th className="w-[8%] sticky left-0 bg-gray-50 z-20 border-b py-3">ID</th>
                    <th className="w-[20%] border-b py-3">Heading</th>
                    <th className="w-[30%] border-b py-3">Details</th>
                    <th className="w-[15%] border-b py-3">Key</th>
                    <th className="w-[15%] border-b py-3">Images</th>
                    <th className="w-[12%] border-b py-3">Status</th>
                    <th className="w-[12%] border-b py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {offers.length > 0 ? (
                    offers.map((offer) => (
                      <tr
                        key={offer.id}
                        className="hover:bg-gray-50 transition duration-150 text-center"
                      >
                        <td className="sticky left-0 bg-white z-10 font-medium text-muted-foreground border-b py-3">
                          {offer.id}
                        </td>
                        <td className="text-gray-800 font-medium border-b py-3">
                          {offer.heading}
                        </td>
                        <td className="border-b py-3 text-gray-700">
                          {offer.details?.length ? (
                            <div className="flex flex-col gap-1">
                              {offer.details.map((detail, i) => (
                                <div key={i} className="text-sm">
                                  {detail.text1} {detail.text2 && `- ${detail.text2}`}{" "}
                                  <span className="text-gray-500">
                                    ({getCategoryNames(detail.categories)})
                                  </span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            "No details"
                          )}
                        </td>
                        <td className="border-b py-3">{offer.key}</td>
                        <td className="border-b py-3">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setImageViewerImages(getOfferImages(offer.details));
                              setImageViewerOpen(true);
                            }}
                          >
                            View ({getOfferImages(offer.details).length})
                          </Button>
                        </td>
                        <td className="border-b py-3">{getStatusBadge(offer.status)}</td>
                        <td className="border-b py-3">
                          <div className="flex justify-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => navigate(`/offers/edit/${offer.id}`)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteOffer(offer.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="text-center py-6 text-gray-500">
                        No offers found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pagination Controls */}
          <div className="flex justify-end items-center gap-2 mt-4">
            <Button
              variant="outline"
              disabled={pagination.current_page === 1}
              onClick={() =>
                setPagination((prev) => ({
                  ...prev,
                  current_page: prev.current_page - 1,
                }))
              }
            >
              Previous
            </Button>
            {Array.from({ length: pagination.total_pages }, (_, i) => i + 1).map(
              (pageNum) => (
                <Button
                  key={pageNum}
                  variant={pageNum === pagination.current_page ? "default" : "outline"}
                  onClick={() =>
                    setPagination((prev) => ({
                      ...prev,
                      current_page: pageNum,
                    }))
                  }
                >
                  {pageNum}
                </Button>
              )
            )}
            <Button
              variant="outline"
              disabled={pagination.current_page === pagination.total_pages}
              onClick={() =>
                setPagination((prev) => ({
                  ...prev,
                  current_page: prev.current_page + 1,
                }))
              }
            >
              Next
            </Button>
          </div>

          {/* Image Viewer Dialog */}
          <Dialog open={imageViewerOpen} onOpenChange={setImageViewerOpen}>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>Offer Images</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {imageViewerImages.length ? (
                  imageViewerImages.map((src, i) => (
                    <img
                      key={i}
                      src={getImageUrl(src)}
                      alt={`Offer Image ${i + 1}`}
                      className="w-full h-48 object-contain rounded border"
                    />
                  ))
                ) : (
                  <p>No images available</p>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    </div>
  );
}