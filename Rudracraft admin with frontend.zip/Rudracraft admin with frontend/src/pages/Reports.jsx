import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Users, Package, ShoppingCart, Download, Calendar, FileText, BarChart3 } from "lucide-react";

const Reports = () => {
  const [timeRange, setTimeRange] = useState('7days');

  // Mock data for charts
  const salesData = [
    { name: 'Jan', sales: 4000, orders: 240, customers: 180 },
    { name: 'Feb', sales: 3000, orders: 198, customers: 150 },
    { name: 'Mar', sales: 2000, orders: 180, customers: 160 },
    { name: 'Apr', sales: 2780, orders: 208, customers: 140 },
    { name: 'May', sales: 1890, orders: 158, customers: 130 },
    { name: 'Jun', sales: 2390, orders: 180, customers: 170 },
    { name: 'Jul', sales: 3490, orders: 220, customers: 190 }
  ];

  const productData = [
    { name: 'Electronics', value: 400, color: '#0088FE' },
    { name: 'Clothing', value: 300, color: '#00C49F' },
    { name: 'Books', value: 200, color: '#FFBB28' },
    { name: 'Home & Garden', value: 150, color: '#FF8042' },
    { name: 'Sports', value: 100, color: '#8884D8' }
  ];

  const revenueData = [
    { month: 'Jan', revenue: 12000, profit: 3000 },
    { month: 'Feb', revenue: 15000, profit: 4500 },
    { month: 'Mar', revenue: 13000, profit: 3900 },
    { month: 'Apr', revenue: 17000, profit: 5100 },
    { month: 'May', revenue: 16000, profit: 4800 },
    { month: 'Jun', revenue: 19000, profit: 5700 }
  ];

  // Report templates
  const reportTemplates = [
    {
      id: 1,
      name: "Monthly Sales Report",
      description: "Comprehensive sales analysis for the current month",
      type: "Sales",
      lastGenerated: "2024-01-15"
    },
    {
      id: 2,
      name: "Customer Analytics",
      description: "Customer behavior and segmentation analysis",
      type: "Customer",
      lastGenerated: "2024-01-14"
    },
    {
      id: 3,
      name: "Product Performance",
      description: "Analysis of top-performing and underperforming products",
      type: "Product",
      lastGenerated: "2024-01-13"
    },
    {
      id: 4,
      name: "Financial Summary",
      description: "Revenue, expenses, and profit analysis",
      type: "Financial",
      lastGenerated: "2024-01-12"
    }
  ];

  return (
    <div className="space-y-6 text-xs">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reports & Analytics</h1>
          <p className="text-muted-foreground text-xs">
            Comprehensive business insights and reporting
          </p>
        </div>
        <div className="flex items-center space-x-2 gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40 text-xs">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days" className="text-xs">Last 7 days</SelectItem>
              <SelectItem value="30days" className="text-xs">Last 30 days</SelectItem>
              <SelectItem value="90days" className="text-xs">Last 90 days</SelectItem>
              <SelectItem value="1year" className="text-xs">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button className="text-xs">
            <Download className="h-4 w-4 mr-2" />
            Export All
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">$45,231.89</div>
            <p className="text-xs text-muted-foreground">
              +20.1% from last month
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium">Total Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">1,284</div>
            <p className="text-xs text-muted-foreground">
              +15.3% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium">New Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">234</div>
            <p className="text-xs text-muted-foreground">
              +8.7% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium">Products Sold</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">3,847</div>
            <p className="text-xs text-muted-foreground">
              +12.4% from last month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Analytics Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
          <TabsTrigger value="sales" className="text-xs">Sales Analytics</TabsTrigger>
          <TabsTrigger value="products" className="text-xs">Product Analysis</TabsTrigger>
          <TabsTrigger value="customers" className="text-xs">Customer Insights</TabsTrigger>
          <TabsTrigger value="reports" className="text-xs">Report Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-xs">Revenue Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip contentStyle={{ fontSize: '12px' }} />
                    <Line type="monotone" dataKey="revenue" stroke="#8884d8" strokeWidth={2} />
                    <Line type="monotone" dataKey="profit" stroke="#82ca9d" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xs">Sales by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={productData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {productData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ fontSize: '12px' }} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sales" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-xs">Sales Performance</CardTitle>
              <CardDescription className="text-xs">Monthly sales, orders, and customer acquisition</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={salesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip contentStyle={{ fontSize: '12px' }} />
                  <Bar dataKey="sales" fill="#8884d8" name="Sales ($)" />
                  <Bar dataKey="orders" fill="#82ca9d" name="Orders" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-xs">Top Products</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { name: "Wireless Headphones", sales: 145, revenue: "$14,500" },
                  { name: "Smart Watch", sales: 132, revenue: "$13,200" },
                  { name: "Laptop Stand", sales: 98, revenue: "$9,800" },
                  { name: "USB-C Cable", sales: 87, revenue: "$8,700" }
                ].map((product, index) => (
                  <div key={index} className="flex items-center justify-between text-xs">
                    <div>
                      <p className="font-medium text-xs">{product.name}</p>
                      <p className="text-xs text-muted-foreground">{product.sales} units sold</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-xs">{product.revenue}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xs">Product Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={productData} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" tick={{ fontSize: 12 }} />
                    <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12 }} />
                    <Tooltip contentStyle={{ fontSize: '12px' }} />
                    <Bar dataKey="value" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="customers" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-xs font-medium">Customer Lifetime Value</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold">$1,247</div>
                <p className="text-xs text-muted-foreground">Average per customer</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-xs font-medium">Repeat Customer Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold">68.4%</div>
                <p className="text-xs text-muted-foreground">Customers making repeat purchases</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-xs font-medium">Customer Acquisition Cost</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold">$45</div>
                <p className="text-xs text-muted-foreground">Average cost per acquisition</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {reportTemplates.map((report) => (
              <Card key={report.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xs">{report.name}</CardTitle>
                    <BarChart3 className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <CardDescription className="text-xs">{report.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Type: {report.type}</p>
                      <p className="text-xs text-muted-foreground">Last generated: {report.lastGenerated}</p>
                    </div>
                    <div className="space-x-2">
                      <Button variant="outline" size="sm" className="text-xs">
                        <FileText className="h-4 w-4 mr-2" />
                        View
                      </Button>
                      <Button size="sm" className="text-xs">
                        <Download className="h-4 w-4 mr-2" />
                        Generate
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;