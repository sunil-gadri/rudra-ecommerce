import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axiosInstance from "../utils/axios";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarDays, User, Mail, Phone, Search } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Input } from "postcss";
import { useToast } from "@/hooks/use-toast";

export default function OrderDetails() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const response = await axiosInstance.get(`/orders/${id}`);
        setOrder(response.data);
        console.log(response.data);
      } catch (error) {
        console.error("Error fetching order:", error);
      }
    };
    fetchOrder();
  }, [id]);

  if (!order) {
    return <p className="p-2 text-gray-500 text-xs">Loading order details...</p>;
  }

  const stripHTML = (html) => {
    const doc = new DOMParser().parseFromString(html, "text/html");
    return doc.body.textContent || "";
  };

  const truncateText = (text, maxLength = 40) => {
    if (!text) return "";
    return text.length > maxLength ? text.substring(0, maxLength) + "..." : text;
  };


  return (
    <div className="w-full p-2" style={{ fontSize: "12px" }}>
      <h2 className="py-1 pb-3 text-lg font-bold">Order Details: #{order.order_id}</h2>

      {/* Top summary cards */}
      <div className="grid md:grid-cols-4 xl:grid-cols-4 gap-2 mb-2">
        <Card className="p-0">
          <div className="p-2 flex items-center w-full rounded-lg gap-2">
            <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
              <CalendarDays className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="min-w-0">
              <h6 className="text-xs mb-0.5 font-medium text-muted-foreground truncate">
                Order Created At
              </h6>
              <p className="text-xs font-bold leading-none truncate">
                {order.updated_at ? new Date(order.updated_at).toUTCString() : "-"}
              </p>
            </div>
          </div>
        </Card>
        <Card className="p-0">
          <div className="p-2 flex items-center w-full rounded-lg gap-2">
            <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
              <User className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="min-w-0">
              <h6 className="text-xs mb-0.5 font-medium text-muted-foreground truncate">
                Name
              </h6>
              <p className="text-xs font-bold leading-none truncate">
                {order.customer_name}
              </p>
            </div>
          </div>
        </Card>
        <Card className="p-0">
          <div className="p-2 flex items-center w-full rounded-lg gap-2">
            <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
              <Mail className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="min-w-0">
              <h6 className="text-xs mb-0.5 font-medium text-muted-foreground truncate">
                Email
              </h6>
              <p className="text-xs font-bold break-words whitespace-normal overflow-hidden truncate">
                {order.customer_email}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-0">
          <div className="p-2 flex items-center w-full rounded-lg gap-2">
            <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
              <Phone className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="min-w-0">
              <h6 className="text-xs mb-0.5 font-medium text-muted-foreground truncate">
                Contact No
              </h6>
              <p className="text-xs font-bold leading-none truncate">
                {order.customer_contact}
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* shipping and billing address */}
      <div className="grid md:grid-cols-2 xl:grid-cols-2 gap-2 my-3">
        {/* Billing */}
        <div className="bg-white border rounded-lg shadow-sm p-2">
          <h3 className="text-sm font-semibold text-gray-800 mb-2 border-b pb-1">
            From
          </h3>
          <div className="space-y-1">
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Street Address:</span>
              <span className="text-xs font-medium">{order.billing_details.street_address}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">City:</span>
              <span className="text-xs font-medium">{order.billing_details.city}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Postal Code:</span>
              <span className="text-xs font-medium">{order.billing_details.postal_code}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">State:</span>
              <span className="text-xs font-medium">{order.billing_details.state}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Country:</span>
              <span className="text-xs font-medium">{order.billing_details.country}</span>
            </div>
          </div>
        </div>
        {/* Shipping */}
        <div className="bg-white border rounded-lg shadow-sm p-2">
          <h3 className="text-sm font-semibold text-gray-800 mb-2 border-b pb-1">
            To
          </h3>
          <div className="space-y-1">
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Name:</span>
              <span className="text-xs font-medium">{order.shipping_details.shipping_name}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Email:</span>
              <span className="text-xs font-medium">{order.shipping_details.shipping_email}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Phone:</span>
              <span className="text-xs font-medium">{order.shipping_details.shipping_phone}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Address Type:</span>
              <span className="text-xs font-medium">{order.shipping_details.address_type}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Street:</span>
              <span className="text-xs font-medium">{order.shipping_details.street_address}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Building:</span>
              <span className="text-xs font-medium">{order.shipping_details.building}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">City:</span>
              <span className="text-xs font-medium">{order.shipping_details.city}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">State:</span>
              <span className="text-xs font-medium">{order.shipping_details.state}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Postal Code:</span>
              <span className="text-xs font-medium">{order.shipping_details.postal_code}</span>
            </div>
            <div className="grid grid-cols-[80px_1fr] gap-2">
              <span className="text-xs text-gray-600">Country:</span>
              <span className="text-xs font-medium">{order.shipping_details.country}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Items */}
      <Card className="p-0">
        <CardHeader className="p-2 pb-1">
          <CardTitle className="text-sm">Order Summary</CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <div className="overflow-x-auto rounded-md">
            <Table className="table-fixed min-w-[140%]">
              <TableHeader>
                <TableRow className="bg-gray-50 text-gray-700 text-center">
                  <TableHead className="text-center text-xs w-[6%] p-1">Product Id</TableHead>
                  <TableHead className="text-center text-xs w-[8%] p-1">Product Image</TableHead>
                  <TableHead className="text-center text-xs w-[14%] p-1">Product Details</TableHead>
                  <TableHead className="text-center text-xs w-[12%] p-1">Size Details</TableHead>
                  <TableHead className="text-center text-xs w-[10%] p-1">Description</TableHead>
                  <TableHead className="text-center text-xs w-[5%] p-1">Quantity</TableHead>
                  <TableHead className="text-center text-xs w-[10%] p-1">Price</TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                {order.items?.map((item, i) => (
                  <TableRow key={item.order_item_id} className="text-xs">
                    <TableCell className="text-center align-middle p-1 text-xs">{item.product_id}</TableCell>
                    <TableCell className="align-middle p-1">
                      <div className="flex justify-center">
                        <img
                          src={`http://192.168.0.9:5000${item.product_image_url}`}
                          alt={item.product_name}
                          className="w-[60px] h-[60px] object-cover rounded"
                        />
                      </div>
                    </TableCell>

                    <TableCell className="text-center align-middle p-1">
                      <p className="font-semibold text-gray-800 text-xs">{item.product_name}</p>
                      <p className="text-xs text-gray-800">Color: {item.product_color || "N/A"}</p>
                      <p className="text-xs text-gray-800">Pattern: {item.product_pattern || "N/A"}</p>
                    </TableCell>
                    <TableCell className="text-center align-middle p-1">
                      <p className="text-xs text-gray-800">Size Category: {item.category || "N/A"}</p>
                      <p className="text-xs text-gray-800">Size Dimensions: {item.product_size || "N/A"}</p>
                    </TableCell>
                    <TableCell className="text-center align-middle p-1">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="cursor-pointer text-xs">
                              {truncateText(stripHTML(item.product_description), 50)}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent className="max-w-sm whitespace-pre-wrap text-xs text-gray-800 p-2">
                            {stripHTML(item.product_description)}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </TableCell>
                    <TableCell className="text-center align-middle p-1 text-xs">{item.quantity}</TableCell>
                    <TableCell className="text-center align-middle p-1 text-xs">
                      <div>
                        <div>{item.price}</div>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

   {/* Price Summary */}
<div className="flex justify-end mt-3">
  <Card className="w-full md:w-80 lg:w-96 shadow-lg border rounded-xl p-0 overflow-hidden">
    <CardHeader className="p-3 pb-2 border-b bg-gray-50">
      <CardTitle className="text-sm font-semibold text-gray-800">
        Price Details
      </CardTitle>
    </CardHeader>
    <CardContent className="p-3 text-xs">
      <div className="space-y-2">

        {/* Order Amount - original before any discount */}
        <div className="flex justify-between text-gray-700">
          <span>Order Amount</span>
          <span className="font-medium">₹{Number(order.order_amount || 0).toFixed(2)}</span>
        </div>

        {/* Item-level saving (already calculated in total_discount) */}
        {Number(order.total_discount || 0) > 0 && (
          <div className="flex justify-between text-green-700">
            <span>Order Saving</span>
            <span className="font-medium">-₹{Number(order.total_discount || 0).toFixed(2)}</span>
          </div>
        )}

     <div className="flex justify-between items-center text-gray-700">
  <span className="flex items-center gap-1.5">
    Coupon Saving
    {order.coupon_code && (
      <span className="inline-block px-1.5 py-0.5 text-[10px] font-medium bg-green-100 text-green-700 rounded">
        {order.coupon_code}
      </span>
    )}
  </span>

  <span className={Number(order.coupon_discount || 0) > 0 ? "font-medium text-green-700" : "font-medium text-gray-500"}>
    {Number(order.coupon_discount || 0) > 0 
      ? `-₹${Number(order.coupon_discount).toFixed(2)}` 
      : "₹0.00"}
  </span>
</div>

        {/* Shipping */}
        <div className="flex justify-between text-gray-700">
          <span>Shipping Cost</span>
          <span className="font-medium">
            {Number(order.shipping_cost || 0) === 0 ? "Free" : `₹${Number(order.shipping_cost || 0).toFixed(2)}`}
          </span>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-300 my-3"></div>

        {/* Final Total */}
        <div className="flex justify-between items-center font-bold text-gray-900">
          <span className="text-sm">Total Amount</span>
          <span className="text-base">₹{Number(order.total_amount || 0).toFixed(2)}</span>
        </div>

      </div>
    </CardContent>
  </Card>
</div>
    </div>
  );
};