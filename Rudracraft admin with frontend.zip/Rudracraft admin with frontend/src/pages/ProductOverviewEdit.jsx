import React, { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useNavigate, useParams } from "react-router-dom";
import { Loader2, Trash2, Plus, ArrowLeft } from "lucide-react";

export default function ProductOverviewEdit() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [overview, setOverview] = useState("");
  const [disclaimer, setDisclaimer] = useState("");
  const [productId, setProductId] = useState("");        // Still needed for submission
  const [productTitle, setProductTitle] = useState("");   // For read-only display

  const [specBlocks, setSpecBlocks] = useState([]);

  const [products, setProducts] = useState([]);
  const [headings, setHeadings] = useState([]);
  const [specificationsMap, setSpecificationsMap] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);

        const [prodRes, headingRes, overviewRes] = await Promise.all([
          axiosInstance.get("/product_title"),
          axiosInstance.get("/specification_heading"),
          axiosInstance.get(`/product-description/${id}`),
        ]);

        setProducts(prodRes.data?.products || []);
        setHeadings(headingRes.data || []);

        const overviewData = overviewRes.data?.data || overviewRes.data;
        if (!overviewData) throw new Error("Overview not found");

        // Set product info
        setProductId(String(overviewData.product_id));

        // Find and display product title (read-only)
        const selectedProduct = (prodRes.data?.products || []).find(
          (p) => p.id === overviewData.product_id
        );
        setProductTitle(selectedProduct?.title || "Unknown Product");

        setOverview(overviewData.overview || "");
        setDisclaimer(overviewData.disclaimer || "");

        const specs = overviewData.specifications || {};
        const blocks = [];

        for (const [headingName, specObj] of Object.entries(specs)) {
          const heading = headingRes.data.find(
            (h) => h.specification_heading === headingName
          );
          if (!heading) continue;

          const specRes = await axiosInstance.get(`/specification/${heading.id}`);
          const specsList = specRes.data || [];

          setSpecificationsMap((prev) => ({
            ...prev,
            [heading.id]: specsList,
          }));

          const rows = Object.entries(specObj).map(([key, value]) => ({
            key,
            value: String(value),
          }));

          blocks.push({
            headingId: String(heading.id),
            headingName,
            rows: rows.length > 0 ? rows : [{ key: "", value: "" }],
          });
        }

        setSpecBlocks(
          blocks.length > 0
            ? blocks
            : [
                {
                  headingId: "",
                  headingName: "",
                  rows: [{ key: "", value: "" }],
                },
              ]
        );
      } catch (err) {
        console.error(err);
        toast.error("Failed to load overview data");
        navigate(-1);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, navigate]);

  const handleHeadingChange = async (blockIdx, headingId) => {
    const heading = headings.find((h) => h.id === headingId);
    if (!heading) return;

    if (!specificationsMap[headingId]) {
      try {
        const res = await axiosInstance.get(`/specification/${headingId}`);
        setSpecificationsMap((prev) => ({
          ...prev,
          [headingId]: res.data || [],
        }));
      } catch (err) {
        toast.error("Failed to load specifications");
      }
    }

    setSpecBlocks((prev) => {
      const updated = [...prev];
      updated[blockIdx] = {
        headingId,
        headingName: heading.specification_heading,
        rows: [{ key: "", value: "" }],
      };
      return updated;
    });
  };

  const addBlock = () => {
    setSpecBlocks((prev) => [
      ...prev,
      { headingId: "", headingName: "", rows: [{ key: "", value: "" }] },
    ]);
  };

  const removeBlock = (idx) => {
    if (specBlocks.length === 1) {
      toast.error("At least one specification group is required");
      return;
    }
    setSpecBlocks((prev) => prev.filter((_, i) => i !== idx));
  };

  const addRow = (blockIdx) => {
    setSpecBlocks((prev) => {
      const updated = [...prev];
      updated[blockIdx].rows.push({ key: "", value: "" });
      return updated;
    });
  };

  const updateRow = (blockIdx, rowIdx, field, value) => {
    setSpecBlocks((prev) => {
      const updated = [...prev];
      updated[blockIdx].rows[rowIdx][field] = value;
      return updated;
    });
  };

  const removeRow = (blockIdx, rowIdx) => {
    setSpecBlocks((prev) => {
      const updated = [...prev];
      if (updated[blockIdx].rows.length === 1) return prev;
      updated[blockIdx].rows.splice(rowIdx, 1);
      return updated;
    });
  };

  const buildPayload = () => {
    const specifications = {};

    for (const block of specBlocks) {
      if (!block.headingId || !block.headingName) continue;

      if (specifications[block.headingName]) {
        toast.error(`Duplicate heading: ${block.headingName}`);
        return null;
      }

      const specsObj = {};
      const usedKeys = new Set();

      for (const row of block.rows) {
        if (!row.key.trim() || !row.value.trim()) continue;
        if (usedKeys.has(row.key)) {
          toast.error(`Duplicate specification in ${block.headingName}`);
          return null;
        }
        usedKeys.add(row.key);
        specsObj[row.key] = row.value.trim();
      }

      if (Object.keys(specsObj).length > 0) {
        specifications[block.headingName] = specsObj;
      }
    }

    return {
      product_id: parseInt(productId),
      overview: overview.trim(),
      disclaimer: disclaimer.trim() || null,
      specifications:
        Object.keys(specifications).length > 0 ? specifications : null,
    };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!productId) return toast.error("Product is missing");
    if (!overview.trim()) return toast.error("Overview is required");

    setSubmitting(true);
    const payload = buildPayload();
    if (!payload) {
      setSubmitting(false);
      return;
    }

    try {
      await axiosInstance.put(`/product-description/${id}`, payload);
      toast.success("Product overview updated successfully!");
      navigate(-1);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to update overview");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <Loader2 className="h-12 w-12 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold">Edit Product Overview</h1>
          </div>
          <Button variant="outline" onClick={() => navigate(-1)}>
            Cancel
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 py-8">
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Product - Read Only */}
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <label className="block text-lg font-medium mb-3">Product</label>
            <div className="w-full px-4 py-3 border rounded-lg bg-gray-50 text-gray-900 font-medium">
              {productTitle || "Loading..."}
            </div>
            <p className="text-sm text-gray-500 mt-2">
              The product cannot be changed when editing an existing overview.
            </p>
          </div>

          {/* Overview & Disclaimer */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-xl border shadow-sm">
              <label className="block text-lg font-medium mb-3">
                Overview <span className="text-red-500">*</span>
              </label>
              <textarea
                value={overview}
                onChange={(e) => setOverview(e.target.value)}
                rows={5}
                className="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500 resize-none"
                placeholder="Write a detailed overview..."
                required
              />
            </div>

            <div className="bg-white p-6 rounded-xl border shadow-sm">
              <label className="block text-lg font-medium mb-3">
                Disclaimer
              </label>
              <textarea
                value={disclaimer}
                onChange={(e) => setDisclaimer(e.target.value)}
                rows={5}
                className="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500 resize-none"
                placeholder="Optional disclaimer..."
              />
            </div>
          </div>

          {/* Specifications */}
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">Specifications</h2>
              <Button type="button" size="sm" onClick={addBlock}>
                <Plus className="h-4 w-4 mr-2" /> Add Group
              </Button>
            </div>

            <div className="space-y-6">
              {specBlocks.map((block, blockIdx) => (
                <div
                  key={blockIdx}
                  className="border-2 border-dashed border-gray-300 rounded-lg p-6 bg-gray-50"
                >
                  <div className="flex gap-3 items-center mb-4">
                    <select
                      value={block.headingId}
                      onChange={(e) =>
                        handleHeadingChange(blockIdx, e.target.value)
                      }
                      className="flex-1 px-4 py-2 border rounded-lg font-medium"
                    >
                      <option value="">Select Heading</option>
                      {headings.map((h) => (
                        <option key={h.id} value={h.id}>
                          {h.specification_heading}
                        </option>
                      ))}
                    </select>
                    {specBlocks.length > 1 && (
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        onClick={() => removeBlock(blockIdx)}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-5 w-5" />
                      </Button>
                    )}
                  </div>

                  {block.headingId && (
                    <div className="space-y-3">
                      {block.rows.map((row, rowIdx) => (
                        <div
                          key={rowIdx}
                          className="flex gap-3 items-center"
                        >
                          <select
                            value={row.key}
                            onChange={(e) =>
                              updateRow(blockIdx, rowIdx, "key", e.target.value)
                            }
                            className="flex-1 px-4 py-2 border rounded-lg"
                          >
                            <option value="">Select Specification</option>
                            {(specificationsMap[block.headingId] || []).map(
                              (spec) => (
                                <option
                                  key={spec.id}
                                  value={spec.specification}
                                >
                                  {spec.specification}
                                </option>
                              )
                            )}
                          </select>

                          <input
                            type="text"
                            value={row.value}
                            onChange={(e) =>
                              updateRow(blockIdx, rowIdx, "value", e.target.value)
                            }
                            placeholder="Value"
                            className="flex-1 px-4 py-2 border rounded-lg"
                          />

                          {block.rows.length > 1 && (
                            <Button
                              type="button"
                              size="icon"
                              variant="ghost"
                              onClick={() => removeRow(blockIdx, rowIdx)}
                              className="text-red-600 hover:bg-red-50"
                            >
                              <Trash2 className="h-5 w-5" />
                            </Button>
                          )}
                        </div>
                      ))}
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => addRow(blockIdx)}
                        className="w-full mt-3"
                      >
                        <Plus className="h-4 w-4 mr-2" /> Add Specification
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="flex justify-end gap-4 py-6 bg-white border-t sticky bottom-0">
            <Button type="button" variant="outline" onClick={() => navigate(-1)}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={submitting}
              className="bg-purple-600 hover:bg-purple-700 min-w-40"
            >
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}