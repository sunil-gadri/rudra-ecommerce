import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";
import { CKEditor } from "ckeditor4-react";
import imageCompression from "browser-image-compression";
import { IMAGE_BASE_URL } from '../utils/imagesUrl.jsx';

export default function ProductsEdit() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { toast } = useToast();

    // Form States
    const [productTitle, setProductTitle] = useState("");
    const [selectedParentCategory, setSelectedParentCategory] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("");
    const [tags, setTags] = useState("");
    const [status, setStatus] = useState("Active");
    const [productDescription, setProductDescription] = useState("");
    const [productImages, setProductImages] = useState([]);

    // Attributes
    const [dimensionUnit, setDimensionUnit] = useState("");
    const [length, setLength] = useState("");
    const [width, setWidth] = useState("");
    const [height, setHeight] = useState("");
    const [selectedSize, setSelectedSize] = useState("");
    const [selectedColor, setSelectedColor] = useState("");
    const [selectedPattern, setSelectedPattern] = useState("");

    // General Info
    const [manufacturerName, setManufacturerName] = useState("");
    const [manufacturerBrand, setManufacturerBrand] = useState("");
    const [stock, setStock] = useState("");
    const [price, setPrice] = useState("");
    const [discount, setDiscount] = useState("");
    const [gst, setGst] = useState(""); 

    // Meta
    const [metaTitle, setMetaTitle] = useState("");
    const [metaKeywords, setMetaKeywords] = useState("");
    const [metaDescription, setMetaDescription] = useState("");

    // Dropdowns
    const [parentCategories, setParentCategories] = useState([]);
    const [categories, setCategories] = useState([]);
    const [manufacturers, setManufacturers] = useState([]);
    const [brands, setBrands] = useState([]);
    const [colors, setColors] = useState([]);
    const [patternOptions, setPatternOptions] = useState([]);
    const [sizes, setSizes] = useState([]);
    const [gstOptions, setGstOptions] = useState([]); 
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchAll = async () => {
            try {
                setLoading(true);
                const [
                    parentRes,
                    catRes,
                    manRes,
                    brandRes,
                    colorsRes,
                    patternsRes,
                    sizesRes,
                    gstRes,
                    productRes,
                ] = await Promise.all([
                    axiosInstance.get("/parent-categories"),
                    axiosInstance.get("/categories"),
                    axiosInstance.get("/manufacturer"),
                    axiosInstance.get("/brands"),
                    axiosInstance.get("/product_colors"),
                    axiosInstance.get("/product_pattern"),
                    axiosInstance.get("/product_sizes"),
                    axiosInstance.get("/gst"), 
                    axiosInstance.get(`/products/${id}`),
                ]);

                const product = productRes.data;

                // GST Options
                const gstList = Array.isArray(gstRes.data) ? gstRes.data : [];
                setGstOptions(gstList);

                const parentCats = Array.isArray(parentRes.data) ? parentRes.data.map(c => ({ ...c, id: String(c.id) })) : [];
                const cats = Array.isArray(catRes.data) ? catRes.data.map(c => ({ ...c, id: String(c.id) })) : [];

                setParentCategories(parentCats);
                setCategories(cats);
                setManufacturers(Array.isArray(manRes.data) ? manRes.data : []);
                setBrands(Array.isArray(brandRes.data) ? brandRes.data : []);
                setColors(Array.isArray(colorsRes.data) ? colorsRes.data : []);
                setPatternOptions(Array.isArray(patternsRes.data) ? patternsRes.data : []);
                setSizes(Array.isArray(sizesRes.data) ? sizesRes.data : []);

                // Map category names → IDs
                const parentCat = parentCats.find(c => c.name === product.parent_category);
                const prodCat = cats.find(c => c.name === product.product_category);

                setSelectedParentCategory(parentCat?.id || "");
                setSelectedCategory(prodCat?.id || "");

                // Basic fields
                setProductTitle(product.title || "");
                setTags(product.tags || "");
                setStatus(product.status || "Active");
                setProductDescription(product.description || "");

                // Attributes
                const attrs = product.attributes || {};
                setDimensionUnit(attrs.unit || "");
                setLength(attrs.length || "");
                setWidth(attrs.width || "");
                setHeight(attrs.height || "");
                setSelectedSize(attrs.size_category || "");
                setSelectedColor(attrs.color || "");
                setSelectedPattern(attrs.pattern || "");

                // General Info
                const general = product.general_info || {};
                setManufacturerName(general.manufacturer_name || "");
                setManufacturerBrand(general.manufacturer_brand || "");
                setStock(general.stock || "");
                setPrice(general.price || "");
                setDiscount(general.discount || "");
                setGst(general.gst || "");

                // Meta
                const meta = product.meta || {};
                setMetaTitle(meta.title || "");
                setMetaKeywords(meta.keywords || "");
                setMetaDescription(meta.description || "");

                // Images
                const files = await Promise.all(
                    (product.images || []).map(async (imgUrl) => {
                        const fullUrl = imgUrl.startsWith("http")
                            ? imgUrl
                            : `${IMAGE_BASE_URL}${imgUrl}`;
                        const fileName = fullUrl.substring(fullUrl.lastIndexOf("/") + 1);
                        const file = await urlToFile(fullUrl, fileName, "image/jpeg");

                        return {
                            file,
                            preview: fullUrl,
                        };
                    })
                );

                setProductImages(files);

            } catch (error) {
                console.error("Failed to load data:", error);
                toast({
                    title: "Error",
                    description: "Failed to load product data.",
                    variant: "destructive",
                });
            } finally {
                setLoading(false);
            }
        };

        if (id) fetchAll();
    }, [id, toast]);

    useEffect(() => {
        return () => {
            productImages.forEach((img) => {
                if (img.preview && img.preview.startsWith("blob:")) {
                    URL.revokeObjectURL(img.preview);
                }
            });
        };
    }, [productImages]);

    const handleImageRemove = (idx) => {
        setProductImages(prev => prev.filter((_, i) => i !== idx));
    };

    const urlToFile = async (url, filename) => {
        try {
            const response = await fetch(url, { mode: "cors" });
            if (!response.ok) throw new Error("Failed to fetch image");
            const blob = await response.blob();
            return new File([blob], filename, { type: blob.type || "image/jpeg" });
        } catch (error) {
            console.warn("urlToFile fallback for:", url, error.message);
            const extension = filename.split(".").pop() || "jpg";
            return new File([], filename, { type: `image/${extension}` });
        }
    };

    const handleImageChange = (e) => {
        const files = Array.from(e.target.files).map((file) => ({
            file,
            preview: URL.createObjectURL(file),
        }));
        setProductImages((prev) => [...prev, ...files]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const error = validateForm();
        if (error) {
            toast({ title: "Validation Error", description: error, variant: "destructive" });
            return;
        }

        const formData = new FormData();
        formData.append("product_title", productTitle);
        formData.append("product_parent_category_id", selectedParentCategory);
        formData.append("product_category_id", selectedCategory);
        formData.append("product_tags", tags);
        formData.append("product_status", status);
        formData.append("product_description", productDescription);

        for (let index = 0; index < productImages.length; index++) {
            const { file } = productImages[index];
            try {
                const compressedFile = await imageCompression(file, {
                    maxSizeMB: 0.03,
                    maxWidthOrHeight: 1024,
                    useWebWorker: true,
                });
                formData.append("images", compressedFile, file.name);
            } catch (error) {
                formData.append("images", file, file.name);
            }
        }

        formData.append("length", length);
        formData.append("width", width);
        formData.append("height", height);
        formData.append("unit", dimensionUnit);
        formData.append("category", selectedSize);
        formData.append("product_color", selectedColor);
        formData.append("product_pattern", selectedPattern);

        formData.append("manufacturer_name", manufacturerName);
        formData.append("manufacturer_brand", manufacturerBrand);
        formData.append("stock", stock);
        formData.append("price", price);
        formData.append("discount", discount || "");
        formData.append("gst", gst || "0"); 

        formData.append("meta_title", metaTitle);
        formData.append("meta_keywords", metaKeywords);
        formData.append("meta_description", metaDescription);

        try {
            await axiosInstance.put(`/products/${id}`, formData, {
                headers: { "Content-Type": "multipart/form-data" },
            });
            toast({ title: "Success", description: "Product updated!" });
            navigate("/products");
        } catch (error) {
            toast({
                title: "Error",
                description: error.response?.data?.message || "Update failed.",
                variant: "destructive",
            });
        }
    };

    const validateForm = () => {
        if (!productTitle.trim()) return "Product title is required.";
        if (!selectedParentCategory) return "Parent category is required.";
        if (!selectedCategory) return "Product category is required.";
        if (!tags.trim()) return "Tags are required.";
        if (!productDescription.trim()) return "Description is required.";
        if (productImages.length === 0) return "At least one image is required.";
        if (!manufacturerName) return "Manufacturer name is required.";
        if (!manufacturerBrand) return "Brand is required.";
        if (!stock || stock < 0) return "Valid stock is required.";
        if (!price || price <= 0) return "Valid price is required.";
        if (!metaTitle.trim()) return "Meta title is required.";
        if (!metaKeywords.trim()) return "Meta keywords are required.";
        if (!metaDescription.trim()) return "Meta description is required.";
        return null;
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600" />
            </div>
        );
    }

    const sizeCategories = Array.from(
        new Set(sizes.filter(s => s.type === "size category" && s.category).map(s => s.category))
    );

    const dimensionUnits = Array.from(
        new Set(sizes.filter(s => s.type === "metric units" && s.unit).map(s => s.unit))
    );

    const colorOptions = [
        { value: "", label: "None", hex_value: null },
        ...colors.map(c => ({
            value: c.color_name,
            label: c.color_name.charAt(0).toUpperCase() + c.color_name.slice(1),
            hex_value: c.hex_value,
        })),
    ];

    return (
        <form onSubmit={handleSubmit} className="space-y-8">
            <h1 className="text-3xl font-bold">Edit Product</h1>

            {/* Product Information */}
            <div className="bg-white p-6 rounded-lg border space-y-6">
                <h2 className="text-2xl font-semibold mb-4">Product Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-lg font-medium text-gray-700 mb-1">Product Title</label>
                        <input
                            type="text"
                            className="w-full px-4 py-2 border rounded focus:ring-2 focus:ring-purple-500"
                            value={productTitle}
                            onChange={(e) => setProductTitle(e.target.value)}
                        />
                    </div>

                    <div>
                        <label className="block text-lg font-medium text-gray-700 mb-1">Parent Category</label>
                        <select
                            className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
                            value={selectedParentCategory}
                            onChange={(e) => setSelectedParentCategory(e.target.value)}
                        >
                            <option value="">Select</option>
                            {parentCategories.map(cat => (
                                <option key={cat.id} value={cat.id}>{cat.name}</option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block text-lg font-medium text-gray-700 mb-1">Product Category</label>
                        <select
                            className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
                            value={selectedCategory}
                            onChange={(e) => setSelectedCategory(e.target.value)}
                        >
                            <option value="">Select</option>
                            {categories.map(cat => (
                                <option key={cat.id} value={cat.id}>{cat.name}</option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block text-lg font-medium text-gray-700 mb-1">Tags</label>
                        <input
                            type="text"
                            className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
                            value={tags}
                            onChange={(e) => setTags(e.target.value)}
                        />
                    </div>

                    <div>
                        <label className="block text-lg font-medium text-gray-700 mb-1">Status</label>
                        <select
                            className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
                            value={status}
                            onChange={(e) => setStatus(e.target.value)}
                        >
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label className="block text-lg font-medium text-gray-700 mb-1">Description</label>
                    <div className="border rounded p-2">
                        <CKEditor
                            initData={productDescription}
                            onChange={(e) => setProductDescription(e.editor.getData())}
                            config={{ versionCheck: false }}
                        />
                    </div>
                </div>
            </div>

            {/* Images */}
            <div className="bg-white p-6 rounded-lg border">
                <h2 className="text-lg font-semibold mb-3">Product Images</h2>
                <div className="flex flex-wrap gap-4">
                    {productImages.map((img, idx) => (
                        <div
                            key={idx}
                            className="relative w-32 h-32 border rounded overflow-hidden bg-gray-100"
                        >
                            <img
                                src={img.preview}
                                alt={`Product ${idx}`}
                                className="w-full h-full object-cover"
                            />
                            <button
                                type="button"
                                onClick={() => handleImageRemove(idx)}
                                className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 text-xs"
                            >
                                X
                            </button>
                        </div>
                    ))}
                    {productImages.length < 5 && (
                        <label className="w-32 h-32 border border-dashed rounded flex items-center justify-center cursor-pointer bg-gray-50 hover:bg-gray-100">
                            <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                multiple
                                onChange={handleImageChange}
                            />
                            <span className="text-gray-500 text-xl">+</span>
                        </label>
                    )}
                </div>
            </div>

            {/* Product Attributes */}
            <div className="bg-white p-6 rounded-lg border space-y-6">
                <h2 className="text-lg font-semibold mb-2">Product Attributes</h2>

                {/* Size Dimensions */}
                <div className="mb-6 pb-6 border-b border-gray-200 flex items-center gap-4">
                    <label className="font-semibold text-gray-700 w-40">Size Dimensions</label>
                    <select
                        className="border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
                        value={dimensionUnit}
                        onChange={(e) => setDimensionUnit(e.target.value)}
                    >
                        <option value="">Select Unit</option>
                        {dimensionUnits.map((unit) => (
                            <option key={unit} value={unit}>{unit}</option>
                        ))}
                    </select>
                    <input
                        type="number"
                        placeholder="Length"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        className="px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 w-24"
                    />
                    <input
                        type="number"
                        placeholder="Width"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        className="px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 w-24"
                    />
                    <input
                        type="number"
                        placeholder="Height"
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        className="px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 w-24"
                    />
                </div>

                {/* Size Category */}
                <div className="mb-6 pb-6 border-b border-gray-200 flex items-center gap-4">
                    <label className="font-semibold text-gray-700 w-40">Size Category</label>
                    <select
                        className="w-full max-w-xs border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
                        value={selectedSize}
                        onChange={(e) => setSelectedSize(e.target.value)}
                    >
                        <option value="">None</option>
                        {sizeCategories.map((size) => (
                            <option key={size} value={size}>{size}</option>
                        ))}
                    </select>
                </div>

                {/* Color Selection */}
                <div className="mb-6 pb-6 border-b border-gray-200 flex items-center gap-4">
                    <label className="font-semibold text-gray-700 w-40">Color</label>
                    <div className="flex gap-4 flex-wrap">
                        {colorOptions.map(({ label: color_name, value: hex_value }) => {
                            const isSelected = color_name === selectedColor;
                            return (
                                <label
                                    key={color_name}
                                    className={`flex items-center gap-2 cursor-pointer px-4 py-2 border rounded whitespace-nowrap transition-all ${isSelected
                                        ? "border-gray-500 bg-gray-100"
                                        : "border-gray-300 hover:bg-gray-50"
                                        }`}
                                >
                                    <input
                                        type="radio"
                                        name="color"
                                        value={color_name}
                                        checked={isSelected}
                                        onChange={(e) => setSelectedColor(e.target.value)}
                                        className="hidden"
                                    />
                                    <span
                                        className="w-6 h-6 rounded-full border-2 border-gray-300"
                                        style={{ backgroundColor: hex_value }}
                                    ></span>
                                    {color_name.charAt(0).toUpperCase() + color_name.slice(1)}
                                </label>
                            );
                        })}
                    </div>
                </div>

                {/* Pattern Selection */}
                <div className="flex items-center gap-4">
                    <label className="font-semibold text-gray-700 w-40">Pattern</label>
                    <select
                        className="w-full max-w-xs border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
                        value={selectedPattern}
                        onChange={(e) => setSelectedPattern(e.target.value)}
                    >
                        <option value="">None</option>
                        {patternOptions.map((patternObj) => (
                            <option key={patternObj.id} value={patternObj.pattern}>
                                {patternObj.pattern}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            {/* General Info */}
            <div className="bg-white p-6 rounded-lg border space-y-6">
                <h2 className="text-lg font-semibold mb-4">General Info</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block font-semibold mb-1 text-gray-700">
                            Manufacturer Name
                        </label>
                        <select
                            value={manufacturerName}
                            onChange={(e) => setManufacturerName(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
                        >
                            <option value="">Select a manufacturer</option>
                            {manufacturers.map((mfr) => (
                                <option key={mfr.id} value={mfr.manufacturer_name}>
                                    {mfr.manufacturer_name}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block font-semibold mb-1 text-gray-700">
                            Manufacturer Brand
                        </label>
                        <select
                            value={manufacturerBrand}
                            onChange={(e) => setManufacturerBrand(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
                        >
                            <option value="">Select a brand</option>
                            {brands.map((brand) => (
                                <option key={brand.id} value={brand.brand_name}>
                                    {brand.brand_name} ({brand.manufacturer_name})
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                    <div>
                        <label className="block font-semibold mb-1 text-gray-700">Stock</label>
                        <input
                            type="number"
                            value={stock}
                            onChange={(e) => setStock(e.target.value)}
                            placeholder="Stock"
                            className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
                        />
                    </div>
                    <div>
                        <label className="block font-semibold mb-1 text-gray-700">Price</label>
                        <div className="flex items-center border border-gray-300 rounded">
                            <span className="px-3 bg-gray-100 text-gray-600">$</span>
                            <input
                                type="number"
                                value={price}
                                onChange={(e) => setPrice(e.target.value)}
                                placeholder="Enter price"
                                className="w-full px-2 py-2 focus:outline-none"
                            />
                        </div>
                    </div>

                    {/* GST Dropdown */}
                    <div>
                        <label className="block font-semibold mb-1 text-gray-700">GST (%)</label>
                        <select
                            value={gst}
                            onChange={(e) => setGst(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
                        >
                            <option value="">Select GST</option>
                            {gstOptions.map((g) => (
                                <option key={g.id} value={g.gst}>
                                    {g.gst}%
                                </option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block font-semibold mb-1 text-gray-700">Discount</label>
                        <div className="flex items-center border border-gray-300 rounded">
                            <input
                                type="number"
                                placeholder="Enter discount"
                                value={discount}
                                onChange={(e) => setDiscount(e.target.value)}
                                className="w-full px-2 py-2 focus:outline-none"
                            />
                            <span className="px-3 bg-gray-100 text-gray-600">%</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Meta Data */}
            <div className="bg-white p-6 rounded-lg border space-y-6">
                <h2 className="text-lg font-semibold">Meta Data</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block font-semibold mb-1 text-gray-700">Meta Title</label>
                        <input
                            type="text"
                            placeholder="Enter meta title"
                            value={metaTitle}
                            onChange={(e) => setMetaTitle(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
                        />
                    </div>
                    <div>
                        <label className="block font-semibold mb-1 text-gray-700">Meta Keywords</label>
                        <input
                            type="text"
                            placeholder="Enter meta keywords"
                            value={metaKeywords}
                            onChange={(e) => setMetaKeywords(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
                        />
                    </div>
                </div>
                <div>
                    <label className="block font-semibold mb-1 text-gray-700">Meta Description</label>
                    <textarea
                        rows={3}
                        placeholder="Enter meta description"
                        value={metaDescription}
                        onChange={(e) => setMetaDescription(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded resize-none focus:ring-2 focus:ring-purple-500"
                    />
                </div>
            </div>

            <div className="flex gap-4">
                <Button variant="outline" type="button" onClick={() => navigate("/products")}>
                    Cancel
                </Button>
                <Button type="submit">Update Product</Button>
            </div>
        </form>
    );
}