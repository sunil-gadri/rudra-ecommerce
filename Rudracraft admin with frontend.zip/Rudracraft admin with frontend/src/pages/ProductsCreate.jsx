import React, { useState, useEffect } from "react";
import { CKEditor } from "ckeditor4-react";
import axiosInstance from "../utils/axios";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import imageCompression from "browser-image-compression";
import { useNavigate } from "react-router-dom";

export default function ProductsCreate() {
  const [productTitle, setProductTitle] = useState("");
  const [selectedParentCategory, setSelectedParentCategory] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [tags, setTags] = useState("");
  const [status, setStatus] = useState("Active");
  const [productDescription, setProductDescription] = useState("");
  const [productImages, setProductImages] = useState([]);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  // Attributes 
  const [dimensionUnit, setDimensionUnit] = useState("");
  const [length, setLength] = useState("");
  const [width, setWidth] = useState("");
  const [height, setHeight] = useState("");
  const [sizes, setSizes] = useState([]);
  const [selectedSize, setSelectedSize] = useState("");
  const [colors, setColors] = useState([]);
  const [selectedColor, setSelectedColor] = useState("");
  const [patternOptions, setPatternOptions] = useState([]);
  const [selectedPattern, setSelectedPattern] = useState("");

  // General Info
  const [manufacturerName, setManufacturerName] = useState("");
  const [manufacturers, setManufacturers] = useState([]);
  const [manufacturerBrand, setManufacturerBrand] = useState("");
  const [brands, setBrands] = useState([]);
  const [stock, setStock] = useState("");
  const [price, setPrice] = useState("");
  const [gstList, setGstList] = useState([]);
  const [gst, setGst] = useState("");
  const [discount, setDiscount] = useState("");

  useEffect(() => {
    axiosInstance
      .get("/gst")
      .then((res) => {
        console.log("Fetched GST list:", res.data);
        setGstList(res.data);
      })
      .catch((err) => console.error("Error fetching GST:", err));
  }, []);

  // Meta
  const [metaTitle, setMetaTitle] = useState("");
  const [metaKeywords, setMetaKeywords] = useState("");
  const [metaDescription, setMetaDescription] = useState("");

  // Parent Categories
  const [parentCategories, setParentCategories] = useState([]);
  const [categories, setCategories] = useState([]);

  const requiredFields = [
    "productTitle",
    "tags",
    "productDescription",
    "parentCategory",
    "productCategory",
    "manufacturerName",
    "manufacturerBrand",
    "images",
    "price",
    "stock",
    "metaTitle",
    "metaKeywords",
    "metaDescription",
  ];

  // Validation function - only on submit
  const validateField = (name, value) => {
    let message = "";

    if (name === "productTitle" && !value.trim()) {
      message = "Product title is required";
    }
    if (name === "tags" && !value.trim()) {
      message = "At least one tag is required";
    }
    if (name === "productDescription" && !value.trim()) {
      message = "Product description is required";
    }
    if (name === "parentCategory" && !value) {
      message = "Parent category is required";
    }
    if (name === "productCategory" && !value) {
      message = "Product category is required";
    }
    if (name === "manufacturerName" && !value) {
      message = "Manufacturer name is required";
    }
    if (name === "manufacturerBrand" && !value) {
      message = "Brand name is required";
    }
    if (name === "images" && (!value || value.length === 0)) {
      message = "At least one product image is required";
    }
    if (name === "price" && (!value || value <= 0)) {
      message = "Price must be greater than 0";
    }
    if (name === "stock" && (value === "" || value < 0)) {
      message = "Stock is required and must be >= 0";
    }
    if (name === "metaTitle" && !value.trim()) {
      message = "Meta title is required";
    }
    if (name === "metaKeywords" && !value.trim()) {
      message = "Meta keywords are required";
    }
    if (name === "metaDescription" && !value.trim()) {
      message = "Meta description is required";
    }

    setErrors((prev) => ({ ...prev, [name]: message }));
    return message === "";
  };

  // Fetch data on mount
  useEffect(() => {
    axiosInstance.get("/product_sizes").then((res) => setSizes(res.data));
    axiosInstance.get("/product_colors").then((res) => setColors(res.data));
    axiosInstance.get("/product_pattern").then((res) => setPatternOptions(res.data));
    axiosInstance.get("/manufacturer").then((res) => setManufacturers(res.data));
    axiosInstance.get("/brands").then((res) => setBrands(res.data));
    axiosInstance.get("/parent-categories").then((res) => setParentCategories(res.data));
    axiosInstance.get("/categories").then((res) => setCategories(res.data));
    axiosInstance.get("/gst").then((res) => setGst(res.data));
  }, []);

  // Clean up image previews
  useEffect(() => {
    return () => {
      productImages.forEach((img) => URL.revokeObjectURL(img.preview));
    };
  }, [productImages]);

  // Image upload handler
  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    const totalImages = productImages.length + files.length;

    if (totalImages > 5) {
      toast.error("You can upload a maximum of 5 product images.");
      return;
    }

    const newImages = files.map((file) => ({
      file,
      preview: URL.createObjectURL(file),
    }));

    setProductImages((prev) => [...prev, ...newImages]);
  };

  // Form submission handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Reset errors
    setErrors({});

    let formIsValid = true;

    // Validate all required fields
    const fieldValues = {
      productTitle,
      tags,
      productDescription,
      parentCategory: selectedParentCategory,
      productCategory: selectedCategory,
      manufacturerName,
      manufacturerBrand,
      images: productImages,
      price,
      stock,
      metaTitle,
      metaKeywords,
      metaDescription,
    };

    for (const field of requiredFields) {
      if (!validateField(field, fieldValues[field])) {
        formIsValid = false;
      }
    }

    if (!formIsValid) {
      toast.error("Please fill all required fields.");
      return;
    }

    const formData = new FormData();
    formData.append("product_title", productTitle);
    formData.append("product_parent_category_id", selectedParentCategory);
    formData.append("product_category_id", selectedCategory);
    formData.append("product_tags", tags);
    formData.append("product_status", status);
    formData.append("product_description", productDescription);

    for (let i = 0; i < productImages.length; i++) {
      const img = productImages[i];
      try {
        const compressedFile = await imageCompression(img.file, {
          maxSizeMB: 0.03,
          maxWidthOrHeight: 1024,
          useWebWorker: true,
        });
        formData.append("images", compressedFile, img.file.name);
      } catch (error) {
        console.error("Image compression error:", error);
        formData.append("images", img.file);
      }
    }

    // Attributes (non-validated, still included in formData)
    formData.append("length", length);
    formData.append("width", width);
    formData.append("height", height);
    formData.append("unit", dimensionUnit);
    formData.append("category", selectedSize);
    formData.append("product_color", selectedColor);
    formData.append("product_pattern", selectedPattern);

    // General Info
    formData.append("manufacturer_name", manufacturerName);
    formData.append("manufacturer_brand", manufacturerBrand);
    formData.append("stock", stock);
    formData.append("price", price);
    formData.append("gst", gst);
    formData.append("discount", discount);

    // Meta Data
    formData.append("meta_title", metaTitle);
    formData.append("meta_keywords", metaKeywords);
    formData.append("meta_description", metaDescription);

    try {
      const response = await axiosInstance.post("/products", formData);
      toast.success("Product created successfully!");
      navigate("/products");

      // Reset form
      setProductTitle("");
      setSelectedParentCategory("");
      setSelectedCategory("");
      setTags("");
      setStatus("Active");
      setProductDescription("");
      setProductImages([]);
      setDimensionUnit("");
      setLength("");
      setWidth("");
      setHeight("");
      setSelectedSize("");
      setSelectedColor("");
      setSelectedPattern("");
      setManufacturerName("");
      setManufacturerBrand("");
      setStock("");
      setPrice("");
      setDiscount("");
      setMetaTitle("");
      setMetaKeywords("");
      setMetaDescription("");
      setErrors({});
    } catch (error) {
      console.error("Error submitting product:", error);
      toast.error("Failed to create product. Please try again.");
    }
  };

  // Get unique units and size categories
  const dimensionUnits = Array.from(
    new Set(sizes.filter((item) => item.type === "metric units" && item.unit).map((item) => item.unit))
  );
  const sizeCategories = Array.from(
    new Set(sizes.filter((item) => item.type === "size category" && item.category).map((item) => item.category))
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <h1 className="text-3xl font-bold">Create Product</h1>
      {/* <p className="text-muted-foreground">Fill in the details to create a new product</p> */}

      <div className="bg-white p-6 rounded-lg border space-y-6">
        <h2 className="text-2xl font-semibold mb-4">Product Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Product Title */}
          <div>
            <label
              htmlFor="product-title"
              className="block text-base font-medium text-gray-700 mb-1"
            >
              Product Title
            </label>
            <input
              id="product-title"
              type="text"
              className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
              placeholder="Enter product title"
              value={productTitle}
              onChange={(e) => {
                const value = e.target.value;
                const formatted = value.charAt(0).toUpperCase() + value.slice(1);
                setProductTitle(formatted);
              }}
            />
            {errors.productTitle && (
              <p className="text-red-500 text-sm mt-1">{errors.productTitle}</p>
            )}
          </div>

          {/* Parent Categories */}
          <div>
            <label className="block text-base font-medium text-gray-700 mb-1">
              Parent Category
            </label>
            <select
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
              value={selectedParentCategory}
              onChange={(e) => setSelectedParentCategory(Number(e.target.value))}
            >
              <option value="">Select a parent category</option>
              {parentCategories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
            {errors.parentCategory && (
              <p className="text-red-500 text-sm mt-1">{errors.parentCategory}</p>
            )}
          </div>

          {/* Product Categories */}
          <div>
            <label className="block text-base font-medium text-gray-700 mb-1">
              Product Category
            </label>
            <select
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(Number(e.target.value))}
            >
              <option value="">Select a product category</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
            {errors.productCategory && (
              <p className="text-red-500 text-sm mt-1">{errors.productCategory}</p>
            )}
          </div>

          {/* Product Tags */}
          <div>
            <label className="block text-base font-medium text-gray-700 mb-1">
              Product Tags
            </label>
            <input
              type="text"
              placeholder="Enter tags (comma separated)"
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
            />
            {errors.tags && (
              <p className="text-red-500 text-sm mt-1">{errors.tags}</p>
            )}
          </div>

          {/* Product Status */}
          <div>
            <label className="block text-base font-medium text-gray-700 mb-1">
              Product Status
            </label>
            <select
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>

        {/* Product Description */}
        <div>
          <label className="block text-base font-medium text-gray-700 mb-1">
            Product Description
          </label>
          <div className="border border-gray-300 rounded p-2" style={{ minHeight: "200px" }}>
            <CKEditor
              initData={productDescription || ""}
              config={{
                height: 300,
                removePlugins: "elementspath",
                resize_enabled: false,
                versionCheck: false,
              }}
              onChange={(evt) => {
                const htmlContent = evt.editor.getData();
                const parser = new DOMParser();
                const parsedDoc = parser.parseFromString(htmlContent, "text/html");
                const plainText = parsedDoc.body.textContent || "";
                setProductDescription(plainText);
              }}
            />
            {errors.productDescription && (
              <p className="text-red-500 text-sm mt-1">{errors.productDescription}</p>
            )}
          </div>
        </div>
      </div>

      {/* Product Images */}
      <div className="bg-white p-6 rounded-lg border">
        <h2 className="text-base font-semibold mb-1">Product Images</h2>
        <p className="text-sm text-gray-500 mb-3">Add up to 5 product images.</p>
        <div className="flex flex-wrap gap-4">
          {productImages.map((img, idx) => (
            <div
              key={idx}
              className="w-32 h-32 border rounded overflow-hidden bg-gray-100"
            >
              <img
                src={img.preview}
                alt={`Product ${idx}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
          {productImages.length < 5 && (
            <label className="w-32 h-32 border border-dashed rounded flex items-center justify-center cursor-pointer bg-gray-50 hover:bg-gray-100">
              <input
                type="file"
                accept="image/*"
                className="hidden"
                multiple
                onChange={handleImageUpload}
              />
              <span className="text-gray-500 text-xl">+</span>
            </label>
          )}
        </div>
        {errors.images && (
          <p className="text-red-500 text-sm mt-1">{errors.images}</p>
        )}
      </div>

      {/* Product Attributes (no validation) */}
      <div className="bg-white p-6 rounded-lg border space-y-6">
        <h2 className="text-base font-semibold mb-2">Product Attributes</h2>

        {/* Size Dimensions */}
        <div className="mb-6 pb-6 border-b border-gray-200 flex items-center gap-4">
          <label className="font-semibold text-gray-700 w-40">Size Dimensions</label>
          <select
            className="border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-purple-500"
            value={dimensionUnit}
            onChange={(e) => setDimensionUnit(e.target.value)}
          >
            <option value="">Select Unit</option>
            {dimensionUnits.map((unit) => (
              <option key={unit} value={unit}>
                {unit}
              </option>
            ))}
          </select>
          <input
            type="number"
            placeholder="Length"
            value={length}
            onChange={(e) => setLength(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 w-24"
          />
          <input
            type="number"
            placeholder="Width"
            value={width}
            onChange={(e) => setWidth(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 w-24"
          />
          <input
            type="number"
            placeholder="Height"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 w-24"
          />
        </div>

        {/* Size Category */}
        <div className="mb-6 pb-6 border-b border-gray-200 flex items-center gap-4">
          <label className="font-semibold text-gray-700 w-40">Size Category</label>
          <div className="flex gap-4 flex-wrap">
            {sizeCategories.map((size) => (
              <label
                key={size}
                className="px-4 py-2 border border-gray-300 rounded cursor-pointer hover:bg-purple-50 whitespace-nowrap flex items-center"
              >
                <input
                  type="radio"
                  name="size-category"
                  value={size}
                  checked={size === selectedSize}
                  onChange={(e) => setSelectedSize(e.target.value)}
                  className="mr-2"
                />
                {size}
              </label>
            ))}
          </div>
        </div>

        {/* Color Selection */}
        <div className="mb-6 pb-6 border-b border-gray-200 flex items-center gap-4">
          <label className="font-semibold text-gray-700 w-40">Color</label>
          <div className="flex gap-4 flex-wrap">
            {colors.map(({ color_name, hex_value }) => {
              const isSelected = color_name === selectedColor;
              return (
                <label
                  key={color_name}
                  className={`flex items-center gap-2 cursor-pointer px-4 py-2 border rounded whitespace-nowrap transition-all ${isSelected ? "border-gray-500 bg-gray-100" : "border-gray-300 hover:bg-gray-50"
                    }`}
                >
                  <input
                    type="radio"
                    name="color"
                    value={color_name}
                    checked={isSelected}
                    onChange={(e) => setSelectedColor(e.target.value)}
                    className="hidden"
                  />
                  <span
                    className="w-6 h-6 rounded-full border-2 border-gray-300"
                    style={{ backgroundColor: hex_value }}
                  ></span>
                  {color_name.charAt(0).toUpperCase() + color_name.slice(1)}
                </label>
              );
            })}
          </div>
        </div>

        {/* Pattern Selection */}
        <div className="flex items-center gap-4">
          <label className="font-semibold text-gray-700 w-40">Pattern</label>
          <div className="flex gap-4 flex-wrap">
            {patternOptions.map((patternObj) => (
              <label
                key={patternObj.id}
                className="px-4 py-2 border border-gray-300 rounded cursor-pointer hover:bg-purple-50 whitespace-nowrap flex items-center"
              >
                <input
                  type="radio"
                  name="pattern"
                  value={patternObj.pattern}
                  checked={selectedPattern === patternObj.pattern}
                  onChange={(e) => setSelectedPattern(e.target.value)}
                  className="mr-2"
                />
                {patternObj.pattern}
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* General Info */}
      <div className="bg-white p-6 rounded-lg border space-y-6">
        <h2 className="text-base font-semibold mb-4">General Info</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Manufacturer Name */}
          <div>
            <label className="block font-semibold mb-1 text-gray-700">
              Manufacturer Name
            </label>
            <select
              value={manufacturerName}
              onChange={(e) => setManufacturerName(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
            >
              <option value="">Select a manufacturer</option>
              {manufacturers.map((mfr) => (
                <option key={mfr.id} value={mfr.manufacturer_name}>
                  {mfr.manufacturer_name}
                </option>
              ))}
            </select>
            {errors.manufacturerName && (
              <p className="text-red-500 text-sm mt-1">{errors.manufacturerName}</p>
            )}
          </div>

          {/* Manufacturer Brand */}
          <div>
            <label className="block font-semibold mb-1 text-gray-700">
              Manufacturer Brand
            </label>
            <select
              value={manufacturerBrand}
              onChange={(e) => setManufacturerBrand(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
            >
              <option value="">Select a brand</option>
              {brands.map((brand) => (
                <option key={brand.id} value={brand.brand_name}>
                  {brand.brand_name} ({brand.manufacturer_name})
                </option>
              ))}
            </select>
            {errors.manufacturerBrand && (
              <p className="text-red-500 text-sm mt-1">{errors.manufacturerBrand}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <label className="block font-semibold mb-1 text-gray-700">Stock</label>
            <input
              type="number"
              value={stock}
              onChange={(e) => setStock(e.target.value)}
              placeholder="Stock"
              className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
            />
            {errors.stock && (
              <p className="text-red-500 text-sm mt-1">{errors.stock}</p>
            )}
          </div>
          <div>
            <label className="block font-semibold mb-1 text-gray-700">Price</label>
            <div className="flex items-center border border-gray-300 rounded">
              <span className="px-3 bg-gray-100 text-gray-600">$</span>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="Enter price"
                className="w-full px-2 py-2 focus:outline-none"
              />
            </div>
            {errors.price && (
              <p className="text-red-500 text-sm mt-1">{errors.price}</p>
            )}
          </div>
          <div>
            <label className="block font-semibold mb-1 text-gray-700">GST</label>
            <div className="flex items-center border border-gray-300 rounded">
              <select
                value={gst}
                onChange={(e) => setGst(e.target.value)}
                className="w-full px-2 py-2 focus:outline-none rounded-l border-none"
              >
                <option value="">Select GST</option>
                {Array.isArray(gstList) &&
                  gstList.map((g) => (
                    <option key={g.id} value={g.gst}>
                      {g.gst}%
                    </option>
                  ))}
              </select>
              <span className="px-3 bg-gray-100 text-gray-600">%</span>
            </div>
          </div>
          <div>
            <label className="block font-semibold mb-1 text-gray-700">Discount</label>
            <div className="flex items-center border border-gray-300 rounded">
              <input
                type="number"
                placeholder="Enter discount"
                value={discount}
                onChange={(e) => setDiscount(e.target.value)}
                className="w-full px-2 py-2 focus:outline-none"
              />
              <span className="px-3 bg-gray-100 text-gray-600">%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Meta Data */}
      <div className="bg-white p-6 rounded-lg border space-y-6">
        <h2 className="text-lg font-semibold">Meta Data</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block font-semibold mb-1 text-gray-700">Meta Title</label>
            <input
              type="text"
              placeholder="Enter meta title"
              value={metaTitle}
              onChange={(e) => setMetaTitle(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
            />
            {errors.metaTitle && (
              <p className="text-red-500 text-sm mt-1">{errors.metaTitle}</p>
            )}
          </div>
          <div>
            <label className="block font-semibold mb-1 text-gray-700">Meta Keywords</label>
            <input
              type="text"
              placeholder="Enter meta keywords"
              value={metaKeywords}
              onChange={(e) => setMetaKeywords(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500"
            />
            {errors.metaKeywords && (
              <p className="text-red-500 text-sm mt-1">{errors.metaKeywords}</p>
            )}
          </div>
        </div>
        <div>
          <label className="block font-semibold mb-1 text-gray-700">Meta Description</label>
          <textarea
            rows={3}
            placeholder="Enter meta description"
            value={metaDescription}
            onChange={(e) => setMetaDescription(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded resize-none focus:ring-2 focus:ring-purple-500"
          />
          {errors.metaDescription && (
            <p className="text-red-500 text-sm mt-1">{errors.metaDescription}</p>
          )}
        </div>
      </div>

      {/* Submit Button */}
      <div>
        <Button type="submit">Submit</Button>
      </div>
    </form>
  );
}