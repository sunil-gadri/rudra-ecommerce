import { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";

export default function ParentCategory() {
  const [formData, setFormData] = useState({ name: "" });
  const [editFormData, setEditFormData] = useState({ name: "" });
  const [editId, setEditId] = useState(null);
  const [categories, setCategories] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const res = await axiosInstance.get("/parent-categories");
      setCategories(res.data);
    } catch (error) {
      console.error("Error fetching parent categories:", error);
    }
  };

  const handleChange = (e) => {
    let value = e.target.value;

    if (value.length > 0) {
      value = value.charAt(0).toUpperCase() + value.slice(1);
    }

    setFormData({ name: value });
  };

  const handleEditChange = (e) => {
    let value = e.target.value;

    if (value.length > 0) {
      value = value.charAt(0).toUpperCase() + value.slice(1);
    }

    setEditFormData({ name: value });
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name.trim()) return alert("Please enter a parent category name.");

    const payload = new FormData();
    payload.append("name", formData.name.trim());

    try {
      await axiosInstance.post("/parent-categories?page=1&limit=10", payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setFormData({ name: "" });
      fetchCategories();
      toast({
        title: "Parent category created",
        description: "New parent category added",
      });
    } catch (error) {
      console.error("Error saving parent category:", error);
      alert("Failed to save parent category.");
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!editFormData.name.trim()) return alert("Please enter a parent category name.");

    const payload = new FormData();
    payload.append("name", editFormData.name.trim());

    try {
      await axiosInstance.put(`/parent-categories/${editId}`, payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setIsDialogOpen(false);
      setEditId(null);
      fetchCategories();
      toast({ title: "Parent Category Updated", description: "Changes saved." });
    } catch (error) {
      console.error("Error updating parent category:", error);
      alert("Failed to update parent category.");
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const startEdit = (category) => {
    setEditFormData({ name: category.name });
    setEditId(category.id);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this parent category?")) return;

    try {
      await axiosInstance.delete(`/parent-categories/${id}`);
      fetchCategories();
      toast({
        title: "Product deleted",
        description: "Product has been successfully deleted.",
      });
    }
    catch (error) {
      console.error("Error deleting parent category:", error);
      alert("Failed to delete parent category.");
      toast({
        title: "Error",
        description: "Something went wrong while deleting the product.",
        variant: "destructive",
      });
    }
  };

  const filteredCategories = categories.filter((category) => {
    const term = searchTerm.toLowerCase();
    return (
      category.id?.toString().includes(term) ||
      (category.name?.toLowerCase() ?? "").includes(term)
    );
  });

  return (
    <div className="space-y-6">
      <form
        onSubmit={handleSubmit}
        className="space-y-6"
      >
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Add Parent Category</h1>
          <p className="text-muted-foreground">
            Manage and configure parent category details
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg border space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1">
                Parent Category Name
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Enter parent category name"
                className="form-input w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>
          </div>
          <div>
            <Button type="submit">Save</Button>
          </div>
        </div>
      </form>

      {/* === CATEGORY TABLE === */}
      <Card>
        <CardHeader>
          <CardTitle>All Parent Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search parent categories..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="border rounded-md">
            {/* Fixed Header */}
            <Table className="w-full table-fixed">
              <TableHeader>
                <TableRow className="bg-gray-50 text-gray-700 text-center sticky top-0 z-10">
                  <TableHead className="text-center w-[30%]">Id</TableHead>
                  <TableHead className="text-center w-[40%]">Name</TableHead>
                  <TableHead className="text-center w-[32%]">Action</TableHead>
                </TableRow>
              </TableHeader>
            </Table>

            {/* Scrollable Body */}
            <div className="max-h-96 overflow-y-auto overflow-x-auto">
              <Table className="w-full table-fixed">
                <TableBody>
                  {filteredCategories.length > 0 ? (
                    filteredCategories.map((category) => (
                      <TableRow key={category.id}>
                        <TableCell className="text-center align-middle font-medium text-muted-foreground w-[30%]">
                          {category.id}
                        </TableCell>
                        <TableCell className="text-center align-middle w-[40%]">
                          <div className="flex flex-col items-center">
                            <span className="font-medium text-gray-800">
                              {category.name}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center align-middle w-[30%]">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="icon" variant="ghost">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => startEdit(category)}>
                                <Edit className="w-4 h-4 mr-2" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => handleDelete(category.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 mr-2" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={3}
                        className="text-center py-6 text-gray-500 w-full"
                      >
                        No parent categories found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* === EDIT DIALOG === */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Parent Category</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1">
                Parent Category Name
              </label>
              <input
                type="text"
                name="name"
                value={editFormData.name}
                onChange={handleEditChange}
                required
                placeholder="Enter parent category name"
                className="form-input w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>

            <DialogFooter className="pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-primary text-white hover:bg-primary/90"
              >
                Update Parent Category
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}