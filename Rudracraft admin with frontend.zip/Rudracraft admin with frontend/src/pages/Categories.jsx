import { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  MoreHorizontal,
  Folder,
  Package,
  Eye,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DateRange } from "react-date-range";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import ExcelJS from "exceljs";
import imageCompression from "browser-image-compression";
import { IMAGE_BASE_URL } from "../utils/imagesUrl";

export default function Categories() {
  const [categories, setCategories] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [parentCategories, setParentCategories] = useState([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const [createFormData, setCreateFormData] = useState({
    name: "",
    image: null,
    preview: undefined,
    description: "",
    parent_category: "",
    status: "Active",
  });

  const [editFormData, setEditFormData] = useState({
    id: null,
    name: "",
    image: null,
    preview: undefined,
    description: "",
    parent_category: "",
    status: "Active",
  });

  const { toast } = useToast();

  useEffect(() => {
    fetchCategories();
    fetchParentCategories();
  }, []);

  useEffect(() => {
    return () => {
      if (createFormData.preview) {
        URL.revokeObjectURL(createFormData.preview);
      }
      if (editFormData.preview) {
        URL.revokeObjectURL(editFormData.preview);
      }
    };
  }, [createFormData.preview, editFormData.preview]);

  const fetchParentCategories = async () => {
    try {
      const res = await axiosInstance.get("parent-categories");
      setParentCategories(res.data);
    } catch (err) {
      console.error("Error fetching parent categories:", err);
    }
  };

  useEffect(() => {
    if (isCreateDialogOpen || isEditDialogOpen) {
      axiosInstance
        .get("parent-categories")
        .then((res) => setParentCategories(res.data))
        .catch((err) =>
          console.error("Error fetching parent categories:", err)
        );
    }
  }, [isCreateDialogOpen, isEditDialogOpen]);

  const fetchCategories = async () => {
    try {
      const response = await axiosInstance.get("categories");
      const data = response.data.map((cat) => ({
        ...cat,
        productCount: cat.productCount ?? 0,
      }));
      setCategories(data);
      console.log("Fetched categories:", data);
    } catch (err) {
      console.error("Failed to fetch categories:", err);
    }
  };

  const getCategoryNameById = (id) => {
    const parentCategory = parentCategories.find(
      (cat) => cat.id.toString() === id?.toString()
    );
    return parentCategory ? parentCategory.name : "N/A";
  };

  const getImageUrl = (path) => {
    if (path && path.startsWith("http")) {
      return path;
    } else {
      return `${IMAGE_BASE_URL}${path}`;
    }
  };

  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData();
    form.append("name", createFormData.name);

    if (createFormData.image) {
      const compressedImage = await compressImage(createFormData.image);
      form.append("image", compressedImage, compressedImage.name);
    }

    form.append("description", createFormData.description);
    form.append("status", createFormData.status);
    form.append("parent_category", createFormData.parent_category || "");

    try {
      await axiosInstance.post("categories", form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast({ title: "Category created" });
      fetchCategories();
      setIsCreateDialogOpen(false);
      setCreateFormData({
        name: "",
        image: null,
        preview: undefined,
        description: "",
        parent_category: "",
        status: "Active",
      });
    } catch (error) {
      toast({
        title: "Error",
        description:
          error?.response?.data?.message || "Failed to create category.",
        variant: "destructive",
      });
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData();
    form.append("name", editFormData.name);

    if (editFormData.image) {
      const compressedImage = await compressImage(editFormData.image);
      form.append("image", compressedImage, compressedImage.name);
    }

    form.append("description", editFormData.description);
    form.append("status", editFormData.status);
    form.append("parent_category", editFormData.parent_category || "");

    try {
      await axiosInstance.put(`categories/${editFormData.id}`, form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast({ title: "Category updated" });
      fetchCategories();
      setIsEditDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description:
          error?.response?.data?.message || "Failed to update category.",
        variant: "destructive",
      });
    }
  };

  const handleEditCategory = (category) => {
    setEditFormData({
      id: category.id,
      name: category.name,
      image: null,
      preview: category.image_url ? getImageUrl(category.image_url) : undefined,
      description: category.description,
      parent_category: category.parent_category || "",
      status: category.status,
    });
    setIsEditDialogOpen(true);
  };

  const handleDeleteCategory = async (id) => {
    const hasChildren = categories.some((cat) => cat.parent_category === id);
    if (hasChildren) {
      toast({
        title: "Cannot delete category",
        description: "This category has subcategories. Delete them first.",
        variant: "destructive",
      });
      return;
    }
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this category?"
    );
    if (!confirmDelete) return;

    try {
      await axiosInstance.delete(`categories/${id}`);
      toast({ title: "Category deleted" });
      fetchCategories();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete category.",
        variant: "destructive",
      });
    }
  };

  const compressImage = async (file) => {
    try {
      const compressedFile = await imageCompression(file, {
        maxSizeMB: 0.03,
        maxWidthOrHeight: 1024,
        useWebWorker: true,
      });
      return compressedFile;
    } catch (error) {
      console.error("Image compression error:", error);
      return file;
    }
  };

  const getStatusBadge = (status) => {
    return status === "Active" ? (
      <Badge variant="default" className="bg-success text-success-foreground">
        Active
      </Badge>
    ) : (
      <Badge variant="destructive">Inactive</Badge>
    );
  };

  const filteredCategories = categories.filter(
    (cat) =>
      cat.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cat.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cat.parent_category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cat.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalCategories = categories.length;
  const activeCategories = categories.filter(
    (c) => c.status === "Active"
  ).length;
  const totalProducts = categories.reduce((sum, c) => sum + c.productCount, 0);
  const parentCategoriesCount = categories.filter(
    (c) => c.parent_category === null
  ).length;

  const renderCategoryFormFields = (formData, setFormData) => (
    <div className="grid gap-4 py-4">
      <div className="grid grid-cols-4 items-center gap-4">
        <Label htmlFor="name" className="text-right">
          Name
        </Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) =>
            setFormData({
              ...formData,
              name: capitalizeFirstLetter(e.target.value)
            })
          }
          className="col-span-3"
          required
        />
      </div>

      <div className="grid grid-cols-4 items-center gap-4">
        <Label htmlFor="image" className="text-right">
          Image
        </Label>
        <div className="col-span-3 space-y-2">
          <Input
            id="image"
            type="file"
            accept="image/*"
            onChange={(e) => {
              const file = e.target.files[0];
              if (file) {
                const preview = URL.createObjectURL(file);
                setFormData({ ...formData, image: file, preview });
              }
            }}
          />
          {formData.preview && (
            <img
              src={formData.preview}
              alt="Preview"
              className="w-20 h-20 rounded-full object-cover"
            />
          )}
        </div>
      </div>

      <div className="grid grid-cols-4 items-center gap-4">
        <Label htmlFor="description" className="text-right">
          Description
        </Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) =>
            setFormData({
              ...formData,
              description: capitalizeFirstLetter(e.target.value)
            })
          }
          className="col-span-3"
          required
        />
      </div>

      <div className="grid grid-cols-4 items-center gap-4">
        <Label htmlFor="parent_category" className="text-right">
          Parent Category
        </Label>
        <Select
          value={formData.parent_category}
          onValueChange={(value) =>
            setFormData({
              ...formData,
              parent_category: value === "none" ? "" : value,
            })
          }
        >
          <SelectTrigger className="col-span-3">
            <SelectValue placeholder="Select parent category (optional)" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">None (Root Category)</SelectItem>
            {parentCategories.map((cat) => (
              <SelectItem key={cat.id} value={cat.id.toString()}>
                {cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-4 items-center gap-4">
        <Label htmlFor="status" className="text-right">
          Status
        </Label>
        <Select
          value={formData.status}
          onValueChange={(value) => setFormData({ ...formData, status: value })}
        >
          <SelectTrigger className="col-span-3">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Active">Active</SelectItem>
            <SelectItem value="Inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );

  const [dateRange, setDateRange] = useState([
    {
      startDate: new Date(),
      endDate: new Date(),
      key: "selection",
    },
  ]);

  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);

  const handleCopyToClipboard = () => {
    const data = filteredCategories
      .map((cat) => `${cat.id}, ${cat.name}, ${cat.description}`)
      .join("\n");

    if (navigator.clipboard) {
      navigator.clipboard
        .writeText(data)
        .then(() => toast({ title: "Copied to clipboard" }))
        .catch((err) => {
          toast({ title: "Failed to copy", description: err.message });
          console.error("Clipboard error:", err);
        });
    } else {
      // Fallback for older browsers
      const textarea = document.createElement("textarea");
      textarea.value = data;
      textarea.style.position = "fixed"; // Prevent scrolling
      document.body.appendChild(textarea);

      textarea.focus();
      textarea.select();

      try {
        document.execCommand("copy");
        toast({ title: "Copied to clipboard" });
      } catch (err) {
        toast({ title: "Failed to copy", description: err.message });
        console.error("Fallback copy failed:", err);
      }

      document.body.removeChild(textarea);
    }

    setShowExportMenu(false);
  };

  const handleExportExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Categories");

    worksheet.columns = [
      { header: "ID", key: "id" },
      { header: "Name", key: "name" },
      { header: "Description", key: "description" },
    ];

    worksheet.addRows(filteredCategories);

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    saveAs(blob, "categories.xlsx");
    setShowExportMenu(false);
  };

  const handleExportCSV = () => {
    const worksheet = XLSX.utils.json_to_sheet(filteredCategories);
    const csv = XLSX.utils.sheet_to_csv(worksheet);

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "categories.csv");

    setShowExportMenu(false);
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();

    // Title
    doc.text("Categories Report", 14, 15);

    // Table headers
    const headers = [["ID", "Name", "Description"]];

    // Table rows
    const data = filteredCategories.map((cat) => [
      cat.id,
      cat.name,
      cat.description,
    ]);

    doc.save("categories.pdf");
    toast({ title: "Exported as PDF" });

    setShowExportMenu(false);
  };

  const isTodayRange = (startDate, endDate) => {
    const today = new Date();
    return (
      startDate.toDateString() === today.toDateString() &&
      endDate.toDateString() === today.toDateString()
    );
  };

  const capitalizeFirstLetter = (text) => {
    if (!text) return "";
    return text.charAt(0).toUpperCase() + text.slice(1);
  };


  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Categories</h1>
          <p className="text-muted-foreground">
            Organize your products with hierarchical categories
          </p>
        </div>

        {/* create dialog box */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Category
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleCreateSubmit}>
              <DialogHeader>
                <DialogTitle>Add Category</DialogTitle>
                <DialogDescription>Create a new category</DialogDescription>
              </DialogHeader>
              {renderCategoryFormFields(createFormData, setCreateFormData)}
              <DialogFooter>
                <Button type="submit">Create</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* edit dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <form onSubmit={handleEditSubmit}>
              <DialogHeader>
                <DialogTitle>Edit Category</DialogTitle>
                <DialogDescription>Update category details</DialogDescription>
              </DialogHeader>
              {renderCategoryFormFields(editFormData, setEditFormData)}
              <DialogFooter>
                <Button type="submit">Update</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

     <div className="w-full">
        <div className="flex flex-col gap-3 md:flex-row md:flex-wrap">
          {/* Total Categories */}
          <Card className="flex-1 min-w-full sm:min-w-[180px]">
            <div className="p-3 flex items-center w-full rounded-lg gap-2">
              <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
                <Folder className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-xs mb-0.5 font-medium text-muted-foreground">
                  Total Categories
                </h6>
                <p className="text-base font-bold leading-none">
                  {totalCategories}
                </p>
              </div>
            </div>
          </Card>

          {/* Active Categories */}
          <Card className="flex-1 min-w-full sm:min-w-[180px]">
            <div className="p-3 flex items-center w-full rounded-lg gap-2">
              <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
                <Eye className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-xs mb-0.5 font-medium text-muted-foreground">
                  Active Categories
                </h6>
                <p className="text-base font-bold leading-none">
                  {activeCategories}
                </p>
              </div>
            </div>
          </Card>

          {/* Total Products */}
          <Card className="flex-1 min-w-full sm:min-w-[180px]">
            <div className="p-3 flex items-center w-full rounded-lg gap-2">
              <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
                <Package className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-xs mb-0.5 font-medium text-muted-foreground">
                  Total Products
                </h6>
                <p className="text-base font-bold leading-none">
                  {totalProducts}
                </p>
              </div>
            </div>
          </Card>

          {/* Root Categories */}
          <Card className="flex-1 min-w-full sm:min-w-[180px]">
            <div className="p-3 flex items-center w-full rounded-lg gap-2">
              <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
                <Folder className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-xs mb-0.5 font-medium text-muted-foreground">
                  Root Categories
                </h6>
                <p className="text-base font-bold leading-none">
                  {parentCategoriesCount}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Category Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Categories ({filteredCategories.length})</CardTitle>
        </CardHeader>

        <CardContent>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            {/* Left Section - Search Bar */}
            <div className="flex items-center gap-2">
              <div className="relative max-w-sm">
                <div className="">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search customers..."
                    className="pl-10 w-64"
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Right Section - Date Picker and Export */}
            <div className="flex items-center gap-2 ml-auto">
              {/* Date Range Picker */}
              <div className="relative">
                <Input
                  className="max-w-[250px] cursor-pointer"
                  readOnly
                  value={
                    isTodayRange(dateRange[0].startDate, dateRange[0].endDate)
                      ? "Today"
                      : `${dateRange[0].startDate.toLocaleDateString()} - ${dateRange[0].endDate.toLocaleDateString()}`
                  }
                  onClick={() => setShowDatePicker(!showDatePicker)}
                />
                {showDatePicker && (
                  <div className="absolute z-50 mt-2 shadow-lg border rounded bg-white">
                    <DateRange
                      editableDateInputs={true}
                      onChange={(item) => setDateRange([item.selection])}
                      moveRangeOnFirstSelection={false}
                      ranges={dateRange}
                      maxDate={new Date()}
                    />
                  </div>
                )}
              </div>

              {/* Export Report Button */}
              <div className="relative">
                <Button onClick={() => setShowExportMenu(!showExportMenu)}>
                  Export Report
                </Button>

                {showExportMenu && (
                  <div className="absolute right-0 mt-2 z-40 bg-white border rounded shadow-md w-48">
                    <div className="p-2 text-sm">
                      <div
                        className="cursor-pointer px-3 py-2 hover:bg-gray-100"
                        onClick={handleCopyToClipboard}
                      >
                        Copy to clipboard
                      </div>
                      <div
                        className="cursor-pointer px-3 py-2 hover:bg-gray-100"
                        onClick={handleExportExcel}
                      >
                        Export as Excel
                      </div>
                      <div
                        className="cursor-pointer px-3 py-2 hover:bg-gray-100"
                        onClick={handleExportCSV}
                      >
                        Export as CSV
                      </div>
                      <div
                        className="cursor-pointer px-3 py-2 hover:bg-gray-100"
                        onClick={handleExportPDF}
                      >
                        Export as PDF
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

        <div className="border rounded-lg shadow-sm overflow-hidden">
            {/* Scrollable Container */}
            <div className="max-h-[450px] overflow-y-auto overflow-x-auto">
              <table className="w-full table-fixed border-collapse">
                {/* Sticky Header */}
                <thead className="sticky top-0 z-20 bg-gray-100">
                  <tr className="text-gray-700 text-xs">
                    <th className="w-[8%] py-3 px-2 text-center font-semibold text-xs">ID</th>
                    <th className="w-[13%] py-3 px-2 text-center font-semibold text-xs">Name</th>
                    <th className="w-[15%] py-3 px-2 text-center font-semibold text-xs">Image</th>
                    <th className="w-[20%] py-3 px-2 text-center font-semibold text-xs">Description</th>
                    <th className="w-[15%] py-3 px-2 text-center font-semibold text-xs">Parent Category</th>
                    <th className="w-[11%] py-3 px-2 text-center font-semibold text-xs">Status</th>
                    <th className="w-[12%] py-3 px-2 text-center font-semibold text-xs">Action</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredCategories.map((category) => (
                    <tr
                      key={category.id}
                      className="hover:bg-gray-50 transition duration-150 border-b last:border-0 text-xs"
                    >
                      {/* ID */}
                      <td className="text-center py-3 px-2 font-medium text-gray-600 text-xs">
                        {category.id}
                      </td>

                      {/* Name */}
                      <td className="text-center py-3 px-2 text-xs">
                        <span className="font-semibold text-gray-800">
                          {category.name}
                        </span>
                      </td>

                      {/* Image */}
                      <td className="text-center py-3 px-2 text-xs">
                        {category.image_url ? (
                          <img
                            src={getImageUrl(category.image_url)}
                            alt={category.name}
                            className="w-10 h-10 rounded-full object-cover mx-auto border shadow-sm"
                          />
                        ) : (
                          <span className="text-xs text-gray-400 italic">No image</span>
                        )}
                      </td>

                      {/* Description */}
                      <td className="text-center py-3 px-2 text-gray-700 text-xs">
                        {category.description || (
                          <span className="text-gray-400 italic">No description</span>
                        )}
                      </td>

                      {/* Parent Category */}
                      <td className="text-center py-3 px-2 text-gray-700 text-xs">
                        {getCategoryNameById(category.parent_category)}
                      </td>

                      {/* Status */}
                      <td className="text-center py-3 px-2 text-xs">
                        {getStatusBadge(category.status)}
                      </td>

                      {/* Actions */}
                      <td className="text-center py-3 px-2 text-xs">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              className="h-8 w-8 p-0"
                            >
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => handleEditCategory(category)}
                              className="cursor-pointer gap-2"
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="cursor-pointer gap-2 text-red-600"
                              onClick={() => handleDeleteCategory(category.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
        </CardContent>
      </Card>
    </div>
  );
}