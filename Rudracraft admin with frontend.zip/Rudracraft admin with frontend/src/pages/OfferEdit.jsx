import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";
import { ArrowLeft } from "lucide-react";
import { IMAGE_BASE_URL } from "../utils/imagesUrl";
import Select from "react-select";
import imageCompression from "browser-image-compression"; // Added

export default function EditOffer() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [productCategories, setProductCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  const [heading, setHeading] = useState("");
  const [key, setKey] = useState("");
  const [discount, setDiscount] = useState("");
  const [price, setPrice] = useState("");

  // one entry per image
  const [details, setDetails] = useState([]);
  const [images, setImages] = useState([]); // File | string (url) | null

  // Fetch categories
  const fetchProductCategories = async () => {
    try {
      const res = await axiosInstance.get("/categories");
      const cats = Array.isArray(res.data) ? res.data : [];
      setProductCategories(cats);
    } catch (err) {
      toast({ title: "Error", description: "Failed to load categories.", variant: "destructive" });
    }
  };

  // Fetch existing offer
  const fetchOffer = async () => {
    try {
      const res = await axiosInstance.get(`/offers/${id}`);
      const offer = res.data?.success ? res.data.data : res.data;
      if (!offer) throw new Error("Offer not found");

      setHeading(offer.heading || "");
      setKey(offer.key || "");
      setDiscount(offer.discount || "");
      setPrice(offer.price || "");

      const fetched = (offer.details || []).map((d) => ({
        id: d.id || null,
        text1: d.text1 || "",
        text2: d.text2 || "",
        details_heading: d.details_heading || "",
        category_names: Array.isArray(d.categories) ? d.categories : [],
        product_category_ids: [],
        image_url: d.image_url || "",
      }));

      const fetchedImgs = (offer.details || []).map((d) => d.image_url || null);
      setDetails(fetched);
      setImages(fetchedImgs);
    } catch (err) {
      toast({ title: "Error", description: err.message || "Failed to load offer.", variant: "destructive" });
      navigate("/offers");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProductCategories();
    if (id) fetchOffer();
  }, [id]);

  // Map category names → IDs once categories are loaded
  useEffect(() => {
    if (!productCategories.length || !details.length) return;

    setDetails((prevDetails) =>
      prevDetails.map((detail) => {
        if (!detail.category_names?.length) return { ...detail, product_category_ids: [] };

        const ids = detail.category_names
          .map((name) => {
            const cat = productCategories.find(
              (c) => c.name.trim().toLowerCase() === name.trim().toLowerCase()
            );
            return cat ? String(cat.id) : null;
          })
          .filter(Boolean);

        return { ...detail, product_category_ids: ids };
      })
    );
  }, [productCategories, details]);

  const addDetail = () => {
    setDetails((prev) => [
      ...prev,
      { text1: "", text2: "", details_heading: "", product_category_ids: [], image_url: "" },
    ]);
    setImages((prev) => [...prev, null]);
  };

  const removeDetail = (idx) => {
    setDetails((prev) => prev.filter((_, i) => i !== idx));
    setImages((prev) => prev.filter((_, i) => i !== idx));
  };

  const updateDetail = (idx, field, value) => {
    setDetails((prev) => {
      const copy = [...prev];
      copy[idx] = { ...copy[idx], [field]: value };
      return copy;
    });
  };

  // Updated: With image compression
  const handleImageChange = async (idx, file) => {
    if (!file) {
      setImages((prev) => {
        const copy = [...prev];
        copy[idx] = null;
        return copy;
      });
      return;
    }

    toast({
      title: "Compressing image...",
      description: "Optimizing for fast upload (~30KB)",
    });

    try {
      const options = {
        maxSizeMB: 0.03,              // ≤30KB
        maxWidthOrHeight: 1024,
        useWebWorker: true,
        fileType: "image/webp",       // Best compression + modern format
        initialQuality: 0.8,
      };

      const compressedFile = await imageCompression(file, options);

      const finalFile = new File(
        [compressedFile],
        file.name.split(".").slice(0, -1).join(".") + ".webp",
        { type: "image/webp", lastModified: Date.now() }
      );

      setImages((prev) => {
        const copy = [...prev];
        copy[idx] = finalFile;
        return copy;
      });

      toast({
        title: "Image ready!",
        description: `${(finalFile.size / 1024).toFixed(1)} KB (WebP)`,
      });
    } catch (error) {
      console.error("Image compression failed:", error);
      toast({
        title: "Compression failed",
        description: "Using original image",
        variant: "destructive",
      });

      // Fallback to original
      setImages((prev) => {
        const copy = [...prev];
        copy[idx] = file;
        return copy;
      });
    }
  };

  const handleSubmit = async () => {
    if (!heading.trim() || !key.trim()) {
      toast({ title: "Error", description: "Heading and Key are required.", variant: "destructive" });
      return;
    }

    const formData = new FormData();
    formData.append("heading", heading);
    formData.append("key", key);
    formData.append("discount", discount || "");
    formData.append("price", price || "");

    formData.append(
      "details",
      JSON.stringify(
        details.map((d) => ({
          id: d.id || undefined,
          text1: d.text1,
          text2: d.text2,
          details_heading: d.details_heading || "",
          product_category_ids: Array.isArray(d.product_category_ids)
            ? d.product_category_ids.join(",")
            : d.product_category_ids,
        }))
      )
    );

    images.forEach((img, i) => {
      if (img instanceof File) {
        formData.append(`image${i}`, img);
      }
    });

    try {
      await axiosInstance.put(`/offers/${id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      toast({ title: "Success", description: "Offer updated successfully." });
      navigate("/offers");
    } catch (err) {
      toast({
        title: "Error",
        description: err.response?.data?.message || "Failed to update offer.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-purple-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Edit Offer</h1>
          <p className="text-muted-foreground">Update the offer details</p>
        </div>
        <Button onClick={() => navigate("/offers")}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Offers
        </Button>
      </div>

      <div className="bg-white p-6 rounded-lg shadow space-y-6">
        {/* Basic Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="heading">Heading</Label>
            <Input
              id="heading"
              value={heading}
              onChange={(e) => setHeading(e.target.value)}
              placeholder="e.g. Summer Sale"
            />
          </div>
          <div>
            <Label htmlFor="key">Key</Label>
            <Input
              id="key"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="e.g. summer-sale"
            />
          </div>
          <div>
            <Label htmlFor="discount">Discount (%)</Label>
            <Input
              id="discount"
              value={discount}
              onChange={(e) => setDiscount(e.target.value)}
              placeholder="20"
            />
          </div>
          <div>
            <Label htmlFor="price">Price</Label>
            <Input
              id="price"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="1999"
            />
          </div>
        </div>

        {/* Details */}
        {details.map((detail, idx) => (
          <div key={idx} className="border p-5 rounded-lg space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold text-lg">Detail {idx + 1}</h3>
              {details.length > 1 && (
                <Button variant="destructive" size="sm" onClick={() => removeDetail(idx)}>
                  Remove
                </Button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Text 1</Label>
                <Input
                  value={detail.text1}
                  onChange={(e) => updateDetail(idx, "text1", e.target.value)}
                  placeholder="e.g. Buy 1"
                />
              </div>

              <div>
                <Label>Text 2</Label>
                <Input
                  value={detail.text2}
                  onChange={(e) => updateDetail(idx, "text2", e.target.value)}
                  placeholder="e.g. Get 1 Free"
                />
              </div>

              <div>
                <Label htmlFor={`details-heading-${idx}`}>Details Heading</Label>
                <Input
                  id={`details-heading-${idx}`}
                  value={detail.details_heading || ""}
                  onChange={(e) => updateDetail(idx, "details_heading", e.target.value)}
                  placeholder="e.g. Special Deal"
                />
              </div>

              <div>
                <Label>Product Categories</Label>
                <Select
                  isMulti
                  options={productCategories.map((c) => ({
                    value: String(c.id),
                    label: c.name,
                  }))}
                  value={detail.product_category_ids.map((id) => {
                    const cat = productCategories.find((c) => String(c.id) === id);
                    return cat ? { value: id, label: cat.name } : null;
                  }).filter(Boolean)}
                  onChange={(selected) =>
                    updateDetail(
                      idx,
                      "product_category_ids",
                      selected.map((opt) => opt.value)
                    )
                  }
                  placeholder="Select categories"
                  className="basic-multi-select"
                  classNamePrefix="select"
                />
              </div>

              {/* Image Upload */}
              <div className="md:col-span-2 space-y-3">
                <Label>Image</Label>
                <Input
                  type="file"
                  accept="image/*"
                  key={images[idx]?.name || idx} // Reset input on change
                  onChange={(e) => {
                    const file = e.target.files?.[0] ?? null;
                    if (file) handleImageChange(idx, file);
                  }}
                />

                {/* Preview */}
                {images[idx] && typeof images[idx] === "string" && (
                  <div className="mt-2">
                    <img
                      src={images[idx].startsWith("http") ? images[idx] : `${IMAGE_BASE_URL}${images[idx]}`}
                      alt={`Detail ${idx + 1}`}
                      className="w-full max-h-48 object-contain rounded border bg-gray-50"
                    />
                    <p className="text-xs text-gray-500 mt-1">Current image</p>
                  </div>
                )}

                {images[idx] instanceof File && (
                  <div className="mt-2">
                    <img
                      src={URL.createObjectURL(images[idx])}
                      alt="Preview"
                      className="w-full max-h-48 object-contain rounded border bg-gray-50"
                    />
                    <p className="text-xs text-green-600 mt-1">
                      New: {(images[idx].size / 1024).toFixed(1)} KB (compressed)
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}

        <Button variant="outline" onClick={addDetail}>
          Add Another Detail
        </Button>

        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={() => navigate("/offers")}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>Update Offer</Button>
        </div>
      </div>
    </div>
  );
}