import { useEffect, useState } from "react";
import axiosInstance from "../utils/axios";

export default function Profile() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem("token");

        const response = await axiosInstance.get("user-profile", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        // API returns an array, so take the first object
        setProfile(response.data[0]);
      } catch (err) {
        console.error("Error fetching profile:", err);
        setError("Failed to load profile");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  if (loading) return <p className="text-gray-600">Loading profile...</p>;
  if (error) return <p className="text-red-500">{error}</p>;

  return (
    <div className="p-6 bg-white shadow rounded-lg max-w-md">
      <h1 className="text-blue-950 text-2xl font-bold mb-4">User Profile</h1>
      {profile ? (
        <div className="space-y-2">
          <p>
            <span className="font-semibold">Name:</span>{" "}
            {profile.first_name} {profile.last_name}
          </p>
          <p>
            <span className="font-semibold">Email:</span> {profile.email}
          </p>
          <p>
            <span className="font-semibold">Gender:</span> {profile.gender}
          </p>
          <p>
            <span className="font-semibold">Phone:</span> {profile.phone}
          </p>
          <p>
            <span className="font-semibold">Status:</span> {profile.status}
          </p>
          <img
            src={profile.profile_image_url}
            alt="Profile"
            className="w-32 h-32 rounded-full object-cover mt-4 "
          />
        </div>
      ) : (
        <p className="text-gray-600">No profile data found.</p>
      )}
    </div>
  );
}
