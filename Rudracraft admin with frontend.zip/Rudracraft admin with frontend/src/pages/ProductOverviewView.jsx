import React, { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useNavigate, useParams } from "react-router-dom";
import { Loader2, Edit3, ArrowLeft, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"; // Make sure you have this component

export default function ProductOverviewView() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [overviewData, setOverviewData] = useState(null);
  const [productTitle, setProductTitle] = useState("Loading...");
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);

        const overviewRes = await axiosInstance.get(`/product-description/product/${id}`);
        const item = overviewRes.data?.data || overviewRes.data;

        if (!item) {
          toast.error("No overview found for this product.");
          navigate("/product/overview");
          return;
        }

        setOverviewData(item);

        const productRes = await axiosInstance.get(`/products/${item.product_id}`);
        const product = productRes.data?.data || productRes.data;

        if (product?.title) {
          setProductTitle(product.title);
        } else {
          setProductTitle(`Product ID: ${item.product_id}`);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        toast.error("Failed to load product overview.");
        setProductTitle("Unknown Product");
        navigate("/product/overview");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, navigate]);

  const handleDelete = async () => {
    if (!overviewData?.id) return;

    try {
      setDeleting(true);
      await axiosInstance.delete(`/product-description/${overviewData.id}`);
      
      toast.success("Product overview deleted successfully.");
      navigate("/products");
    } catch (error) {
      console.error("Delete failed:", error);
      toast.error("Failed to delete overview. Please try again.");
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-50">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!overviewData) return null;

  return (
    <div className="min-h-screen bg-gray-50 p-10">
      {/* Full-width Header */}
      <div className="bg-white border-b">
        <div className="flex justify-between items-center px-6 py-5">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold">Product Overview</h1>
          </div>

          <div className="flex gap-3">
            {/* Edit Button */}
            <Button
              onClick={() => navigate(`/admin/product/overview/edit/${overviewData.id}`)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Edit3 className="h-4 w-4 mr-2" /> Edit Overview
            </Button>

            {/* Delete Button with Confirmation */}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" disabled={deleting}>
                  {deleting ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Trash2 className="h-4 w-4 mr-2" />
                  )}
                  Delete Overview
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the product overview
                    for <strong>{productTitle}</strong>.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                    {deleting ? "Deleting..." : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>

      {/* Rest of your content remains unchanged */}
      <div className="w-full">
        <div className="bg-white shadow-lg border-t">
          <div className="pt-4 pl-8 pr-8">
            <h3 className="text-2xl font-semibold text-gray-800 mb-2">Product Title</h3>
            <h3 className="text-xl">{productTitle}</h3>
          </div>

          <div className="px-8 py-10 space-y-12">
            {/* Overview */}
            <div>
              <h3 className="text-2xl font-semibold text-gray-800 mb-5">Overview</h3>
              <p className="text-lg text-gray-700 bg-gray-50 p-6 rounded-lg border">
                {overviewData.overview || "No overview available."}
              </p>
            </div>

            {/* Disclaimer */}
            {overviewData.disclaimer && (
              <div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-5">Disclaimer</h3>
                <p className="text-lg text-gray-700 bg-gray-50 p-6 rounded-lg border">
                  {overviewData.disclaimer}
                </p>
              </div>
            )}

            {/* Specifications */}
            {overviewData.specifications && Object.keys(overviewData.specifications).length > 0 ? (
              <div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-8">Specifications</h3>
                {Object.entries(overviewData.specifications).map(([heading, specs]) => (
                  <div key={heading} className="mb-12">
                    <h4 className="text-2xl font-bold text-purple-700 mb-6 border-b pb-3">
                      {heading}
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {Object.entries(specs).map(([key, value]) => (
                        <div
                          key={key}
                          className="bg-gray-50 p-5 rounded-lg border hover:shadow-md transition-shadow"
                        >
                          <dt className="text-sm font-medium text-gray-600">{key}</dt>
                          <dd className="mt-2 text-lg font-semibold text-gray-900 break-words">
                            {value}
                          </dd>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-12 text-lg">
                No specifications added.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}