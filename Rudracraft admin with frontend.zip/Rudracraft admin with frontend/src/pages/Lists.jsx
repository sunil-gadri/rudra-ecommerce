import { useState } from "react";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const mockLists = [
  {
    id: 1,
    name: "Product Categories",
    description: "Main product categorization list",
    type: "Category",
    items: 45,
    status: "Active",
    lastUpdated: "2024-01-15",
    createdBy: "Admin"
  },
  {
    id: 2,
    name: "Promotional Tags",
    description: "Tags for promotional campaigns",
    type: "Tag",
    items: 23,
    status: "Active",
    lastUpdated: "2024-01-14",
    createdBy: "Marketing Team"
  },
  {
    id: 3,
    name: "Priority Levels",
    description: "Customer priority classification",
    type: "Priority",
    items: 8,
    status: "Draft",
    lastUpdated: "2024-01-13",
    createdBy: "Support Team"
  },
  {
    id: 4,
    name: "Shipping Methods",
    description: "Available delivery options",
    type: "Shipping",
    items: 12,
    status: "Active",
    lastUpdated: "2024-01-12",
    createdBy: "Operations"
  }
];

export default function Lists() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");

  const filteredLists = mockLists.filter(list => {
    const matchesSearch = list.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         list.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === "all" || list.type.toLowerCase() === filterType.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (status) => {
    const variant = status === "Active" ? "default" : "secondary";
    return <Badge variant={variant}>{status}</Badge>;
  };

  const getTypeBadge = (type) => {
    const colors = {
      Category: "bg-blue-100 text-blue-800",
      Tag: "bg-green-100 text-green-800",
      Priority: "bg-purple-100 text-purple-800",
      Shipping: "bg-orange-100 text-orange-800"
    };
    return (
      <Badge className={colors[type] || "bg-gray-100 text-gray-800"}>
        {type}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center ">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Lists</h1>
          <p className="text-muted-foreground">Manage your system lists and categories</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Create List
        </Button>
      </div>

      <div className="flex gap-4 items-center py-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search lists..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="h-4 w-4" />
          Filters
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Lists ({filteredLists.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Updated</TableHead>
                <TableHead>Created By</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLists.map((list) => (
                <TableRow key={list.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium text-foreground">{list.name}</div>
                      <div className="text-sm text-muted-foreground">{list.description}</div>
                    </div>
                  </TableCell>
                  <TableCell>{getTypeBadge(list.type)}</TableCell>
                  <TableCell className="font-medium">{list.items}</TableCell>
                  <TableCell>{getStatusBadge(list.status)}</TableCell>
                  <TableCell className="text-muted-foreground">{list.lastUpdated}</TableCell>
                  <TableCell className="text-muted-foreground">{list.createdBy}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem className="gap-2">
                          <Eye className="h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2">
                          <Edit className="h-4 w-4" />
                          Edit List
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="gap-2 text-destructive">
                          <Trash2 className="h-4 w-4" />
                          Delete List
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}