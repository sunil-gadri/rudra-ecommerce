import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Edit, Trash2, Plus, Search, MoreHorizontal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { IMAGE_BASE_URL } from "../utils/imagesUrl";

export default function Offers() {
  const [offers, setOffers] = useState([]);
  const [filteredOffers, setFilteredOffers] = useState([]);
  const [productCategories, setProductCategories] = useState([]);
  const [imageViewerOpen, setImageViewerOpen] = useState(false);
  const [imageViewerImages, setImageViewerImages] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  const navigate = useNavigate();
  const { toast } = useToast();

  // Fetch product categories
  const fetchProductCategories = async () => {
    try {
      const response = await axiosInstance.get("/categories");
      const categories = response.data?.success
        ? response.data.data
        : Array.isArray(response.data)
          ? response.data
          : [];
      setProductCategories(categories);
    } catch (error) {
      console.error("Error fetching product categories:", error);
      toast({
        title: "Error",
        description: "Failed to fetch product categories.",
        variant: "destructive",
      });
    }
  };

  const fetchOffers = async () => {
    try {
      const response = await axiosInstance.get(`/offers`);
      console.log("Offers API response:", response.data);

      const rawOffers = response.data.offers || [];

      const formatted = rawOffers.map((o) => ({
        id: o.id,
        heading: o.heading,
        key: o.key,
        details: o.details || [],
        discount: o.discount,
        price: o.price,
        // status: "Active",
      }));

      setOffers(formatted);
      setFilteredOffers(formatted);
    } catch (error) {
      console.error("Error fetching offers:", error);
      toast({
        title: "Error",
        description: "Failed to fetch offers.",
        variant: "destructive",
      });
      setOffers([]);
      setFilteredOffers([]);
    }
  };

  useEffect(() => {
    const filtered = offers.filter((offer) => {
      const heading = offer.heading ? offer.heading.toLowerCase() : "";
      const key = offer.key ? offer.key.toLowerCase() : "";

      const detailsMatch = Array.isArray(offer.details)
        ? offer.details.some((detail) => {
          const text1 = detail.text1 ? detail.text1.toLowerCase() : "";
          const text2 = detail.text2 ? detail.text2.toLowerCase() : "";
          return `${text1} ${text2}`.includes(searchTerm.toLowerCase());
        })
        : false;

      return (
        heading.includes(searchTerm.toLowerCase()) ||
        key.includes(searchTerm.toLowerCase()) ||
        detailsMatch
      );
    });

    setFilteredOffers(filtered);
  }, [searchTerm, offers]);

  // Initial data load
  useEffect(() => {
    fetchProductCategories();
    fetchOffers();
  }, []);

  const handleDeleteOffer = async (offerId) => {
    if (!window.confirm("Are you sure you want to delete this offer?")) return;
    try {
      const response = await axiosInstance.delete(`/offers/${offerId}`);
      if (response.data) {
        toast({
          title: "Success",
          description: "Offer deleted successfully.",
        });
        await fetchOffers();
      } else {
        toast({
          title: "Error",
          description: response.data.message || "Failed to delete offer.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error deleting offer:", error);
      toast({
        title: "Error",
        description: error.response?.data?.message || "An error occurred while deleting the offer.",
        variant: "destructive",
      });
    }
  };

  // Get image URL
  const getImageUrl = (path) => {
    if (!path) return "";
    return path.startsWith("http") ? path : `${IMAGE_BASE_URL}${path}`;
  };

  // Get status badge
  const getStatusBadge = (status) => {
    if (status.toLowerCase() === "inactive") {
      return <Badge variant="destructive">Inactive</Badge>;
    }
    return <Badge variant="default" className="bg-green-500 text-white">Active</Badge>;
  };

  // Get category names from IDs
  const getCategoryNames = (categories) => {
    if (!categories || !Array.isArray(categories)) return "";
    return categories.map((cat) => cat.name).join(", ");
  };

  // Get images from details array
  const getOfferImages = (details) => {
    return (details || [])
      .filter((detail) => detail.image_url)
      .map((detail) => detail.image_url);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Offers</h1>
          <p className="text-muted-foreground">Manage your offers here</p>
        </div>
        <Button onClick={() => navigate("/admin/offers/create")}>
          <Plus className="mr-2 h-4 w-4" />
          Add Offer
        </Button>
      </div>

      <Card className="w-full">
        <CardHeader>
          <CardTitle>Offer Information ({filteredOffers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Search Bar */}
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search offers..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Offers Table */}
         <div className="border rounded-md">
            <div className="max-h-[600px] overflow-y-auto overflow-x-auto">
              <table className="table-fixed min-w-[110%] border-collapse w-full text-xs">
                <thead className="sticky top-0 z-30 bg-gray-50">
                  <tr className="text-gray-700 text-center text-xs">
                    <th className="w-[8%] sticky left-0 bg-gray-50 z-20 border-b py-3 text-xs">ID</th>
                    <th className="w-[20%] border-b py-3 text-xs">Heading</th>
                    <th className="w-[15%] border-b py-3 text-xs">Discount</th>
                    <th className="w-[15%] border-b py-3 text-xs">Price</th>
                    <th className="w-[30%] border-b py-3 text-xs">Details</th>
                    <th className="w-[15%] border-b py-3 text-xs">Key</th>
                    <th className="w-[15%] border-b py-3 text-xs">Images</th>
                    <th className="w-[12%] border-b py-3 text-xs">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOffers.length > 0 ? (
                    filteredOffers.map((offer) => (
                      <tr
                        key={offer.id}
                        className="hover:bg-gray-50 transition duration-150 text-center text-xs"
                      >
                        <td className="sticky left-0 bg-white z-10 font-medium text-muted-foreground border-b py-3 text-xs">
                          {offer.id}
                        </td>
                        <td className="text-gray-800 font-medium border-b py-3 text-xs">
                          {offer.heading}
                        </td>
                        <td className="text-gray-800 font-medium border-b py-3 text-xs">
                          {offer.discount || "-"}
                        </td>
                        <td className="text-gray-800 font-medium border-b py-3 text-xs">
                          {offer.price || "-"}
                        </td>
                        <td className="border-b py-3 text-gray-700 text-xs">
                          {offer.details?.length ? (
                            <div className="flex flex-col gap-1">
                              {offer.details.map((detail, i) => (
                                <div key={i} className="text-xs">
                                  {detail.text1} {detail.text2 && `- ${detail.text2}`}{" "}
                                  <span className="text-gray-500 text-xs">
                                    ({getCategoryNames(detail.categories)})
                                  </span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            "No details"
                          )}
                        </td>
                        <td className="border-b py-3 text-xs">{offer.key}</td>
                        <td className="border-b py-3 text-xs">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setImageViewerImages(getOfferImages(offer.details));
                              setImageViewerOpen(true);
                            }}
                            disabled={getOfferImages(offer.details).length === 0}
                            className="text-xs"
                          >
                            View ({getOfferImages(offer.details).length})
                          </Button>
                        </td>
                        <td className="border-b py-3 text-xs">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-32">
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => navigate(`/offers/edit/${offer.id}`)}
                                className="cursor-pointer gap-2 text-xs">
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleDeleteOffer(offer.id)}
                                className="cursor-pointer gap-2 text-red-600 text-xs">
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="text-center py-6 text-gray-500 text-xs">
                        {searchTerm ? "No offers match your search." : "No offers found."}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Image Viewer Dialog */}
          <Dialog open={imageViewerOpen} onOpenChange={setImageViewerOpen}>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>Offer Images</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {imageViewerImages.length ? (
                  imageViewerImages.map((src, i) => (
                    <img
                      key={i}
                      src={getImageUrl(src)}
                      alt={`Offer Image ${i + 1}`}
                      className="w-full h-48 object-contain rounded border"
                    />
                  ))
                ) : (
                  <p className="col-span-full text-center text-gray-500">
                    No images available
                  </p>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    </div>
  );
}