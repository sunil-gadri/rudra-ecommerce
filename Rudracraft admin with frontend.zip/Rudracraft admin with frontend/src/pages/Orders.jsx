import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Search, Eye, Package, DollarSign, Clock, CheckCircle, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../utils/axios";

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [pagination, setPagination] = useState({
    current_page: 1,
    total_pages: 1,
    limit: 10,
    total_orders: 0,
  });

  const navigate = useNavigate();
  const { toast } = useToast();

  const fetchOrders = async (page = 1, limit = 10, search = "") => {
    try {
      const response = await axiosInstance.get(`/orders?page=${page}&limit=${limit}&search=${encodeURIComponent(search)}`);
      console.log("Orders API response:", response.data);
      const { orders, pagination } = response.data;

      const formattedOrders = orders.map((order) => ({
        id: order.id,
        customer_name: order.customer_name,
        order_at: order.order_at,
        status: order.status.charAt(0).toUpperCase() + order.status.slice(1).toLowerCase(),
        total_amount: Number(order.total_amount) || 0,
        payment_status: order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1).toLowerCase(),
        no_of_items: order.no_of_items,
      }));

      setOrders(formattedOrders);
      setPagination({
        current_page: pagination.current_page || 1,
        total_pages: pagination.total_pages || 1,
        limit: pagination.limit || 10,
        total_orders: pagination.total_orders || orders.length,
      });
    } catch (error) {
      console.error("Error fetching orders:", error);
      toast({
        title: "Error",
        description: "Failed to fetch orders.",
        variant: "destructive",
      });
      setOrders([]);
      setPagination({
        current_page: 1,
        total_pages: 1,
        limit: 10,
        total_orders: 0,
      });
    }
  };

  useEffect(() => {
    fetchOrders(pagination.current_page, pagination.limit, searchTerm);
  }, [pagination.current_page, searchTerm]);

  const safeStr = (v) => (v === null || v === undefined) ? "" : String(v);

  const totalRevenue = orders.reduce((sum, o) => {
    const isPaid = o.payment_status.toLowerCase() === "paid";
    return sum + (isPaid ? o.total_amount : 0);
  }, 0);
  const pendingOrders = orders.filter(o => o.status.toLowerCase() === "pending").length;
  const deliveredOrders = orders.filter(o => o.status.toLowerCase() === "delivered").length;

  const statusTransitions = {
    Pending: ["Confirmed", "Cancelled"],
    Confirmed: ["Shipped", "Cancelled"],
    Shipped: ["Delivered"],
    Delivered: [],
    Cancelled: [],
  };

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      setOrders((prevOrders) =>
        prevOrders.map((order) =>
          order.id === orderId ? { ...order, status: newStatus } : order
        )
      );

      const formData = new FormData();
      formData.append("status", newStatus.toLowerCase());

      await axiosInstance.put(`/orders/${orderId}/status`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      toast({
        title: "Status Updated",
        description: `Order #${orderId} marked as ${newStatus}`,
      });
    } catch (error) {
      console.error("Failed to update status:", error);
      toast({
        title: "Update Failed",
        description: "Could not update order status. Try again.",
        variant: "destructive",
      });

      setOrders((prevOrders) =>
        prevOrders.map((order) =>
          order.id === orderId ? { ...order, status: order.status } : order
        )
      );
    }
  };

  const getInvoicePDF = (id) => {
    const url = `http://192.168.0.9:5000/invoices/${id}/download`;
    window.open(url, "_blank");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Orders</h1>
          <p className="text-muted-foreground">
            Track and manage customer orders
          </p>
        </div>
      </div>

      {/* Stats Cards */}
     <div className="w-full">
        <div className="flex flex-col gap-3 md:flex-row md:flex-wrap">
          {/* Total Orders */}
          <Card className="flex-1 min-w-full sm:min-w-[180px]">
            <div className="p-3 flex items-center w-full rounded-lg gap-2">
              <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
                <Package className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-xs mb-0.5 font-medium text-muted-foreground">
                  Total Orders
                </h6>
                <p className="text-base font-bold leading-none">{pagination.total_orders}</p>
              </div>
            </div>
          </Card>

          {/* Total Revenue */}
          <Card className="flex-1 min-w-full sm:min-w-[180px]">
            <div className="p-3 flex items-center w-full rounded-lg gap-2">
              <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-xs mb-0.5 font-medium text-muted-foreground">
                  Total Revenue
                </h6>
                <p className="text-base font-bold leading-none">
                  ${totalRevenue.toLocaleString()}
                </p>
              </div>
            </div>
          </Card>

          {/* Pending Orders */}
          <Card className="flex-1 min-w-full sm:min-w-[180px]">
            <div className="p-3 flex items-center w-full rounded-lg gap-2">
              <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
                <Clock className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-xs mb-0.5 font-medium text-muted-foreground">
                  Pending Orders
                </h6>
                <p className="text-base font-bold leading-none">{pendingOrders}</p>
              </div>
            </div>
          </Card>

          {/* Delivered Orders */}
          <Card className="flex-1 min-w-full sm:min-w-[180px]">
            <div className="p-3 flex items-center w-full rounded-lg gap-2">
              <div className="flex items-center justify-center p-2 rounded-full bg-gray-200 border flex-shrink-0">
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-xs mb-0.5 font-medium text-muted-foreground">
                  Delivered Orders
                </h6>
                <p className="text-base font-bold leading-none">{deliveredOrders}</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Orders Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Orders ({pagination.total_orders})</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Search */}
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-m
uted-foreground h-4 w-4" />
            <Input
              placeholder="Search orders..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Scrollable Table */}
        <div className="w-full overflow-x-auto">
            <div className="border rounded-md">
              <div className="max-h-[600px] overflow-y-auto overflow-x-auto">
                <table className="table-fixed min-w-[120%] border-collapse w-full text-xs">
                  <thead className="sticky top-0 z-30 bg-gray-50">
                    <tr className="text-gray-700 text-center text-xs">
                      <th className="w-[5%] sticky left-0 bg-gray-50 z-20 border-b py-2 px-1 text-xs">Id</th>
                      <th className="w-[12%] border-b py-2 px-1 text-xs">Customer</th>
                      <th className="w-[10%] border-b py-2 px-1 text-xs">Order Date</th>
                      <th className="w-[12%] border-b py-2 px-1 text-xs">Status</th>
                      <th className="w-[10%] border-b py-2 px-1 text-xs">Total Amount</th>
                      <th className="w-[12%] border-b py-2 px-1 text-xs">Payment Status</th>
                      <th className="w-[8%] border-b py-2 px-1 text-xs">Items</th>
                      <th className="w-[18%] border-b py-2 px-1 text-xs">Invoice</th>
                      <th className="w-[13%] border-b py-2 px-1 text-xs">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.length > 0 ? (
                      orders.map((order) => (
                        <tr
                          key={order.id}
                          className="hover:bg-gray-50 transition duration-150 text-center text-xs"
                        >
                          <td className="sticky left-0 bg-white z-10 font-medium text-muted-foreground border-b py-2 px-1 text-xs">
                            {order.id}
                          </td>
                          <td className="border-b py-2 px-1 text-xs truncate">{order.customer_name}</td>
                          <td className="border-b py-2 px-1 text-xs whitespace-nowrap">
                            {order.order_at ? new Date(order.order_at).toLocaleDateString() : "-"}
                          </td>
                          <td className="border-b py-2 px-1 text-xs">
                            <Select
                              value={order.status}
                              onValueChange={(value) => handleStatusChange(order.id, value)}
                            >
                              <SelectTrigger className="w-[100px] mx-auto text-xs h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value={order.status} className="text-xs">{order.status}</SelectItem>
                                {statusTransitions[order.status]?.map((nextStatus) => (
                                  <SelectItem key={nextStatus} value={nextStatus} className="text-xs">
                                    {nextStatus}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </td>
                          <td className="font-semibold border-b py-2 px-1 text-xs">
                            ${order.total_amount.toLocaleString()}
                          </td>
                          <td className="border-b py-2 px-1 text-xs">{order.payment_status}</td>
                          <td className="border-b py-2 px-1 text-xs text-center">{order.no_of_items}</td>
                          <td className="border-b py-2 px-1 text-xs">
                            <Button
                              onClick={() => getInvoicePDF(order.id)}
                              variant="outline"
                              size="sm"
                              className="text-xs h-7 px-2 whitespace-nowrap"
                            >
                              <Download className="h-3 w-3 mr-1" />
                              Invoice
                            </Button>
                          </td>
                          <td className="border-b py-2 px-1 text-xs">
                            <Button
                              onClick={() => navigate(`/admin/orders/${order.id}`)}
                              variant="outline"
                              size="sm"
                              className="text-xs h-7 px-2"
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          colSpan={9}
                          className="text-center py-4 text-gray-500 border-b text-xs"
                        >
                          No orders found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Pagination Controls */}
          <div className="flex justify-end items-center gap-2 mt-4">
            <Button
              variant="outline"
              disabled={pagination.current_page === 1}
              onClick={() =>
                setPagination((prev) => ({
                  ...prev,
                  current_page: prev.current_page - 1,
                }))
              }
            >
              Previous
            </Button>
            {Array.from({ length: pagination.total_pages }, (_, i) => i + 1).map(
              (pageNum) => (
                <Button
                  key={pageNum}
                  variant={pageNum === pagination.current_page ? "default" : "outline"}
                  onClick={() =>
                    setPagination((prev) => ({
                      ...prev,
                      current_page: pageNum,
                    }))
                  }
                >
                  {pageNum}
                </Button>
              )
            )}
            <Button
              variant="outline"
              disabled={pagination.current_page === pagination.total_pages}
              onClick={() =>
                setPagination((prev) => ({
                  ...prev,
                  current_page: prev.current_page + 1,
                }))
              }
            >
              Next
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}