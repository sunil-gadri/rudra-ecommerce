import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axiosInstance from "../utils/axios";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Loader2, Trash2, Plus } from "lucide-react";

export default function ProductOverviewCreate() {
  const navigate = useNavigate();
  const location = useLocation();

  // Form States
  const [selectedProduct, setSelectedProduct] = useState(null); // { id, title }
  const [overview, setOverview] = useState("");
  const [disclaimer, setDisclaimer] = useState("");

  const [specBlocks, setSpecBlocks] = useState([
    { headingId: "", rows: [{ key: "", value: "" }] },
  ]);

  // Data
  const [products, setProducts] = useState([]);
  const [headings, setHeadings] = useState([]);
  const [headingMap, setHeadingMap] = useState({});
  const [specMap, setSpecMap] = useState({});

  // Loading & Submitting
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [fetchingSpecs, setFetchingSpecs] = useState({});

  // AUTO SET PRODUCT FROM PRODUCTS LIST (No dropdown, just read-only input)
  useEffect(() => {
    if (location.state?.productId && products.length > 0) {
      const id = String(location.state.productId);
      const product = products.find((p) => String(p.id) === id);

      if (product) {
        setSelectedProduct({ id: product.id, title: product.title });
        toast.success(`"${product.title}" loaded for overview`, { duration: 4000 });
      } else {
        toast.warning("Product not found. Redirecting...");
        navigate("/products");
      }
    }
  }, [location.state, products, navigate]);

  // Fetch Products & Headings
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [prodRes, headRes] = await Promise.all([
          axiosInstance.get("/product_title"),
          axiosInstance.get("/specification_heading"),
        ]);

        const prods = Array.isArray(prodRes.data?.products) ? prodRes.data.products : [];
        setProducts(prods);

        const heads = Array.isArray(headRes.data) ? headRes.data : [];
        setHeadings(heads);

        const map = {};
        heads.forEach((h) => {
          if (h.id && h.specification_heading) map[h.id] = h.specification_heading;
        });
        setHeadingMap(map);
      } catch (err) {
        toast.error("Failed to load data");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // अगर कोई product select नहीं है तो back भेज दो
  if (!loading && !selectedProduct) {
    return (
      <div className="flex flex-col items-center justify-center h-screen gap-4">
        <p className="text-xl text-red-600">No product selected!</p>
        <Button onClick={() => navigate("/products")}>Go Back to Products</Button>
      </div>
    );
  }

  // बाकी functions same हैं...
  const fetchSpecsForHeading = async (headingId, blockIndex) => {
    if (!headingId) return;
    setFetchingSpecs((prev) => ({ ...prev, [blockIndex]: true }));
    try {
      const res = await axiosInstance.get(`/specification/${headingId}`);
      const specs = Array.isArray(res.data) ? res.data : [];
      setSpecMap((prev) => ({ ...prev, [headingId]: specs }));
    } catch (err) {
      toast.error("Failed to load specifications");
    } finally {
      setFetchingSpecs((prev) => ({ ...prev, [blockIndex]: false }));
    }
  };

  const addSpecBlock = () => setSpecBlocks((prev) => [...prev, { headingId: "", rows: [{ key: "", value: "" }] }]);
  const updateBlockHeading = (blockIndex, headingId) => {
    setSpecBlocks((prev) => {
      const updated = [...prev];
      updated[blockIndex] = { headingId, rows: [{ key: "", value: "" }] };
      fetchSpecsForHeading(headingId, blockIndex);
      return updated;
    });
  };
  const addRowToBlock = (blockIndex) => setSpecBlocks((prev) => { const u = [...prev]; u[blockIndex].rows.push({ key: "", value: "" }); return u; });
  const updateRowInBlock = (blockIndex, rowIndex, field, value) => {
    setSpecBlocks((prev) => {
      const u = [...prev];
      u[blockIndex].rows[rowIndex][field] = value;
      return u;
    });
  };
  const removeRowFromBlock = (blockIndex, rowIndex) => {
    setSpecBlocks((prev) => {
      const u = [...prev];
      if (u[blockIndex].rows.length === 1) {
        toast.error("At least one row required");
        return prev;
      }
      u[blockIndex].rows.splice(rowIndex, 1);
      return u;
    });
  };
  const removeSpecBlock = (blockIndex) => {
    if (specBlocks.length === 1) {
      toast.error("At least one group required");
      return;
    }
    setSpecBlocks((prev) => prev.filter((_, i) => i !== blockIndex));
  };

  const buildSpecifications = () => {
    const specs = {};
    const usedHeadings = new Set();
    for (const block of specBlocks) {
      if (!block.headingId) continue;
      const name = headingMap[block.headingId];
      if (!name || usedHeadings.has(name)) {
        toast.error(`Duplicate heading: ${name}`);
        throw new Error();
      }
      usedHeadings.add(name);
      const blockSpecs = {};
      block.rows.forEach((r) => {
        if (r.key?.trim() && r.value?.trim()) blockSpecs[r.key.trim()] = r.value.trim();
      });
      if (Object.keys(blockSpecs).length) specs[name] = blockSpecs;
    }
    return Object.keys(specs).length ? specs : null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!overview.trim()) return toast.error("Overview is required");

    setSubmitting(true);
    let specifications;
    try {
      specifications = buildSpecifications();
    } catch {
      setSubmitting(false);
      return;
    }

    const payload = {
      product_id: parseInt(selectedProduct.id),
      overview: overview.trim(),
      disclaimer: disclaimer.trim() || null,
      specifications,
    };

    try {
      await axiosInstance.post("/product-description", payload);
      toast.success("Overview created successfully!");
      navigate("/products");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to save");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <form onSubmit={handleSubmit} className="space-y-8">

        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">Create Product Overview</h1>
            <p className="text-gray-600 mt-1">For: <strong>{selectedProduct?.title}</strong></p>
          </div>
          <Button type="button" variant="outline" onClick={() => navigate(-1)}>
            Cancel
          </Button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border p-8 space-y-8">

          {/* Product Name - Read Only Input */}
          <div>
            <label className="block text-lg font-semibold mb-3">Product</label>
            <input
              type="text"
              value={selectedProduct?.title || ""}
              readOnly
              disabled
              className="w-full px-4 py-3 bg-gray-100 border border-gray-300 rounded-lg text-gray-800 font-medium cursor-not-allowed"
            />
            <p className="text-sm text-gray-500 mt-2">This product was selected from the products list</p>
          </div>

          {/* Overview */}
          <div>
            <label className="block text-lg font-semibold mb-3">Product Overview <span className="text-red-500">*</span></label>
            <textarea
              value={overview}
              onChange={(e) => setOverview(e.target.value)}
              placeholder="Write a detailed overview..."
              rows={4}
              className="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500"
              required
            />
          </div>

          {/* Disclaimer */}
          <div>
            <label className="block text-lg font-semibold mb-3">Disclaimer (Optional)</label>
            <input
              type="text"
              value={disclaimer}
              onChange={(e) => setDisclaimer(e.target.value)}
              placeholder="e.g. Colors may vary due to lighting"
              className="w-full px-4 py-3 border rounded-lg"
            />
          </div>

          {/* Specifications */}
          <div className="space-y-6 pt-6 border-t">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Specifications</h2>
              <Button type="button" onClick={addSpecBlock}>
                <Plus className="h-4 w-4 mr-2" /> Add Group
              </Button>
            </div>

            {specBlocks.map((block, blockIndex) => (
              <div key={blockIndex} className="border rounded-lg p-6 bg-gray-50">
                <div className="flex gap-3 mb-4">
                  <select
                    value={block.headingId}
                    onChange={(e) => updateBlockHeading(blockIndex, e.target.value)}
                    className="flex-1 px-4 py-3 border rounded-lg"
                  >
                    <option value="">Select Heading</option>
                    {headings.map((h) => (
                      <option key={h.id} value={h.id}>{h.specification_heading}</option>
                    ))}
                  </select>
                  {specBlocks.length > 1 && (
                    <Button variant="ghost" size="icon" onClick={() => removeSpecBlock(blockIndex)} className="text-red-600">
                      <Trash2 className="h-5 w-5" />
                    </Button>
                  )}
                </div>

                {block.rows.map((row, rowIndex) => (
                  <div key={rowIndex} className="flex gap-3 mb-3">
                    <select
                      value={row.key}
                      onChange={(e) => updateRowInBlock(blockIndex, rowIndex, "key", e.target.value)}
                      className="flex-1 px-4 py-3 border rounded-lg"
                      disabled={!block.headingId}
                    >
                      <option value="">{block.headingId ? "Select spec" : "First select heading"}</option>
                      {(specMap[block.headingId] || []).map((s) => (
                        <option key={s.id} value={s.specification}>{s.specification}</option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="Value"
                      value={row.value}
                      onChange={(e) => updateRowInBlock(blockIndex, rowIndex, "value", e.target.value)}
                      className="flex-1 px-4 py-3 border rounded-lg"
                    />
                    {block.rows.length > 1 && (
                      <Button variant="ghost" size="icon" onClick={() => removeRowFromBlock(blockIndex, rowIndex)} className="text-red-600">
                        <Trash2 className="h-5 w-5" />
                      </Button>
                    )}
                  </div>
                ))}

                <Button variant="outline" size="sm" onClick={() => addRowToBlock(blockIndex)} className="w-full mt-3">
                  <Plus className="h-4 w-4 mr-2" /> Add Row
                </Button>
              </div>
            ))}
          </div>

          {/* Submit */}
          <div className="flex justify-end pt-8 border-t">
            <Button type="submit" size="lg" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Saving...
                </>
              ) : (
                "Create Overview"
              )}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}