import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Lock, User } from "lucide-react";
import axiosInstance from "../utils/axios";

export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const formData = new FormData();
      formData.append("username", username);
      formData.append("password", password);

      const response = await axiosInstance.post("admin/login", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      const token = response.data.token;
      localStorage.setItem("token", token);
      localStorage.setItem("username", username);

      console.log("Login successful:", response.data);
      navigate("/admin/dashboard");
    } catch (err) {
      console.error("Login error:", err);
      if (err.response && err.response.data) {
        alert(err.response.data.message || "Login failed");
      } else {
        alert("An error occurred during login. Please try again.");
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      {/* Card */}
      <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-8">
        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-6">
          {/* Header */}
          <div className="flex text-center justify-between">
            <h2 className="text-2xl font-bold text-purple-700">Login</h2>
          </div>

          {/* Username */}
          <div>
            <label className="text-sm font-medium text-gray-700">
              Username
            </label>
            <div className="relative mt-2">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500"
                required
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="text-sm font-medium text-gray-700">
              Password
            </label>
            <div className="relative mt-2">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500"
                required
              />
            </div>
          </div>

          {/* Options */}
          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2 text-gray-600">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-gray-300 focus:ring-purple-500"
              />
              Keep me signed in
            </label>
            <p
              className="text-purple-600 font-medium cursor-pointer hover:underline"
              onClick={() => alert("Implement forgot password")}
            >
              Forgot Password?
            </p>
          </div>

          {/* Button */}
          <button
            type="submit"
            className="w-full bg-purple-600 text-white py-3 rounded-lg font-medium hover:bg-purple-700 transition-colors duration-200"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
}
