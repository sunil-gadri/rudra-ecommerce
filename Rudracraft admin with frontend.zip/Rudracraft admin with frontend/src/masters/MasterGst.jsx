import { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import {
    DropdownMenu,
    DropdownMenuTrigger,
    DropdownMenuContent,
    DropdownMenuLabel,
    DropdownMenuItem,
    DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";

export default function MasterGst() {
    const [gstList, setGstList] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
    const [currentGst, setCurrentGst] = useState({ id: null, gst: "" });
    const [newGst, setNewGst] = useState("");

    useEffect(() => {
        fetchGstList();
    }, []);

    const fetchGstList = async () => {
        try {
            const response = await axiosInstance.get("/gst");
            setGstList(response.data);
        } catch (error) {
            console.error("Error fetching GST list:", error);
        }
    };

    const handleAddSubmit = async (e) => {
        e.preventDefault();
        if (!newGst) return;
        try {
            const formData = new FormData();
            formData.append("gst", newGst);
            await axiosInstance.post("/gst", formData);
            setNewGst("");
            fetchGstList();
        } catch (error) {
            console.error("Error adding GST:", error);
        }
    };

    const handleEdit = (gst) => {
        setCurrentGst(gst);
        setIsEditDialogOpen(true);
    };

    const handleUpdate = async () => {
        try {
            const formData = new FormData();
            formData.append("gst", currentGst.gst);
            await axiosInstance.put(`/gst/${currentGst.id}`, formData);
            setIsEditDialogOpen(false);
            fetchGstList();
        } catch (error) {
            console.error("Error updating GST:", error);
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm("Are you sure you want to delete this GST?")) {
            try {
                await axiosInstance.delete(`/gst/${id}`);
                fetchGstList();
            } catch (error) {
                console.error("Error deleting GST:", error);
            }
        }
    };

    const filteredGst = gstList.filter((item) =>
        item.gst.toString().toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="space-y-6">
            <form onSubmit={handleAddSubmit} className="space-y-6">
                <div>
                    <h1 className="text-3xl font-bold tracking-tighter">Add GST</h1>
                    <p className="text-muted-foreground">
                        Manage and configure gst details
                    </p>
                </div>

                <div className="bg-white p-6 rounded-lg border space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <Label>GST</Label>
                            <Input
                                type="text"
                                value="gst"
                                readOnly
                                className="form-input w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2 text-sm"
                            />
                        </div>
                        <div>
                            <Label>GST Value</Label>
                            <Input
                                type="number"
                                required
                                placeholder="Enter GST value"
                                value={newGst}
                                onChange={(e) => setNewGst(e.target.value)}
                                className="form-input w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                            />
                        </div>
                    </div>
                    <div>
                        <Button type="submit">Save</Button>
                    </div>
                </div>
            </form>
            {/* gst table */}
            <Card>
                <CardHeader>
                    <CardTitle>All GST</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="relative max-w-sm mb-4">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                        <Input
                            placeholder="Search GST..."
                            className="pl-10 w-64"
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="border rounded-md">
                        <Table>
                            <TableHeader className="sticky top-0 bg-gray-50">
                                <TableRow className="bg-gray-50 text-gray-700 text-center sticky top-0 z-10">
                                    <TableHead className="text-center">Id</TableHead>
                                    <TableHead className="text-center">GST%</TableHead>
                                    <TableHead className="text-center">Action</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredGst.map((item) => (
                                    <TableRow key={item.id}>
                                        <TableCell className="text-center align-middle">
                                            {item.id}
                                        </TableCell>
                                        <TableCell className="text-center align-middle">
                                            {item.gst}%
                                        </TableCell>
                                        <TableCell className="text-center align-middle">
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button size="icon" variant="ghost">
                                                        <MoreHorizontal className="w-4 h-4" />
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end">
                                                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                                    <DropdownMenuItem onClick={() => handleEdit(item)}>
                                                        <Edit className="w-4 h-4 mr-2" /> Edit
                                                    </DropdownMenuItem>
                                                    <DropdownMenuItem
                                                        onClick={() => handleDelete(item.id)}
                                                        className="text-red-600"
                                                    >
                                                        <Trash2 className="w-4 h-4 mr-2" /> Delete
                                                    </DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Edit GST</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                        <Label>GST Value</Label>
                        <Input
                            type="number"
                            value={currentGst.gst}
                            onChange={(e) =>
                                setCurrentGst({ ...currentGst, gst: e.target.value })
                            }
                            placeholder="Enter GST value"
                        />
                    </div>
                    <DialogFooter>
                        <Button onClick={handleUpdate}>Save Changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}