import { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function MasterSpecificationHeading() {
  const [specifications, setSpecifications] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [newSpec, setNewSpec] = useState("");
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentSpec, setCurrentSpec] = useState({ id: null, specification_heading: "" });

  // Fetch specifications on mount
  useEffect(() => {
    fetchSpecifications();
  }, []);

  const fetchSpecifications = async () => {
    try {
      const response = await axiosInstance.get("/specification_heading");
      setSpecifications(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error("Error fetching specification headings:", error);
      alert("Failed to load specification headings. Check console.");
    }
  };

  // Add new specification heading
  const handleAddSubmit = async (e) => {
    e.preventDefault();
    if (!newSpec.trim()) return;

    try {
      const formData = new FormData();
      formData.append("specification_heading", newSpec.trim());

      await axiosInstance.post("/specification_heading", formData);

      setNewSpec("");
      fetchSpecifications();
    } catch (error) {
      console.error("Error adding specification heading:", error);
      alert("Failed to add specification heading. Check console.");
    }
  };

  // Open edit dialog
  const handleEdit = (spec) => {
    setCurrentSpec({
      id: spec.id,
      specification_heading: spec.specification_heading,
    });
    setIsEditDialogOpen(true);
  };

  // Update specification heading
  const handleUpdate = async () => {
    if (!currentSpec.specification_heading.trim()) return;

    try {
      const formData = new FormData();
      formData.append("specification_heading", currentSpec.specification_heading.trim());

      await axiosInstance.put(`/specification_heading/${currentSpec.id}`, formData);

      setIsEditDialogOpen(false);
      fetchSpecifications();
    } catch (error) {
      console.error("Error updating specification heading:", error);
      alert("Failed to update specification heading. Check console.");
    }
  };

  // Delete specification heading
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this specification heading?")) {
      try {
        await axiosInstance.delete(`/specification_heading/${id}`);
        fetchSpecifications();
      } catch (error) {
        console.error("Error deleting specification heading:", error);
        alert("Failed to delete.");
      }
    }
  };

  // Filter specifications
  const filteredSpecs = specifications.filter((item) =>
    item.specification_heading?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Add Form */}
      <form onSubmit={handleAddSubmit} className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter">Add Specification Heading</h1>
          <p className="text-muted-foreground">
            Manage and configure specification heading details
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg border space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>Field</Label>
              <Input
                type="text"
                value="specification_heading"
                readOnly
                className="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>
            <div>
              <Label>Specification Heading Name</Label>
              <Input
                type="text"
                required
                placeholder="e.g., Care Instructions, Fabric"
                value={newSpec}
                onChange={(e) => setNewSpec(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>
          </div>
          <div>
            <Button type="submit">Save</Button>
          </div>
        </div>
      </form>

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Specification Headings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search specification headings..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-center">ID</TableHead>
                  <TableHead className="text-center">Specification Heading</TableHead>
                  <TableHead className="text-center">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSpecs.length > 0 ? (
                  filteredSpecs.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="text-center align-middle">
                        {item.id}
                      </TableCell>
                      <TableCell className="text-center align-middle font-medium">
                        {item.specification_heading}
                      </TableCell>
                      <TableCell className="text-center align-middle">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="icon" variant="ghost">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleEdit(item)}>
                              <Edit className="w-4 h-4 mr-2" /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDelete(item.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center py-4 text-muted-foreground">
                      {searchTerm ? "No matching specification headings found." : "No specification headings available."}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Specification Heading</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Label>Specification Heading Name</Label>
            <Input
              type="text"
              value={currentSpec.specification_heading || ""}
              onChange={(e) =>
                setCurrentSpec({ ...currentSpec, specification_heading: e.target.value })
              }
              placeholder="e.g., Care Instructions"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdate}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}