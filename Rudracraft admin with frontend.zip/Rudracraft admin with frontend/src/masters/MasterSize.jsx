import React, { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";


export default function MasterSize() {
  const [sizes, setSizes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const [addOption, setAddOption] = useState("");
  const [addUnit, setAddUnit] = useState("");
  const [addCategory, setAddCategory] = useState("");

  const [editItem, setEditItem] = useState(null);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editOption, setEditOption] = useState("");
  const [editUnit, setEditUnit] = useState("");
  const [editCategory, setEditCategory] = useState("");

  useEffect(() => {
    fetchSizes();
  }, []);

  const fetchSizes = async () => {
    try {
      const response = await axiosInstance.get("/product_sizes");
      setSizes(response.data);
    } catch (error) {
      console.error("Error fetching sizes:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();

    if (!addOption) {
      alert("Please select a type.");
      return;
    }

    const formData = new FormData();
    const typeValue =
      addOption === "ProductDimensions" ? "metric units" : "size category";
    formData.append("type", typeValue);

    if (typeValue === "metric units") {
      if (!addUnit) return alert("Please enter a unit.");
      formData.append("unit", addUnit);
    } else {
      if (!addCategory) return alert("Please enter a size category.");
      formData.append("category", addCategory);
    }

    try {
      await axiosInstance.post("/product_sizes", formData);
      resetAddForm();
      fetchSizes();
    } catch (err) {
      console.error("Failed to save size:", err);
      alert("Error saving size. Check console.");
    }
  };

  const resetAddForm = () => {
    setAddOption("");
    setAddUnit("");
    setAddCategory("");
  };

  const openEditModal = (item) => {
    setEditItem(item);
    setEditOption(
      item.type === "metric units" ? "ProductDimensions" : "SizeCategory"
    );
    setEditUnit(item.unit || "");
    setEditCategory(item.category || "");
    setIsEditOpen(true);
  };

  const handleUpdate = async (e) => {
    e.preventDefault();

    if (!editItem) return;

    const formData = new FormData();
    const typeValue =
      editOption === "ProductDimensions" ? "metric units" : "size category";
    formData.append("type", typeValue);

    if (typeValue === "metric units") {
      if (!editUnit) return alert("Please enter a unit.");
      formData.append("unit", editUnit);
    } else {
      if (!editCategory) return alert("Please enter a size category.");
      formData.append("category", editCategory);
    }

    try {
      await axiosInstance.put(`/product_sizes/${editItem.id}`, formData);
      setIsEditOpen(false);
      fetchSizes();
    } catch (err) {
      console.error("Failed to update size:", err);
      alert("Error updating size. Check console.");
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this item?")) return;
    try {
      await axiosInstance.delete(`/product_sizes/${id}`);
      fetchSizes();
    } catch (err) {
      console.error("Failed to delete item:", err);
    }
  };

  const filteredSizes = sizes.filter((item) => {
    const term = searchTerm.toLowerCase();
    return (
      item.id.toString().includes(term) ||
      item.type?.toLowerCase().includes(term) ||
      item.unit?.toLowerCase().includes(term) ||
      item.category?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      {/* ADD FORM */}
      <form
        onSubmit={handleSave}
        className="space-y-6"
      >
        <div>
          <h1 className="text-3xl font-bold">Add Size</h1>
          <p className="text-muted-foreground">
            Manage and configure size details
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg border space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="block text-sm mb-1">Select Type</Label>
              <Select
                value={addOption}
                onValueChange={(value) => {
                  setAddOption(value);
                  setAddUnit("");
                  setAddCategory("");
                }}
                className="form-select w-full border px-3 py-2 rounded-md"
              >
                <SelectTrigger className="w-full border px-3 py-2 rounded-md">
                  <SelectValue placeholder="Choose" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ProductDimensions">Metric Units</SelectItem>
                  <SelectItem value="SizeCategory">Size Category</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {addOption === "ProductDimensions" ? (
              <div>
                <Label className="block text-sm mb-1">Enter Unit</Label>
                <Input
                  value={addUnit}
                  onChange={(e) => setAddUnit(e.target.value)}
                  placeholder="e.g. cm, m"
                  className="w-full"
                />
              </div>
            ) : addOption === "SizeCategory" ? (
              <div>
                <Label className="block text-sm mb-1">Enter Size Category</Label>
                <Input
                  value={addCategory}
                  onChange={(e) => setAddCategory(e.target.value)}
                  placeholder="e.g. XL, Medium"
                  className="w-full"
                />
              </div>
            ) : null}
          </div>
          <Button type="submit">Save</Button>
        </div>
      </form>

      {/* TABLE DISPLAY */}
      <Card>
        <CardHeader>
          <CardTitle>All Sizes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search sizes..."
              className="pl-10 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="border rounded-md">
            {/* Fixed Header */}
            <Table className="w-full table-fixed">
              <TableHeader>
                <TableRow className="bg-gray-50 text-gray-700 text-center sticky top-0 z-10">
                  <TableHead className="text-center w-[14%]">Id</TableHead>
                  <TableHead className="text-center w-[16%]">Type</TableHead>
                  <TableHead className="text-center w-[20%]">Unit</TableHead>
                  <TableHead className="text-center w-[20%]">Size Category</TableHead>
                  <TableHead className="text-center w-[20%]">Action</TableHead>
                </TableRow>
              </TableHeader>
            </Table>

            {/* Scrollable Body */}
            <div className="max-h-96 overflow-y-auto overflow-x-auto">
              <Table className="w-full table-fixed">
                <TableBody>
                  {filteredSizes.map((item) => (
                    <TableRow
                      key={item.id}
                      className="hover:bg-gray-50 transition duration-150"
                    >
                      <TableCell className="text-center align-middle font-medium text-muted-foreground w-[15%]">
                        {item.id}
                      </TableCell>
                      <TableCell className="text-center align-middle w-[20%]">
                        <div className="flex flex-col items-center">
                          <span className="font-medium text-gray-800">
                            {item.type}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center align-middle w-[20%]">
                        {item.unit || "-"}
                      </TableCell>
                      <TableCell className="text-center align-middle w-[25%]">
                        {item.category || "-"}
                      </TableCell>
                      <TableCell className="text-center align-middle w-[20%]">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="icon" variant="ghost">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => openEditModal(item)}>
                              <Edit className="w-4 h-4 mr-2" /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => handleDelete(item.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

        </CardContent>
      </Card>

      {/* EDIT MODAL */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Size</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleUpdate} className="space-y-4">
            <div>
              <label className="block text-sm mb-1">Type</label>
              <select
                value={editOption}
                onChange={(e) => {
                  setEditOption(e.target.value);
                  setEditUnit("");
                  setEditCategory("");
                }}
                className="form-select w-full border px-3 py-2 rounded-md"
              >
                <option value="ProductDimensions">Metric Units</option>
                <option value="SizeCategory">Size Category</option>
              </select>
            </div>
            {editOption === "ProductDimensions" ? (
              <div>
                <label className="block text-sm mb-1">Unit</label>
                <Input
                  required
                  value={editUnit}
                  onChange={(e) => setEditUnit(e.target.value)}
                  placeholder="e.g. cm, m"
                />
              </div>
            ) : (
              <div>
                <label className="block text-sm mb-1">Size Category</label>
                <Input
                  required
                  value={editCategory}
                  onChange={(e) => setEditCategory(e.target.value)}
                  placeholder="e.g. XL, Medium"
                />
              </div>
            )}
            <DialogFooter className="mt-4">
              <Button type="submit" className="bg-primary text-white">
                Update
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
