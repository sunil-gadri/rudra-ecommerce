import { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Label } from "@/components/ui/label";

export default function MasterColor() {
  const [formData, setFormData] = useState({
    hexCode: "#000000",
    colorId: "",
  });

  const [editFormData, setEditFormData] = useState({
    hexCode: "#000000",
    colorId: "",
  });

  const [editId, setEditId] = useState(null);
  const [colors, setColors] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchColors();
  }, []);

  const fetchColors = async () => {
    try {
      const res = await axiosInstance.get("/product_colors");
      setColors(res.data);
    } catch (error) {
      console.error("Error fetching colors:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    let newValue = value;
    if (name === "colorId" && value.length > 0) {
      newValue = value.charAt(0).toUpperCase() + value.slice(1);
    }

    setFormData((prev) => ({ ...prev, [name]: newValue }));
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;

    let newValue = value;
    if (name === "colorId" && value.length > 0) {
      newValue = value.charAt(0).toUpperCase() + value.slice(1);
    }

    setEditFormData((prev) => ({ ...prev, [name]: newValue }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.colorId.trim()) return alert("Please provide a color name.");

    const payload = new FormData();
    payload.append("color_name", formData.colorId.trim());
    payload.append("hex_value", formData.hexCode);

    try {
      await axiosInstance.post("/product_colors", payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setFormData({ hexCode: "#000000", colorId: "" });
      fetchColors();
    } catch (error) {
      console.error("Error saving color:", error);
      alert("Failed to save color.");
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();

    const payload = new FormData();
    payload.append("color_name", editFormData.colorId.trim());
    payload.append("hex_value", editFormData.hexCode);

    try {
      await axiosInstance.put(`/product_colors/${editId}`, payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setIsDialogOpen(false);
      setEditId(null);
      fetchColors();
    } catch (error) {
      console.error("Error updating color:", error);
      alert("Failed to update color.");
    }
  };

  const startEdit = (color) => {
    setEditFormData({
      hexCode: color.hex_value,
      colorId: color.color_name,
    });
    setEditId(color.id);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this color?")) return;

    try {
      await axiosInstance.delete(`/product_colors/${id}`);
      fetchColors();
    } catch (error) {
      console.error("Error deleting color:", error);
      alert("Failed to delete color.");
    }
  };

  const filterColors = colors.filter((color) => {
    const term = searchTerm.toLowerCase();
    return (
      color.id?.toString().includes(term) ||
      (color.color_name?.toLowerCase() ?? "").includes(term) ||
      (color.hex_value?.toLowerCase() ?? "").includes(term)
    )
  })

  return (
    <div className="space-y-6">
      {/* === ADD FORM === */}
      <form
        onSubmit={handleSubmit}
        className="space-y-6"
      >
        <div className="">
          <h1 className="text-3xl font-bold tracking-tight">Add Color</h1>
          <p className="text-muted-foreground">
            Manage and configure color details
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg border space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <Label>
                Color
              </Label>
              <Input
                type="text"
                value="Color"
                readOnly
              />
            </div>

            <div>
              <Label>
                Pick Color
              </Label>
              <Input
                type="color"
                name="hexCode"
                value={formData.hexCode}
                onChange={handleChange}
                className="w-full h-[42px] rounded-md border border-gray-300 p-1"
              />
            </div>

            <div>
              <Label>
                Color Name
              </Label>
              <Input
                type="text"
                name="colorId"
                required
                placeholder="e.g., Sky Blue"
                value={formData.colorId}
                onChange={handleChange}
                className="form-input w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>
          </div>
          <div className="">
            <Button type="submit">Save</Button>
          </div>
        </div>
      </form>

      {/* === COLORS TABLE === */}
      <Card>
        <CardHeader>
          <CardTitle>All Colors</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search colors..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          {filterColors.length === 0 ? (
            <p className="text-gray-500">No colors added yet.</p>
          ) : (
            <div className="border rounded-md">
              {/* Fixed Header */}
              <Table className="w-full table-fixed">
                <TableHeader>
                  <TableRow className="bg-gray-50 text-gray-700 text-center sticky top-0 z-10">
                    <TableHead className="text-center w-[15%]">ID</TableHead>
                    <TableHead className="text-center w-[20%]">Color Name</TableHead>
                    <TableHead className="text-center w-[20%]">Hex Code</TableHead>
                    <TableHead className="text-center w-[20%]">Preview</TableHead>
                    <TableHead className="text-center w-[27%]">Action</TableHead>
                  </TableRow>
                </TableHeader>
              </Table>

              {/* Scrollable Body */}
              <div className="max-h-96 overflow-y-auto overflow-x-auto">
                <Table className="w-full table-fixed">
                  <TableBody>
                    {filterColors.map((color) => (
                      <TableRow key={color.id}>
                        <TableCell className="text-center align-middle font-medium text-muted-foreground w-[15%]">
                          {color.id}
                        </TableCell>
                        <TableCell className="text-center align-middle w-[20%]">
                          <div className="flex flex-col items-center">
                            <span className="font-medium text-gray-800">
                              {color.color_name}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center align-middle w-[20%]">
                          {color.hex_value}
                        </TableCell>
                        <TableCell className="text-center align-middle w-[20%]">
                          <div
                            className="w-6 h-6 mx-auto rounded border"
                            style={{ backgroundColor: color.hex_value }}
                          />
                        </TableCell>
                        <TableCell className="text-center align-middle w-[25%]">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="icon" variant="ghost">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => startEdit(color)}>
                                <Edit className="w-4 h-4 mr-2" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => handleDelete(color.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 mr-2" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* === EDIT DIALOG === */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Color</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1">
                Color Name
              </label>
              <input
                type="text"
                name="colorId"
                value={editFormData.colorId}
                onChange={handleEditChange}
                required
                className="form-input w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1">
                Pick Color
              </label>
              <input
                type="color"
                name="hexCode"
                value={editFormData.hexCode}
                onChange={handleEditChange}
                className="w-full h-[42px] rounded-md border border-gray-300 p-1"
              />
            </div>

            <DialogFooter className="pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-primary text-white hover:bg-primary/90"
              >
                Update Color
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
