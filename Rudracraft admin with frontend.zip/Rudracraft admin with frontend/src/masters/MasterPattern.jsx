import { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function MasterPattern() {
  const [formData, setFormData] = useState({ pattern: "" });
  const [editFormData, setEditFormData] = useState({ pattern: "" });
  const [editId, setEditId] = useState(null);
  const [patterns, setPatterns] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchPatterns();
  }, []);

  const fetchPatterns = async () => {
    try {
      const res = await axiosInstance.get("/product_pattern");
      setPatterns(res.data);
    } catch (error) {
      console.error("Error fetching patterns:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    let newValue = value;
    if (name === "pattern" && value.length > 0) {
      newValue = value.charAt(0).toUpperCase() + value.slice(1);
    }

    setFormData({ [name]: newValue });
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;

    let newValue = value;
    if (name === "pattern" && value.length > 0) {
      newValue = value.charAt(0).toUpperCase() + value.slice(1);
    }

    setEditFormData({ [name]: newValue });
  };
  

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.pattern.trim()) return alert("Please select a pattern.");

    const payload = new FormData();
    payload.append("pattern", formData.pattern.trim());

    try {
      await axiosInstance.post("/product_pattern", payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setFormData({ pattern: "" });
      fetchPatterns();
    } catch (error) {
      console.error("Error saving pattern:", error);
      alert("Failed to save pattern.");
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!editFormData.pattern.trim()) return alert("Please select a pattern.");

    const payload = new FormData();
    payload.append("pattern", editFormData.pattern.trim());

    try {
      await axiosInstance.put(`/product_pattern/${editId}`, payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setIsDialogOpen(false);
      setEditId(null);
      fetchPatterns();
    } catch (error) {
      console.error("Error updating pattern:", error);
      alert("Failed to update pattern.");
    }
  };

  const startEdit = (pattern) => {
    setEditFormData({ pattern: pattern.pattern });
    setEditId(pattern.id);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this pattern?")) return;

    try {
      await axiosInstance.delete(`/product_pattern/${id}`);
      fetchPatterns();
    } catch (error) {
      console.error("Error deleting pattern:", error);
      alert("Failed to delete pattern.");
    }
  };

  const filteredPatterns = patterns.filter((pattern) => {
    const term = searchTerm.toLowerCase();
    return (
      pattern.id?.toString().includes(term) ||
      (pattern.pattern?.toLowerCase() ?? "").includes(term)
    );
  });

  return (
    <div className="space-y-6">
      <form
        onSubmit={handleSubmit}
        className="space-y-6"
      >
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Add Pattern</h1>
          <p className="text-muted-foreground">
            Manage and configure pattern details
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg border space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>
                Pattern
              </Label>
              <Input
                type="text"
                value="Pattern"
                readOnly
                className="form-input w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>

            <div>
              <Label>
                Pattern Type
              </Label>
              <input
                type="text"
                name="pattern"
                value={formData.pattern}
                onChange={handleChange}
                required
                placeholder="Enter pattern"
                className="form-input w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>
          </div>
          <div>
            <Button type="submit">Save</Button>
          </div>
        </div>
      </form>

      <Card>
        <CardHeader>
          <CardTitle>All Patterns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search patterns..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="border rounded-md">
            <Table className="w-full table-fixed">
              <TableHeader>
                <TableRow className="bg-gray-50 text-gray-700 text-center sticky top-0 z-10">
                  <TableHead className="text-center w-[30%]">Id</TableHead>
                  <TableHead className="text-center w-[40%]">Pattern Type</TableHead>
                  <TableHead className="text-center w-[30%]">Action</TableHead>
                </TableRow>
              </TableHeader>
            </Table>

            {/* Scrollable Body */}
            <div className="max-h-96 overflow-y-auto overflow-x-auto">
              <Table className="w-full table-fixed">
                <TableBody>
                  {filteredPatterns.length > 0 ? (
                    filteredPatterns.map((pattern) => (
                      <TableRow key={pattern.id}>
                        <TableCell className="text-center align-middle font-medium text-muted-foreground w-[30%]">
                          {pattern.id}
                        </TableCell>
                        <TableCell className="text-center align-middle w-[40%]">
                          <div className="flex flex-col items-center">
                            <span className="font-medium text-gray-800">
                              {pattern.pattern}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center align-middle w-[30%]">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="icon" variant="ghost">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => startEdit(pattern)}>
                                <Edit className="w-4 h-4 mr-2" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => handleDelete(pattern.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 mr-2" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={3}
                        className="text-center py-6 text-gray-500 w-full"
                      >
                        No mennesker found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* === EDIT DIALOG === */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Pattern</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1">
                Pattern
              </label>
              <input
                type="text"
                value="Pattern"
                readOnly
                className="form-input w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1">
                Pattern Type
              </label>
              <input
                type="text"
                name="pattern"
                value={editFormData.pattern}
                onChange={handleEditChange}
                required
                placeholder="Enter pattern"
                className="form-input w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>

            <DialogFooter className="pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-primary text-white hover:bg-primary/90"
              >
                Update Pattern
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
