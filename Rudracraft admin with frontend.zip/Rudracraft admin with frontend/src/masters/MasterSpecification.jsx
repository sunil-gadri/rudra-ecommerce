import { useState, useEffect } from "react";
import axiosInstance from "../utils/axios";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Edit, Trash2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function MasterSpecification() {
  const [specifications, setSpecifications] = useState([]);
  const [headings, setHeadings] = useState([]); // For dropdown
  const [headingMap, setHeadingMap] = useState({}); // id → name
  const [searchTerm, setSearchTerm] = useState("");
  const [newSpec, setNewSpec] = useState("");
  const [selectedHeadingId, setSelectedHeadingId] = useState("");
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentSpec, setCurrentSpec] = useState({
    id: null,
    specification: "",
    specification_heading_id: "",
  });

  // Fetch specification headings (for dropdown & name lookup)
  useEffect(() => {
    const fetchHeadings = async () => {
      try {
        const response = await axiosInstance.get("/specification_heading");
        const data = Array.isArray(response.data) ? response.data : [];
        setHeadings(data);

        // Create map: id → specification_heading
        const map = {};
        data.forEach((h) => {
          if (h.id && h.specification_heading) {
            map[h.id] = h.specification_heading;
          }
        });
        setHeadingMap(map);
      } catch (error) {
        console.error("Error fetching specification headings:", error);
        alert("Failed to load headings. Check console.");
      }
    };
    fetchHeadings();
  }, []);

  // Fetch specifications
  useEffect(() => {
    fetchSpecifications();
  }, []);

  const fetchSpecifications = async () => {
    try {
      const response = await axiosInstance.get("/specification");
      const data = Array.isArray(response.data) ? response.data : [];
      setSpecifications(data);
    } catch (error) {
      console.error("Error fetching specifications:", error);
      alert("Failed to load specifications. Check console.");
    }
  };

  // Add new specification
  const handleAddSubmit = async (e) => {
    e.preventDefault();
    if (!newSpec.trim() || !selectedHeadingId) return;

    try {
      const formData = new FormData();
      formData.append("specification", newSpec.trim());
      formData.append("specification_heading_id", selectedHeadingId);

      await axiosInstance.post("/specification", formData);

      setNewSpec("");
      setSelectedHeadingId("");
      fetchSpecifications();
    } catch (error) {
      console.error("Error adding specification:", error);
      alert("Failed to add specification. Check console.");
    }
  };

  // Open edit dialog
  const handleEdit = (spec) => {
    setCurrentSpec({
      id: spec.id,
      specification: spec.specification,
      specification_heading_id: spec.specification_heading_id,
    });
    setIsEditDialogOpen(true);
  };

  // Update specification
  const handleUpdate = async () => {
    if (!currentSpec.specification.trim() || !currentSpec.specification_heading_id) return;

    try {
      const formData = new FormData();
      formData.append("specification", currentSpec.specification.trim());
      formData.append("specification_heading_id", currentSpec.specification_heading_id);

      await axiosInstance.put(`/specification/${currentSpec.id}`, formData);

      setIsEditDialogOpen(false);
      fetchSpecifications();
    } catch (error) {
      console.error("Error updating specification:", error);
      alert("Failed to update specification. Check console.");
    }
  };

  // Delete specification
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this specification?")) {
      try {
        await axiosInstance.delete(`/specification/${id}`);
        fetchSpecifications();
      } catch (error) {
        console.error("Error deleting specification:", error);
        alert("Failed to delete.");
      }
    }
  };

  // Filter specifications
  const filteredSpecs = specifications.filter((item) =>
    item.specification?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    headingMap[item.specification_heading_id]?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Add Form */}
      <form onSubmit={handleAddSubmit} className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter">Add Specification</h1>
          <p className="text-muted-foreground">
            Manage and configure specification details
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg border space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>Specification</Label>
              <Input
                type="text"
                value="specification"
                readOnly
                className="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>
            <div>
              <Label>Specification Name</Label>
              <Input
                type="text"
                required
                placeholder="Enter specification value (e.g., Wash with cold water)"
                value={newSpec}
                onChange={(e) => setNewSpec(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div>
            <Label>Specification Heading</Label>
            <Select value={selectedHeadingId} onValueChange={setSelectedHeadingId} required>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a heading" />
              </SelectTrigger>
              <SelectContent>
                {headings.map((heading) => (
                  <SelectItem key={heading.id} value={heading.id.toString()}>
                    {heading.specification_heading}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Button type="submit">Save</Button>
          </div>
        </div>
      </form>

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Specifications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search by specification or heading..."
              className="pl-10 w-64"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-center">ID</TableHead>
                  <TableHead className="text-center">Specification</TableHead>
                  <TableHead className="text-center">Heading</TableHead>
                  <TableHead className="text-center">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSpecs.length > 0 ? (
                  filteredSpecs.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="text-center align-middle">
                        {item.id}
                      </TableCell>
                      <TableCell className="text-center align-middle">
                        {item.specification}
                      </TableCell>
                      <TableCell className="text-center align-middle font-medium">
                        {headingMap[item.specification_heading_id] || `ID: ${item.specification_heading_id}`}
                      </TableCell>
                      <TableCell className="text-center align-middle">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="icon" variant="ghost">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleEdit(item)}>
                              <Edit className="w-4 h-4 mr-2" /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDelete(item.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-4 text-muted-foreground">
                      {searchTerm ? "No matching specifications found." : "No specifications available."}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Specification</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Specification Name</Label>
              <Input
                type="text"
                value={currentSpec.specification || ""}
                onChange={(e) =>
                  setCurrentSpec({ ...currentSpec, specification: e.target.value })
                }
                placeholder="Enter specification value"
              />
            </div>
            <div>
              <Label>Specification Heading</Label>
              <Select
                value={currentSpec.specification_heading_id?.toString()}
                onValueChange={(value) =>
                  setCurrentSpec({ ...currentSpec, specification_heading_id: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select heading" />
                </SelectTrigger>
                <SelectContent>
                  {headings.map((heading) => (
                    <SelectItem key={heading.id} value={heading.id.toString()}>
                      {heading.specification_heading}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdate}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}