// utils/axios.js

import axios from "axios";
import { toast } from "sonner";

const axiosInstance = axios.create({
  baseURL: "/api",
  withCredentials: true,
});

axiosInstance.interceptors.request.use(
  (config) => {
    const adminToken = localStorage.getItem("token");
    const customerToken = localStorage.getItem("customerToken");

    if (customerToken) {
      config.headers.Authorization = `Bearer ${customerToken}`;
    } else if (adminToken) {
      config.headers.Authorization = `Bearer ${adminToken}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      const customerToken = localStorage.getItem("customerToken");
      const adminToken = localStorage.getItem("token");

      if (customerToken) {
        localStorage.removeItem("customerToken");
        localStorage.removeItem("customerId");
        toast.error("Session expired. Please login again.");
        window.location.href = "/"; 
      } else if (adminToken) {
        localStorage.removeItem("token");
        toast.error("Session expired. Please login again.");
        window.location.href = "/admin-login";
      }
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;