// src/Frontend/Account/ProfileUser.jsx
import React, { useState, useEffect } from "react";
import { toast } from "sonner";
import axiosInstance from "../../utils/axios";
import AccountSidebar from "./AccountSidebar";
import { Camera, Save, X, User, Mail, Phone, UserCircle, Edit2 } from "lucide-react";

export default function ProfileUser() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(false);

  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    gender: "male",
  });

  const [profileImage, setProfileImage] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);

  const customerId = localStorage.getItem("customerId");
  const defaultProfileImage = "https://via.placeholder.com/200?text=Profile"; // Fallback image

  // Fetch user profile
  useEffect(() => {
    if (!customerId) {
      toast.error("Please log in to view profile");
      return;
    }

    const fetchProfile = async () => {
      try {
        setLoading(true);
        const response = await axiosInstance.get(`/customer-profile/${customerId}`);
        const userData = response.data;

        setUser(userData);

        setFormData({
          first_name: userData.first_name || "",
          last_name: userData.last_name || "",
          email: userData.email || "",
          phone: userData.phone?.toString() || "", // Convert number to string
          gender: userData.gender?.toLowerCase() || "male",
        });

        // Use the full URL provided by backend
        setPreviewImage(userData.profile_image_url || defaultProfileImage);
      } catch (error) {
        toast.error(error?.response?.data?.message || "Failed to load profile");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [customerId]);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle profile image upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Safe string trim helper
  const safeTrim = (value) => (value ?? "").toString().trim();

  // Submit updated profile
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!customerId) return;

    // Validation
    if (!safeTrim(formData.first_name)) {
      toast.error("First name is required");
      return;
    }
    if (!safeTrim(formData.last_name)) {
      toast.error("Last name is required");
      return;
    }
    if (!safeTrim(formData.email)) {
      toast.error("Email is required");
      return;
    }
    if (!safeTrim(formData.phone)) {
      toast.error("Phone number is required");
      return;
    }

    setSaving(true);
    const data = new FormData();
    data.append("first_name", safeTrim(formData.first_name));
    data.append("last_name", safeTrim(formData.last_name));
    data.append("email", safeTrim(formData.email));
    data.append("phone", safeTrim(formData.phone));
    data.append("gender", formData.gender);

    if (profileImage) {
      data.append("profile_image", profileImage);
    }

    try {
      const response = await axiosInstance.put(`/customer-profile/${customerId}`, data, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      toast.success("Profile updated successfully!");
      setUser(response.data);
      setEditing(false);
      setProfileImage(null);
      setPreviewImage(response.data.profile_image_url || defaultProfileImage);
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  // Cancel edit
  const handleCancel = () => {
    if (user) {
      setFormData({
        first_name: user.first_name || "",
        last_name: user.last_name || "",
        email: user.email || "",
        phone: user.phone?.toString() || "",
        gender: user.gender?.toLowerCase() || "male",
      });
      setPreviewImage(user.profile_image_url || defaultProfileImage);
      setProfileImage(null);
      setEditing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#7A6E54]/30 border-t-[#7A6E54] rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-gray-600">No profile data found. Please log in again.</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      <AccountSidebar />

      <div className="flex-1 p-6 md:p-10 bg-gradient-to-br from-slate-50 via-white to-slate-50">
        <div className="max-w-3xl mx-auto">
          {/* Profile Card */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            {/* Reduced height Gradient Header */}
            <div className="h-32 md:h-40 bg-gradient-to-r from-[#7A6E54] to-[#6B6048] relative">
              <div className="absolute -bottom-12 left-6 md:left-10">
                <div className="relative w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-white shadow-2xl overflow-hidden bg-white">
                  <img
                    src={previewImage || defaultProfileImage}
                    alt="Profile"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.target.src = defaultProfileImage;
                      e.target.onerror = null;
                    }}
                  />

                  {editing && (
                    <label
                      htmlFor="profile-upload"
                      className="absolute bottom-2 right-2 bg-[#7A6E54] text-white p-3 rounded-full cursor-pointer shadow-lg hover:bg-[#6B6048] transition"
                    >
                      <Camera size={24} />
                      <input
                        id="profile-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageChange}
                      />
                    </label>
                  )}
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="pt-20 pb-10 px-6 md:px-12">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6">
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold text-gray-900">
                    {user.first_name} {user.last_name}
                  </h1>
                  <p className="text-gray-600 mt-2 flex items-center gap-2">
                    <Mail size={18} className="text-[#7A6E54]" />
                    {user.email}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  {!editing ? (
                    <button
                      onClick={() => setEditing(true)}
                      className="flex items-center gap-2 px-6 py-3 bg-[#7A6E54] text-white rounded-lg hover:bg-[#6B6048] transition shadow-md"
                    >
                      <Edit2 size={20} />
                      Edit Profile
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={handleCancel}
                        className="flex items-center gap-2 px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
                      >
                        <X size={20} />
                        Cancel
                      </button>
                      <button
                        onClick={handleSubmit}
                        disabled={saving}
                        className="flex items-center gap-2 px-6 py-3 bg-[#7A6E54] text-white rounded-lg hover:bg-[#6B6048] transition disabled:opacity-50 shadow-md"
                      >
                        <Save size={20} />
                        {saving ? "Saving..." : "Save Changes"}
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Editable Fields Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Personal Info */}
                <div className="space-y-6">
                  <div className="flex items-center gap-3">
                    <UserCircle size={28} className="text-[#7A6E54]" />
                    <h3 className="text-xl font-semibold text-gray-800">Personal Information</h3>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-xl space-y-5">
                    {/* First & Last Name */}
                    {editing ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            First Name
                          </label>
                          <input
                            name="first_name"
                            value={formData.first_name}
                            onChange={handleChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7A6E54] focus:border-[#7A6E54] outline-none transition"
                            placeholder="Enter first name"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Last Name
                          </label>
                          <input
                            name="last_name"
                            value={formData.last_name}
                            onChange={handleChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7A6E54] focus:border-[#7A6E54] outline-none transition"
                            placeholder="Enter last name"
                            required
                          />
                        </div>
                      </div>
                    ) : (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Full Name
                        </label>
                        <p className="text-gray-900 font-medium">
                          {formData.first_name} {formData.last_name || "—"}
                        </p>
                      </div>
                    )}

                    {/* Gender */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Gender
                      </label>
                      {!editing ? (
                        <p className="text-gray-900 font-medium capitalize">
                          {formData.gender || "Not specified"}
                        </p>
                      ) : (
                        <select
                          name="gender"
                          value={formData.gender}
                          onChange={handleChange}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7A6E54] focus:border-[#7A6E54] outline-none transition"
                        >
                          <option value="male">Male</option>
                          <option value="female">Female</option>
                          <option value="other">Other</option>
                        </select>
                      )}
                    </div>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="space-y-6">
                  <div className="flex items-center gap-3">
                    <Mail size={28} className="text-[#7A6E54]" />
                    <h3 className="text-xl font-semibold text-gray-800">Contact Information</h3>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-xl space-y-5">
                    {/* Email */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email Address
                      </label>
                      {!editing ? (
                        <p className="text-gray-900 font-medium">{formData.email || "—"}</p>
                      ) : (
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7A6E54] focus:border-[#7A6E54] outline-none transition"
                          placeholder="Enter email address"
                          required
                        />
                      )}
                    </div>

                    {/* Phone */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Phone Number
                      </label>
                      {!editing ? (
                        <p className="text-gray-900 font-medium">{formData.phone || "—"}</p>
                      ) : (
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7A6E54] focus:border-[#7A6E54] outline-none transition"
                          placeholder="Enter phone number"
                          required
                        />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}