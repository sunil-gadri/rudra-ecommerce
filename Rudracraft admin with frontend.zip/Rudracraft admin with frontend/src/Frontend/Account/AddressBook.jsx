// src/Frontend/Account/AddressBook.jsx
import React, { useState, useEffect } from "react";
import {
  MapPin,
  Plus,
  Edit2,
  Trash2,
  X,
} from "lucide-react";
import axiosInstance from "../../utils/axios";
import { toast } from "sonner";
import AccountSidebar from "./AccountSidebar";

export default function AddressBook() {
  const [addresses, setAddresses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editAddress, setEditAddress] = useState(null);

  const customerId = localStorage.getItem("customerId");

  useEffect(() => {
    if (!customerId) {
      toast.error("Please log in to view addresses");
      setLoading(false);
      return;
    }

    const fetchAddresses = async () => {
      try {
        setLoading(true);
        const response = await axiosInstance.get(`/address/${customerId}`);
        let addrList = response.data.addresses || [];
        
        // Sort by ID descending (newest first) - assuming higher ID = newer
        addrList.sort((a, b) => b.id - a.id);
        
        // Alternative: If you have created_at timestamp (uncomment if available)
        // addrList.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        setAddresses(addrList);
      } catch (error) {
        toast.error("Failed to load addresses");
      } finally {
        setLoading(false);
      }
    };

    fetchAddresses();
  }, [customerId]);

  const handleSaveAddress = async (formData) => {
    try {
      const endpoint = editAddress
        ? `/address/${customerId}/${editAddress.id}`
        : `/address/${customerId}`;
      const method = editAddress ? "put" : "post";

      await axiosInstance[method](endpoint, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      toast.success(editAddress ? "Address updated!" : "Address added!");
      setShowModal(false);
      setEditAddress(null);

      // Refetch and sort again after save
      const response = await axiosInstance.get(`/address/${customerId}`);
      let addrList = response.data.addresses || [];
      
      // Sort newest first (by ID descending)
      addrList.sort((a, b) => b.id - a.id);
      
      // Alternative timestamp sort (uncomment if you have created_at)
      // addrList.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

      setAddresses(addrList);
    } catch (error) {
      toast.error(error?.response?.data?.message || "Operation failed");
    }
  };

  const handleDelete = async (addressId) => {
    if (!window.confirm("Delete this address?")) return;
    try {
      await axiosInstance.delete(`/address/${customerId}/${addressId}`);
      toast.success("Address deleted");
      setAddresses(addresses.filter((a) => a.id !== addressId));
    } catch (error) {
      toast.error("Failed to delete address");
    }
  };

  const openEditModal = (addr) => {
    setEditAddress(addr);
    setShowModal(true);
  };

  const content = (
    <div className="flex-1 p-8 bg-gradient-to-br from-slate-50 via-white to-slate-50">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-2">
              <MapPin size={20} className="text-gray-600" />
              <h1 className="text-lg font-semibold text-gray-800">Address Book</h1>
            </div>
            <button
              onClick={() => {
                setEditAddress(null);
                setShowModal(true);
              }}
              className="flex items-center gap-1 px-4 py-2 border border-gray-300 rounded-md text-sm font-medium hover:bg-gray-50 transition"
            >
              <Plus size={16} />
              Add New
            </button>
          </div>

          {loading && (
            <div className="text-center py-8 text-gray-500">Loading...</div>
          )}

          {!loading && addresses.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No addresses saved yet
            </div>
          )}

          {!loading && addresses.length > 0 && (
            <div className="space-y-4">
              {addresses.map((addr) => (
                <div
                  key={addr.id}
                  className="relative border border-gray-300 rounded-md p-4 hover:border-gray-400 transition-all"
                >
              {/* Address selection radio icon - now using MapPin */}
<div className="absolute left-4 top-5 w-5 h-5 border-[#7A6E54] flex items-center justify-center bg-white">
  <MapPin size={14} className="text-[#7A6E54]" strokeWidth={2.5} />
</div>

                  <div className="pl-10">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-gray-800">
                          {addr.full_name} ({addr.address_type})
                        </h3>
                        <p className="text-sm text-gray-600 mt-1">
                          {addr.building}, {addr.street_address}, {addr.city},{" "}
                          {addr.state} - {addr.postal_code}
                        </p>
                        <p className="text-sm text-gray-600 mt-1">
                          Phone: {addr.phone}
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => openEditModal(addr)}
                          className="p-1 hover:bg-gray-100 rounded"
                        >
                          <Edit2 size={16} className="text-gray-600" />
                        </button>
                        <button
                          onClick={() => handleDelete(addr.id)}
                          className="p-1 hover:bg-gray-100 rounded"
                        >
                          <Trash2 size={16} className="text-red-500" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {showModal && (
        <AddressModal
          onClose={() => {
            setShowModal(false);
            setEditAddress(null);
          }}
          onSave={handleSaveAddress}
          initialData={editAddress}
        />
      )}
    </div>
  );

  return (
    <div className="flex min-h-screen">
      <AccountSidebar />
      {content}
    </div>
  );
}

function AddressModal({ onClose, onSave, initialData }) {
  const isEdit = !!initialData;

  // Use snake_case keys to match backend
  const [form, setForm] = useState({
    full_name: initialData?.full_name || "",
    phone: initialData?.phone || "",
    email: initialData?.email || "",
    building: initialData?.building || "",
    street_address: initialData?.street_address || "",
    city: initialData?.city || "",
    state: initialData?.state || "",
    postal_code: initialData?.postal_code || "",
    address_type: initialData?.address_type || "Home",
    country: initialData?.country || "India",
  });

  const [saving, setSaving] = useState(false);

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    const required = [
      "full_name", "phone", "email", "building",
      "street_address", "city", "state", "postal_code"
    ];
    for (const field of required) {
      if (!form[field]?.trim()) {
        toast.error(`Please fill ${field.replace(/_/g, " ")}`);
        return;
      }
    }

    setSaving(true);
    const formData = new FormData();

    Object.entries(form).forEach(([key, value]) => {
      formData.append(key, value);
    });

    try {
      await onSave(formData);
    } catch (err) {
      // Error handled in onSave
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-lg p-6 relative">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-1 hover:bg-gray-100 rounded"
        >
          <X size={20} />
        </button>

        <h2 className="text-xl font-bold mb-6">
          {isEdit ? "Edit Address" : "Add New Address"}
        </h2>

        <div className="space-y-4">
          <input
            placeholder="Full Name *"
            value={form.full_name}
            onChange={(e) => handleChange("full_name", e.target.value)}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
            required
          />
          <input
            placeholder="Phone Number *"
            value={form.phone}
            onChange={(e) => handleChange("phone", e.target.value)}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
            required
          />
          <input
            type="email"
            placeholder="Email Address *"
            value={form.email}
            onChange={(e) => handleChange("email", e.target.value)}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
            required
          />

          <div className="flex gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="address_type"
                value="Home"
                checked={form.address_type === "Home"}
                onChange={(e) => handleChange("address_type", e.target.value)}
                className="accent-[#7A6E54]"
              />
              Home
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="address_type"
                value="Office"
                checked={form.address_type === "Office"}
                onChange={(e) => handleChange("address_type", e.target.value)}
                className="accent-[#7A6E54]"
              />
              Office
            </label>
          </div>

          <select
            value={form.country}
            onChange={(e) => handleChange("country", e.target.value)}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
          >
            <option value="India">India</option>
          </select>

          <input
            placeholder="Building / Flat No. *"
            value={form.building}
            onChange={(e) => handleChange("building", e.target.value)}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
            required
          />
          <input
            placeholder="Street / Locality *"
            value={form.street_address}
            onChange={(e) => handleChange("street_address", e.target.value)}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
            required
          />

          <div className="grid grid-cols-3 gap-4">
            <input
              placeholder="City *"
              value={form.city}
              onChange={(e) => handleChange("city", e.target.value)}
              className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
              required
            />
            <input
              placeholder="State *"
              value={form.state}
              onChange={(e) => handleChange("state", e.target.value)}
              className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
              required
            />
            <input
              placeholder="PIN Code *"
              value={form.postal_code}
              onChange={(e) => handleChange("postal_code", e.target.value)}
              className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#7A6E54]"
              required
            />
          </div>

          <div className="flex gap-4 mt-6">
            <button
              onClick={onClose}
              className="flex-1 py-2.5 border border-gray-300 rounded hover:bg-gray-50 transition"
              disabled={saving}
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={saving}
              className="flex-1 py-2.5 bg-[#7A6E54] text-white rounded hover:bg-[#6B6048] transition disabled:opacity-60"
            >
              {saving ? "Saving..." : isEdit ? "Update Address" : "Save Address"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}