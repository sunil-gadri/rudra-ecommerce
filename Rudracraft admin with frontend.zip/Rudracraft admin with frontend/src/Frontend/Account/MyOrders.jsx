// src/Frontend/Account/MyOrders.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../utils/axios";
import { toast } from "sonner";
import { Clock, CheckCircle, XCircle, Package, ChevronRight } from "lucide-react";
import AccountSidebar from "./AccountSidebar";

export default function MyOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    current_page: 1,
    total_pages: 1,
    total_products: 0,
  });

  const navigate = useNavigate();
  const customerId = localStorage.getItem("customerId");

  // Fetch orders
  useEffect(() => {
    if (!customerId) {
      toast.error("Please log in to view orders");
      setLoading(false);
      return;
    }

    const fetchOrders = async (page = 1) => {
      try {
        setLoading(true);
        const response = await axiosInstance.get(`/customers/${customerId}/orders?page=${page}&limit=10`);
        
        // Assuming API returns { orders: [...], pagination: {...} }
        const data = response.data;
        setOrders(data.orders || []);
        setPagination(data.pagination || {
          current_page: 1,
          total_pages: 1,
          total_products: 0,
        });
      } catch (error) {
        toast.error(error?.response?.data?.message || "Failed to load orders");
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [customerId]);

  // Handle pagination change
  const handlePageChange = (newPage) => {
    if (newPage < 1 || newPage > pagination.total_pages) return;
    // Re-fetch for new page (or update state if you fetch all at once)
    // For now assuming single page fetch
    // fetchOrders(newPage);
  };

  // Status badge styling
  const getStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case "confirmed":
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
            <CheckCircle size={14} /> Confirmed
          </span>
        );
      case "pending":
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">
            <Clock size={14} /> Pending
          </span>
        );
      case "cancelled":
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">
            <XCircle size={14} /> Cancelled
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
            <Package size={14} /> {status || "Unknown"}
          </span>
        );
    }
  };

  return (
    <div className="flex min-h-screen">
      <AccountSidebar />

      <div className="flex-1 p-6 md:p-10 bg-gradient-to-br from-slate-50 via-white to-slate-50">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">My Orders</h1>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="w-12 h-12 border-4 border-[#7A6E54]/30 border-t-[#7A6E54] rounded-full animate-spin"></div>
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl shadow-md">
              <Package size={64} className="mx-auto text-gray-400 mb-4" />
              <h2 className="text-2xl font-semibold text-gray-700 mb-2">No Orders Yet</h2>
              <p className="text-gray-500 mb-6">Start shopping to see your orders here!</p>
              <button
                onClick={() => navigate("/shop")}
                className="px-6 py-3 bg-[#7A6E54] text-white rounded-lg hover:bg-[#6B6048] transition"
              >
                Browse Products
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map((order) => (
                <div
                  key={order.order_id}
                  onClick={() => navigate(`/customers/${customerId}/orders/${order.order_id}`)}
                  className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer border border-gray-100"
                >
                  <div className="p-6 flex flex-col md:flex-row gap-6 items-start md:items-center">
                    {/* Product Image */}
                    <div className="w-24 h-24 md:w-32 md:h-32 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                      <img
                        src={
                          order.product_image?.startsWith("http")
                            ? order.product_image
                            : `${axiosInstance.defaults.baseURL}${order.product_image}`
                        }
                        alt={order.product_name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.target.src = "https://via.placeholder.com/150?text=Product";
                        }}
                      />
                    </div>

                    {/* Order Details */}
                    <div className="flex-1">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-3">
                        <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">
                          {order.product_name}
                        </h3>
                        {getStatusBadge(order.status)}
                      </div>

                      <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                        {order.product_description?.replace(/<[^>]+>/g, "") || "No description"}
                      </p>

                      <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <Clock size={16} />
                          <span>{order.order_at}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Package size={16} />
                          <span>Order ID: #{order.order_id}</span>
                        </div>
                      </div>
                    </div>

                    {/* Arrow for navigation */}
                    <ChevronRight size={24} className="text-gray-400 hidden md:block" />
                  </div>
                </div>
              ))}

              {/* Pagination (simple) */}
              {pagination.total_pages > 1 && (
                <div className="flex justify-center items-center gap-4 mt-8">
                  <button
                    onClick={() => handlePageChange(pagination.current_page - 1)}
                    disabled={pagination.current_page === 1}
                    className="px-4 py-2 border rounded-lg disabled:opacity-50"
                  >
                    Previous
                  </button>
                  <span className="text-gray-600">
                    Page {pagination.current_page} of {pagination.total_pages}
                  </span>
                  <button
                    onClick={() => handlePageChange(pagination.current_page + 1)}
                    disabled={pagination.current_page === pagination.total_pages}
                    className="px-4 py-2 border rounded-lg disabled:opacity-50"
                  >
                    Next
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}