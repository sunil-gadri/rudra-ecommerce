import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axiosInstance from "../../utils/axios";
import { toast } from "sonner";
import {
  CheckCircle,
  Clock,
  XCircle,
  Package,
  CreditCard,
  Truck,
  MapPin,
  Calendar,
} from "lucide-react";
import AccountSidebar from "./AccountSidebar";

export default function OrderDetailsUser() {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  const customerId = localStorage.getItem("customerId");

  useEffect(() => {
    if (!orderId || !customerId) {
      toast.error("Invalid order or not logged in");
      setLoading(false);
      return;
    }

    const fetchOrder = async () => {
      try {
        setLoading(true);
        const res = await axiosInstance.get(`/orders/${orderId}`);
        setOrder(res.data);
      } catch (err) {
        toast.error("Failed to load order details");
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();
  }, [orderId, customerId]);

  const getStatusBadge = (status) => {
    const s = status?.toLowerCase();
    if (s === "confirmed" || s === "paid") {
      return (
        <span className="px-3 py-1 text-sm rounded-full bg-green-100 text-green-700 flex items-center gap-1">
          <CheckCircle size={16} /> {status}
        </span>
      );
    }
    if (s === "pending") {
      return (
        <span className="px-3 py-1 text-sm rounded-full bg-yellow-100 text-yellow-700 flex items-center gap-1">
          <Clock size={16} /> {status}
        </span>
      );
    }
    if (s === "cancelled") {
      return (
        <span className="px-3 py-1 text-sm rounded-full bg-red-100 text-red-700 flex items-center gap-1">
          <XCircle size={16} /> {status}
        </span>
      );
    }
    return (
      <span className="px-3 py-1 text-sm rounded-full bg-gray-100 text-gray-700">
        {status || "Unknown"}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="w-10 h-10 border-4 border-[#7A6E54]/30 border-t-[#7A6E54] rounded-full animate-spin" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-lg text-gray-600">Order not found</p>
      </div>
    );
  }

  /* ---------------- calculations ---------------- */

  const subtotal = order.items.reduce((sum, i) => {
    const price = Number(i.base_price || i.price);
    return sum + price * i.quantity;
  }, 0);

  const shipping = Number(order.shipping_cost || 0);
  const coupon = Number(order.coupon_discount || 0);
  const grandTotal = Number(order.total_amount || 0);

  return (
    <div className="flex min-h-screen bg-slate-50">
      <AccountSidebar />

      <div className="flex-1 p-6 md:p-10">
        <div className="max-w-6xl mx-auto space-y-10">
          {/* ---------- Header ---------- */}
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold">
                Order #{order.order_id}
              </h1>
              <p className="flex items-center gap-2 text-gray-600 mt-1">
                <Calendar size={16} />
                {order.order_at}
              </p>
            </div>
            <div className="flex items-center gap-4">
              {getStatusBadge(order.status)}
              <span className="text-sm text-gray-700">
                Payment: <strong>{order.payment_status?.toUpperCase()}</strong>
              </span>
            </div>
          </div>

          {/* ---------- Main Grid ---------- */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* ---------- Items ---------- */}
            <div className="lg:col-span-2 space-y-4">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Package size={20} /> Ordered Items
              </h2>

              <div className="bg-white rounded-xl shadow divide-y">
                {order.items.map((item) => {
                  const base = Number(item.base_price || item.price);
                  const discountAmount = (base * Number(item.discount)) / 100;
                  const taxAmount = ((base - discountAmount) * Number(item.tax)) / 100;
                  const lineTotal = (base - discountAmount + taxAmount) * item.quantity;

                  return (
                  <div
  key={item.order_item_id}
  className="p-5 flex flex-col sm:flex-row gap-5 bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
>
  {/* Product Image */}
  <div className="relative">
    <img
      className="w-28 h-28 rounded-lg object-cover bg-gray-100 border"
      src={
        item.product_image_url?.startsWith("http")
          ? item.product_image_url
          : `${axiosInstance.defaults.baseURL}${item.product_image_url}`
      }
      alt={item.product_name}
      onError={(e) =>
        (e.target.src = "https://via.placeholder.com/150")
      }
    />

    {/* Discount Badge */}
    {item.discount > 0 && (
      <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs px-2 py-0.5 rounded-full">
        -{item.discount}%
      </span>
    )}
  </div>

  {/* Product Details */}
  <div className="flex-1 space-y-3">
    <h3 className="text-lg font-semibold text-gray-800">
      {item.product_name}
    </h3>

    {/* Info Grid */}
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm mt-2">
      <div className="bg-gray-50 rounded-lg p-2">
        <span className="text-gray-500 text-xs">Qty</span>
        <p className="font-medium">{item.quantity}</p>
      </div>

 <div className="bg-gray-50 rounded-lg p-2 text-center">
  <span className="text-black text-xs">Price</span>
  <p className="font-medium line-through decoration-black decoration-2">
    ₹{item.price}
  </p>
</div>

       <div className="bg-gray-50 rounded-lg p-2">
        <span className="text-gray-500 text-xs">Discounted Price</span>
        <p className="font-medium">₹{item.discounted_price}</p> 
      </div>

      <div className="bg-red-50 rounded-lg p-2">
        <span className="text-gray-500 text-xs">Discount</span>
        <p className="font-medium text-red-600">
          -{item.discount}%
        </p>
      </div>

    </div>

    {/* Divider */}
    <div className="border-t pt-3 flex justify-between items-center">
      <span className="text-sm text-gray-500">Line Total</span>
      <span className="text-lg font-semibold text-gray-900">
        ₹{lineTotal.toFixed(2)}
      </span>
    </div>
  </div>
</div>

                  );
                })}
              </div>
            </div>

            {/* ---------- Sidebar ---------- */}
            <div className="space-y-6">
              {/* Shipping */}
              <div className="bg-white p-5 rounded-xl shadow">
                <h3 className="font-semibold flex items-center gap-2 mb-3">
                  <Truck size={18} /> Shipping Details
                </h3>
                <p><strong>{order.shipping_details?.shipping_name}</strong></p>
                <p>{order.shipping_details?.shipping_phone}</p>
                <p>{order.shipping_details?.shipping_email}</p>
                <p className="text-sm mt-2">
                  {order.shipping_details?.building},{" "}
                  {order.shipping_details?.street_address},{" "}
                  {order.shipping_details?.city},{" "}
                  {order.shipping_details?.state} -{" "}
                  {order.shipping_details?.postal_code},{" "}
                  {order.shipping_details?.country}
                </p>
              </div>

              {/* Billing */}
              <div className="bg-white p-5 rounded-xl shadow">
                <h3 className="font-semibold flex items-center gap-2 mb-3">
                  <MapPin size={18} /> Billing Address
                </h3>
                <p className="text-sm">
                  {order.billing_details?.street_address},{" "}
                  {order.billing_details?.city},{" "}
                  {order.billing_details?.state} -{" "}
                  {order.billing_details?.postal_code},{" "}
                  {order.billing_details?.country}
                </p>
              </div>

     {/* Order Summary */}
<div className="bg-white p-6 rounded-xl shadow border border-gray-100">
  <h3 className="font-semibold text-lg flex items-center gap-2 mb-5">
    <CreditCard size={18} /> Order Summary
  </h3>

  <div className="space-y-4 text-base">
    {/* Order Amount (original price before any discount) */}
    <div className="flex justify-between items-center">
      <span className="text-gray-600">Order Amount</span>
      <span className="font-semibold text-gray-900">
        ₹{Number(order.order_amount || 0).toFixed(2)}
      </span>
    </div>

    {/* Order Saving (total discount on items) */}
    <div className="flex justify-between items-center text-green-700">
      <span>Order Saving</span>
      <span className="font-semibold">
        -₹{Number(order.total_discount || 0).toFixed(2)}
      </span>
    </div>

    {/* Coupon Saving */}
    <div className="flex justify-between items-center text-green-700">
      <span>Coupon Saving {order.coupon_code ? `(${order.coupon_code})` : ""}</span>
      <span className="font-semibold">
        -₹{Number(order.coupon_discount || 0).toFixed(2)}
      </span>
    </div>

    {/* Shipping Cost */}
    <div className="flex justify-between items-center">
      <span className="text-gray-600">Shipping Cost</span>
      <span className="font-semibold">
        ₹{Number(order.shipping_cost || 0).toFixed(2)}
      </span>
    </div>

    {/* Final Total Amount */}
    <div className="pt-4 mt-3 border-t border-gray-200 flex justify-between items-center">
      <span className="text-lg font-semibold text-gray-900">Total Amount</span>
      <span className="text-2xl font-bold text-[#7A6E54]">
        ₹{Number(order.total_amount || 0).toFixed(2)}
      </span>
    </div>
  </div>
</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
