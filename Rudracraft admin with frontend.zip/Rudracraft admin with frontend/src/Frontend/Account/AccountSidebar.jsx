// src/Frontend/Account/AccountSidebar.jsx
import { NavLink, useLocation } from "react-router-dom";
import { LogOut, ShoppingBag, User, MapPin, ChevronRight, Home } from "lucide-react";
import { useState } from "react";

const menuItems = [
  { path: "/my-profile", label: "Profile", icon: User },
  { path: "/my-orders", label: "My Orders", icon: ShoppingBag },
  { path: "/my-address", label: "Address Book", icon: MapPin },
  { path: "/", label: "Back to Home", icon: Home },
];

export default function AccountSidebar() {
  const location = useLocation();
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("customerToken");
    localStorage.removeItem("customerId");
    window.location.replace("/");
  };

  const isPathActive = (path) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <>
      <aside className="w-72 bg-white border-r border-slate-200 shadow-lg sticky top-0 h-screen flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#7A6E54] to-[#6B6048] rounded-xl flex items-center justify-center shadow-md">
              <User className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">My Account</h2>
              <p className="text-sm text-slate-500">Manage your profile & orders</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-1">
          {menuItems.map(({ path, label, icon: Icon }) => (
            <NavLink
              key={path}
              to={path}
              className={({ isActive }) =>
                `w-full flex items-center justify-between px-4 py-3.5 rounded-xl transition-all duration-300 group ${
                  isActive || isPathActive(path)
                    ? "bg-gradient-to-r from-[#7A6E54] to-[#6B6048] text-white shadow-lg shadow-[#7A6E54]/30"
                    : "text-slate-700 hover:bg-slate-100 hover:shadow-sm"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className="flex items-center gap-4">
                    <Icon
                      className={`w-5 h-5 transition-colors ${
                        isActive || isPathActive(path)
                          ? "text-white"
                          : "text-slate-600 group-hover:text-[#7A6E54]"
                      }`}
                    />
                    <span
                      className={`font-medium text-base ${
                        isActive || isPathActive(path)
                          ? "text-white"
                          : "text-slate-700 group-hover:text-[#7A6E54]"
                      }`}
                    >
                      {label}
                    </span>
                  </div>
                  <ChevronRight
                    className={`w-4 h-4 transition-all duration-300 ${
                      isActive || isPathActive(path)
                        ? "text-white translate-x-1"
                        : "text-slate-400 opacity-0 group-hover:opacity-100 group-hover:translate-x-1"
                    }`}
                  />
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Logout Button */}
        <div className="p-4 border-t border-slate-200">
          <button
            onClick={() => setShowLogoutModal(true)}
            className="w-full flex items-center justify-center gap-3 px-5 py-3.5 bg-red-50 text-red-600 rounded-xl font-medium hover:bg-red-100 hover:shadow-sm transition-all duration-300 group"
          >
            <LogOut className="w-5 h-5 group-hover:scale-110 transition-transform" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Logout Confirmation Modal */}
      {showLogoutModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="p-6 border-b border-slate-200">
              <h3 className="text-xl font-bold text-slate-900">Confirm Logout</h3>
              <p className="text-sm text-slate-500 mt-1">
                Are you sure you want to log out of your account?
              </p>
            </div>

            {/* Body */}
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-3 text-sm text-slate-600">
                <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center">
                  <LogOut className="w-5 h-5 text-red-600" />
                </div>
                <p>You'll need to sign in again to access your account.</p>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center gap-3 p-6 border-t border-slate-200 bg-slate-50">
              <button
                onClick={() => setShowLogoutModal(false)}
                className="flex-1 py-3 px-5 bg-white border border-slate-300 rounded-xl font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowLogoutModal(false);
                  handleLogout();
                }}
                className="flex-1 py-3 px-5 bg-red-600 text-white rounded-xl font-medium hover:bg-red-700 transition-colors shadow-sm"
              >
                Yes, Logout
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}