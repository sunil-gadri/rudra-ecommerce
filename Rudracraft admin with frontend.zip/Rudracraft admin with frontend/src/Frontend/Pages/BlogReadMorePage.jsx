import React from "react";
import { BlogReadMore } from "../Components/BlogReadMore";

export const BlogReadMorePage = () => {
  return (
    <>
        <BlogReadMore />
    </>
  );
};
