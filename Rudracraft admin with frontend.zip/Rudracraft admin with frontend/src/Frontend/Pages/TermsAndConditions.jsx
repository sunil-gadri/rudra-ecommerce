import React from "react";
import policyimg from "../../Assets/policyimg.jpg";

import { MdKeyboardArrowRight } from "react-icons/md";

export const TermsAndConditions = () => {
  const sections = [
    {
      title: "Acceptance of Terms",
      content: "By using our website or mobile app, you confirm that: You have read and understood these Terms. You are at least 18 years old or have parental permission. You agree to follow all rules, policies, and guidelines mentioned here."
    },
    {
      title: "Use of Our Platforms",
      content: "You agree to use our website/app only for lawful purposes. Not to harm, interrupt, or misuse our services or servers. Not to upload harmful files, attempt unauthorized access, or copy our content without permission."
    },
    {
      title: "Account Registration",
      content: "To make purchases, you may need to create an account. You are responsible for maintaining the confidentiality of your login credentials. Any activity done through your account will be your responsibility. RudraCraft is not liable for losses due to unauthorized account access caused by user negligence."
    },
    {
      title: "Product Information",
      content: "We strive to provide accurate product descriptions and images. However, slight variations in color or design may occur due to photography and screen differences. We reserve the right to update product details, prices, or availability without notice."
    },
    {
      title: "Orders & Payments",
      content: "All orders are subject to product availability and confirmation. We may cancel or refuse an order due to stock issues, incorrect pricing, or suspicious activity. Payments must be completed using secure payment options available in the app and website. In case of failed transactions, deducted amounts will be refunded as per banking timelines."
    },
    {
      title: "Pricing & Billing",
      content: "Prices listed on the website/app are final and may include/exclude taxes as applicable. Errors in pricing due to technical issues may result in order cancellation or refunds. We reserve the right to update prices at any time."
    },
    {
      title: "Shipping & Delivery",
      content: "Estimated delivery timelines will be shown at checkout. Delays may occur due to courier issues, location constraints, or unforeseen events. RudraCraft is not responsible for delivery delays beyond our control."
    },
    {
      title: "Returns, Refunds & Exchanges",
      content: "Returns are accepted as per our Return & Refund Policy. Products must be unused, undamaged, and in original packaging. Refunds are processed only after the returned product passes quality checks. Certain products may not be eligible for returns (e.g., hygiene-sensitive items)."
    },
    {
      title: "Cancellation Policy",
      content: "Orders can be canceled before they are shipped. If already shipped, cancellation may not be possible. Refunds for canceled orders follow standard timelines."
    },
    {
      title: "Offers, Discounts & Promotions",
      content: "All offers are subject to specific terms and validity. RudraCraft reserves the right to modify or withdraw promotions at any time. Coupon codes may not apply to all products."
    },
    {
      title: "Intellectual Property",
      content: "All text, logos, graphics, images, and designs on our website/app belong to RudraCraft. Copying, reproducing, or using any content without written permission is prohibited."
    },
    {
      title: "Privacy & Data Security",
      content: "Your personal information is handled according to our Privacy Policy. By using our platforms, you permit RudraCraft to collect and use information necessary for order processing and service improvement. We use industry-standard security measures but cannot guarantee absolute security."
    },
    {
      title: "Third-Party Services",
      content: "Our platforms may include links or integrations to third-party websites, apps, or payment gateways. RudraCraft is not responsible for the content, privacy, or practices of any third-party services."
    },
    {
      title: "Mobile App Permissions",
      content: "The RudraCraft mobile app may require certain permissions such as: Storage access (to save app files), Camera access (for profile photos), Notification access (to send order updates and offers). You may manage these permissions in your device settings."
    },
    {
      title: "Limitation of Liability",
      content: "RudraCraft is not liable for any direct, indirect, incidental, or consequential damages arising out of the use of our website/app. We do not guarantee uninterrupted, error-free service. You agree to use the platforms at your own risk."
    },
    {
      title: "Modification of Terms",
      content: "RudraCraft may update or modify these Terms at any time. Changes will be posted on the website/app. Continued use after changes implies acceptance of updated Terms."
    },
    {
      title: "Governing Law",
      content: "These Terms are governed by the laws of India. Any disputes shall be handled under the jurisdiction of courts in Jaipur, Rajasthan."
    }
  ];

  return (
    <>
    
      <div className="w-full flex justify-center items-center">
        <div className="relative text-start">
          <img src={policyimg} alt="policyimg" />
          <div className="absolute top-1/2 left-[4%] -translate-y-1/2">
            <h1 className="text-[20px] md:text-[48px]">Terms & Conditions</h1>
            <div className="flex items-center gap-[1px] justify-start">
              <a className="text-[#3F4754]" href="/">
                Home
              </a>
              <MdKeyboardArrowRight />
              <a className="text-[#3F4754]" href="#">
                Terms & Conditions
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-6 p-12">
        <div className="flex flex-col gap-2">
          <h2 className="text-2xl font-bold">Terms & Conditions – RudraCraft</h2>
          <p className="text-gray-600">
            Welcome to RudraCraft ("Company", "we", "our", "us"). These Terms & Conditions ("Terms") govern your use of our website (rudracrafts.com) and mobile application (RudraCraft App). By accessing, browsing, or using any of our platforms, you agree to be bound by these Terms. If you do not agree, please discontinue use immediately.
          </p>
        </div>

        {sections.map((section, index) => (
          <div key={index} className="flex flex-col gap-2">
            <h4 className="text-2xl font-semibold">{index + 1}. {section.title}</h4>
            <p className="text-lg text-gray-700 leading-relaxed">{section.content}</p>
          </div>
        ))}

        <div className="flex flex-col gap-4 mt-6 pt-6 border-t border-gray-300">
          <h3 className="text-lg font-semibold">Contact Information</h3>
          <p className="text-gray-700">
            For queries, complaints, or support, contact us:
          </p>
          <div className="flex flex-col gap-2 ml-4">
            <p><strong>Email:</strong> support@rudracrafts.com</p>
            <p><strong>Address:</strong> Jaipur, Rajasthan</p>
          </div>
        </div>
      </div>
      
    </>
  );
};