import React from 'react';
import { Link } from 'react-router-dom';
import { Home } from 'lucide-react'; // Optional icon from lucide-react

function PageNotFoundUser() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8">
      {/* Main Container */}
      <div className="max-w-md w-full text-center">
        {/* 404 Number */}
        <h1 className="text-8xl md:text-9xl font-extrabold text-gray-200 select-none">
          404
        </h1>

        {/* Overlay Text */}
        <div className="relative -mt-16 md:-mt-20">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-800 mb-4">
            Oops! Page Not Found
          </h2>
          <p className="text-base md:text-lg text-gray-600 mb-8 leading-relaxed">
            The page you're looking for doesn't exist or has been moved.
            <br />
            Don't worry, let's get you back on track!
          </p>
        </div>

        {/* Back to Home Button */}
        <Link
          to="/"
          className="inline-flex items-center gap-3 px-8 py-4 bg-[#7A6E54] hover:bg-[#6B6048] text-white font-semibold text-lg rounded-xl shadow-lg transition-all duration-300 transform hover:scale-105 active:scale-95"
        >
          <Home className="w-5 h-5" />
          Back to Home
        </Link>

        {/* Optional Fun Illustration Text */}
        <div className="mt-12 text-gray-400 text-sm">
          <p>Or maybe the page is out shopping... 🛍️</p>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-[#7A6E54]/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-pink-200/20 rounded-full blur-3xl"></div>
      </div>
    </div>
  );
}

export default PageNotFoundUser;