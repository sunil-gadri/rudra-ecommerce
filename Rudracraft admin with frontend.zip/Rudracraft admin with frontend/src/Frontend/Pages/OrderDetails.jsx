import React, { useEffect } from "react";
import { IoIosArrowRoundBack } from "react-icons/io";
import { Link } from "react-router-dom";
import LayoutFront from "./LayoutFornt";

const OrderDetails = () => {
  // ================== DUMMY DATA ==================
  const item = {
    order_id: "ORD123456789",
    order_created_at: "2025-11-28T10:30:00Z", // Sample date
    quantity: 2,
    price: 1499.0,
    product_name: "Premium Cotton Kurta Set - Blue",
    thumbnail_url:
      "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",

    shipping_first_name: "Rahul",
    shipping_last_name: "Sharma",
    shipping_address_line1: "Flat No. 302, Sunshine Apartments",
    shipping_address_line2: "Near Metro Station, Andheri East",
    shipping_city: "Mumbai",
    shipping_state: "Maharashtra",
    shipping_country: "India",
    shipping_zip_code: "400069",
    shipping_phone: "+91 98765 43210",
    shipping_email: "rahul.sharma@example.com",
    customer_email: "rahul.sharma@example.com",
  };
  // ================================================

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const orderTotal = (Number(item.price) * item.quantity).toFixed(2);
  const orderDate = new Date(item.order_created_at).toLocaleDateString("en-US", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <LayoutFront>
      <div className="max-w-6xl mx-auto px-4 py-10 mt-10">
        {/* Back Button */}
        <div className="mb-8">
          <Link
            to="/customer"
            className="flex items-center gap-2 text-gray-700 hover:text-green-700 transition-colors"
          >
            <IoIosArrowRoundBack className="text-2xl" />
            <span className="underline">Back to orders</span>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-20">
          {/* Left Column - Product & Order Info */}
          <div className="space-y-8">
            {/* Order Status Header */}
            <div>
              <h2 className="text-2xl font-bold text-green-700 mb-2">
                Order Delivered
              </h2>
              <p className="text-gray-600">
                Shipment 1 of 1 • {item.quantity} item
                {item.quantity > 1 ? "s" : ""} ({item.quantity} Delivered)
              </p>
              <div className="mt-3 flex flex-col sm:flex-row items-start sm:items-center gap-6">
                <p className="text-sm text-gray-500">
                  Order placed on <strong>{orderDate}</strong>
                </p>
                <button className="border border-gray-400 px-6 py-2 text-sm hover:bg-gray-50 transition rounded">
                  Download Invoice
                </button>
              </div>
            </div>

            {/* Product Card */}
            <div className="flex gap-6">
              <img
                src={item.thumbnail_url}
                alt={item.product_name}
                className="w-32 h-32 md:w-40 md:h-40 object-cover rounded-lg shadow-md"
                onError={(e) =>
                  (e.target.src =
                    "https://via.placeholder.com/400x400?text=Product+Image")
                }
              />
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">
                  {item.product_name}
                </h3>
                <p className="text-xl font-bold text-gray-800 mt-2">
                  ₹{Number(item.price).toFixed(2)}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  Includes all taxes & convenience fee
                </p>
              </div>
            </div>
          </div>

          {/* Right Column - Payment & Shipping */}
          <div className="space-y-6">
            {/* Payment Details */}
            <div className="border border-gray-300 rounded-lg p-6 bg-gray-50">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm text-gray-500">Order ID</span>
                <span className="font-mono font-semibold">#{item.order_id}</span>
              </div>

              <h4 className="font-semibold text-lg mb-4">
                Order Payment Details
              </h4>

              <div className="space-y-3 text-gray-700">
                <div className="flex justify-between">
                  <span>Price (per item)</span>
                  <span>₹{Number(item.price).toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Quantity</span>
                  <span>
                    {item.quantity} item{item.quantity > 1 ? "s" : ""}
                  </span>
                </div>
                <div className="border-t pt-3 mt-3">
                  <div className="flex justify-between font-bold text-lg">
                    <span>Order Total</span>
                    <span className="text-green-700">₹{orderTotal}</span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t">
                <p className="font-medium mb-1">Payment Mode</p>
                <p className="text-sm text-gray-600">
                  Paid via Cash on Delivery • ₹{orderTotal}
                </p>
                <button className="text-blue-600 text-sm mt-3 underline hover:no-underline">
                  View Return Policy
                </button>
              </div>
            </div>

            {/* Shipping Address */}
            <div className="border border-gray-300 rounded-lg p-6 bg-gray-50">
              <h4 className="font-semibold text-lg mb-4">Delivered to</h4>
              <div className="text-gray-800">
                <p className="font-bold text-lg">
                  {item.shipping_first_name} {item.shipping_last_name}
                </p>
                <p className="mt-2">
                  {item.shipping_address_line1}
                  {item.shipping_address_line2 &&
                    `, ${item.shipping_address_line2}`}
                </p>
                <p>
                  {item.shipping_city}, {item.shipping_state} -{" "}
                  {item.shipping_zip_code}
                </p>
                <p>{item.shipping_country}</p>
                <p className="mt-3">
                  <strong>Phone:</strong> {item.shipping_phone}
                </p>
                <p>
                  <strong>Email:</strong>{" "}
                  {item.shipping_email || item.customer_email || "Not provided"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </LayoutFront>
  );
};

export default OrderDetails;