import React, { useState, useEffect } from "react";
import Countdown from "react-countdown";
import { ClassyCollection } from "../Components/ClassyCollection";
import { DiscountBanner } from "../Components/DiscountBanner";
import { OurServices } from "../Components/OurServices";
import Subscription from "../Components/Subscription";
import { useMediaQuery } from "@mui/material";
import { FaStar } from "react-icons/fa";
import Marquee from "react-fast-marquee";
import flowericon from '../../Assets/flowericon.svg'
import { BsArrowLeftCircleFill, BsArrowRightCircleFill } from "react-icons/bs";
import CIMG1 from "../../Assets/collection-img-2.jpg";
import CIMG2 from "../../Assets/collection-img-3.jpeg";
import CIMG3 from "../../Assets/collection-img-4.jpeg";
import CIMG4 from "../../Assets/collection-img-1.jpg";
import shopcrouselbannerimg from "../../Assets/collection-img-1.jpg";
import shopbanner1 from "../../Assets/shopbanner1.jpeg";
import shopbanner2 from "../../Assets/shopbanner2.jpeg";
import collectionimg1 from "../../Assets/collection-img-1.jpg";
import collectionimg2 from "../../Assets/collection-img-2.jpg";
import collectionimg3 from "../../Assets/collection-img-3.jpeg";
import collectionimg4 from "../../Assets/collection-img-4.jpeg";
import "swiper/css/effect-fade";
import { Autoplay, EffectCube, EffectFade, Parallax } from "swiper/modules";
import slide1 from "../../Assets/Slide1.jpeg";
import slide2 from "../../Assets/Slide2.jpg";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { ShoppingBag } from "lucide-react";


const SlideInfo = ({ title, price }) => {
  return (
    <div style={{ textAlign: "center", marginTop: "1rem" }}>
      <h2 style={{ fontSize: "1.5rem" }}>{title}</h2>
      <p style={{ fontSize: "1.5rem", color: "#555" }}>${price}</p>
    </div>
  );
};


// HomePage Component
const HomePage = () => {

  const currentYear = new Date().getFullYear();
const targetDate = `${currentYear}-12-31T23:59:59`;

  const CountdownRenderer = ({ days, hours, minutes, seconds, completed }) => {
    if (completed) {
      return <div>The countdown is over!</div>;
    } else {
      return (
        <div
          style={{ gap: isXs ? "2rem" : "", marginTop: ".7rem" }}
          className="flex gap-20 "
        >
          <div className="flex flex-col justify-center items-center gap-0">
            <span
              style={{
                fontFamily: "kugile",
                color: "#7A6E54",
                fontSize: isXs ? "1.5rem" : "",
              }}
              className="text-7xl"
            >
              {days}
            </span>
            <span style={{ fontSize: "1rem", color: "#89867F" }}>Days</span>
          </div>

          <div className="flex flex-col justify-center items-center gap-0">
            <span
              style={{
                fontFamily: "kugile",
                color: "#7A6E54",
                fontSize: isXs ? "1.5rem" : "",
              }}
              className="text-7xl"
            >
              {hours}
            </span>
            <span style={{ fontSize: "1rem", color: "#89867F" }}>Hours</span>
          </div>
          <div className="flex flex-col justify-center items-center gap-0">
            <span
              style={{
                fontFamily: "kugile",
                color: "#7A6E54",
                fontSize: isXs ? "1.5rem" : "",
              }}  
              className="text-7xl"
            >
              {minutes}
            </span>
            <span style={{ fontSize: "1rem", color: "#89867F" }}>Minutes</span>
          </div>
          <div className="flex flex-col justify-center items-center gap-0">
            <span
              style={{
                fontFamily: "kugile",
                color: "#7A6E54",
                fontSize: isXs ? "1.5rem" : "",
              }}
              className="text-7xl"
            >
              {seconds}
            </span>
            <span style={{ fontSize: "1 rem", color: "#89867F" }}>Second</span>
          </div>
        </div>
      );
    }
  };



  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    setShowPopup(true);
  }, []);

  const [currentIndex, setCurrentIndex] = useState(0);
  const isXs = useMediaQuery('(min-width:0px) and (max-width:900px)');

  const reviews = [
    {
      text: "Great service! Highly recommended Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.",
      name: "Jane Doe"
    },
    {
      text: "Great service! Highly recommended Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.",
      name: "John Smith"
    },
    {
      text: "Great service! Highly recommended Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.",
      name: "Jane Doe"
    },
    {
      text: "Great service! Highly recommended Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.",
      name: "Jane Doe"
    },
  ];

  const handlePrev = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex > 0 ? prevIndex - 1 : reviews.length - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex < reviews.length - 1 ? prevIndex + 1 : 0
    );
  };

  const handleSlideTo = (index) => {
    setCurrentIndex(index);
  };

  const [currentIndexNew, setCurrentIndexNew] = useState(0);
  const images = [CIMG1, CIMG2, CIMG3, CIMG4];
  const slideInfo = [
    { title: "Cashmere Dreams", price: "1.00" },
    { title: "Elegant Wool", price: "2.00" },
    { title: "Soft Touch", price: "3.00" },
    { title: "Luxury Blend", price: "4.00" },
  ];

  const totalImages = images.length;

  const prevSlide = () => {
    setCurrentIndexNew((prev) => (prev === 0 ? totalImages - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndexNew((prev) => (prev === totalImages - 1 ? 0 : prev + 1));
  };

  const [isHovered, setIsHovered] = useState(false);
  const [isHovered2, setIsHovered2] = useState(false);
  const buttonStyle = {
    width: "10rem",
    marginTop: "2rem",
    height: "3rem",
    backgroundColor: isHovered ? "white" : "#A91E28",
    color: isHovered ? "black" : "white",
    border: "none",
    transition: "background-color 0.3s, color 0.3s",
    fontFamily: "lora",
  };
  const buttonStyle2 = {
    width: "10rem",
    marginTop: "2rem",
    height: "3rem",
    backgroundColor: isHovered2 ? "white" : "#A91E28",
    color: isHovered2 ? "black" : "white",
    border: "none",
    transition: "background-color 0.3s, color 0.3s",
    fontFamily: "lora",
  };




  return (
    <>
     


        {/*HeaderSlider */}

        <Swiper
          style={{ position: "relative" }}
          spaceBetween={30}
          effect="fade"
          speed={6000}
          centeredSlides={true}
          autoplay={{
            delay: 900,
            disableOnInteraction: false,
          }}
          modules={[Autoplay, EffectFade, EffectCube, Parallax,]}
        >
          <SwiperSlide>
            <div style={{ height: isXs ? "30rem" : '100%' }}><img style={{ objectFit: isXs ? 'cover' : '' }} src={slide1} alt="Slide 1" /></div>
            <div
              style={{
                position: "absolute",
                width: "100%",
                color: "white",
                top: isXs ? "70%" : "62%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                gap: ".2rem",
                fontFamily: "Lora-Regular",
                textAlign: "center",
              }}
            >
              <p style={{ fontSize: isXs ? "1.5rem" : "2.5rem", fontFamily: 'kugile' }}>
                Wrap Yourself in Luxury with Cashmere Shawls
              </p>
              <span
                style={{ fontSize: "1rem", width: "90%", lineHeight: "1.5rem" }}
              >
                Experience the unmatched softness and warmth of our premium cashmere
                shawls, perfect for every occasion.
              </span>
              <button
                style={buttonStyle}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
              >
                Shop Now
              </button>
            </div>
          </SwiperSlide>

          <SwiperSlide>
            <div style={{ height: isXs ? "30rem" : '100%' }}><img style={{ objectFit: isXs ? 'cover' : '' }} src={slide2} alt="Slide 1" /></div>
            <div
              style={{
                position: "absolute",
                width: "100%",
                color: "white",
                top: isXs ? "70%" : "62%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                gap: ".2rem",
                fontFamily: "Lora-Regular",
                textAlign: "center",
              }}
            >
              <p style={{ fontSize: isXs ? "1.5rem" : "2.5rem", fontFamily: 'kugile' }}>
                Handwoven Heritage
              </p>
              <span

                style={{ fontSize: "1rem", width: "90%", lineHeight: "1.5rem" }}
              >
                Discover our collection of beautifully crafted handwoven stoles that celebrate India's rich heritage.
              </span>
              <button
                style={buttonStyle}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
              >
                Shop Now
              </button>
            </div>
          </SwiperSlide>
        </Swiper>


        {/* <FestiveBanner /> */}

        <div
              style={{
                flexDirection: isXs ? "column" : "row",
                padding: isXs ? "2rem" : "",
                gap: isXs ? "2rem" : "",
                height: isXs ? "25rem" : "",
              }}
              className="bg-custom-color w-full h-80 flex justify-center px-20 items-center"
            >
              <div
                style={{ width: "100%", alignItems: isXs ? "center" : "" }}
                className=" flex flex-col "
              >
                <p
                  style={{ fontFamily: "kugile", fontSize: isXs ? "1.6rem" : "" }}
                  className="text-4xl"
                >
                  Festive Sale Bonanza
                </p>
                <p
                  style={{
                    width: isXs ? "95%" : "",
                    textAlign: isXs ? "center" : "",
                    fontSize: isXs ? ".8rem" : "",
                  }}
                  className="w-8/12"
                >
                  "Celebrate the season with unbeatable discounts on our exclusive
                  collection of shawls and stoles. Limited time only
                </p>
                <a href="/shop">
                <button
                  style={{ fontFamily: "lora", display: isXs ? "none" : "", backgroundColor: '#A91E28' }}
                  className="w-40 h-12 text-white mt-7"
                >
                  Shop Now
                </button>
                </a>
                <div
                  style={{ display: isXs ? "" : "none" }}
                  className="countdown-timer"
                >
                  <Countdown date={new Date(targetDate)} renderer={CountdownRenderer} />
                </div>
              </div>
        
              <div style={{ display: isXs ? "none" : "" }} className="countdown-timer">
                <Countdown date={new Date(targetDate)} renderer={CountdownRenderer} />
              </div>
              
              <button
                style={{ fontFamily: "lora", display: isXs ? "" : "none" }}
                className="w-40 h-12 bg-color-shopnow text-white mt-2"
              >
                Shop Now
              </button>
            </div>

        {/* CollectionCrousel */}
<div
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
      style={{
        marginTop: "1rem",
        padding: "1.6rem",
        display: isXs ? "none" : "",
      }}
    >
      {/* Category 1 */}
      <div className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
        <div className="relative h-[30rem] overflow-hidden">
          <img
            src={collectionimg1}
            alt="Collection 1"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-500" />
          
          {/* Content */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
            <div className="text-center transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
              <h3 className="text-2xl font-bold text-white mb-2">Women's Collection</h3>
              <p className="text-sm text-gray-200 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                Explore Latest Trends
              </p>
            </div>
            
            {/* Shop Now Button */}
            <a
              href="/shop"
              className="flex items-center gap-2 px-8 py-3 rounded-full font-semibold transform translate-y-12 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500 delay-150 hover:scale-105"
              style={{ backgroundColor: '#A91E28', color: 'white' }}
            >
              <ShoppingBag size={18} />
              Shop Now
            </a>
          </div>

          {/* Shine Effect */}
          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        </div>
      </div>

      {/* Category 2 */}
      <div className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
        <div className="relative h-[30rem] overflow-hidden">
          <img
            src={collectionimg2}
            alt="Collection 2"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-500" />
          
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
            <div className="text-center transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
              <h3 className="text-2xl font-bold text-white mb-2">Men's Collection</h3>
              <p className="text-sm text-gray-200 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                Discover New Styles
              </p>
            </div>
            
            <a
              href="/shop"
              className="flex items-center gap-2 px-8 py-3 rounded-full font-semibold transform translate-y-12 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500 delay-150 hover:scale-105"
              style={{ backgroundColor: '#A91E28', color: 'white' }}
            >
              <ShoppingBag size={18} />
              Shop Now
            </a>
          </div>

          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        </div>
      </div>

      {/* Category 3 */}
      <div className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
        <div className="relative h-[30rem] overflow-hidden">
          <img
            src={collectionimg3}
            alt="Collection 3"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-500" />
          
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
            <div className="text-center transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
              <h3 className="text-2xl font-bold text-white mb-2">Accessories</h3>
              <p className="text-sm text-gray-200 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                Complete Your Look
              </p>
            </div>
            
            <a
              href="/shop"
              className="flex items-center gap-2 px-8 py-3 rounded-full font-semibold transform translate-y-12 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500 delay-150 hover:scale-105"
              style={{ backgroundColor: '#A91E28', color: 'white' }}
            >
              <ShoppingBag size={18} />
              Shop Now
            </a>
          </div>

          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        </div>
      </div>

      {/* Category 4 */}
      <div className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
        <div className="relative h-[30rem] overflow-hidden">
          <img
            src={collectionimg4}
            alt="Collection 4"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-500" />
          
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
            <div className="text-center transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
              <h3 className="text-2xl font-bold text-white mb-2">New Arrivals</h3>
              <p className="text-sm text-gray-200 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                Fresh & Trending
              </p>
            </div>
            
            <a
              href="/shop"
              className="flex items-center gap-2 px-8 py-3 rounded-full font-semibold transform translate-y-12 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500 delay-150 hover:scale-105"
              style={{ backgroundColor: '#A91E28', color: 'white' }}
            >
              <ShoppingBag size={18} />
              Shop Now
            </a>
          </div>

          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        </div>
      </div>
    </div>

        {/* ShopBanner  */}

        <div style={{ display: 'grid', gridTemplateColumns: isXs ? '1fr' : '' }} className="grid grid-cols-2 gap-8 p-4 ">

          <div data-aos="fade-left" style={{ height: isXs ? '30rem' : '' }} className="h-[50rem] flex items-center justify-center relative">

            <img src={shopbanner1} alt="shopbanner1" className="object-cover w-full h-full" />
            <div data-aos="fade-left" style={{ position: "absolute", margin: "2rem", color: 'white', display: 'flex', flexDirection: 'column', alignItems: isXs ? 'center' : 'center', justifyContent: 'center', bottom: '3rem' }}>
              <div style={{ fontSize: "2.5rem", fontFamily: "lora" }}>
                Winter Luxe
              </div>
              <p data-aos="fade-left" style={{ fontSize: ".9rem", fontFamily: "lora", width: isXs ? "100%" : "70%", textAlign: 'center' }}>
                A luxurious selection of warm and cozy shawls, perfect for the winter
                season, blending style and comfort.
              </p>

              <a href="/shop">
                <button
                  style={buttonStyle}
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                >
                  Shop Now
                </button></a>
            </div>
          </div>

          <div data-aos="fade-right" style={{ height: isXs ? '30rem' : '' }} className="h-[50rem] flex items-center justify-center relative">

            <img src={shopbanner2} alt="shopbanner1" className="object-cover w-full h-full" />
            <div data-aos="fade-right" style={{ position: "absolute", margin: "2rem", color: 'white', display: 'flex', flexDirection: 'column', alignItems: isXs ? 'center' : 'center', justifyContent: 'center', top: '9.5rem', right: '4.5rem' }}>
              <div style={{ fontSize: "2.5rem", fontFamily: "lora" }}>
                Winter Luxe
              </div>
              <p data-aos="fade-left" style={{ fontSize: ".9rem", fontFamily: "lora", width: isXs ? "100%" : "70%", textAlign: 'center' }}>
                A luxurious selection of warm and cozy shawls, perfect for the winter
                season, blending style and comfort.
              </p>

              <a href="/shop">
                <button
                  style={buttonStyle2}
                  onMouseEnter={() => setIsHovered2(true)}
                  onMouseLeave={() => setIsHovered2(false)}
                >
                  Shop Now
                </button></a>
            </div>
          </div>
        </div>

        <ClassyCollection />
        <DiscountBanner />

        {/*ShopCrouse */}
        <div
          data-aos="zoom-out"
          style={{ gridTemplateColumns: isXs ? "1fr" : "" }}
          className="grid grid-cols-2 gap-2 p-2 mt-10"
        >
          <div
            style={{
              display: "flex",
              fontFamily: "Lora",
              flexDirection: "column",
              alignItems: "center",
              padding: isXs ? "3rem" : "6rem",
              gap: ".8rem",
              backgroundColor: "#DBD8CF",
              width: "100%",
              height: isXs ? "45rem" : "56.9rem",
            }}
          >
            <div>
              <h1 style={{ fontSize: "2rem" }}>Shop the look</h1>
            </div>

            <div style={{ fontSize: "1rem", textAlign: "center" }}>
              Felis imperdiet proin fermentum leo vel orci porta!
            </div>

            <div
              style={{
                width: isXs ? "200px" : "250px",
                height: isXs ? "400px" : "350px",
                overflow: "hidden",
                marginTop: "2rem",
              }}
            >
              <div
                style={{
                  display: "flex",
                  transition: "transform 0.5s ease-in-out",
                  transform: `translateX(-${currentIndexNew * 100}%)`,
                  width: `${26 * totalImages}%`,
                  height: "100%",
                }}
              >
                {images.map((image, idx) => (
                  <img
                    src={image}
                    alt={`slide-${idx}`}
                    key={idx}
                    style={{
                      flex: "0 0 100%",
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                      boxShadow: "0px 0px 7px #666",
                    }}
                  />
                ))}
              </div>
            </div>

            <div style={{ textAlign: "center" }}>
              <SlideInfo
                title={slideInfo[currentIndexNew].title}
                price={slideInfo[currentIndexNew].price}
              />
            </div>

            <div style={{ display: "flex", gap: "4rem" }}>
              <BsArrowLeftCircleFill
                onClick={prevSlide}
                style={{
                  transform: "translateY(-50%)",
                  width: "2.5rem",
                  height: "2.5rem",
                  color: "white",
                  cursor: "pointer",
                }}
              />
              <BsArrowRightCircleFill
                onClick={nextSlide}
                style={{
                  transform: "translateY(-50%)",
                  width: "2.5rem",
                  height: "2.5rem",
                  color: "white",
                  cursor: "pointer",
                }}
              />
            </div>
          </div>

          <div style={{ height: '57rem', width: '100%' }}>
            <img
              style={{ width: "100%", height: '100%', objectFit: 'cover' }}
              src={shopcrouselbannerimg}
              alt="Shop Carousel Banner"
            />
          </div>
        </div>

        {/* Marquee Section */}
        <div style={{ width: "100%", height: "6rem", backgroundColor: "#DBD8CF", color: "white", display: "flex", alignItems: "center", fontSize: "1.5rem", fontFamily: "Lora-Regular", marginTop: "2rem" }}>
          <Marquee>
            <div style={{ display: "flex", gap: "2rem", color: "#87462D", justifyContent: "space-between", alignItems: "center" }}>
              <span>Heritage Weaves</span>
              <span><img width={50} src={flowericon} alt="flowericon" /></span>
              <span>Winter Luxe</span>
              <span><img width={50} src={flowericon} alt="flowericon" /></span>
              <span> Festive Radiance</span>
              <span><img width={50} src={flowericon} alt="flowericon" /></span>
              <span>Heritage Weaves</span>
              <span><img width={50} src={flowericon} alt="flowericon" /></span>
              <span>Winter Luxe</span>
              <span><img width={50} src={flowericon} alt="flowericon" /></span>
              <span></span>
            </div>
          </Marquee>
        </div>

        {/*Client Review Section */}
        <div data-aos="fade-up"
          style={{
            color: "white",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            gap: "4rem",
            width: "100%",
            height: "32rem",
            backgroundColor: "#7A6E54",
            marginTop: "3rem",
            position: "relative",
          }}
        >
          <div style={{ fontSize: isXs ? "1.5rem" : "2.5rem", fontFamily: "lora" }}>
            What Clients Say About Us
          </div>
          <div
            style={{
              position: "relative",
              width: "100%",
              overflow: "hidden",
              height: "40vh",
              borderRadius: "0.5rem",
            }}
            data-carousel="slide"
          >
            <div
              style={{
                display: "flex",
                transition: "transform 0.7s ease-in-out",
                transform: `translateX(-${currentIndex * 100}%)`,
                height: "100%",
              }}
            >
              {reviews.map((review, index) => (
                <div
                  key={index}
                  style={{
                    minWidth: "100%",
                    textAlign: "center",
                    padding: "1rem",
                    fontSize: "1rem",
                    fontFamily: "lora",
                    color: "white",
                    boxSizing: "border-box",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    position: "relative",
                  }}
                >
                  <div style={{ position: "absolute", top: "0rem", left: "50%", transform: "translateX(-50%)", display: "flex", gap: ".5rem" }}>
                    <FaStar style={{ color: "orange" }} />
                    <FaStar style={{ color: "orange" }} />
                    <FaStar style={{ color: "orange" }} />
                    <FaStar style={{ color: "orange" }} />
                    <FaStar style={{ color: "orange" }} />
                  </div>
                  <div style={{ width: "70%", textAlign: "center" }}>
                    {review.text}
                  </div>
                  <div style={{ marginTop: "1rem", fontStyle: "italic" }}>
                    - {review.name}
                  </div>
                </div>
              ))}
            </div>
            <div
              style={{
                position: "absolute",
                zIndex: 30,
                display: "flex",
                justifyContent: "center",
                bottom: "1rem",
                left: "50%",
                transform: "translateX(-50%)",
              }}
            >
              {reviews.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  style={{
                    width: "0.5rem",
                    height: "0.5rem",
                    borderRadius: "50%",
                    margin: "0 0.25rem",
                    backgroundColor: currentIndex === index ? "#fff" : "#9A9A9A",
                    border: "none",
                    cursor: "pointer",
                  }}
                  onClick={() => handleSlideTo(index)}
                />
              ))}
            </div>
            <button
              type="button"
              style={{
                position: "absolute",
                top: "2rem",
                left: "0",
                zIndex: 30,
                display: "flex",
                alignItems: "start",
                justifyContent: "center",
                height: "100%",
                padding: "0 1rem",
                cursor: "pointer",
              }}
              onClick={handlePrev}
            >
              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "2.5rem",
                  height: "2.5rem",
                  borderRadius: "50%",
                  backgroundColor: "rgba(255, 255, 255, 0.3)",
                  color: "#fff",
                }}
              >
                <svg
                  style={{ width: "1rem", height: "1rem" }}
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 6 10"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M5 1 1 5l4 4"
                  />
                </svg>
              </span>
              <span style={{ position: "absolute", visibility: "hidden" }}>
                Previous
              </span>
            </button>
            <button
              type="button"
              style={{
                position: "absolute",
                top: "2rem",
                right: "0",
                zIndex: 30,
                display: "flex",
                alignItems: "start",
                justifyContent: "center",
                height: "100%",
                padding: "0 1rem",
                cursor: "pointer",
                zIndex: "1"
              }}
              onClick={handleNext}
            >
              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "2.5rem",
                  height: "2.5rem",
                  borderRadius: "50%",
                  backgroundColor: "rgba(255, 255, 255, 0.3)",
                  color: "#fff",
                }}
              >
                <svg
                  style={{ width: "1rem", height: "1rem" }}
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 6 10"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="m1 9 4-4-4-4"
                  />
                </svg>
              </span>
              <span style={{ position: "absolute", visibility: "hidden" }}>
                Next
              </span>
            </button>
          </div>
        </div>

        <OurServices />
        <Subscription />

    </>
  );
};

export default HomePage;
