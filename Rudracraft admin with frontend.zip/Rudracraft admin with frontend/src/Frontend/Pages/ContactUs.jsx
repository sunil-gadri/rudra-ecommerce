import React, { useEffect, useRef, useState } from "react";
import { MdKeyboardArrowRight } from "react-icons/md";
import { FaLocationDot } from "react-icons/fa6";
import { MdEmail, MdCall } from "react-icons/md";
import { toast, Toaster } from "sonner";
import axiosInstance from "../../utils/axios";
import imageCompression from "browser-image-compression"; // ← added

function ContactUs() {
  // Form states
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  // Captcha states
  const canvasRef = useRef(null);
  const [captchaText, setCaptchaText] = useState("");
  const [captchaInput, setCaptchaInput] = useState("");

  // Images with compression
  const [images, setImages] = useState([]); // will store compressed File objects
  const maxImages = 5;

  // Compression settings (same as in ProductsCreate)
  const compressionOptions = {
    maxSizeMB: 0.3,           // target max file size ~300KB
    maxWidthOrHeight: 1024,   // max dimension
    useWebWorker: true,
    fileType: "image/jpeg",   // force jpeg for better compression
  };

  // Generate captcha
  const generateCaptcha = () => {
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    let text = "";
    for (let i = 0; i < 5; i++) {
      text += chars[Math.floor(Math.random() * chars.length)];
    }
    setCaptchaText(text);
    setCaptchaInput("");
  };

  const drawCaptcha = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "rgba(0,0,0,0.06)";
    for (let i = 0; i < 35; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      ctx.fillRect(x, y, 2, 2);
    }

    ctx.font = "bold 32px Arial";
    ctx.fillStyle = "#000000";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    const chars = captchaText.split("");
    const totalWidth = chars.length * 36;
    const startX = canvas.width / 2 - totalWidth / 2 + 18;

    chars.forEach((char, i) => {
      const x = startX + i * 36;
      const rotation = (Math.random() - 0.5) * 0.3;
      const yOffset = Math.sin(i * 1.3 + Date.now() * 0.001) * 6;

      ctx.save();
      ctx.translate(x, canvas.height / 2 + yOffset);
      ctx.rotate(rotation);
      ctx.fillText(char, 0, 0);
      ctx.restore();
    });

    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
      ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
      ctx.strokeStyle = `rgba(0,0,0,${Math.random() * 0.3 + 0.1})`;
      ctx.lineWidth = 1;
      ctx.stroke();
    }
  };

  useEffect(() => {
    generateCaptcha();
  }, []);

  useEffect(() => {
    if (captchaText) drawCaptcha();
  }, [captchaText]);

  // Image handling with compression
  const handleImageChange = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length + images.length > maxImages) {
      toast.error(`Maximum ${maxImages} images allowed`);
      return;
    }

    const compressedFiles = [];

    for (const file of files) {
      try {
        const compressedFile = await imageCompression(file, compressionOptions);
        compressedFiles.push(compressedFile);
      } catch (error) {
        console.error("Image compression failed:", error);
        // Fallback: use original if compression fails
        compressedFiles.push(file);
      }
    }

    setImages((prev) => [...prev, ...compressedFiles]);
    toast.success("Images added successfully (compressed)");
  };

  const removeImage = (index) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  // Form submit
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!captchaInput.trim()) {
      toast.error("Please enter the captcha code");
      return;
    }

    if (captchaInput.toLowerCase() !== captchaText.toLowerCase()) {
      toast.error("Incorrect captcha! Try again.");
      generateCaptcha();
      return;
    }

    const formData = new FormData();
    formData.append("first_name", firstName.trim());
    formData.append("last_name", lastName.trim());
    formData.append("email", email.trim());
    formData.append("mobile", phone.trim());
    formData.append("subject", subject.trim());
    formData.append("details", message.trim()); // or "message" - depending on your backend

    // Append compressed images
    images.forEach((img) => {
      formData.append("images", img); // backend should accept "images" as array
    });

    try {
      await axiosInstance.post("/help/add", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      toast.success("Message sent successfully!");

      // Reset form
      setFirstName("");
      setLastName("");
      setEmail("");
      setPhone("");
      setSubject("");
      setMessage("");
      setImages([]);
      setCaptchaInput("");
      generateCaptcha();
    } catch (error) {
      console.error(error);
      const errorMsg =
        error.response?.data?.message || "Failed to send message";
      toast.error(errorMsg);
    }
  };

  return (
    <>

      {/* ================= HEADER ================= */}
      <div className="w-full bg-[#CFD9E2] flex items-center justify-center h-[12rem]">
        <div className="flex flex-col">
          <h1 className="font-light text-[#3F4754] text-3xl text-center">
            Contact Us
          </h1>
          <div className="flex justify-center items-center gap-2">
            <a className="text-[#3F4754]" href="/">
              Home
            </a>
            <MdKeyboardArrowRight />
            <span className="text-[#3F4754]">Contact Us</span>
          </div>
        </div>
      </div>

      {/* ================= MAIN CONTENT ================= */}
      <div className="bg-[#EEEAE8] w-full m-0 p-0 overflow-x-hidden">
        <div
          className="flex flex-col md:flex-row justify-center m-0 p-0"
          style={{
            width: "100%",
            maxWidth: "100%",
            marginLeft: "auto",
            marginRight: "auto",
            boxSizing: "border-box",
          }}
        >
          {/* Map + Contact Info */}
          <div className="flex flex-col mt-20 pl-6 w-full md:max-w-[57%] lg:max-w-[55%] xl:max-w-[60%]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227748.0545842157!2d75.625184!3d26.96715096384316!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5699ea20ee5%3A0x53625211402ee851!2sSHREE%20RUDRA%20CRAFT%20AND%20CREATIONS!5e0!3m2!1sen!2sin!4v1740646577951!5m2!1sen!2sin"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Rudra Crafts Location"
            ></iframe>

            <div className="flex flex-col md:flex-row justify-start py-8 px-5 w-full gap-8 md:gap-12">
              <div className="flex flex-col items-center text-center">
                <div className="text-5xl text-[#88472E]">
                  <FaLocationDot />
                </div>
                <div className="mt-3 max-w-[220px]">
                  125, Taneja Block, Saket Colony, Adarsh Nagar, Jaipur, Rajasthan
                  302004
                </div>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="text-5xl text-[#88472E]">
                  <MdEmail />
                </div>
                <div className="mt-3">info@rudracrafts.com</div>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="text-5xl text-[#88472E]">
                  <MdCall />
                </div>
                <div className="mt-3">+91-9983339820</div>
              </div>
            </div>
          </div>

          {/* FORM */}
          <form
            onSubmit={handleSubmit}
            className="flex flex-col gap-4 md:p-8 w-full md:max-w-[50%] lg:max-w-[45%] xl:max-w-[40%] mx-auto md:mx-0"
          >
            <div className="text-[2.5rem] font-medium">Let's Discuss</div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                className="border border-gray-300 h-[2.5rem] p-2 bg-[#DCD8D5] text-[15px]"
                placeholder="First Name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
              />
              <input
                className="border border-gray-300 h-[2.5rem] p-2 bg-[#DCD8D5] text-[15px]"
                placeholder="Last Name"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
              />
            </div>

            <input
              className="border border-gray-300 h-[2.5rem] p-2 bg-[#DCD8D5] text-[15px]"
              placeholder="Email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <input
              className="border border-gray-300 h-[2.5rem] p-2 bg-[#DCD8D5] text-[15px]"
              placeholder="Phone Number"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
            />

            <input
              className="border border-gray-300 h-[2.5rem] p-2 bg-[#DCD8D5] text-[15px]"
              placeholder="Subject"
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              required
            />

            <textarea
              className="border border-gray-300 p-2 bg-[#DCD8D5] text-[15px]"
              rows="5"
              placeholder="Message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
            />

            {/* Image Upload with Compression */}
            <div className="mt-2">
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageChange}
                className="border border-gray-300 p-2 bg-[#DCD8D5] w-full text-[14px]"
              />
              <p className="text-xs text-gray-600 mt-1">
                Max 5 images allowed (automatically compressed)
              </p>

              <div className="flex flex-wrap gap-3 mt-3">
                {images.map((img, index) => (
                  <div key={index} className="relative">
                    <img
                      src={URL.createObjectURL(img)}
                      alt="preview"
                      className="w-16 h-16 object-cover border rounded"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full px-2 py-1 shadow-md"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Captcha */}
            <div className="mt-4">
              <label className="block text-gray-700 mb-2 text-sm font-medium">
                Security Check
              </label>

              <div className="inline-flex items-center gap-3 bg-white p-3 rounded border border-gray-200">
                <canvas
                  ref={canvasRef}
                  width="260"
                  height="65"
                  className="border border-gray-300 bg-white shadow-sm rounded"
                />
                <button
                  type="button"
                  onClick={generateCaptcha}
                  className="bg-gray-200 hover:bg-gray-300 px-3 py-2 rounded text-xl flex-shrink-0"
                >
                  🔄
                </button>
              </div>

              <input
                type="text"
                value={captchaInput}
                onChange={(e) => setCaptchaInput(e.target.value)}
                className="mt-3 border border-gray-300 h-11 px-4 bg-[#DCD8D5] w-full max-w-[340px] text-[15px] rounded"
                placeholder="Enter the code above"
                maxLength={5}
                required
              />
            </div>

            <button
              type="submit"
              className="mt-6 text-white bg-[#88472E] w-[120px] py-2 text-[16px] hover:bg-[#6e3a24] transition-colors"
            >
              Send
            </button>
          </form>
        </div>
      </div>
    </>
  );
}

export default ContactUs;