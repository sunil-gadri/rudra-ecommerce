// src/components/SignUpModal.jsx
import React, { useState, useEffect } from "react";
import { toast } from "sonner";
import axiosInstance from "../../utils/axios";

const SignUpModal = ({ isOpen, onClose, onOpenSignIn }) => {
  const [loading, setLoading] = useState(false);
  const [selectedGender, setSelectedGender] = useState("male");
  const [profileImage, setProfileImage] = useState(null);
  const [first_name, setFirstName] = useState("");
  const [last_name, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  const handleGenderChange = (gender) => setSelectedGender(gender.toLowerCase());

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = document.getElementById("signup-preview-img");
        if (img) img.src = event.target.result;
        img.classList.remove("hidden");
        document.getElementById("default-icon")?.classList.add("hidden");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSignUp = async (e) => {
    e.preventDefault();
    setLoading(true);

    const data = new FormData();
    data.append("first_name", first_name);
    data.append("last_name", last_name);
    data.append("email", email);
    data.append("phone", phone);
    data.append("password", password);
    data.append("gender", selectedGender);
    data.append("status", "active");
    if (profileImage) data.append("profile_image", profileImage);

    try {
      await axiosInstance.post("customer/signup", data, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      toast.success("Account created successfully! Please log in.");
      setFirstName("");
      setLastName("");
      setEmail("");
      setPhone("");
      setPassword("");
      setProfileImage(null);
      setSelectedGender("male");
      onClose();
      onOpenSignIn();
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300" 
        onClick={onClose}
        aria-label="Close modal"
      />

      {/* Modal Container - Fixed with 90vh height and increased width */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
        {/* Modal Content - 90vh height with scrollable content */}
        <div
          className="rounded-xl sm:rounded-2xl shadow-2xl w-full max-w-xs sm:max-w-xs md:max-w-sm h-[95vh] flex flex-col relative animate-in fade-in zoom-in-95 duration-300"
          style={{ backgroundColor: "#D6CBC6" }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 sm:top-4 sm:right-4 text-gray-600 hover:text-gray-900 text-2xl sm:text-3xl font-light transition-colors duration-200 z-10"
            aria-label="Close"
          >
            ×
          </button>

          {/* Scrollable Content - Hide scrollbar */}
          <div 
            className="overflow-y-auto flex-1 p-5 sm:p-6 md:p-8" 
            style={{ 
              scrollbarWidth: 'none',
              msOverflowStyle: 'none'
            }}
          >
            <style>{`
              div::-webkit-scrollbar {
                display: none;
              }
            `}</style>
            {/* Header */}
            <div className="text-center mb-4 sm:mb-6 mt-2">
              <h1 className="text-xl sm:text-2xl font-bold text-gray-900 mb-1">
                Create Account
              </h1>
              <p className="text-xs sm:text-sm text-gray-600">
                Join us today and get started
              </p>
            </div>

            {/* Profile Image Upload */}
            <div className="flex justify-center mb-4 sm:mb-6">
              <div className="relative">
                <div
                  className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border-4 transition-transform duration-300"
                  style={{ borderColor: "#E5DDD7" }}
                >
                  <img
                    id="signup-preview-img"
                    alt="profile"
                    className="w-full h-full object-cover hidden"
                  />
                  <svg
                    id="default-icon"
                    width="24"
                    height="24"
                    className="sm:w-8 sm:h-8"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#bbb"
                    strokeWidth="1.5"
                  >
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                </div>
                <label
                  htmlFor="signup-profileUpload"
                  className="absolute bottom-0 right-0 w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center cursor-pointer border-3 border-white transition-all duration-300 hover:opacity-90 hover:shadow-lg"
                  style={{
                    backgroundColor: "#7A6E54",
                    boxShadow: "0 4px 12px rgba(122, 110, 84, 0.2)",
                  }}
                >
                  <svg
                    width="12"
                    height="12"
                    className="sm:w-4 sm:h-4"
                    viewBox="0 0 24 24"
                    fill="white"
                    stroke="white"
                    strokeWidth="2"
                  >
                    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
                    <circle cx="12" cy="13" r="4" />
                  </svg>
                </label>
                <input
                  id="signup-profileUpload"
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSignUp} className="space-y-3 sm:space-y-4">
              {/* Gender Selection */}
              <div>
                <label className="block font-semibold text-gray-900 mb-2 text-xs">
                  Gender
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {["Female", "Male", "Non Binary"].map((gender) => (
                    <button
                      key={gender}
                      type="button"
                      onClick={() => handleGenderChange(gender)}
                      className="py-1.5 sm:py-2 px-2 rounded-lg font-medium text-xs transition-all duration-300 border-2 hover:shadow-md"
                      style={{
                        borderColor: "#7A6E54",
                        backgroundColor:
                          selectedGender === gender.toLowerCase() ? "#7A6E54" : "#fff",
                        color:
                          selectedGender === gender.toLowerCase() ? "white" : "#666",
                      }}
                    >
                      {gender}
                    </button>
                  ))}
                </div>
              </div>

              {/* First Name & Last Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  required
                  placeholder="First Name"
                  value={first_name}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="w-full h-10 sm:h-11 px-3 sm:px-4 rounded-lg text-sm transition-colors duration-200"
                  style={{ border: "2px solid #E5DDD7" }}
                  onFocus={(e) => (e.target.style.borderColor = "#7A6E54")}
                  onBlur={(e) => (e.target.style.borderColor = "#E5DDD7")}
                />
                <input
                  required
                  placeholder="Last Name"
                  value={last_name}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full h-10 sm:h-11 px-3 sm:px-4 rounded-lg text-sm transition-colors duration-200"
                  style={{ border: "2px solid #E5DDD7" }}
                  onFocus={(e) => (e.target.style.borderColor = "#7A6E54")}
                  onBlur={(e) => (e.target.style.borderColor = "#E5DDD7")}
                />
              </div>

              {/* Phone Number */}
              <div>
                <input
                  required
                  placeholder="Phone Number"
                  type="tel"
                  maxLength="10"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full h-10 sm:h-11 px-3 sm:px-4 rounded-lg text-sm transition-colors duration-200"
                  style={{ border: "2px solid #E5DDD7" }}
                  onFocus={(e) => (e.target.style.borderColor = "#7A6E54")}
                  onBlur={(e) => (e.target.style.borderColor = "#E5DDD7")}
                />
              </div>

              {/* Email */}
              <div>
                <input
                  required
                  placeholder="Email Id"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-10 sm:h-11 px-3 sm:px-4 rounded-lg text-sm transition-colors duration-200"
                  style={{ border: "2px solid #E5DDD7" }}
                  onFocus={(e) => (e.target.style.borderColor = "#7A6E54")}
                  onBlur={(e) => (e.target.style.borderColor = "#E5DDD7")}
                />
              </div>

              {/* Password */}
              <div>
                <input
                  required
                  placeholder="Password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-10 sm:h-11 px-3 sm:px-4 rounded-lg text-sm transition-colors duration-200"
                  style={{ border: "2px solid #E5DDD7" }}
                  onFocus={(e) => (e.target.style.borderColor = "#7A6E54")}
                  onBlur={(e) => (e.target.style.borderColor = "#E5DDD7")}
                />
              </div>

              {/* Sign Up Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full h-10 sm:h-11 mt-4 sm:mt-6 font-semibold text-white rounded-lg transition-all duration-200 hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
                style={{
                  backgroundColor: "#7A6E54",
                  boxShadow: "0 4px 15px rgba(122, 110, 84, 0.2)",
                }}
              >
                {loading ? "Creating Account..." : "Sign Up"}
              </button>
            </form>

            {/* Sign In Link */}
            <div className="text-center text-xs sm:text-sm mt-5 sm:mt-6 pb-4">
              <span className="text-gray-600">
                Already registered?{" "}
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    onClose();
                    onOpenSignIn();
                  }}
                  className="font-bold transition-opacity duration-200 hover:opacity-80"
                  style={{
                    color: "#87472D",
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Log In
                </button>
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignUpModal;