import React from 'react';
import policyimg from "../../Assets/policyimg.jpg";
import { MdKeyboardArrowRight } from "react-icons/md";

function ShippingPolicy() {
  const sections = [
    {
      title: "Order Processing Time",
      content: "All orders are processed within 1–2 business days. Orders placed on weekends or holidays will be processed on the next working day. During high-demand periods (sales, festivals, special offers), processing time may be slightly longer."
    },
    {
      title: "Shipping Time & Delivery Duration",
      subsections: [
        {
          subtitle: "Delivery time depends on your location:",
          content: "Metro Cities: 3–5 business days. Other Cities: 5–7 business days. Remote or Rural Areas: 7–10 business days."
        },
        {
          subtitle: "You will receive notifications for:",
          content: "Order confirmation, Order dispatch, Delivery updates, Delivery completion"
        }
      ]
    },
    {
      title: "Shipping Charges",
      content: "Free Shipping on prepaid orders above a minimum order value (if applicable). Standard shipping charges may apply for orders below the minimum value. COD orders may include an additional fee. (You may customize values later as per your business requirements.)"
    },
    {
      title: "Cash on Delivery (COD)",
      content: "COD is available on selected pin codes. COD orders may require verification via phone or SMS. Refusal of COD delivery repeatedly may result in restrictions on future COD orders."
    },
    {
      title: "Order Tracking",
      content: "Once the order is shipped, you will receive: A tracking link via SMS/Email/App Notification, Courier partner details, Expected delivery date. You can also track your package anytime under My Orders on the website or app."
    },
    {
      title: "Delivery Attempts",
      subsections: [
        {
          subtitle: "Our courier partner will make up to 2 attempts for delivery.",
          content: "Delivery may fail if: The customer is unavailable, The address is incorrect/incomplete, Phone number is unreachable. If delivery fails, the package may return to our warehouse. Re-shipping may require additional charges."
        }
      ]
    },
    {
      title: "Delayed Delivery",
      subsections: [
        {
          subtitle: "Delivery may be delayed due to:",
          content: "Weather conditions, Political disruptions / strikes, Courier partner delays, Incorrect address provided. If your order is delayed beyond the expected time, please contact our support team."
        }
      ]
    },
    {
      title: "Damaged or Tampered Delivery",
      subsections: [
        {
          subtitle: "If your package appears:",
          content: "Damaged, Tampered, or Opened. We request you to: 1. Do not accept the parcel, or 2. Take photos/video immediately and contact us within 24 hours. We will arrange a replacement or assistance based on the situation."
        }
      ]
    },
    {
      title: "International Shipping (Optional Section)",
      subsections: [
        {
          subtitle: "Currently editable—only include if you plan to ship internationally.",
          content: "If enabled: International shipping rates will vary by country. Delivery timelines may range from 10–20 days. Customs duties, if applicable, must be paid by the customer."
        }
      ]
    }
  ];

  return (
    <>
        <div className="w-full flex justify-center items-center">
          <div className="relative text-start">
            <img src={policyimg} alt="policyimg" />
            <div className="absolute top-1/2 left-[4%] -translate-y-1/2">
              <h1 className="text-[20px] md:text-[48px]">Shipping & Delivery Policy</h1>
              <div className="flex items-center gap-[1px] justify-start">
                <a className="text-[#3F4754]" href="/">
                  Home
                </a>
                <MdKeyboardArrowRight />
                <a className="text-[#3F4754]" href="#">
                  Shipping & Delivery Policy
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 p-12">
          <div className="flex flex-col gap-2">
            <h2 className="text-4xl font-bold">Shipping & Delivery Policy</h2>
            <p className="text-lg text-gray-600">RudraCraft Website & Mobile App</p>
            <p className="text-lg text-gray-700 leading-relaxed">
              At RudraCraft, we aim to deliver your favorite Home Furnishings, Décor, Apparel, and Accessories quickly, safely, and efficiently. Please read our Shipping & Delivery Policy to understand how your orders reach you.
            </p>
          </div>

          {sections.map((section, index) => (
            <div key={index} className="flex flex-col gap-3">
              <h3 className="text-2xl font-semibold">{index + 1}. {section.title}</h3>
              
              {section.subsections ? (
                <div className="flex flex-col gap-4 ml-4">
                  {section.subsections.map((subsection, subIndex) => (
                    <div key={subIndex} className="flex flex-col gap-2">
                      <h4 className="text-xl font-semibold text-gray-800">{subsection.subtitle}</h4>
                      <p className="text-lg text-gray-700 leading-relaxed">{subsection.content}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-lg text-gray-700 leading-relaxed">{section.content}</p>
              )}
            </div>
          ))}

          <div className="flex flex-col gap-4 mt-6 pt-6 border-t border-gray-300">
            <h3 className="text-2xl font-semibold">Customer Support</h3>
            <p className="text-lg text-gray-700 leading-relaxed">
              For any shipping or delivery-related questions:
            </p>
            <div className="flex flex-col gap-2 ml-4">
              <p className="text-lg">
                <strong>📧 Email:</strong> support@rudracrafts.com
              </p>
              <p className="text-lg">
                <strong>📞 Phone:</strong> +91-XXXXXXXXXX
              </p>
              <p className="text-lg">
                <strong>🌐 Website:</strong> www.rudracrafts.com
              </p>
            </div>
          </div>
        </div>
    </>
  );
}

export default ShippingPolicy;