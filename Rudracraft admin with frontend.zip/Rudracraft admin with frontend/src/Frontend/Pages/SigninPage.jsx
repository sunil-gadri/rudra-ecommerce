import React, { useState, useEffect } from "react";
import { toast } from "sonner";
import axiosInstance from "../../utils/axios";
import { useNavigate } from "react-router-dom"; 

const SignInModal = ({ isOpen, onClose, onOpenSignUp }) => {
  const [loading, setLoading] = useState(false);
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate(); 

  const isMobile = (value) => /^[0-9]{10}$/.test(value);

  const handleSignIn = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (!identifier || !password) {
      toast.error("Please fill in all fields");
      setLoading(false);
      return;
    }

    const formData = new FormData();
    if (isMobile(identifier)) {
      formData.append("phone", identifier);
    } else {
      formData.append("email", identifier);
    }
    formData.append("password", password);

    try {
      const res = await axiosInstance.post("customer/login", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      localStorage.setItem("customerToken", res.data.token);
      localStorage.setItem("customerId", res.data.user.id);

      toast.success("Logged in successfully!");
      setIdentifier("");
      setPassword("");
      onClose();
    } catch (err) {
      toast.error(err?.response?.data?.message || "Invalid login details");
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={onClose} />
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div
          className="rounded-2xl shadow-2xl w-full max-w-md p-6 md:p-8 relative"
          style={{ backgroundColor: "#D6CBC6" }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-600 hover:text-gray-900 text-3xl font-light"
          >
            ×
          </button>

          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h1>
            <p className="text-gray-600 text-sm md:text-base">Sign in to your account</p>
          </div>

          <form onSubmit={handleSignIn}>
            {/* Your existing inputs */}
            <div className="mb-4">
              <input placeholder="Email or Mobile Number" type="text" value={identifier} onChange={(e) => setIdentifier(e.target.value)}
                className="w-full h-10 px-4 rounded-lg text-sm" style={{ border: "2px solid #E5DDD7" }}
                onFocus={(e) => e.target.style.borderColor = "#7A6E54"} onBlur={(e) => e.target.style.borderColor = "#E5DDD7"} />
            </div>
            <div className="mb-2">
              <input placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                className="w-full h-10 px-4 rounded-lg text-sm" style={{ border: "2px solid #E5DDD7" }}
                onFocus={(e) => e.target.style.borderColor = "#7A6E54"} onBlur={(e) => e.target.style.borderColor = "#E5DDD7"} />
            </div>
            <div className="mb-6 text-right">
              <a href="/reset" className="text-sm font-semibold" style={{ color: "#87472D" }}>Forgot your password?</a>
            </div>

            <button type="submit" disabled={loading}
              className="w-full h-11 mb-4 font-semibold text-white rounded-lg"
              style={{ backgroundColor: "#7A6E54", boxShadow: "0 4px 15px rgba(122, 110, 84, 0.2)" }}>
              {loading ? "Signing in..." : "Sign In"}
            </button>
          </form>

          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px" style={{ backgroundColor: "#E5DDD7" }}></div>
            <span className="text-xs text-gray-500">OR</span>
            <div className="flex-1 h-px" style={{ backgroundColor: "#E5DDD7" }}></div>
          </div>

          <div className="text-center text-sm">
            <span className="text-gray-600">
              Don't have an account?{" "}
              <button
                onClick={(e) => {
                  e.preventDefault();
                  onClose();
                  onOpenSignUp();  
                }}
                className="font-bold transition-colors duration-300 hover:opacity-80"
                style={{ color: "#87472D", background: "none", border: "none", cursor: "pointer" }}
              >
                Sign Up
              </button>
            </span>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignInModal;