import React, { useState, useEffect, useRef } from "react";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import { MdOutlineFilterList, MdKeyboardArrowRight } from "react-icons/md";
import { AiOutlineShoppingCart } from "react-icons/ai";
import { TiHeartFullOutline } from "react-icons/ti";
import axiosInstance from "../../utils/axios";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export const AllShopProduct = () => {
  const [products, setProducts] = useState([]);
  const [categoriesList, setCategoriesList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalProducts, setTotalProducts] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [sortBy, setSortBy] = useState("");
  const menuRef = useRef(null);
  const navigate = useNavigate();

  const [expandedFilters, setExpandedFilters] = useState({
    category: true,
    availability: true,
    price: true,
  });

  const [selectedFilters, setSelectedFilters] = useState({
    category: [],
    availability: [],
    priceRange: [0, 30000],
  });

  // States for wishlist & cart interaction
  const [wishlistStatus, setWishlistStatus] = useState({});
  const [addingToCart, setAddingToCart] = useState({});

  const isXs = window.innerWidth <= 900;
  const itemsPerPage = 21;

  const customerId = localStorage.getItem("customerId");

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [menuOpen]);

  const fetchCategories = async () => {
    try {
      const response = await axiosInstance.get('/categories');
      setCategoriesList(response.data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchProducts = async (pageNum = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.append('page', pageNum);
      params.append('limit', itemsPerPage);

      selectedFilters.category.forEach((catId) => params.append('category', catId));
      if (selectedFilters.priceRange[0] > 0 || selectedFilters.priceRange[1] < 30000) {
        params.append('min_price', selectedFilters.priceRange[0]);
        params.append('max_price', selectedFilters.priceRange[1]);
      }
      if (selectedFilters.availability.includes("in_stock")) {
        params.append('in_stock', 'true');
      }
      if (sortBy) params.append('sort', sortBy);

      const response = await axiosInstance.get('/products', { params });

      setProducts(response.data.products || []);

      const total = response.data.total_products || response.data.total || 0;
      setTotalProducts(total);
      setTotalPages(Math.ceil(total / itemsPerPage));
      setCurrentPage(pageNum);
    } catch (error) {
      console.error('Error fetching products:', error);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

useEffect(() => {
  fetchProducts(currentPage);
}, [currentPage, selectedFilters, sortBy]);

  // Load wishlist status
  useEffect(() => {
    const loadWishlistStatus = async () => {
      if (!customerId) return;

      try {
        const res = await axiosInstance.get(`/wishlist/${customerId}`);
        const wishlistIds = new Set(res.data.products?.map(item => String(item.id)) || []);

        const newStatus = {};
        products.forEach(product => {
          newStatus[product.id] = wishlistIds.has(String(product.id));
        });

        setWishlistStatus(prev => ({ ...prev, ...newStatus }));
      } catch (error) {
        console.error("Failed to load wishlist status:", error);
      }
    };

    if (products.length > 0) {
      loadWishlistStatus();
    }
  }, [products, customerId]);

  const handleAddToCart = async (productId) => {
    if (!customerId) {
      alert("Please log in to add to cart");
      return;
    }

    setAddingToCart(prev => ({ ...prev, [productId]: true }));

    try {
      const formData = new FormData();
      formData.append("product_id", productId);
      formData.append("quantity", 1);

      await axiosInstance.post(`/cart/${customerId}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      window.dispatchEvent(new Event("cartUpdated"));
toast.success("Product added to cart successfully");
    } catch (error) {
      console.error("Add to cart failed:", error);
      alert("Failed to add to cart. Please try again.");
    } finally {
      setAddingToCart(prev => ({ ...prev, [productId]: false }));
    }
  };

  const handleWishlist = async (productId) => {
    if (!customerId) {
      alert("Please log in to modify wishlist");
      return;
    }

    const isCurrentlyIn = wishlistStatus[productId] || false;

    try {
      if (isCurrentlyIn) {
        await axiosInstance.delete(`/wishlist/${customerId}/${productId}`);
        setWishlistStatus(prev => ({ ...prev, [productId]: false }));
      } else {
        const formData = new FormData();
        formData.append("product_id", productId);
        await axiosInstance.post(`/wishlist/${customerId}`, formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        setWishlistStatus(prev => ({ ...prev, [productId]: true }));
      }
      window.dispatchEvent(new Event("wishlistUpdated"));
    } catch (error) {
      console.error("Wishlist operation failed:", error);
      alert("Operation failed.");
    }
  };

  const handleFilterChange = (filterType, value) => {
    setCurrentPage(1);
    setSelectedFilters((prev) => {
      if (filterType === "priceRange") return { ...prev, priceRange: value };
      const arr = prev[filterType];
      return arr.includes(value)
        ? { ...prev, [filterType]: arr.filter((i) => i !== value) }
        : { ...prev, [filterType]: [...arr, value] };
    });
  };

  const handlePageChange = (pageNum) => {
    setCurrentPage(pageNum);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const toggleFilterExpand = (name) => {
    setExpandedFilters((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  const clearAllFilters = () => {
    setSelectedFilters({ category: [], availability: [], priceRange: [0, 30000] });
    setSortBy("");
    setCurrentPage(1);
  };

  const keyframesStyle = `
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  `;

  return (
    <>
      <style>{keyframesStyle}</style>

      {/* Modern Header */}
      <div className='w-full bg-[#CFD9E2] flex items-center justify-center h-[12rem]'>
        <div className='flex flex-col' >
          <h1 className='font-light text-[#3F4754] text-3xl text-center'>
            Products
          </h1>
          <div className='flex justify-center items-center gap-2' >
            <a className='text-[#3F4754]' href="/">
              Home
            </a>
            <MdKeyboardArrowRight />
            <a className='text-[#3F4754]' href=" ">
              Products
            </a>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div
        style={{
          width: "100%",
          marginTop: "3rem",
          display: "flex",
          padding: "0 1.5rem",
          gap: "3rem",
        }}
      >
        {/* Sidebar Filters */}
        {!isXs && (
          <div
            style={{
              width: "22%",
              minHeight: "100vh",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                background: "linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)",
                padding: "2rem",
                borderRadius: "12px",
                backdropFilter: "blur(10px)",
                position: "sticky",
                top: "20px",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem" }}>
                <h4 style={{ marginTop: 0, marginBottom: 0, color: "#333", fontSize: "1.3rem", fontWeight: "600" }}>
                  Filters
                </h4>
                <button
                  onClick={clearAllFilters}
                  style={{
                    background: "none",
                    border: "none",
                    color: "#667eea",
                    cursor: "pointer",
                    fontSize: "0.85rem",
                    fontWeight: "600",
                    textDecoration: "underline",
                  }}
                >
                  Clear All
                </button>
              </div>
              <hr style={{ border: "1px solid rgba(0,0,0,0.1)" }} />

              {/* Category Filter */}
              <div style={{ marginBottom: "1.5rem" }}>
                <div
                  onClick={() => toggleFilterExpand("category")}
                  style={{
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "0.75rem 0",
                  }}
                >
                  <h5 style={{ margin: 0, color: "#333", fontWeight: "600" }}>
                    Category
                  </h5>
                  {expandedFilters.category ? (
                    <FaChevronUp style={{ fontSize: "0.9rem", color: "#667eea" }} />
                  ) : (
                    <FaChevronDown style={{ fontSize: "0.9rem", color: "#999" }} />
                  )}
                </div>
                {expandedFilters.category && (
                  <div style={{ marginTop: "0.75rem", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                    {categoriesList && categoriesList.length > 0 ? (
                      categoriesList.map((cat) => (
                        <label
                          key={cat.id}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "0.5rem",
                            cursor: "pointer",
                            fontSize: "0.95rem",
                            color: "#666",
                          }}
                        >
                          <input
                            type="checkbox"
                            checked={selectedFilters.category.includes(cat.id.toString())}
                            onChange={() => handleFilterChange("category", cat.id.toString())}
                            style={{ cursor: "pointer", width: "16px", height: "16px" }}
                          />
                          {cat.name}
                        </label>
                      ))
                    ) : (
                      <span style={{ fontSize: "0.9rem", color: "#999" }}>Loading categories...</span>
                    )}
                  </div>
                )}
              </div>
              <hr style={{ border: "1px solid rgba(0,0,0,0.05)" }} />

              {/* Availability Filter */}
              <div style={{ marginBottom: "1.5rem" }}>
                <div
                  onClick={() => toggleFilterExpand("availability")}
                  style={{
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "0.75rem 0",
                  }}
                >
                  <h5 style={{ margin: 0, color: "#333", fontWeight: "600" }}>
                    Availability
                  </h5>
                  {expandedFilters.availability ? (
                    <FaChevronUp style={{ fontSize: "0.9rem", color: "#667eea" }} />
                  ) : (
                    <FaChevronDown style={{ fontSize: "0.9rem", color: "#999" }} />
                  )}
                </div>
                {expandedFilters.availability && (
                  <div style={{ marginTop: "0.75rem", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                    <label
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "0.5rem",
                        cursor: "pointer",
                        fontSize: "0.95rem",
                        color: "#666",
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={selectedFilters.availability.includes("in_stock")}
                        onChange={() => handleFilterChange("availability", "in_stock")}
                        style={{ cursor: "pointer", width: "16px", height: "16px" }}
                      />
                      In Stock
                    </label>
                  </div>
                )}
              </div>
              <hr style={{ border: "1px solid rgba(0,0,0,0.05)" }} />

              {/* Price Range Filter */}
              <div style={{ marginBottom: "1.5rem" }}>
                <div
                  onClick={() => toggleFilterExpand("price")}
                  style={{
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "0.75rem 0",
                  }}
                >
                  <h5 style={{ margin: 0, color: "#333", fontWeight: "600" }}>
                    Price Range
                  </h5>
                  {expandedFilters.price ? (
                    <FaChevronUp style={{ fontSize: "0.9rem", color: "#667eea" }} />
                  ) : (
                    <FaChevronDown style={{ fontSize: "0.9rem", color: "#999" }} />
                  )}
                </div>
                {expandedFilters.price && (
                  <div style={{ marginTop: "0.75rem" }}>
                    <div style={{ display: "flex", gap: "1rem", marginBottom: "1rem" }}>
                      <div style={{ flex: 1 }}>
                        <label style={{ fontSize: "0.85rem", color: "#666", display: "block", marginBottom: "0.5rem" }}>
                          Min: ₹{selectedFilters.priceRange[0]}
                        </label>
                        <input
                          type="range"
                          min="0"
                          max="30000"
                          value={selectedFilters.priceRange[0]}
                          onChange={(e) =>
                            handleFilterChange("priceRange", [
                              parseInt(e.target.value),
                              selectedFilters.priceRange[1],
                            ])
                          }
                          style={{ width: "100%", cursor: "pointer" }}
                        />
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: "1rem" }}>
                      <div style={{ flex: 1 }}>
                        <label style={{ fontSize: "0.85rem", color: "#666", display: "block", marginBottom: "0.5rem" }}>
                          Max: ₹{selectedFilters.priceRange[1]}
                        </label>
                        <input
                          type="range"
                          min="0"
                          max="30000"
                          value={selectedFilters.priceRange[1]}
                          onChange={(e) =>
                            handleFilterChange("priceRange", [
                              selectedFilters.priceRange[0],
                              parseInt(e.target.value),
                            ])
                          }
                          style={{ width: "100%", cursor: "pointer" }}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Products Section */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "2rem" }}>
          {/* Filter & Sort */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              flexWrap: "wrap",
              gap: "1rem",
              background: "rgba(0,0,0,0.02)",
              padding: "1.5rem",
              borderRadius: "10px",
              backdropFilter: "blur(10px)",
            }}
          >
            {isXs && (
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <MdOutlineFilterList
                  style={{
                    cursor: "pointer",
                    fontSize: "1.5rem",
                    color: "#667eea",
                  }}
                  onClick={() => setMenuOpen(!menuOpen)}
                />
                <span style={{ color: "#333", fontWeight: "500" }}>Filter</span>
              </div>
            )}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              style={{
                width: isXs ? "6.4rem" : "18rem",
                border: "2px solid #667eea",
                color: "#667eea",
                padding: "0.75rem 1rem",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: "500",
                transition: "all 0.3s ease",
                background: "#fff",
              }}
            >
              <option value="">Sort By</option>
              <option value="best">Best Selling</option>
              <option value="asc">Alphabetically A-Z</option>
              <option value="low">Price Low to High</option>
              <option value="high">Price High to Low</option>
            </select>
            <span style={{ fontSize: "0.9rem", color: "#666" }}>
              Showing {products.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0}-
              {Math.min(currentPage * itemsPerPage, totalProducts)} of {totalProducts}
            </span>
          </div>

          {/* Products Grid */}
          {loading ? (
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                minHeight: "400px",
              }}
            >
              <div
                style={{
                  border: "4px solid rgba(102, 126, 234, 0.1)",
                  borderTop: "4px solid #667eea",
                  borderRadius: "50%",
                  width: "50px",
                  height: "50px",
                  animation: "spin 1s linear infinite",
                }}
              />
            </div>
          ) : products.length > 0 ? (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: isXs ? "repeat(2, 1fr)" : "repeat(3, 1fr)",
                gap: "2.5rem",
                padding: isXs ? "0" : "0 1rem",
              }}
            >
              {products.map((product, idx) => (
                <div
                  key={product.id}
                  style={{
                    animation: `fadeInUp 0.6s ease forwards`,
                    animationDelay: `${idx * 0.1}s`,
                    position: "relative",
                    borderRadius: "12px",
                    overflow: "hidden",
                    background: "#fff",
                    boxShadow: "0 10px 30px rgba(102, 126, 234, 0.15)",
                    transition: "all 0.3s ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.boxShadow = "0 20px 40px rgba(102, 126, 234, 0.25)";
                    e.currentTarget.style.transform = "translateY(-8px)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.boxShadow = "0 10px 30px rgba(102, 126, 234, 0.15)";
                    e.currentTarget.style.transform = "translateY(0)";
                  }}
                >
                  {/* Image Container */}
                  <div
                    style={{
                      width: "100%",
                      height: "200px",
                      overflow: "hidden",
                      backgroundColor: "#f8f9ff",
                      position: "relative",
                    }}
                  >
                    <img
                      src={
                        product.images && product.images[0]
                          ? `${axiosInstance.defaults.baseURL}/${product.images[0]}`
                          : "https://via.placeholder.com/300x300?text=No+Image"
                      }
                      alt={product.title}
                      style={{
                        width: "100%",
                        height: "100%",
                        objectFit: "cover",
                        transition: "transform 0.3s ease",
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.transform = "scale(1.08)";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.transform = "scale(1)";
                      }}
                    />

                    {/* Wishlist Icon - Top Right */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleWishlist(product.id);
                      }}
                      style={{
                        position: "absolute",
                        top: "10px",
                        right: "10px",
                        background: "rgba(255,255,255,0.9)",
                        borderRadius: "50%",
                        width: "36px",
                        height: "36px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "none",
                        cursor: "pointer",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                        transition: "all 0.2s ease",
                        zIndex: 10,
                      }}
                    >
                      <TiHeartFullOutline
                        style={{
                          width: "20px",
                          height: "20px",
                          color: wishlistStatus[product.id] ? "#ef4444" : "#666",
                        }}
                      />
                    </button>
                  </div>

                  {/* Product Info */}
                  <div
                    style={{
                      padding: "1.10rem 1.25rem",
                      display: "flex",
                      flexDirection: "column",
                      gap: "0.25rem",
                      position: "relative",
                    }}
                  >
                    <h6
                      style={{
                        fontSize: "0.95rem",
                        fontWeight: "600",
                        color: "#333",
                        margin: 0,
                        lineHeight: "1.4",
                        minHeight: "2.8em",
                        cursor:'pointer'
                      }}
                      onClick={() => {
                        window.scrollTo({ top: 0, behavior: "smooth" });
                        navigate(`/product/${product.id}`);
                      }}
                    >
                      {product.title}
                    </h6>

                    {/* Price */}
                    <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
                      <span
                        style={{
                          fontSize: "1rem",
                          fontWeight: "700",
                          background: "linear-gradient(135deg, #080b15ff 0%, #764ba2 100%)",
                          WebkitBackgroundClip: "text",
                          WebkitTextFillColor: "transparent",
                          backgroundClip: "text",
                        }}
                      >
                        ₹{product.general_info?.discounted_price?.toFixed(2) || product.general_info?.price?.toFixed(2)}
                      </span>
                      {product.general_info && product.general_info.discount > 0 && (
                        <>
                          <span
                            style={{
                              fontSize: "0.85rem",
                              color: "#999",
                              textDecoration: "line-through",
                            }}
                          >
                            ₹{product.general_info.price.toFixed(2)}
                          </span>
                          <span className="text-xs">
                            ({product.general_info.discount}% OFF)
                          </span>
                        </>
                      )}
                    </div>

                    {/* Stock Status */}
                    <div
                      style={{
                        fontSize: "0.8rem",
                        fontWeight: "500",
                        color: product.general_info?.in_stock ? "#10b981" : "#ef4444",
                      }}
                    >
                      {product.general_info?.in_stock
                        ? `✓ In Stock (${product.general_info?.stock})`
                        : "Out of Stock"}
                    </div>

                    {/* Add to Cart Button - Bottom of Card (slides up on hover) */}
                    <div
                      style={{
                        marginTop: "0.4rem",
                        background: "#C62839",
                        color: "white",
                        padding: "0.45rem",
                        borderRadius: "8px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: "0.5rem",
                        fontWeight: "600",
                        fontSize: "0.9rem",
                        cursor: "pointer",
                        boxShadow: "0 4px 12px rgba(169,30,40,0.3)",
                        transition: "all 0.3s ease",
                        transform: "translateY(0)",
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.transform = "translateY(-2px)";
                        e.currentTarget.style.boxShadow = "0 12px 24px rgba(169,30,40,0.4)";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.transform = "translateY(0)";
                        e.currentTarget.style.boxShadow = "0 4px 12px rgba(169,30,40,0.3)";
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddToCart(product.id);
                      }}
                    >
                      <AiOutlineShoppingCart size={18} />
                      {addingToCart[product.id] ? "Adding..." : "Add to Cart"}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                minHeight: "400px",
                color: "#999",
                fontSize: "1.1rem",
              }}
            >
              No products found matching your filters
            </div>
          )}

 {totalPages > 1 && (
  <div style={{ 
    display: "flex", 
    justifyContent: "center", 
    gap: "0.5rem",           
    flexWrap: "wrap", 
    margin: "2.5rem 0"        
  }}>
    {/* Prev Button - */}
    <button
      onClick={() => handlePageChange(currentPage - 1)}
      disabled={loading || currentPage === 1}
      style={{
        padding: "0.55rem 1.1rem",     
        border: "2px solid #70644C",
        background: loading || currentPage === 1 ? "#f8f8f8" : "#fff",
        color: loading || currentPage === 1 ? "#aaa" : "#70644C",
        borderRadius: "8px",
        fontWeight: "600",
        fontSize: "0.95rem",           
        cursor: loading || currentPage === 1 ? "not-allowed" : "pointer",
        opacity: loading || currentPage === 1 ? 0.6 : 1,
      }}
    >
      ← Prev
    </button>

    {/* Page Numbers */}
    {[...Array(totalPages)].map((_, i) => {
      const pageNumber = i + 1;
      const isActive = currentPage === pageNumber;

      return (
        <button
          key={pageNumber}
          onClick={() => handlePageChange(pageNumber)}
          disabled={loading}
          style={{
            padding: "0.55rem 0.9rem",      
            minWidth: "38px",               
            border: "2px solid #70644C",
            background: isActive ? "#70644C" : "#fff",
            color: isActive ? "#fff" : "#70644C",
            borderRadius: "8px",
            fontWeight: "600",
            fontSize: "0.95rem",
            cursor: loading ? "not-allowed" : "pointer",
            opacity: loading ? 0.6 : 1,
            boxShadow: isActive ? "0 3px 10px #70644C" : "none",
            transition: "all 0.2s ease",
          }}
        >
          {pageNumber}
        </button>
      );
    })}

    {/* Next Button  */}
    <button
      onClick={() => handlePageChange(currentPage + 1)}
      disabled={loading || currentPage === totalPages}
      style={{
        padding: "0.55rem 1.1rem",     
        border: "2px solid #70644C",
        background: loading || currentPage === totalPages ? "#f8f8f8" : "#fff",
        color: loading || currentPage === totalPages ? "#aaa" : "#70644C",
        borderRadius: "8px",
        fontWeight: "600",
        fontSize: "0.95rem",
        cursor: loading || currentPage === totalPages ? "not-allowed" : "pointer",
        opacity: loading || currentPage === totalPages ? 0.6 : 1,
      }}
    >
      Next →
    </button>
  </div>
)}
        </div>
      </div>
    </>
  );
};