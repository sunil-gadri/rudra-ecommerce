import React from "react";
import policyimg from "../../Assets/policyimg.jpg";
import { MdKeyboardArrowRight } from "react-icons/md";

export const Disclaimer = () => {
  const sections = [
    {
      title: "General Information",
      content: "All information provided on the RudraCraft website and mobile app—including product details, descriptions, prices, images, and content—is for general informational purposes only. While we strive for accuracy, we do not guarantee that all information is completely reliable, current, or error-free."
    },
    {
      title: "Product Colors & Appearance",
      content: "We make every effort to display product colors, designs, and textures as accurately as possible. However, actual appearance may vary due to screen resolution, device display settings, and lighting conditions during product photography. These variations are not considered errors or defects."
    },
    {
      title: "Pricing & Availability",
      subsections: [
        {
          subtitle: "General Terms",
          content: "Product prices, offers, and availability may change at any time without prior notice. While we try to maintain accurate pricing, errors may occasionally occur."
        },
        {
          subtitle: "RudraCraft Reserves the Right To:",
          content: "Correct any pricing errors, Update product information, Cancel orders affected by inaccuracies (Refunds will be processed where applicable.)"
        }
      ]
    },
    {
      title: "External Links",
      content: "Our website/app may contain links to third-party websites for your convenience. RudraCraft does not control, endorse, or guarantee the content or practices of these external sites and is not responsible for any losses or damages that may arise from using them."
    },
    {
      title: "No Professional Advice",
      content: "Any recommendations, styling tips, or content provided on the platform are general suggestions only. They should not be considered professional or expert advice. Customers are encouraged to use their own discretion before making purchasing decisions."
    },
    {
      title: "Limitation of Liability",
      subsections: [
        {
          subtitle: "RudraCraft shall not be held liable for:",
          content: "Any direct, indirect, incidental, or consequential damages, Loss of data, profits, or business opportunities, Issues arising from the use or inability to use the website/app, Delays or interruptions caused by technical issues, malware, or server errors. Usage of our platform is at your own risk."
        }
      ]
    },
    {
      title: "Technical Issues",
      subsections: [
        {
          subtitle: "RudraCraft does not guarantee:",
          content: "Uninterrupted access, Error-free functionality, Virus-free or malware-free environment. Users are advised to use updated security and antivirus measures."
        }
      ]
    },
    {
      title: "User Responsibility",
      subsections: [
        {
          subtitle: "By using our platform, you agree to:",
          content: "Provide accurate and genuine information, Not misuse or attempt to disrupt the platform, Comply with all policies, terms, and applicable laws"
        }
      ]
    },
    {
      title: "Changes to Disclaimer",
      content: "RudraCraft reserves the right to update or modify this Disclaimer at any time. Changes will be posted on the website/app and are effective immediately."
    }
  ];

  return (
    <>
        <div className="w-full flex justify-center items-center">
          <div className="relative text-start">
            <img src={policyimg} alt="policyimg" />
            <div className="absolute top-1/2 left-[4%] -translate-y-1/2">
              <h1 className="text-[20px] md:text-[48px]">Disclaimer</h1>
              <div className="flex items-center gap-[1px] justify-start">
                <a className="text-[#3F4754]" href="/">
                  Home
                </a>
                <MdKeyboardArrowRight />
                <a className="text-[#3F4754]" href="#">
                  Disclaimer
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 p-12">
          <div className="flex flex-col gap-2">
            <h2 className="text-4xl font-bold">Disclaimer</h2>
            <p className="text-lg text-gray-600">RudraCraft Website & Mobile App</p>
            <p className="text-lg text-gray-700 leading-relaxed">
              Welcome to RudraCraft. By accessing or using our website and mobile application, you agree to the terms of this Disclaimer. Please read it carefully.
            </p>
          </div>

          {sections.map((section, index) => (
            <div key={index} className="flex flex-col gap-3">
              <h3 className="text-2xl font-semibold">{index + 1}. {section.title}</h3>
              
              {section.subsections ? (
                <div className="flex flex-col gap-4 ml-4">
                  {section.subsections.map((subsection, subIndex) => (
                    <div key={subIndex} className="flex flex-col gap-2">
                      <h4 className="text-xl font-semibold text-gray-800">{subsection.subtitle}</h4>
                      <p className="text-lg text-gray-700 leading-relaxed">{subsection.content}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-lg text-gray-700 leading-relaxed">{section.content}</p>
              )}
            </div>
          ))}

          <div className="flex flex-col gap-4 mt-6 pt-6 border-t border-gray-300">
            <h3 className="text-2xl font-semibold">Contact Us</h3>
            <p className="text-lg text-gray-700 leading-relaxed">
              If you have any questions regarding this Disclaimer, please reach out to us:
            </p>
            <div className="flex flex-col gap-2 ml-4">
              <p className="text-lg">
                <strong>📧 Email:</strong> support@rudracrafts.com
              </p>
              <p className="text-lg">
                <strong>📞 Phone:</strong> +91-XXXXXXXXXX
              </p>
              <p className="text-lg">
                <strong>🌐 Website:</strong> www.rudracrafts.com
              </p>
            </div>
          </div>
        </div>
      
    </>
  );
};