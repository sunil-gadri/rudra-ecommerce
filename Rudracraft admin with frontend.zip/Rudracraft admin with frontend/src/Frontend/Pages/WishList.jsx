import React, { useState, useEffect } from "react";
import { MdKeyboardArrowRight } from "react-icons/md";
import { RiDeleteBinLine } from "react-icons/ri";
import { useMediaQuery } from "@mui/material";
import { Link } from "react-router-dom";
import axiosInstance from "../../utils/axios";

export const WishList = () => {
  const [wishlistItems, setWishlistItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [removingId, setRemovingId] = useState(null);

  const isMobile = useMediaQuery("(max-width:900px)");

  const customerId = localStorage.getItem("customerId");
  const isLoggedIn = !!localStorage.getItem("customerToken");

  // Fetch wishlist on mount
  useEffect(() => {
    const fetchWishlist = async () => {
      if (!isLoggedIn || !customerId) {
        setWishlistItems([]);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const response = await axiosInstance.get(`/wishlist/${customerId}`);
        const products = response.data.products || [];
        setWishlistItems(products);
      } catch (error) {
        console.error("Failed to fetch wishlist:", error);
        setWishlistItems([]);
      } finally {
        setLoading(false);
      }
    };

    fetchWishlist();
  }, [isLoggedIn, customerId]);

  // Remove item from wishlist
  const handleRemove = async (productId) => {
    if (!customerId) return;

    setRemovingId(productId);

    try {
      await axiosInstance.delete(`/wishlist/${customerId}/${productId}`);

      // Remove from local state
      setWishlistItems(prev => prev.filter(item => item.id !== productId));

      // Update Navbar wishlist count in real-time
      window.dispatchEvent(new Event("wishlistUpdated"));
    } catch (error) {
      console.error("Failed to remove from wishlist:", error);
      alert("Failed to remove item. Please try again.");
    } finally {
      setRemovingId(null);
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="w-full h-screen flex items-center justify-center">
        <div className="w-14 h-14 border-8 border-gray-300 border-t-black rounded-full animate-spin"></div>
      </div>
    );
  }

  // Not logged in
  if (!isLoggedIn) {
    return (
      <div className="w-full h-screen flex flex-col items-center justify-center bg-[#CFD9E2] gap-6">
        <h2 className="text-2xl text-[#7A6E54]">Please log in to view your wishlist</h2>
        <Link to="/signin">
          <button className="bg-[#7A6E54] text-white px-8 py-3 rounded-lg font-semibold">Sign In</button>
        </Link>
      </div>
    );
  }

  return (
    <>
      {/* BREADCRUMB HEADER */}
      <div
        style={{
          width: "100%",
          height: "12rem",
          backgroundColor: "#CFD9E2",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
          <h1 style={{ fontWeight: "lighter", color: "#3F4754", fontSize: "2.5rem" }}>
            Wishlist
          </h1>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5em", marginTop: "0.5rem" }}>
            <Link to="/" style={{ color: "#3F4754" }}>Home</Link>
            <MdKeyboardArrowRight />
            <span style={{ color: "#3F4754" }}>Wishlist</span>
          </div>
        </div>
      </div>

      {/* EMPTY WISHLIST STATE */}
      {wishlistItems.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 px-4 text-center">
          <h1 className="text-2xl md:text-3xl text-gray-700 mb-6">
            Nothing found in wishlist!
          </h1>
          <Link
            to="/shop"
            style={{
              backgroundColor: "#7A6E54",
              color: "white",
              padding: "1rem 2rem",
              borderRadius: "4px",
              fontSize: "1.1rem",
              width: isMobile ? "100%" : "auto",
              maxWidth: "300px",
              textAlign: "center",
            }}
          >
            Continue Shopping
          </Link>
        </div>
      )}

      {/* WISHLIST ITEMS GRID */}
      {wishlistItems.length > 0 && (
        <div
          className={`container mx-auto px-4 py-12 grid ${
            isMobile 
              ? "grid-cols-1 md:grid-cols-2" 
              : "grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
          } gap-8`}
        >
          {wishlistItems.map((item) => {
            // Safe price handling
            const price = item.general_info?.price || item.price || 0;
            const discountedPrice = item.general_info?.discounted_price || price;
            const discount = item.general_info?.discount || 0;

            return (
              <div
                key={item.id}
                className="flex flex-col border border-gray-300 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow"
              >
                {/* Product Image */}
                <Link to={`/product/${item.id}`} className="block">
                  <img
                    src={
                      item.images && item.images.length > 0
                        ? `${axiosInstance.defaults.baseURL}${item.images[0]}`
                        : "https://via.placeholder.com/300x300?text=No+Image"
                    }
                    alt={item.title || "Product"}
                    className="w-full h-64 object-cover"
                  />
                </Link>

                {/* Product Details */}
                <div className="p-4 flex flex-col flex-grow">
                  <Link to={`/product/${item.id}`} className="block">
                    <h3 className="text-lg font-medium text-center text-gray-800 line-clamp-2">
                      {item.title || "Unnamed Product"}
                    </h3>
                  </Link>

                  {/* Price */}
                  <div className="mt-3 text-center">
                    <span className="text-2xl font-bold text-gray-900">
                      ₹{Number(discountedPrice).toFixed(2)}
                    </span>
                    {discount > 0 && (
                      <>
                        <span className="ml-2 text-lg line-through text-gray-500">
                          ₹{Number(price).toFixed(2)}
                        </span>
                        <span className="ml-2 text-green-600 font-medium">
                          ({discount}% Off)
                        </span>
                      </>
                    )}
                  </div>

                  {/* Stock Status */}
                  {item.general_info?.in_stock !== undefined && (
                    <div className="text-center mt-2 text-sm">
                      <span style={{ color: item.general_info.in_stock ? "#10b981" : "#ef4444" }}>
                        {item.general_info.in_stock 
                          ? `✓ In Stock (${item.general_info.stock || 0})`
                          : "Out of Stock"
                        }
                      </span>
                    </div>
                  )}

                  {/* Buttons */}
                  <div className="mt-4 flex flex-col gap-3">
                    <Link to={`/product/${item.id}`}>
                      <button className="w-full py-3 bg-[#7A6E54] text-white font-medium rounded hover:bg-[#6a5f49] transition">
                        Select Option
                      </button>
                    </Link>

                    <button
                      onClick={() => handleRemove(item.id)}
                      disabled={removingId === item.id}
                      className="w-full py-3 border border-gray-400 text-gray-800 font-medium rounded flex items-center justify-center gap-2 hover:bg-gray-50 disabled:opacity-70 transition"
                    >
                      {removingId === item.id ? (
                        <div className="w-5 h-5 border-2 border-gray-400 border-t-black rounded-full animate-spin"></div>
                      ) : (
                        <>
                          Remove <RiDeleteBinLine className="text-xl" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
};

export default WishList;