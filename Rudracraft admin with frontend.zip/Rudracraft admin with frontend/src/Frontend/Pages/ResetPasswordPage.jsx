import React, { useState, useEffect } from "react";
import axios from "axios";
import axiosInstance from "../../utils/axios";

export const ResetPasswordPage = () => {
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState("email"); // email -> otp -> password
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const isXs = windowWidth <= 768;

  // Step 1: Send OTP
  const handleSendOtp = async (e) => {
    e.preventDefault();
    if (!email) {
      alert("Please enter your email");
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("email", email);

      const response = await axiosInstance.post("customer/send-reset-otp", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      alert("OTP sent to your email!");
      setStep("otp");
    } catch (error) {
      alert(error.response?.data?.message || "Error sending OTP");
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Handle OTP input
  const handleOtpChange = (index, value) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto focus to next input
    if (value && index < 5) {
      document.getElementById(`otp-${index + 1}`).focus();
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      document.getElementById(`otp-${index - 1}`).focus();
    }
  };

  // Step 2: Verify OTP
  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    const otpCode = otp.join("");
    if (otpCode.length !== 6) {
      alert("Please enter all 6 digits");
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("email", email);
      formData.append("otp", otpCode);

      const response = await axiosInstance.post("customer/verify-reset-otp", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      alert("OTP verified successfully!");
      setStep("password");
    } catch (error) {
      alert(error.response?.data?.message || "Invalid OTP");
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Step 3: Reset Password
  const handleResetPassword = async (e) => {
    e.preventDefault();
    if (!newPassword || !confirmPassword) {
      alert("Please enter both passwords");
      return;
    }

    if (newPassword !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    if (newPassword.length < 6) {
      alert("Password must be at least 6 characters");
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("email", email);
      formData.append("new_password", newPassword);

      const response = await axiosInstance.post("customer/reset-password", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      alert("Password reset successfully!");
      // Reset all states
      setEmail("");
      setOtp(["", "", "", "", "", ""]);
      setNewPassword("");
      setConfirmPassword("");
      setStep("email");
      window.location.href = "/";
    } catch (error) {
      alert(error.response?.data?.message || "Error resetting password");
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4 md:p-8"
      style={{ backgroundColor: "#EEEAE8" }}
    >
      <div 
        className="rounded-2xl shadow-lg w-full md:w-[500px] p-6 md:p-8"
        style={{ backgroundColor: "#D6CBC6" }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div 
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ backgroundColor: "#7A6E54" }}
            >
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Reset Password</h1>
          <p className="text-gray-600 text-sm md:text-base">
            {step === "email" && "Enter your email address to receive an OTP"}
            {step === "otp" && "Enter the 6-digit code sent to your email"}
            {step === "password" && "Create a new password for your account"}
          </p>
        </div>

        {/* Step Indicator */}
        <div className="flex justify-between mb-8">
          <div className={`flex-1 h-1 rounded-full mr-2 transition-all ${step === "email" || step === "otp" || step === "password" ? "bg-blue-500" : "bg-gray-300"}`} style={{ backgroundColor: step === "email" || step === "otp" || step === "password" ? "#7A6E54" : "#E5DDD7" }}></div>
          <div className={`flex-1 h-1 rounded-full mr-2 transition-all ${step === "otp" || step === "password" ? "bg-blue-500" : "bg-gray-300"}`} style={{ backgroundColor: step === "otp" || step === "password" ? "#7A6E54" : "#E5DDD7" }}></div>
          <div className={`flex-1 h-1 rounded-full transition-all ${step === "password" ? "bg-blue-500" : "bg-gray-300"}`} style={{ backgroundColor: step === "password" ? "#7A6E54" : "#E5DDD7" }}></div>
        </div>

        {/* Step 1: Email */}
        {step === "email" && (
          <div>
            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-900 mb-2">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="Enter your email"
                className="w-full h-11 px-4 rounded-lg text-sm font-normal text-gray-900 placeholder-gray-400 transition-all duration-300 focus:outline-none"
                style={{ border: "2px solid #E5DDD7" }}
                onFocus={(e) => e.target.style.borderColor = "#7A6E54"}
                onBlur={(e) => e.target.style.borderColor = "#E5DDD7"}
              />
            </div>

            <div className="flex gap-3">
              <a href="/user-login" className="flex-1">
                <button
                  type="button"
                  className="w-full h-11 font-semibold rounded-lg transition-all duration-300 border-2 text-gray-900 hover:bg-gray-50"
                  style={{
                    borderColor: "#7A6E54",
                    backgroundColor: "#fff",
                  }}
                >
                  Cancel
                </button>
              </a>
              <button
                onClick={handleSendOtp}
                disabled={loading}
                className="flex-1 h-11 font-semibold text-white rounded-lg transition-all duration-300 hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                style={{
                  backgroundColor: "#7A6E54",
                  boxShadow: "0 4px 15px rgba(122, 110, 84, 0.2)",
                }}
              >
                {loading ? "Sending..." : "Send OTP"}
              </button>
            </div>
          </div>
        )}

        {/* Step 2: OTP Verification */}
        {step === "otp" && (
          <div>
            <div className="mb-8">
              <label className="block text-sm font-semibold text-gray-900 mb-4">Enter 6-Digit Code</label>
              <div className="flex gap-3 justify-center">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    id={`otp-${index}`}
                    type="text"
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(index, e)}
                    maxLength="1"
                    className="w-12 h-12 text-center text-lg font-bold rounded-lg transition-all duration-300 focus:outline-none"
                    style={{
                      border: "2px solid #E5DDD7",
                      color: "#1a1a1a",
                    }}
                    onFocus={(e) => e.target.style.borderColor = "#7A6E54"}
                    onBlur={(e) => e.target.style.borderColor = "#E5DDD7"}
                  />
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setStep("email");
                  setOtp(["", "", "", "", "", ""]);
                }}
                className="flex-1 h-11 font-semibold rounded-lg transition-all duration-300 border-2 text-gray-900 hover:bg-gray-50"
                style={{
                  borderColor: "#7A6E54",
                  backgroundColor: "#fff",
                }}
              >
                Back
              </button>
              <button
                onClick={handleVerifyOtp}
                disabled={loading}
                className="flex-1 h-11 font-semibold text-white rounded-lg transition-all duration-300 hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                style={{
                  backgroundColor: "#7A6E54",
                  boxShadow: "0 4px 15px rgba(122, 110, 84, 0.2)",
                }}
              >
                {loading ? "Verifying..." : "Verify"}
              </button>
            </div>
          </div>
        )}

        {/* Step 3: New Password */}
        {step === "password" && (
          <div>
            <div className="mb-4">
              <label className="block text-sm font-semibold text-gray-900 mb-2">New Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full h-11 px-4 pr-10 rounded-lg text-sm font-normal text-gray-900 placeholder-gray-400 transition-all duration-300 focus:outline-none"
                  style={{ border: "2px solid #E5DDD7" }}
                  onFocus={(e) => e.target.style.borderColor = "#7A6E54"}
                  onBlur={(e) => e.target.style.borderColor = "#E5DDD7"}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-600"
                >
                  {showPassword ? "👁️" : "👁️‍🗨️"}
                </button>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-900 mb-2">Confirm Password</label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm new password"
                  className="w-full h-11 px-4 pr-10 rounded-lg text-sm font-normal text-gray-900 placeholder-gray-400 transition-all duration-300 focus:outline-none"
                  style={{ border: "2px solid #E5DDD7" }}
                  onFocus={(e) => e.target.style.borderColor = "#7A6E54"}
                  onBlur={(e) => e.target.style.borderColor = "#E5DDD7"}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-600"
                >
                  {showConfirmPassword ? "👁️" : "👁️‍🗨️"}
                </button>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setStep("otp");
                  setNewPassword("");
                  setConfirmPassword("");
                }}
                className="flex-1 h-11 font-semibold rounded-lg transition-all duration-300 border-2 text-gray-900 hover:bg-gray-50"
                style={{
                  borderColor: "#7A6E54",
                  backgroundColor: "#fff",
                }}
              >
                Back
              </button>
              <button
                onClick={handleResetPassword}
                disabled={loading}
                className="flex-1 h-11 font-semibold text-white rounded-lg transition-all duration-300 hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                style={{
                  backgroundColor: "#7A6E54",
                  boxShadow: "0 4px 15px rgba(122, 110, 84, 0.2)",
                }}
              >
                {loading ? "Resetting..." : "Reset Password"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};