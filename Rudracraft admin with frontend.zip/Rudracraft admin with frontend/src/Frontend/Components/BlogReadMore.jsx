import React from "react";
import blogimg1 from "../../Assets/blogimg-1.jpg";
import { useTheme, useMediaQuery } from '@mui/material';

export const BlogReadMore = () => {

  const theme = useTheme();
  const isXs = useMediaQuery('(min-width:0px) and (max-width:900px)');
  return (
    <>
      <div
        style={{ backgroundColor: "beige" }}
        className="flex flex-col  items-center gap-4 "
      >
        <div
          style={{
            width: "100%",
            height: "35rem",
            position: "relative",
            marginBottom: isXs ? "40rem" : "30rem",
          }}
        >
          <img
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
            src={blogimg1}
            alt="blogimg1"
          />
        </div>

        <div
          style={{
            backgroundColor: "white",
            width: isXs ? '90%' : "80%",
            position: "absolute",
            top: "35rem",
            padding: isXs ? '2rem' : ''
          }}
          className="flex flex-col gap-4 pt-5  p-14"
        >
          <div style={{ fontSize: isXs ? ".7rem" : "" }} className="flex gap-2">
            <span style={{ color: "#87472D" }}>31 October, 2024</span>
            <span>|</span>
            <span style={{ color: "#87472D" }}>karthika R</span>
            <span>|</span>
            <span style={{ color: "#87472D" }}>0 comments</span>
          </div>
          <div className="flex flex-col gap-2 ">
            <h2>The Art of Draping: 7 Unique Ways to Style Your Stole</h2>
            <span>
              This blog explores various innovative ways to drape a stole, from
              traditional to modern styles. It can include step-by-step images
              and videos to guide readers.
            </span>
          </div>
          <ul
            style={{
              lineHeight: "3rem",
              color: "black",
              listStyleType: "circle",
            }}
          >
            <li>Classic shoulder drape</li>
            <li>Belted stole for a chic look</li>
            <li>Layered style for winters</li>
            <li>The European loop for casual wear</li>
            <li>How to drape for a professional or formal setting</li>
          </ul>
        </div>

        <div style={{width: '80%'}} className="pt-0 flex flex-col">
          <h3>2 Comments</h3>
         <div className="mt-4 flex flex-col gap-4">
          <span>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat
            praesentium ab cumque ipsa optio impedit asperiores ea, adipisci
            facere tempora officia totam aut sed veritatis numquam perspiciatis
            pariatur dicta earum tempore soluta odio. Temporibus harum ducimus
            quasi quos, fugit ullam sunt sint a doloremque id officia, sit quis
            autem quibusdam.
          </span>

          <span>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat
            praesentium ab cumque ipsa optio impedit asperiores ea, adipisci
            facere tempora officia totam aut sed veritatis numquam perspiciatis
            pariatur dicta earum tempore soluta odio. Temporibus harum ducimus
            quasi quos, fugit ullam sunt sint a doloremque id officia, sit quis
            autem quibusdam.
          </span>
          </div> 
        </div>

        
        <div style={{width: '80%'}} className=" mt-4 mb-12 flex flex-col">
          <h3>Leave A Reply</h3>
         <div className="mt-4 flex flex-col gap-4">
          
          <div style={{ display: 'flex' , flexDirection: isXs ? 'column' : ''}} className="flex gap-3 ">
            <input style={{padding: '1rem', width: isXs ? '18rem' : '20rem'}} placeholder="Name" type="text" name="name" id="name" />
            <input style={{padding: '1rem', width: isXs ? '18rem' : '20rem'}} placeholder="Email" type="email" name="email" id="email" />
          </div>

          <div>
            <textarea style={{width: isXs ? '18rem' : '60%', padding: '1rem', height: '12rem'}} placeholder="Your Message" name="" id=""></textarea>
          </div>
          <a className="flex items-center justify-center" style={{backgroundColor: '#7A6E54', padding: '1rem', width: isXs ? '50%' : '20%', color: 'white'}} href="#">Submit Now</a>
          </div> 
        </div>

      </div>
    </>
  );
};
