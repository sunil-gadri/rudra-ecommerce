import React, { useState } from "react";
import footerlogo from "../../Assets/logo.png";
import phone from "../../Assets/phone.svg";
import mail from "../../Assets/email.svg";
import location from "../../Assets/location.svg";
import insta from "../../Assets/insta.svg";
import fb from "../../Assets/fb.svg";
import twitter from "../../Assets/twitter.svg";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";

export default function Footer() {
  const [open, setOpen] = useState(null);

  const toggle = (key) => {
    setOpen(open === key ? null : key);
  };

  return (
    <footer className="bg-[#191E26] text-white w-full mt-10">
      
      {/* Desktop */}
      <div className="hidden md:block w-full px-16 py-16">
        <div className="grid grid-cols-5 gap-10">
          
          {/* Logo */}
          <div className="flex flex-col gap-4">
            <img width={120} src={footerlogo} alt="" />

            <p className="text-gray-400 text-sm leading-5">
              It is a long established fact that a reader will be distracted by the readable content.
            </p>

            <div className="flex gap-5 mt-4">
              <img src={insta} alt="" width={20} />
              <img src={fb} alt="" width={20} />
              <img src={twitter} alt="" width={18} />
            </div>
          </div>

          {/* Shop */}
          <div className="flex flex-col gap-4">
            <h1 className="font-semibold text-base">Shop</h1>
            <div className="flex flex-col gap-2 text-gray-400 text-base">
              <a href="#" className="hover:text-white transition-colors duration-200">Shop All</a>
              <a href="#" className="hover:text-white transition-colors duration-200">New In</a>
              <a href="/shop" className="hover:text-white transition-colors duration-200">Bestsellers</a>
              <a href="/collections" className="hover:text-white transition-colors duration-200">Collections</a>
              <a href="#" className="hover:text-white transition-colors duration-200">Lookbook</a>
              <a href="#" className="hover:text-white transition-colors duration-200">Gifts Cards</a>
            </div>
          </div>

          {/* Customer Care */}
          <div className="flex flex-col gap-4">
            <h1 className="font-semibold text-base">Customer Care</h1>
            <div className="flex flex-col gap-2 text-gray-400 text-base">
              <a href="shipping-policy" className="hover:text-white transition-colors duration-200">Shipping & Delivery Policy</a>
              <a href="refundpolicy" className="hover:text-white transition-colors duration-200">Refund Policy</a>
              <a href="privacypolicy" className="hover:text-white transition-colors duration-200">Privacy Policy</a>
              <a href="/termsandconditions" className="hover:text-white transition-colors duration-200">Terms and Conditions</a>
              <a href="/user-login" className="hover:text-white transition-colors duration-200">Account</a>
              <a href="/contact-us" className="hover:text-white transition-colors duration-200">Contact Us</a>
            </div>
          </div>

          {/* Company */}
          <div className="flex flex-col gap-4">
            <h1 className="font-semibold text-base">Company</h1>
            <div className="flex flex-col gap-2 text-gray-400 text-base">
              <a href="/about" className="hover:text-white transition-colors duration-200">About</a>
              <a href="/blogs" className="hover:text-white transition-colors duration-200">Stories</a>
              <a href="/FAQs" className="hover:text-white transition-colors duration-200">FAQs</a>
              <a href="/disclaimer" className="hover:text-white transition-colors duration-200">Disclaimer</a>
            </div>
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-4">
            <h1 className="font-semibold text-base">Contact</h1>

            <div className="flex gap-2 items-center">
              <img width={20} src={phone} alt="" />
              <a className="text-gray-400 text-base hover:text-white transition-colors duration-200" href="#">+91-9983339820</a>
            </div>

            <div className="flex items-center gap-2">
              <img width={20} src={mail} alt="" />
              <a className="text-gray-400 text-base hover:text-white transition-colors duration-200" href="#">info@rudracrafts.com</a>
            </div>

            <div className="flex items-start gap-2">
              <img width={20} src={location} alt="" />
              <p className="text-gray-400 text-base leading-6">
                125, Taneja Block, Saket Colony, Adarsh Nagar, Jaipur, Rajasthan 302004
              </p>
            </div>
          </div>

        </div>

        <div className="border-t border-gray-600 mt-10 pt-6 flex justify-between text-sm text-gray-400">
          <p>© Rudra Craft all rights Reserved</p>
          <p>Powered By Infomagine Softwares Pvt. Ltd.</p>
        </div>
      </div>

      {/* Mobile */}
      <div className="block md:hidden px-6 py-10">
        {/* Logo + Intro */}
        <div className="flex flex-col gap-4">
          <img width={100} src={footerlogo} alt="" />

          <p className="text-gray-400 text-xs leading-4">
            It is a long established fact that a reader will be distracted by the readable content.
          </p>

          <div className="flex flex-col gap-4 text-sm text-gray-400">
            <div className="flex gap-2 items-center">
              <img width={20} src={phone} alt="" />
              <a href="#">+91-9983339820</a>
            </div>

            <div className="flex items-center gap-2">
              <img width={20} src={mail} alt="" />
              <a href="#">info@rudracraft.com</a>
            </div>

            <div className="flex items-start gap-2">
              <img width={20} src={location} alt="" />
              <p className="leading-4 text-xs">
                125, Taneja Block, Saket Colony, Jaipur, Rajasthan 302004
              </p>
            </div>
          </div>

          <div className="flex gap-5 mt-4">
            <img src={insta} alt="" width={20} />
            <img src={fb} alt="" width={20} />
            <img src={twitter} alt="" width={18} />
          </div>
        </div>

        {/* Accordion */}
        <div className="mt-8 flex flex-col gap-4 text-sm">

          {/* Shop */}
          <AccordionItem
            title="Shop"
            open={open === "shop"}
            toggle={() => toggle("shop")}
            items={[
              "Shop All",
              "New In",
              "Bestsellers",
              "Collections",
              "Lookbook",
              "Gifts Cards",
            ]}
          />

          {/* Customer Care */}
          <AccordionItem
            title="Customer Care"
            open={open === "care"}
            toggle={() => toggle("care")}
            items={[
              "Shipping & Delivery Policy",
              "Refund Policy",
              "Privacy Policy",
              "Terms and Conditions",
              "Account",
              "Contact Us",
            ]}
          />

          {/* Company */}
          <AccordionItem
            title="Company"
            open={open === "company"}
            toggle={() => toggle("company")}
            items={[
              "About",
              "Stories",
              "FAQs",
              "Disclaimer",
            ]}
          />
        </div>

        <div className="border-t border-gray-600 mt-10 py-6 flex flex-col text-center gap-2 text-xs text-gray-400">
          <p>© StoleSutra all rights Reserved</p>
          <p>Powered By Infomagine Softwares Pvt. Ltd.</p>
        </div>
      </div>
    </footer>
  );
}

// Accordion Component
function AccordionItem({ title, open, toggle, items }) {
  return (
    <div>
      <div
        onClick={toggle}
        className="flex justify-between items-center text-white cursor-pointer"
      >
        <p className="font-medium">{title}</p>
        {open ? <FaChevronUp size={14} /> : <FaChevronDown size={14} />}
      </div>

                {open && (
        <div className="flex flex-col gap-1 mt-2 text-gray-400">
          {items.map((x, i) => (
            <a key={i}>{x}</a>
          ))}
        </div>
      )}
    </div>
  );
}