import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { MdKeyboardArrowRight } from "react-icons/md";
import { TiHeartFullOutline } from "react-icons/ti";
import { HiChevronDown, HiOutlineShoppingBag } from "react-icons/hi2";
import { useMediaQuery } from "@mui/material";
import axiosInstance from "../../utils/axios";

import { DiscountBanner } from "./DiscountBanner";
import Subscription from "./Subscription";
import { OurServices } from "./OurServices";
import { ClassyCollection } from "./ClassyCollection";
import { toast } from "sonner";

export const ProductNew = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [largeImage, setLargeImage] = useState("");
  const [loading, setLoading] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState({});
  const [isInWishlist, setIsInWishlist] = useState(false);
  const [wishlistLoading, setWishlistLoading] = useState(false);
  const [cartLoading, setCartLoading] = useState(false);
  const [message, setMessage] = useState("");

  const isMobile = useMediaQuery("(max-width:900px)");

  const customerId = localStorage.getItem("customerId");
  const isLoggedIn = !!customerId;

  const checkWishlistStatus = async () => {
    if (!customerId) {
      setIsInWishlist(false);
      return;
    }

    try {
      const response = await axiosInstance.get(`/wishlist/${customerId}`);
      const wishlistProducts = response.data.products || [];
      const productFound = wishlistProducts.some(item => String(item.id) === String(id));
      setIsInWishlist(productFound);
    } catch (error) {
      console.error("Wishlist check failed:", error);
      setIsInWishlist(false);
    }
  };

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        setLoading(true);
        const productResponse = await axiosInstance.get(`/products/${id}`);
        const productData = productResponse.data;
        let overviewData = {};
        try {
          const overviewResponse = await axiosInstance.get(`/product-description/product/${id}`);
          overviewData = overviewResponse.data || {};
        } catch (err) {
          console.warn(`Overview not found for product ID: ${id}`);
        }
        const mergedData = { ...productData, ...overviewData };
        setProduct(mergedData);
        if (mergedData.images && mergedData.images.length > 0) {
          setLargeImage(`${axiosInstance.defaults.baseURL}/${mergedData.images[0]}`);
        }
        await checkWishlistStatus();
      } catch (error) {
        console.error("Failed to fetch product data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProductData();
  }, [id]);

  const handleWishlist = async () => {
    if (!isLoggedIn) {
      setMessage("Please log in to add to wishlist");
      setTimeout(() => setMessage(""), 3000);
      return;
    }

    setWishlistLoading(true);

    try {
      if (isInWishlist) {
        await axiosInstance.delete(`/wishlist/${customerId}/${id}`);
        setIsInWishlist(false);
        setMessage("Removed from wishlist");
      } else {
        const formData = new FormData();
        formData.append("product_id", id);
        await axiosInstance.post(`/wishlist/${customerId}`, formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        setIsInWishlist(true);
        setMessage("Added to wishlist ❤️");
      }
      // Navbar wishlist count update
      window.dispatchEvent(new Event("wishlistUpdated"));
    } catch (error) {
      console.error("Wishlist operation failed:", error);
      setMessage("Failed. Please try again.");
    } finally {
      setWishlistLoading(false);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  const handleAddToCart = async () => {
    if (!isLoggedIn) {
      setMessage("Please log in to add to cart");
      setTimeout(() => setMessage(""), 3000);
      return;
    }

    setCartLoading(true);

    const formData = new FormData();
    formData.append("product_id", id);
    formData.append("quantity", 1);

    try {
      await axiosInstance.post(`/cart/${customerId}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast.success("Added to cart successfully! 🛒");
      // Navbar cart count update
      window.dispatchEvent(new Event("cartUpdated"));
    } catch (error) {
      console.error("Add to cart failed:", error);
      setMessage("Failed to add to cart. Please try again.");
    } finally {
      setCartLoading(false);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  const toggleCategory = (category) => {
    setExpandedCategories((prev) => ({ ...prev, [category]: !prev[category] }));
  };

  if (!product) {
    return (
      <div className="w-full h-screen flex items-center justify-center">
        Loading product...
      </div>
    );
  }

  const title = product.title || product.general_info?.name || "Product";
  const description = product.description || product.overview || "";
  const images = product.images?.map((img) => `${axiosInstance.defaults.baseURL}/${img}`) || [];
  const discount_percentage = product.general_info?.discount || 0;
  const price = product.general_info?.price || 0;
  const discountedPrice = discount_percentage
    ? (price - (price * discount_percentage) / 100).toFixed(2)
    : price;

  return (
    <>
      {loading && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="w-14 h-14 border-8 border-gray-300 border-t-black rounded-full animate-spin"></div>
        </div>
      )}

      {/* BREADCRUMB */}
      <div className="w-full h-48 bg-[#CFD9E2] flex items-center justify-center text-center">
        <div>
          <h1 className="text-4xl font-light text-[#3F4754]">{title}</h1>
          <div className="flex items-center justify-center gap-2 mt-3 text-[#3F4754]">
            <a href="/">Home</a> <MdKeyboardArrowRight />
            <a href="/shop">Shop</a> <MdKeyboardArrowRight />
            {title}
          </div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="container mx-auto px-12 py-20">
        <div className={`grid ${isMobile ? "grid-cols-1" : "grid-cols-2"} gap-10`}>
          {/* LEFT SIDE - IMAGES */}
          <div className="flex flex-col gap-6">
            <div className="flex gap-6">
              <div className={`flex flex-col gap-4 ${isMobile ? "flex-row overflow-x-auto pb-4" : ""}`}>
                {images.map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    onClick={() => setLargeImage(img)}
                    className={`w-20 h-20 object-cover rounded-lg border-4 cursor-pointer flex-shrink-0 ${
                      img === largeImage
                        ? "border-black shadow-lg"
                        : "border-transparent opacity-60 hover:opacity-100"
                    }`}
                    alt={`Thumbnail ${index + 1}`}
                  />
                ))}
              </div>

              <div className="flex-1 relative">
                <img
                  src={largeImage}
                  className="w-full max-w-[480px] h-[480px] object-cover rounded-xl"
                  alt={title}
                />
              </div>
            </div>

            {/* ACTION BUTTONS */}
            <div className="flex w-full gap-3 mt-10">
              <button
                onClick={handleAddToCart}
                disabled={cartLoading}
                className="flex-1 py-3 bg-[#7A6E54] hover:bg-[#6B6048] active:scale-95 text-white font-bold rounded-lg transition-all duration-300 flex items-center justify-center gap-2 shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {cartLoading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <HiOutlineShoppingBag className="text-xl" />
                )}
                {cartLoading ? "Adding..." : "Add to Cart"}
              </button>

              <button
                onClick={handleWishlist}
                disabled={wishlistLoading}
                className={`flex-1 py-3 font-bold rounded-lg transition-all duration-300 flex items-center justify-center gap-2 shadow-md hover:shadow-lg ${
                  isInWishlist
                    ? 'bg-[#ec4899] text-white hover:bg-[#db2777]'
                    : 'bg-white text-[#7A6E54] hover:bg-[#7A6E54] hover:text-white'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                {wishlistLoading ? (
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <TiHeartFullOutline className="text-lg transition-all duration-300" />
                    <span>{isInWishlist ? "Added to Wishlist" : "Add to wishlist"}</span>
                  </>
                )}
              </button>
            </div>

            {/* Message */}
            {message && (
              <div className={`mt-4 text-center text-sm font-medium ${message.includes("success") || message.includes("Added") ? "text-green-600" : "text-red-600"}`}>
                {message}
              </div>
            )}
          </div>

          {/* RIGHT SIDE INFO */}
          <div className="flex flex-col gap-6">
            <h1 className="text-3xl md:text-4xl font-medium">{title}</h1>
            <p className="text-gray-700">{description}</p>

            <div className="flex items-center gap-3">
              <h2 className="text-3xl font-bold">₹{discountedPrice}</h2>
              {discount_percentage > 0 && (
                <>
                  <h3 className="line-through text-gray-500">₹{price}</h3>
                  <h3 className="text-green-600 font-medium">({discount_percentage}% Off)</h3>
                </>
              )}
            </div>

            <hr className="my-6 border-gray-300" />

            <div className="space-y-8">
              {/* Overview */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Overview</h3>
                {product.overview ? (
                  <p className="text-sm text-gray-700 leading-relaxed">{product.overview}</p>
                ) : (
                  <p className="text-sm text-gray-600 italic">
                    Overview not available for this product.
                  </p>
                )}
              </div>

              {/* Specifications */}
              {product.specifications && Object.keys(product.specifications).length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Specifications</h3>
                  <div className="border border-gray-200 rounded-lg divide-y divide-gray-200">
                    {Object.keys(product.specifications).map((category) => (
                      <div key={category}>
                        <button
                          onClick={() => toggleCategory(category)}
                          className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-all duration-200"
                        >
                          <h4 className="text-base font-medium text-gray-800 capitalize">
                            {category.replace(/_/g, " ")}
                          </h4>
                          <HiChevronDown
                            className={`text-xl text-gray-600 transition-transform duration-300 ${
                              expandedCategories[category] ? "rotate-180" : ""
                            }`}
                          />
                        </button>

                        <div
                          className={`overflow-hidden transition-all duration-500 ease-in-out ${
                            expandedCategories[category] ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0"
                          }`}
                        >
                          <div className="px-5 pb-5 pt-2 space-y-3">
                            {Object.entries(product.specifications[category]).map(([key, value]) => (
                              <div key={key} className="flex justify-between text-sm py-2 border-b border-gray-100 last:border-0">
                                <span className="text-gray-600 capitalize">{key.replace(/_/g, " ")}</span>
                                <span className="font-medium text-gray-900 text-right max-w-[60%]">{value}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <DiscountBanner />
      <ClassyCollection />
      <Subscription />
      <OurServices />
    </>
  );
};

export default ProductNew;