import React, { useState } from "react";
import cimg1 from "../../Assets/CIMG1.jpg";
import cimg2 from "../../Assets/CIMG2.jpg";
import { HiOutlineShoppingBag } from "react-icons/hi2";
import { TiHeartFullOutline } from "react-icons/ti";
import cimg3 from "../../Assets/CIMG3.jpg";
import cimg4 from "../../Assets/CIMG4.jpg";
import { useTheme, useMediaQuery } from "@mui/material";
import { Swiper, SwiperSlide } from "swiper/react";

import "swiper/css";
import "swiper/css/pagination";

import { Pagination } from "swiper/modules";

export const ClassyCollection = () => {
  const theme = useTheme();
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");
  const [hoveredIndex, setHoveredIndex] = useState(null);
  const [isPressed, setIsPressed] = useState(false);

  const handleMouseEnter = (index) => {
    setHoveredIndex(index);
  };

  const handleClick = () => {
    setIsPressed(!isPressed);
  };

  const handleMouseLeave = () => {
    setHoveredIndex(null);
  };

  const imageContainerStyle = {
    position: "relative",
    overflow: "hidden",
  };

  const imageStyle = {
    transition: "transform 0.6s ease",
  };

  const overlayStyle = (index) => ({
    width: "100%",
    height: "3rem",
    backgroundColor: "#7A6E54",
    position: "absolute",
    top: "88%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "white",
    gap: "1rem",
    transform: hoveredIndex === index ? "translateY(0)" : "translateY(100%)",
    transition: "transform 0.3s ease-out",
  });

  return (
    <>
      <div
        style={{ fontFamily: "Lora" }}
        className="flex flex-col items-center text-center mt-20 gap-6"
      >
        <div className="flex flex-col gap-4 items-center">
          <h1
            style={{ fontSize: isXs ? "2rem" : "3rem" }} 
            data-aos="fade-up"
            className="text-5xl"
          >
            Classy Collections
          </h1>
          <p
            style={{
              width: isXs ? "80%" : "70%",
              fontSize: isXs ? ".9rem" : "1rem", 
              textAlign: "center",
            }}
            data-aos="fade-up"
            className="text-base"
          >
            Maecenas Tincidunt Ipsum Et Felis Pellentesque Volutpat. Phasellus
            Ligula Arcu, Aliquam Non Accumsan Eu
          </p>
        </div>

        <div
          style={{ display: isXs ? "none" : "grid" }} 
          data-aos="fade-up"
          className="grid grid-cols-5 gap-6 p-4"
        >
          {[cimg2, cimg3, cimg4, cimg1, cimg2].map((image, index) => (
            <div key={index} className="flex flex-col gap-3">
              <div
                onMouseEnter={() => handleMouseEnter(index)}
                onMouseLeave={handleMouseLeave}
                style={imageContainerStyle}
              >
                <img
                  src={image}
                  alt={`Classy Collection ${index + 1}`}
                  style={{
                    ...imageStyle,
                    transform:
                      hoveredIndex === index ? "scale(1.1)" : "scale(1)",
                  }}
                />
                <div
                  style={overlayStyle(index)} 
                >
                  <button
                    onClick={handleClick}
                    style={{
                      backgroundColor: isPressed ? "#f5f5f5" : "",
                      color: isPressed ? "#ff0000" : "lightgrey",
                      border: "none",
                      borderRadius: "5px",
                      padding: "5px",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "24px",
                      transition: "background-color 0.3s ease",
                    }}
                  >
                    <TiHeartFullOutline />
                  </button>

                  <hr
                    style={{
                      border: "1px solid",
                      rotate: "180deg",
                      height: "1.5rem",
                    }}
                  />

                  <div className="flex gap-1 items-center justify-center">
                    <HiOutlineShoppingBag style={{ fontSize: "1.3rem" }} />

                    <a
                      style={{ textDecoration: "none", color: "white" }}
                      href="/cart"
                    >
                      {" "}
                      Add to Bag
                    </a>
                  </div>
                </div>
              </div>
              <div>
                <a style={{ fontSize: "1.2rem", color: "black" }} href="#">
                  Shawl Head Wrap
                </a>
              </div>
              <div style={{ fontSize: "1.2rem" }}>$1.00</div>
            </div>
          ))}
        </div>

        <div
          style={{
            width: "100%",
            padding: "0rem 2rem",
            display: isXs ? "flex" : "none",
          }}
        >
          <Swiper
            spaceBetween={20}
            pagination={{
              clickable: true,
            }}
            modules={[Pagination]}
            className="mySwiper"
            style={{ "--swiper-pagination-color": "#7A6E54" }}
          >
            <SwiperSlide>
              <div style={imageContainerStyle}>
                <img src={cimg1} alt="" style={imageStyle} />
              </div>
              <div style={{ padding: "1rem 2rem 2.5rem 2rem" }}>
                <a style={{ fontSize: "1.2rem", color: "black" }} href="#">
                  Shawl Head Wrap
                </a>

                <div style={{ fontSize: "1.2rem" }}>$1.00</div>
              </div>
            </SwiperSlide>

            <SwiperSlide>
              <div style={imageContainerStyle}>
                <img src={cimg2} alt="" style={imageStyle} />
              </div>
              <div>
                <a style={{ fontSize: "1.2rem", color: "black" }} href="#">
                  Shawl Head Wrap
                </a>
              </div>
              <div style={{ fontSize: "1.2rem" }}>$1.00</div>
            </SwiperSlide>

            <SwiperSlide>
              <div style={imageContainerStyle}>
                <img src={cimg3} alt="" style={imageStyle} />
              </div>
              <div>
                <a style={{ fontSize: "1.2rem", color: "black" }} href="#">
                  Shawl Head Wrap
                </a>
              </div>
              <div style={{ fontSize: "1.2rem" }}>$1.00</div>
            </SwiperSlide>

            <SwiperSlide>
              <div style={imageContainerStyle}>
                <img src={cimg4} alt="" style={imageStyle} />
              </div>
              <div>
                <a style={{ fontSize: "1.2rem", color: "black" }} href="#">
                  Shawl Head Wrap
                </a>
              </div>
              <div style={{ fontSize: "1.2rem" }}>$1.00</div>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </>
  );
};
