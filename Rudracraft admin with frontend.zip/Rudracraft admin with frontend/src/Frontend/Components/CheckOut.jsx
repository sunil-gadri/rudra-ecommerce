import React, { useState, useEffect } from "react";
import { ChevronRight, Mail, MapPin, Home, Building, Lock, Plus, X, Edit, Trash2,} from "lucide-react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../utils/axios";
import { toast } from "sonner";

// ========== Add Address Modal Component ==========
const AddAddressModal = ({ onClose, onSuccess }) => {
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [building, setBuilding] = useState("");
  const [streetAddress, setStreetAddress] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [addressType, setAddressType] = useState("Home");
  const [country, setCountry] = useState("India");

  const customerId = localStorage.getItem("customerId");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("full_name", fullName);
    formData.append("phone", phone);
    formData.append("email", email);
    formData.append("building", building);
    formData.append("street_address", streetAddress);
    formData.append("city", city);
    formData.append("state", state);
    formData.append("postal_code", postalCode);
    formData.append("address_type", addressType);
    formData.append("country", country);

    try {
      await axiosInstance.post(`/address/${customerId}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("Address added successfully!");
      onSuccess(); // Trigger parent to refetch addresses
      onClose();
    } catch (error) {
      alert(error?.response?.data?.message || "Failed to add address");
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(0,0,0,0.5)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 50,
      }}
      onClick={onClose}
    >
      <div
        style={{
          backgroundColor: "white",
          borderRadius: "12px",
          width: "90%",
          maxWidth: "480px",
          maxHeight: "90vh",
          overflowY: "auto",
          padding: "1.5rem",
          position: "relative",
          boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          style={{ position: "absolute", top: "0.8rem", right: "0.8rem", background: "none", border: "none", cursor: "pointer" }}
        >
          <X size={20} />
        </button>

        <h2 style={{ fontSize: "1.25rem", marginBottom: "1rem", color: "#3F4754", fontWeight: "600" }}>
          Add New Address
        </h2>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "1rem" }}>
            <h3 style={{ fontSize: "0.9rem", fontWeight: "600", marginBottom: "0.6rem", display: "flex", alignItems: "center", gap: "0.4rem" }}>
              <Mail size={16} style={{ color: "#7A6E54" }} />
              Contact Information
            </h3>
            <input type="text" placeholder="Full Name" value={fullName} onChange={(e) => setFullName(e.target.value)} required style={smallInputStyle} />
            <input type="tel" placeholder="Phone Number" value={phone} onChange={(e) => setPhone(e.target.value)} required style={smallInputStyle} />
            <input type="email" placeholder="Email Address" value={email} onChange={(e) => setEmail(e.target.value)} required style={smallInputStyle} />
          </div>

          <div>
            <h3 style={{ fontSize: "0.9rem", fontWeight: "600", marginBottom: "0.6rem", display: "flex", alignItems: "center", gap: "0.4rem" }}>
              <MapPin size={16} style={{ color: "#7A6E54" }} />
              Delivery Address
            </h3>

            <div style={{ display: "flex", gap: "1rem", marginBottom: "0.8rem" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "0.4rem", fontSize: "0.85rem" }}>
                <input type="radio" name="type_add" value="Home" checked={addressType === "Home"} onChange={(e) => setAddressType(e.target.value)} style={{ accentColor: "#7A6E54" }} />
                <Home size={14} />
                Home
              </label>
              <label style={{ display: "flex", alignItems: "center", gap: "0.4rem", fontSize: "0.85rem" }}>
                <input type="radio" name="type_add" value="Office" checked={addressType === "Office"} onChange={(e) => setAddressType(e.target.value)} style={{ accentColor: "#7A6E54" }} />
                <Building size={14} />
                Office
              </label>
            </div>

            <select value={country} onChange={(e) => setCountry(e.target.value)} required style={smallInputStyle}>
              <option value="">Select Country</option>
              <option value="India">India</option>
            </select>

            <input type="text" placeholder="Building / Flat No." value={building} onChange={(e) => setBuilding(e.target.value)} required style={smallInputStyle} />
            <input type="text" placeholder="Street / Locality" value={streetAddress} onChange={(e) => setStreetAddress(e.target.value)} required style={smallInputStyle} />

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.6rem", marginTop: "0.4rem" }}>
              <input type="text" placeholder="City" value={city} onChange={(e) => setCity(e.target.value)} required style={smallInputStyle} />
              <input type="text" placeholder="State" value={state} onChange={(e) => setState(e.target.value)} required style={smallInputStyle} />
              <input type="text" placeholder="PIN Code" value={postalCode} onChange={(e) => setPostalCode(e.target.value)} required style={smallInputStyle} />
            </div>

            <div style={{ display: "flex", gap: "0.8rem", marginTop: "1.5rem" }}>
              <button type="button" onClick={onClose} style={{ flex: 1, padding: "0.75rem", backgroundColor: "#f3f4f6", border: "none", borderRadius: "6px", cursor: "pointer", fontSize: "0.85rem" }}>
                Cancel
              </button>
              <button type="submit" style={{ flex: 1, padding: "0.75rem", backgroundColor: "#7A6E54", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontSize: "0.85rem", fontWeight: "600" }}>
                Save Address
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

// ========== Edit Address Modal Component ==========
const EditAddressModal = ({ address, onClose, onSuccess }) => {
  const [fullName, setFullName] = useState(address.full_name || "");
  const [phone, setPhone] = useState(address.phone || "");
  const [email, setEmail] = useState(address.email || "");
  const [building, setBuilding] = useState(address.building || "");
  const [streetAddress, setStreetAddress] = useState(address.street_address || "");
  const [city, setCity] = useState(address.city || "");
  const [state, setState] = useState(address.state || "");
  const [postalCode, setPostalCode] = useState(address.postal_code || "");
  const [addressType, setAddressType] = useState(address.address_type || "Home");
  const [country, setCountry] = useState(address.country || "India");

  const customerId = localStorage.getItem("customerId");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("full_name", fullName);
    formData.append("phone", phone);
    formData.append("email", email);
    formData.append("building", building);
    formData.append("street_address", streetAddress);
    formData.append("city", city);
    formData.append("state", state);
    formData.append("postal_code", postalCode);
    formData.append("address_type", addressType);
    formData.append("country", country);

    try {
      await axiosInstance.put(`/address/${customerId}/${address.id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("Address updated successfully!");
      onSuccess();
      onClose();
    } catch (error) {
      alert(error?.response?.data?.message || "Failed to update address");
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(0,0,0,0.5)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 50,
      }}
      onClick={onClose}
    >
      <div
        style={{
          backgroundColor: "white",
          borderRadius: "12px",
          width: "90%",
          maxWidth: "480px",
          maxHeight: "90vh",
          overflowY: "auto",
          padding: "1.5rem",
          position: "relative",
          boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          style={{ position: "absolute", top: "0.8rem", right: "0.8rem", background: "none", border: "none", cursor: "pointer" }}
        >
          <X size={20} />
        </button>

        <h2 style={{ fontSize: "1.25rem", marginBottom: "1rem", color: "#3F4754", fontWeight: "600" }}>
          Edit Address
        </h2>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "1rem" }}>
            <h3 style={{ fontSize: "0.9rem", fontWeight: "600", marginBottom: "0.6rem", display: "flex", alignItems: "center", gap: "0.4rem" }}>
              <Mail size={16} style={{ color: "#7A6E54" }} />
              Contact Information
            </h3>
            <input type="text" placeholder="Full Name" value={fullName} onChange={(e) => setFullName(e.target.value)} required style={smallInputStyle} />
            <input type="tel" placeholder="Phone Number" value={phone} onChange={(e) => setPhone(e.target.value)} required style={smallInputStyle} />
            <input type="email" placeholder="Email Address" value={email} onChange={(e) => setEmail(e.target.value)} required style={smallInputStyle} />
          </div>

          <div>
            <h3 style={{ fontSize: "0.9rem", fontWeight: "600", marginBottom: "0.6rem", display: "flex", alignItems: "center", gap: "0.4rem" }}>
              <MapPin size={16} style={{ color: "#7A6E54" }} />
              Delivery Address
            </h3>

            <div style={{ display: "flex", gap: "1rem", marginBottom: "0.8rem" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "0.4rem", fontSize: "0.85rem" }}>
                <input type="radio" name="type_edit" value="Home" checked={addressType === "Home"} onChange={(e) => setAddressType(e.target.value)} style={{ accentColor: "#7A6E54" }} />
                <Home size={14} />
                Home
              </label>
              <label style={{ display: "flex", alignItems: "center", gap: "0.4rem", fontSize: "0.85rem" }}>
                <input type="radio" name="type_edit" value="Office" checked={addressType === "Office"} onChange={(e) => setAddressType(e.target.value)} style={{ accentColor: "#7A6E54" }} />
                <Building size={14} />
                Office
              </label>
            </div>

            <select value={country} onChange={(e) => setCountry(e.target.value)} required style={smallInputStyle}>
              <option value="">Select Country</option>
              <option value="India">India</option>
            </select>

            <input type="text" placeholder="Building / Flat No." value={building} onChange={(e) => setBuilding(e.target.value)} required style={smallInputStyle} />
            <input type="text" placeholder="Street / Locality" value={streetAddress} onChange={(e) => setStreetAddress(e.target.value)} required style={smallInputStyle} />

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.6rem", marginTop: "0.4rem" }}>
              <input type="text" placeholder="City" value={city} onChange={(e) => setCity(e.target.value)} required style={smallInputStyle} />
              <input type="text" placeholder="State" value={state} onChange={(e) => setState(e.target.value)} required style={smallInputStyle} />
              <input type="text" placeholder="PIN Code" value={postalCode} onChange={(e) => setPostalCode(e.target.value)} required style={smallInputStyle} />
            </div>

            <div style={{ display: "flex", gap: "0.8rem", marginTop: "1.5rem" }}>
              <button type="button" onClick={onClose} style={{ flex: 1, padding: "0.75rem", backgroundColor: "#f3f4f6", border: "none", borderRadius: "6px", cursor: "pointer", fontSize: "0.85rem" }}>
                Cancel
              </button>
              <button type="submit" style={{ flex: 1, padding: "0.75rem", backgroundColor: "#7A6E54", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontSize: "0.85rem", fontWeight: "600" }}>
                Update Address
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

// ========== Main Checkout Component ==========
export const CheckOut = () => {
  const [cartData, setCartData] = useState(null);
  const [addresses, setAddresses] = useState([]);
  const [selectedAddressId, setSelectedAddressId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingAddresses, setLoadingAddresses] = useState(true);

  // Modal visibility
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingAddress, setEditingAddress] = useState(null);

  const navigate = useNavigate();
  const customerId = localStorage.getItem("customerId");
  const isLoggedIn = !!localStorage.getItem("customerToken");

  // Fetch cart
  useEffect(() => {
    const fetchCart = async () => {
      if (!isLoggedIn || !customerId) {
        navigate("/cart");
        return;
      }
      try {
        setLoading(true);
        const response = await axiosInstance.get(`/cart/${customerId}`);
        setCartData(response.data);
      } catch (error) {
        console.error("Failed to load cart:", error);
        navigate("/cart");
      } finally {
        setLoading(false);
      }
    };
    fetchCart();
  }, [isLoggedIn, customerId, navigate]);

  // Fetch addresses
  const fetchAddresses = async () => {
    if (!customerId) return;
    try {
      setLoadingAddresses(true);
      const response = await axiosInstance.get(`/address/${customerId}`);
      const addrList = response.data.addresses || [];
      setAddresses(addrList);
      if (addrList.length > 0 && !selectedAddressId) {
        setSelectedAddressId(addrList[0].id);
      }
    } catch (error) {
      console.error("Error fetching addresses:", error);
    } finally {
      setLoadingAddresses(false);
    }
  };

  useEffect(() => {
    if (isLoggedIn) fetchAddresses();
  }, [customerId, isLoggedIn]);

  useEffect(() => {
    if (addresses.length === 0) {
      setSelectedAddressId(null);
      return;
    }
    const exists = addresses.some((addr) => addr.id === selectedAddressId);
    if (!exists) {
      setSelectedAddressId(addresses[0].id);
    }
  }, [addresses]);

  const openEdit = (addr) => {
    setEditingAddress(addr);
    setShowEditModal(true);
  };

  // Delete address
  const handleDeleteAddress = async (addressId) => {
    if (!window.confirm("Are you sure you want to delete this address?")) return;
    try {
      await axiosInstance.delete(`/address/${customerId}/${addressId}`);
      alert("Address deleted successfully!");
      await fetchAddresses();
    } catch (error) {
      alert(error?.response?.data?.message || "Failed to delete address");
    }
  };

// Place order - POST to /orders
const handlePlaceOrder = async () => {
  if (!selectedAddressId) {
    alert("Please select or add a delivery address");
    return;
  }

  const selectedAddress = addresses.find((a) => a.id === selectedAddressId);

 const orderItems = cart.map((item) => ({
    product_id: item.id,                
    quantity: item.quantity,
    base_price: item.base_price,                 
    discount: item.discount,
    discounted_price:item.discounted_price,
    tax: item.gst,  
  }));

  const payload = {
    customer_id: Number(customerId),
    total_amount: summary.payable_amount,   
    total_discount: summary.total_discount,   
    coupon_code: summary.coupon_code || null,
    order_amount:summary.order_amount,
    coupon_discount: summary.coupon_discount || 0,
    shipping_cost: summary.shipping_cost || 0,
    shipping_details: {
      shipping_name: selectedAddress.full_name,
      shipping_phone: selectedAddress.phone.toString(), 
      shipping_email: selectedAddress.email,
      building: selectedAddress.building,
      street_address: selectedAddress.street_address,
      city: selectedAddress.city,
      state: selectedAddress.state,
      postal_code: selectedAddress.postal_code.toString(),
      country: selectedAddress.country,
      address_type: selectedAddress.address_type,
    },
    items: orderItems,
  };


 try {
  const response = await axiosInstance.post("/orders", payload);
  
  toast.success("Order created successfully! Redirecting to payment...");
  initiateRazorpayPayment(response.data);

} catch (error) {
  console.error("Order placement failed:", error);
  alert(error?.response?.data?.message || "Failed to place order. Please try again.");
}
};

const initiateRazorpayPayment = (apiResponse) => {
  const {
    razorpay_key,
    razorpay_order_id,
    invoice_number,
    currency = "INR",
    order_id,
  } = apiResponse;

  const amountInPaise = Math.round(summary.payable_amount * 100);

  const options = {
    key: razorpay_key,
    amount: amountInPaise,
    currency,
    name: "Rudra Crafts",
    description: `Order #${invoice_number}`,
    order_id: razorpay_order_id,
    handler: function (response) {
      verifyPayment(response, order_id);
    },
    prefill: {
      name: selectedAddress.full_name,
      email: selectedAddress.email,
      contact: selectedAddress.phone.toString(),
    },
    notes: {
      order_id: order_id,
      invoice_number: invoice_number,
    },
    theme: {
      color: "#7A6E54",
    },
    modal: {
      ondismiss: () => {
        alert("Payment cancelled. You can try again.");
      },
    },
  };

  // Dynamically load Razorpay script if not already loaded
  if (!window.Razorpay) {
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => {
      const rzp = new window.Razorpay(options);
      rzp.open();
    };
    script.onerror = () => {
      alert("Failed to load Razorpay SDK. Please check your internet connection.");
    };
    document.body.appendChild(script);
  } else {
    const rzp = new window.Razorpay(options);
    rzp.open();
  }
};

const verifyPayment = async (paymentResponse, internalOrderId) => {
  try {
    const verifyPayload = {
      razorpay_order_id: paymentResponse.razorpay_order_id,
      razorpay_payment_id: paymentResponse.razorpay_payment_id,
      razorpay_signature: paymentResponse.razorpay_signature,
    };

    await axiosInstance.post("/verify_payment", verifyPayload);

    toast.success("Payment successful! Your order has been confirmed.");
  } catch (error) {
    console.error("Payment verification failed:", error);
    alert("Payment verification failed. Please contact support.");
  }
};
  

  if (loading || loadingAddresses) {
    return (
      <div className="w-full h-screen flex items-center justify-center">
        <div className="w-14 h-14 border-8 border-gray-300 border-t-black rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!isLoggedIn) return null;

  if (!cartData || cartData.cart.length === 0) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "1.5rem" }}>
        <h2 style={{ fontSize: "1.5rem", color: "#7A6E54" }}>Your cart is empty</h2>
        <a href="/cart">
          <button style={{ backgroundColor: "#7A6E54", color: "white", padding: "0.8rem 2rem", borderRadius: "8px", fontWeight: "600" }}>
            Go to Cart
          </button>
        </a>
      </div>
    );
  }

  const { cart, summary } = cartData;
  const selectedAddress = addresses.find((a) => a?.id === selectedAddressId);

  return (
    <div style={{ backgroundColor: "#FFFFFF", minHeight: "100vh" }}>
      {/* Header */}
      <div style={{ width: "100%", backgroundColor: "#CFD9E2", padding: "3rem 1rem", textAlign: "center", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}>
        <h1 style={{ fontSize: "2rem", fontWeight: "400", color: "#3F4754", marginBottom: "1rem" }}>Checkout</h1>
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "0.5rem", color: "#3F4754", fontSize: "0.85rem" }}>
          <a href="/" style={{ color: "#3F4754", textDecoration: "none" }}>Home</a>
          <ChevronRight size={18} />
          <a href="/cart" style={{ color: "#3F4754", textDecoration: "none" }}>Cart</a>
          <ChevronRight size={18} />
          <span>Checkout</span>
        </div>
      </div>

      <div style={{ padding: "2rem 1rem", maxWidth: "1280px", margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "2rem" }}>
          {/* Left: Address Selection */}
          <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
            <div style={{ backgroundColor: "white", borderRadius: "12px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", padding: "1.5rem" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.2rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                  <MapPin size={18} style={{ color: "#7A6E54" }} />
                  <h2 style={{ fontSize: "0.95rem", fontWeight: "600", color: "#3F4754" }}>Delivery Address</h2>
                </div>
                <button
                  onClick={() => setShowAddModal(true)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "0.5rem",
                    background: "none",
                    border: "1px dashed #7A6E54",
                    color: "#7A6E54",
                    padding: "0.5rem 1rem",
                    borderRadius: "8px",
                    fontSize: "0.85rem",
                    cursor: "pointer",
                  }}
                >
                  <Plus size={18} />
                  Add New
                </button>
              </div>

              {addresses.length === 0 ? (
                <p style={{ color: "#666", fontSize: "0.9rem", textAlign: "center" }}>No saved addresses. Please add one.</p>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                  {addresses.map((addr) => (
                    <label
                      key={addr.id}
                      style={{
                        display: "flex",
                        alignItems: "flex-start",
                        gap: "1rem",
                        padding: "1rem",
                        border: "2px solid",
                        borderColor: selectedAddressId === addr.id ? "#7A6E54" : "#e5e7eb",
                        borderRadius: "12px",
                        cursor: "pointer",
                        backgroundColor: selectedAddressId === addr.id ? "#f8fafc" : "white",
                        position: "relative",
                      }}
                    >
                      <input
                        type="radio"
                        name="address"
                        checked={selectedAddressId === addr.id}
                        onChange={() => setSelectedAddressId(addr.id)}
                        style={{ accentColor: "#7A6E54", marginTop: "0.3rem" }}
                      />
                      <div style={{ flex: 1 }}>
                        <p style={{ fontWeight: "600", marginBottom: "0.3rem" }}>
                          {addr.full_name} ({addr.address_type})
                        </p>
                        <p style={{ fontSize: "0.85rem", color: "#555", lineHeight: "1.4" }}>
                          {addr.building}, {addr.street_address}, {addr.city}, {addr.state} - {addr.postal_code}
                          <br />
                          Phone: {addr.phone}
                        </p>
                      </div>
                      <div style={{ display: "flex", gap: "0.5rem", alignSelf: "center" }}>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            openEdit(addr);
                          }}
                          style={{ padding: "0.4rem", background: "none", border: "none", cursor: "pointer" }}
                        >
                          <Edit size={18} color="#7A6E54" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteAddress(addr.id);
                          }}
                          style={{ padding: "0.4rem", background: "none", border: "none", cursor: "pointer" }}
                        >
                          <Trash2 size={18} color="#dc2626" />
                        </button>
                      </div>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Selected Address Summary */}
            {selectedAddress ? (
              <div style={{ backgroundColor: "#f0fdf4", border: "1px solid #86efac", borderRadius: "12px", padding: "1rem", color: "#166534" }}>
                <strong>Delivering to:</strong> {selectedAddress.full_name}, {selectedAddress.building}, {selectedAddress.street_address}, {selectedAddress.city}, {selectedAddress.state} - {selectedAddress.postal_code}
              </div>
            ) : addresses.length > 0 ? (
              <div style={{ padding: "1rem", color: "#999", fontStyle: "italic", textAlign: "center" }}>
                Please select a delivery address
              </div>
            ) : null}

            <button
              onClick={handlePlaceOrder}
              style={{
                width: "100%",
                padding: "1rem",
                backgroundColor: "#7A6E54",
                color: "white",
                fontSize: "0.95rem",
                fontWeight: "600",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer",
              }}
            >
              <Lock size={18} style={{ display: "inline", marginRight: "0.5rem" }} />
              Place Order Securely
            </button>
          </div>

          {/* Right: Order Summary */}
          <div>
            <div style={{ backgroundColor: "#CFD9E2", color: "#3F4754", borderRadius: "12px", padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", position: "sticky", top: "2rem" }}>
              <h3 style={{ fontSize: "0.95rem", fontWeight: "600", marginBottom: "1.5rem" }}>
                Order Summary ({cart.length} items)
              </h3>
              <div style={{ maxHeight: "400px", overflowY: "auto", marginBottom: "1.5rem", paddingBottom: "1.5rem", borderBottom: "1px solid rgba(0,0,0,0.1)" }}>
                {cart.map((item) => (
                  <div key={item.id} style={{ display: "flex", gap: "1rem", marginBottom: "1.2rem" }}>
                    <div style={{ width: "70px", height: "70px", borderRadius: "8px", overflow: "hidden", backgroundColor: "white" }}>
                      <img
                        src={item.images?.[0] ? `${axiosInstance.defaults.baseURL}${item.images[0]}` : "/placeholder.jpg"}
                        alt={item.title}
                        style={{ width: "100%", height: "100%", objectFit: "cover" }}
                      />
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{ fontSize: "0.8rem", fontWeight: "600", margin: "0 0 0.3rem 0" }}>{item.title}</p>
                      <p style={{ fontSize: "0.75rem", color: "#666" }}>Qty: {item.quantity}</p>
                      <p style={{ fontSize: "0.8rem", fontWeight: "600", color: "#7A6E54" }}>₹{item.item_total.toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "0.8rem", padding: "1rem 0", borderTop: "1px solid rgba(0,0,0,0.1)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem" }}>
                  <span>Subtotal (MRP)</span>
                  <span style={{ fontWeight: "600" }}>₹{summary.total_price.toFixed(2)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem" }}>
                  <span>Discount</span>
                  <span style={{ fontWeight: "600", color: "gray" }}>-₹{summary.total_discount.toFixed(2)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem" }}>
                  <span>GST</span>
                  <span style={{ fontWeight: "600" }}>₹{summary.total_gst.toFixed(2)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem" }}>
                  <span>Shipping</span>
                  <span style={{ fontWeight: "600" }}>{summary.shipping_cost > 0 ? `₹${summary.shipping_cost}` : "Free"}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "1.1rem", fontWeight: "bold", marginTop: "1rem" }}>
                  <span>Total Payable</span>
                  <span style={{ color: "#7A6E54" }}>₹{summary.payable_amount.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Render Modals */}
      {showAddModal && (
        <AddAddressModal
          onClose={() => setShowAddModal(false)}
          onSuccess={fetchAddresses}
        />
      )}

      {showEditModal && editingAddress && (
        <EditAddressModal
          address={editingAddress}
          onClose={() => setShowEditModal(false)}
          onSuccess={fetchAddresses}
        />
      )}
    </div>
  );
};

// Small input style
const smallInputStyle = {
  width: "100%",
  padding: "0.65rem 0.8rem",
  fontSize: "0.85rem",
  border: "1px solid #d1d5db",
  borderRadius: "6px",
  marginBottom: "0.6rem",
  outline: "none",
  transition: "border-color 0.2s ease",
};

export default CheckOut;