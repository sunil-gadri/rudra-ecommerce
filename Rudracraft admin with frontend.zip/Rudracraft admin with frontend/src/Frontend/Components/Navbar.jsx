import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { setCartCount } from "../../redux/cartSlice";
import { setWishlistCount } from "../../redux/wishlistSlice";
import search from "../../Assets/Search.svg";
import login from "../../Assets/Login.svg";
import login1 from "../../Assets/Login1.svg";
import logo from "../../Assets/logo.png";
import wishlist from "../../Assets/Wishlist.svg";
import cart from "../../Assets/Cart.svg";
import Marquee from "react-fast-marquee";
import { useMediaQuery } from "@mui/material";
import { RiMenu2Fill } from "react-icons/ri";
import { NavLink } from "react-router-dom";
import SignInModal from "../Pages/SigninPage";
import SignUpModal from "../Pages/SignUpPage";
import axiosInstance from "../../utils/axios";

export const Navbar = () => {
  const [loading, setLoading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [showSignInModal, setShowSignInModal] = useState(false);
  const [showSignUpModal, setShowSignUpModal] = useState(false);

  const dispatch = useDispatch();
  const cartCount = useSelector((state) => state.cart.count);
  const wishlistCount = useSelector((state) => state.wishlist.count);

  const menuRef = useRef(null);
  const navigate = useNavigate();
  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");

  const customerId = localStorage.getItem("customerId");
  const isLoggedIn = !!localStorage.getItem("customerToken");

  // Fetch cart & wishlist count + listen for real-time updates
  useEffect(() => {
    const fetchCounts = async () => {
      if (!customerId) {
        dispatch(setCartCount(0));
        dispatch(setWishlistCount(0));
        return;
      }

      try {
        const [cartRes, wishRes] = await Promise.all([
          axiosInstance.get(`/cart/${customerId}`),
          axiosInstance.get(`/wishlist/${customerId}`)
        ]);

        const totalQty = (cartRes.data.cart || []).reduce((sum, item) => sum + item.quantity, 0);
        dispatch(setCartCount(totalQty));

        dispatch(setWishlistCount(wishRes.data.products?.length || 0));
      } catch (error) {
        console.error("Failed to fetch navbar counts:", error);
        dispatch(setCartCount(0));
        dispatch(setWishlistCount(0));
      }
    };

    fetchCounts();

    // Real-time update when cart or wishlist changes on other pages
    const handleCartUpdate = () => fetchCounts();
    const handleWishlistUpdate = () => fetchCounts();

    window.addEventListener("cartUpdated", handleCartUpdate);
    window.addEventListener("wishlistUpdated", handleWishlistUpdate);

    return () => {
      window.removeEventListener("cartUpdated", handleCartUpdate);
      window.removeEventListener("wishlistUpdated", handleWishlistUpdate);
    };
  }, [customerId, dispatch]);

  const activeStyle = { color: "#a55130" };
  const linkStyle = { color: "#89867F", textDecoration: "none" };

  const openSignIn = () => {
    if (isLoggedIn) {
      navigate("/my-profile");
    } else {
      setShowSignInModal(true);
      setShowSignUpModal(false);
    }
  };

  const openSignUp = () => {
    setShowSignUpModal(true);
    setShowSignInModal(false);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [menuOpen]);

  const handleClick = (e, url) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      navigate(url);
      setLoading(false);
    }, 1000);
  };

  const toggleMenu = () => setMenuOpen(!menuOpen);

  const overlayStyle = {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "#EEEAE8",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 9999,
    opacity: loading ? 1 : 0,
    pointerEvents: loading ? "auto" : "none",
    transition: "opacity 0.5s ease",
  };

  const loaderStyle = {
    border: "6px solid white",
    borderTop: "6px solid #87472D",
    borderRadius: "50%",
    width: "70px",
    height: "70px",
    animation: "spin 2s linear infinite",
  };

  return (
    <nav>
      {loading && (
        <div style={overlayStyle}>
          <div style={loaderStyle}></div>
          <style jsx>{`
            @keyframes spin {
              from { transform: rotate(0deg); }
              to { transform: rotate(360deg); }
            }
          `}</style>
        </div>
      )}

      <div
        style={{
          width: "100%",
          height: "7rem",
          backgroundColor: "#ffffff",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: isXs ? "2rem 1.4rem" : "2rem 4rem",
          gap: "1rem",
        }}
      >
        {isXs && (
          <RiMenu2Fill
            onClick={toggleMenu}
            style={{ fontSize: "1.5rem", color: "grey", cursor: "pointer" }}
          />
        )}

        <div style={{ display: "flex", gap: "1.5rem", display: isXs ? "none" : "flex" }}>
          <button onClick={() => alert("Search coming soon")}>
            <img src={search} alt="Search" width={18} />
          </button>

          <button onClick={openSignIn}>
            <img
              src={isLoggedIn ? login1 : login}
              alt="Profile / Sign In"
              width={18}
              style={{ cursor: "pointer" }}
            />
          </button>
        </div>

        <div style={{ fontFamily: "Lora-Medium", display: "flex", justifyContent: "center", alignItems: "center" }}>
          {isXs && <img src={logo} alt="Logo" style={{ width: "80%" }} />}

          <ul
            ref={menuRef}
            style={{
              display: isXs ? "block" : "flex",
              position: isXs ? "fixed" : "relative",
              top: isXs ? "0" : "auto",
              left: isXs ? (menuOpen ? "0" : "-200px") : "auto",
              height: isXs ? "100vh" : "auto",
              width: isXs ? "200px" : "auto",
              backgroundColor: isXs ? "white" : "transparent",
              zIndex: 20,
              padding: isXs ? "2rem" : "0",
              boxShadow: isXs ? "6px 2px 20px rgba(0,0,0,0.2)" : "none",
              listStyle: "none",
              margin: 0,
              gap: "3rem",
              alignItems: "center",
              justifyContent: "center",
              transition: "left 0.3s ease",
            }}
          >
            <NavLink to="/" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeStyle } : linkStyle)} onClick={(e) => handleClick(e, "/")}>
              HOME
            </NavLink>
            <NavLink to="/about" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeStyle } : linkStyle)} onClick={(e) => handleClick(e, "/about")}>
              ABOUT
            </NavLink>
            <NavLink to="/shop" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeStyle } : linkStyle)} onClick={(e) => handleClick(e, "/shop")}>
              SHOP
            </NavLink>
            {!isXs && <img src={logo} alt="Logo" />}
            <NavLink to="/collections" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeStyle } : linkStyle)} onClick={(e) => handleClick(e, "/collections")}>
              COLLECTIONS
            </NavLink>
            <NavLink to="/blogs" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeStyle } : linkStyle)} onClick={(e) => handleClick(e, "/blogs")}>
              BLOG
            </NavLink>
            <NavLink to="/contact-us" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeStyle } : linkStyle)} onClick={(e) => handleClick(e, "/contact-us")}>
              CONTACT US
            </NavLink>
          </ul>
        </div>

        <div style={{ display: "flex", gap: "1.5rem", alignItems: "center" }}>
          {/* Wishlist */}
          <NavLink to="/wishlist" style={{ position: "relative", display: isXs ? "none" : "block" }}>
            <img src={wishlist} alt="Wishlist" width={18} />
            {wishlistCount > 0 && (
              <span
                style={{
                  position: "absolute",
                  top: "-8px",
                  right: "-10px",
                  backgroundColor: "#ec4899",
                  color: "white",
                  borderRadius: "50%",
                  width: "18px",
                  height: "18px",
                  fontSize: "12px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {wishlistCount}
              </span>
            )}
          </NavLink>

          {isXs && <img src={search} alt="Search" width={18} onClick={() => alert("Search coming soon")} style={{ cursor: "pointer" }} />}

          {/* Cart */}
          <NavLink to="/cart" style={{ position: "relative" }}>
            <img src={cart} alt="Cart" width={16} />
            {cartCount > 0 && (
              <span
                style={{
                  position: "absolute",
                  top: "-8px",
                  right: "-10px",
                  backgroundColor: "#a91e28",
                  color: "white",
                  borderRadius: "50%",
                  width: "18px",
                  height: "18px",
                  fontSize: "12px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {cartCount}
              </span>
            )}
          </NavLink>
        </div>
      </div>

      <div style={{ width: "100%", height: "2.4rem", backgroundColor: "#a91e28", color: "white", display: "flex", alignItems: "center", fontSize: ".9rem" }}>
        <Marquee>
          <div style={{ display: "flex", gap: "5rem" }}>
            <span>"Limited Edition Festive Shawls – Now on Sale!"</span>
            <span>"Limited Edition Festive Shawls – Now on Sale!"</span>
            <span>"Limited Edition Festive Shawls – Now on Sale!"</span>
          </div>
        </Marquee>
      </div>

      <SignInModal isOpen={showSignInModal} onClose={() => setShowSignInModal(false)} onOpenSignUp={openSignUp} />
      <SignUpModal isOpen={showSignUpModal} onClose={() => setShowSignUpModal(false)} onOpenSignIn={openSignIn} />
    </nav>
  );
};

export default Navbar;