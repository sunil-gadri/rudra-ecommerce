import React, { useState, useEffect } from "react";
import img9 from "../../Assets/img-9.jpg";
import { TfiWrite } from "react-icons/tfi";
import { RiDeleteBinLine } from "react-icons/ri";
import { MdKeyboardArrowRight } from "react-icons/md";
import { useMediaQuery } from "@mui/material";
import { ShoppingBag } from "lucide-react";
import SignInModal from "../../Frontend/Pages/SigninPage";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../utils/axios";

export const Cart = () => {
  const [cartData, setCartData] = useState(null); // { cart: [], summary: {} }
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState(null);
  const [isSignInOpen, setIsSignInOpen] = useState(false);

  const isXs = useMediaQuery("(min-width:0px) and (max-width:900px)");
  const navigate = useNavigate();

  const customerId = localStorage.getItem("customerId");
  const isLoggedIn = !!localStorage.getItem("customerToken");

  // Fetch full cart with summary
  const fetchCart = async () => {
    if (!isLoggedIn || !customerId) {
      setCartData(null);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const response = await axiosInstance.get(`/cart/${customerId}`);
      setCartData(response.data);
      // Navbar update के लिए event dispatch
      window.dispatchEvent(new Event("cartUpdated"));
    } catch (error) {
      console.error("Failed to load cart:", error);
      setCartData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCart();
  }, [isLoggedIn, customerId]);

  // Refresh cart after any change (for auto total update)
  const refreshCart = async () => {
    try {
      const response = await axiosInstance.get(`/cart/${customerId}`);
      setCartData(response.data);
      window.dispatchEvent(new Event("cartUpdated"));
    } catch (error) {
      console.error("Refresh failed:", error);
    }
  };

  // Increment quantity (only product_id)
  const incrementQuantity = async (productId) => {
    setUpdatingId(productId);
    const formData = new FormData();
    formData.append("product_id", productId);

    try {
      await axiosInstance.post(`/cart/${customerId}/increment`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      await refreshCart();
    } catch (error) {
      alert("Failed to update quantity");
    } finally {
      setUpdatingId(null);
    }
  };

  // Decrement quantity (only product_id)
  const decrementQuantity = async (productId) => {
    setUpdatingId(productId);
    const formData = new FormData();
    formData.append("product_id", productId);

    try {
      await axiosInstance.post(`/cart/${customerId}/decrement`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      await refreshCart();
    } catch (error) {
      alert("Failed to update quantity");
    } finally {
      setUpdatingId(null);
    }
  };

  // Remove item
  const removeFromCart = async (productId) => {
    setUpdatingId(productId);
    try {
      await axiosInstance.delete(`/cart/${customerId}/product/${productId}`);
      await refreshCart();
    } catch (error) {
      alert("Failed to remove item");
    } finally {
      setUpdatingId(null);
    }
  };

  const handleCheckoutClick = () => {
    if (isLoggedIn) {
      navigate("/checkout");
    } else {
      setIsSignInOpen(true);
    }
  };

  // Loading
  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="w-14 h-14 border-8 border-gray-300 border-t-black rounded-full animate-spin"></div>
      </div>
    );
  }

  // Not logged in
  if (!isLoggedIn) {
    return (
      <div style={{ textAlign: "center", padding: "4rem", backgroundColor: "#CFD9E2", minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <ShoppingBag size={80} style={{ color: "#FFFFFF", marginBottom: "2rem" }} />
        <h2 style={{ fontSize: "1.5rem", color: "#7A6E54", fontWeight: "600" }}>Please log in to view your cart</h2>
        <button onClick={() => setIsSignInOpen(true)} style={{ marginTop: "1rem", backgroundColor: "#7A6E54", color: "white", padding: "0.8rem 1.5rem", borderRadius: "8px", fontWeight: "600" }}>
          Sign In
        </button>
      </div>
    );
  }

  // Empty cart
  if (!cartData || cartData.cart.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: "4rem", backgroundColor: "#CFD9E2", minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <ShoppingBag size={80} style={{ color: "#FFFFFF", marginBottom: "2rem" }} />
        <h2 style={{ fontSize: "1.5rem", color: "#7A6E54", fontWeight: "600", marginBottom: "1rem" }}>Your cart is empty</h2>
        <p style={{ fontSize: "0.85rem", color: "#7A6E54", marginBottom: "2rem" }}>Add some items to get started</p>
        <a href="/shop">
          <button style={{ backgroundColor: "#7A6E54", color: "white", padding: "0.8rem 1.5rem", fontSize: "0.9rem", fontWeight: "600", border: "none", borderRadius: "8px", cursor: "pointer", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}>
            Continue Shopping
          </button>
        </a>
      </div>
    );
  }

  const { cart, summary } = cartData;

  return (
    <>
      <div style={{ backgroundColor: "#FFFFFF", minHeight: "100vh" }}>
        {/* Header */}
        <div style={{ width: "100%", backgroundColor: "#CFD9E2", display: "flex", alignItems: "center", justifyContent: "center", padding: "3rem 1rem", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
            <h1 style={{ fontWeight: "400", color: "black", fontSize: "2.5rem", marginBottom: "1rem" }}>Your Shopping Cart</h1>
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "0.5rem", color: "black", fontSize: "1rem" }}>
              <a style={{ color: "black", textDecoration: "none" }} href="/">Home</a>
              <MdKeyboardArrowRight size={20} />
              <span>Your Shopping Cart</span>
            </div>
          </div>
        </div>

        <div style={{ padding: isXs ? "1.5rem 1rem" : "2rem 2rem", maxWidth: "1280px", margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: isXs ? "1fr" : "2fr 1fr", gap: "2rem" }}>
            {/* Left: Items & Notes */}
            <div>
              {/* Order Summary Box */}
              <div style={{ backgroundColor: "white", borderRadius: "12px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", overflow: "hidden" }}>
                <div style={{ padding: "1.2rem", backgroundColor: "#7A6E54", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <h3 style={{ fontSize: "0.95rem", fontWeight: "600", color: "#FFFFFF", margin: 0 }}>Order Summary</h3>
                  <span style={{ backgroundColor: "#FFFFFF", color: "#7A6E54", padding: "0.4rem 0.8rem", borderRadius: "20px", fontSize: "0.8rem", fontWeight: "bold" }}>
                    {cart.length} items
                  </span>
                </div>

                <div style={{ borderTop: "1px solid #e5e7eb" }}>
                  {cart.map((item) => (
                    <div
                      key={item.id}
                      style={{
                        padding: "1.2rem",
                        borderBottom: "1px solid #CFD9E2",
                        transition: "background-color 0.3s ease",
                        backgroundColor: "#FFFFFF",
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#f5f5f5")}
                      onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#FFFFFF")}
                    >
                      <div style={{ display: "flex", gap: "1rem", flexDirection: isXs ? "column" : "row", alignItems: isXs ? "flex-start" : "center" }}>
                        <div style={{ width: isXs ? "100%" : "80px", height: "80px", borderRadius: "8px", overflow: "hidden", backgroundColor: "#CFD9E2", flexShrink: 0 }}>
                          <img
                            src={item.images?.[0] ? `${axiosInstance.defaults.baseURL}${item.images[0]}` : img9}
                            alt={item.title}
                            style={{ width: "100%", height: "100%", objectFit: "cover" }}
                          />
                        </div>

                        <div style={{ flex: 1 }}>
                          <h4 style={{ fontSize: "0.9rem", fontWeight: "600", color: "#7A6E54", margin: "0 0 0.3rem 0" }}>
                            {item.title}
                          </h4>
                          <p style={{ fontSize: "1rem", fontWeight: "bold", color: "#7A6E54", margin: 0 }}>
                            ₹{item.discounted_price.toFixed(2)}
                          </p>
                        </div>

                        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", backgroundColor: "#f3f4f6", borderRadius: "8px", padding: "0.5rem" }}>
                          <button
                            onClick={() => decrementQuantity(item.id)}
                            disabled={updatingId === item.id}
                            style={{ width: "28px", height: "28px", borderRadius: "6px", backgroundColor: "white", border: "1px solid #d1d5db", cursor: "pointer" }}
                          >
                            -
                          </button>
                          <span style={{ width: "28px", textAlign: "center", fontWeight: "600", color: "#3F4754", fontSize: "0.8rem" }}>
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => incrementQuantity(item.id)}
                            disabled={updatingId === item.id}
                            style={{ width: "28px", height: "28px", borderRadius: "6px", backgroundColor: "white", border: "1px solid #d1d5db", cursor: "pointer" }}
                          >
                            +
                          </button>
                        </div>

                        {!isXs && (
                          <div style={{ textAlign: "right", minWidth: "120px" }}>
                            <p style={{ fontSize: "0.7rem", color: "#7A8FA3", margin: "0 0 0.2rem 0" }}>Subtotal</p>
                            <p style={{ fontSize: "0.95rem", fontWeight: "bold", color: "#3F4754", margin: 0 }}>
                              ₹{item.item_total.toFixed(2)}
                            </p>
                          </div>
                        )}

                        <button
                          onClick={() => removeFromCart(item.id)}
                          disabled={updatingId === item.id}
                          style={{
                            backgroundColor: "transparent",
                            border: "none",
                            color: "#dc2626",
                            cursor: "pointer",
                            padding: "0.5rem",
                            borderRadius: "6px",
                            transition: "all 0.2s ease",
                          }}
                          onMouseEnter={(e) => (e.target.style.backgroundColor = "#fee2e2")}
                          onMouseLeave={(e) => (e.target.style.backgroundColor = "transparent")}
                        >
                          <RiDeleteBinLine size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Continue Shopping */}
                <div style={{ padding: "1.2rem", backgroundColor: "#f9fafb", borderTop: "1px solid #e5e7eb" }}>
                  <a href="/shop" style={{ textDecoration: "none" }}>
                    <button
                      style={{
                        width: "100%",
                        backgroundColor: "#f3f4f6",
                        border: "none",
                        color: "#3F4754",
                        fontWeight: "600",
                        padding: "0.65rem",
                        borderRadius: "8px",
                        cursor: "pointer",
                        transition: "all 0.2s ease",
                        fontSize: "0.9rem",
                      }}
                      onMouseEnter={(e) => (e.target.style.backgroundColor = "#e5e7eb")}
                      onMouseLeave={(e) => (e.target.style.backgroundColor = "#f3f4f6")}
                    >
                      ← Continue Shopping
                    </button>
                  </a>
                </div>
              </div>

              {/* Order Notes */}
              <div style={{ marginTop: "1.5rem", backgroundColor: "white", borderRadius: "12px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", padding: "1.2rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem" }}>
                  <TfiWrite size={18} style={{ color: "#7A6E54" }} />
                  <h4 style={{ fontSize: "0.9rem", fontWeight: "600", color: "#3F4754", margin: 0 }}>Order Notes</h4>
                </div>
                <textarea
                  placeholder="Add any special requests or notes here..."
                  style={{
                    width: "100%",
                    height: "100px",
                    padding: "0.8rem",
                    border: "2px solid #e5e7eb",
                    borderRadius: "8px",
                    fontSize: "0.85rem",
                    fontFamily: "inherit",
                    resize: "none",
                    transition: "border-color 0.2s ease",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "#7A6E54")}
                  onBlur={(e) => (e.target.style.borderColor = "#e5e7eb")}
                />
              </div>
            </div>

            {/* Right: Order Summary Sidebar */}
            <div>
              <div style={{ backgroundColor: "#3F4754", color: "white", borderRadius: "12px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", padding: "1.5rem", position: isXs ? "relative" : "sticky", top: isXs ? "auto" : "2rem" }}>
                <h3 style={{ fontSize: "1.1rem", fontWeight: "600", margin: "0 0 1.5rem 0" }}>Order Total</h3>

                <div style={{ display: "flex", flexDirection: "column", gap: "0.8rem", marginBottom: "1.5rem", paddingBottom: "1.5rem", borderBottom: "1px solid rgba(255,255,255,0.2)" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", color: "#d1d5db" }}>
                    <span>Total Price</span>
                    <span style={{ fontWeight: "600" }}>₹{summary.total_price.toFixed(2)}</span>
                  </div>

                   <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", color: "#d1d5db" }}>
                    <span>Tax</span>
                    <span style={{ fontWeight: "600" }}>₹{summary.total_gst.toFixed(2)}</span>
                  </div>

                   <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", color: "#d1d5db" }}>
                    <span>Total Discount</span>
                    <span style={{ fontWeight: "600" }}>₹{summary.total_discount.toFixed(2)}</span>
                  </div>

                   <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", color: "#d1d5db" }}>
                    <span>Shipping Cost</span>
                    <span style={{ fontWeight: "600" }}>₹{summary.shipping_cost.toFixed(2)}</span>
                  </div>


                  
                  
                </div>

                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem", paddingBottom: "1.5rem", borderBottom: "1px solid rgba(255,255,255,0.2)" }}>
                  <span style={{ fontSize: "0.95rem", fontWeight: "600" }}>Total</span>
                  <span style={{ fontSize: "1.4rem", fontWeight: "bold" }}>₹{summary.payable_amount.toFixed(2)}</span>
                </div>

                <button
                  onClick={handleCheckoutClick}
                  style={{
                    width: "100%",
                    backgroundColor: "#7A6E54",
                    color: "white",
                    fontWeight: "600",
                    padding: "0.75rem",
                    borderRadius: "8px",
                    border: "none",
                    cursor: "pointer",
                    fontSize: "0.9rem",
                    marginBottom: "0.6rem",
                    transition: "all 0.2s ease",
                  }}
                  onMouseEnter={(e) => (e.target.style.backgroundColor = "#6b5c47")}
                  onMouseLeave={(e) => (e.target.style.backgroundColor = "#7A6E54")}
                >
                  Check Out
                </button>

                <button
                  style={{
                    width: "100%",
                    border: "2px solid #7A6E54",
                    color: "#7A6E54",
                    backgroundColor: "transparent",
                    fontWeight: "600",
                    padding: "0.65rem",
                    borderRadius: "8px",
                    cursor: "pointer",
                    fontSize: "0.9rem",
                    transition: "all 0.2s ease",
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.backgroundColor = "#7A6E54";
                    e.target.style.color = "white";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.backgroundColor = "transparent";
                    e.target.style.color = "#7A6E54";
                  }}
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <SignInModal isOpen={isSignInOpen} onClose={() => setIsSignInOpen(false)} onOpenSignUp={() => setIsSignInOpen(false)} />
    </>
  );
};

export default Cart;