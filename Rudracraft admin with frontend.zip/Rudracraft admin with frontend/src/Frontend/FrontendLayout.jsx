// import Navbar from "./components/Navbar";
import { Outlet } from "react-router-dom";
import Footer from "./Components/Footer";
import { Navbar } from "./Components/Navbar";

export default function FrontendLayout() {
  return (
    <div className="">
      <Navbar />

      <main className="">
        <Outlet />
      </main>

      <Footer />
    </div>
  );
}
