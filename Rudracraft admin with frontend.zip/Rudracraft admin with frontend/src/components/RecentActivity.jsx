import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const recentActivities = [
  {
    id: "1",
    user: {
      name: "Sarah Johnson",
      email: "sarah@example.com",
    },
    action: "Created new order",
    target: "#ORD-2024-001",
    timestamp: "2 minutes ago",
    status: "success",
  },
  {
    id: "2",
    user: {
      name: "Mike Chen",
      email: "mike@example.com",
    },
    action: "Updated product",
    target: "Premium Headphones",
    timestamp: "5 minutes ago",
    status: "info",
  },
  {
    id: "3",
    user: {
      name: "Emily Davis",
      email: "emily@example.com",
    },
    action: "Payment processed",
    target: "$2,350.00",
    timestamp: "8 minutes ago",
    status: "success",
  },
  {
    id: "4",
    user: {
      name: "Alex Rivera",
      email: "alex@example.com",
    },
    action: "Inventory low",
    target: "Smartphone Case",
    timestamp: "12 minutes ago",
    status: "warning",
  },
  {
    id: "5",
    user: {
      name: "Lisa Thompson",
      email: "lisa@example.com",
    },
    action: "New user registered",
    target: "Premium Plan",
    timestamp: "15 minutes ago",
    status: "info",
  },
];

function getStatusBadge(status) {
  switch (status) {
    case "success":
      return <Badge className="bg-success text-success-foreground">Success</Badge>;
    case "warning":
      return <Badge className="bg-warning text-warning-foreground">Warning</Badge>;
    case "info":
      return <Badge className="bg-info text-info-foreground">Info</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
}

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentActivities.map((activity) => (
            <div
              key={activity.id}
              className="flex items-center space-x-4 p-3 rounded-lg hover:bg-muted/50 transition-colors"
            >
              <Avatar className="h-10 w-10">
                <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
                <AvatarFallback>
                  {activity.user.name.split(" ").map(n => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium leading-none">
                    {activity.user.name}
                  </p>
                  {getStatusBadge(activity.status)}
                </div>
                <p className="text-sm text-muted-foreground">
                  {activity.action} <span className="font-medium">{activity.target}</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  {activity.timestamp}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}