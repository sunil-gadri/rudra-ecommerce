import { Navigate, Outlet } from "react-router-dom";

export default function CustomerProtectedRoute() {
  const token = localStorage.getItem("customerToken");

  if (!token) {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
}