import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  Package,
  ShoppingCart,
  CreditCard,
  BarChart3,
  Settings,
  UserCheck,
  Layers,
  TrendingUp,
  FileText,
  Megaphone,
  BadgePercent,
  Slack,
  Codesandbox,
  ChevronDown,
  ChevronUp,
  TicketPercent
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: "/admin/dashboard",
    icon: LayoutDashboard,
    group: "Overview",
  },
  {
    title: "Customers",
    url: "/admin/customers",
    icon: UserCheck,
    group: "Management",
  },
  {
    title: "Products",
    icon: Package,
    group: "Management",
    children: [
      { title: "All Products", url: "/admin/products" },
      { title: "Create Product", url: "/admin/products/create" },
    ],
  },
  {
    title: "Parent Categories",
    url: "/admin/parent_categories",
    icon: Layers,
    group: "Management",
  },
  {
    title: "Categories",
    url: "/admin/categories",
    icon: Layers,
    group: "Management",
  },
  {
    title: "Sliders & Banners",
    url: "/admin/ads",
    icon: Megaphone,
    group: "Management",
  },
  {
    title: "Offers",
    icon: BadgePercent,
    group: "Commerce",
    children: [
      { title: "All Offers", url: "/admin/offers" },
      { title: "Create Offer", url: "/admin/offers/create" },
    ],
  },
  {
    title: "Coupon",
    icon: TicketPercent,
    group: "Commerce",
    children: [
      { title: "All Coupon", url: "/admin/coupon" },
      { title: "Create Coupon", url: "/admin/coupon/create" },
    ],
  },
  {
    title: "Orders",
    url: "/admin/orders",
    icon: ShoppingCart,
    group: "Commerce",
  },
  {
    title: "Payments",
    url: "/admin/payments",
    icon: CreditCard,
    group: "Commerce",
  },
  {
    title: "Invoice",
    url: "/admin/invoice",
    icon: FileText,
    group: "Commerce",
  },
  {
    title: "Manage Masters",
    icon: Package,
    group: "Masters",
    children: [
      { title: "Size", url: "/admin/masters-size" },
      { title: "Color", url: "/admin/masters-color" },
      { title: "Pattern", url: "/admin/masters-pattern" },
      { title: "GST", url: "/admin/masters-gst" },
      { title: "Specification", url: "/admin/masters-specifications" },
      { title: "Specification Heading", url: "/admin/masters-specification-heading" },
    ],
  },
  {
    title: "Manage Manufacturer",
    url: "/admin/manufacturers",
    icon: Codesandbox,
    group: "Manufacturers",
  },
  {
    title: "Manage Brand",
    url: "/admin/brands",
    icon: Slack,
    group: "Brand",
  },
  {
    title: "Settings",
    url: "/admin/settings",
    icon: Settings,
    group: "System",
  },
];

export function AdminSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const currentPath = location.pathname;
  const collapsed = state === "collapsed";

  const [openMenus, setOpenMenus] = useState({});

  const toggleMenu = (title) => {
    setOpenMenus((prev) => ({ ...prev, [title]: !prev[title] }));
  };

  const isActive = (path) => currentPath === path;
  const getNavClasses = (path) =>
    isActive(path)
      ? "bg-primary text-primary-foreground font-medium shadow-sm"
      : "hover:bg-accent hover:text-accent-foreground transition-colors";

  const groupedItems = navigationItems.reduce((acc, item) => {
    if (!acc[item.group]) acc[item.group] = [];
    acc[item.group].push(item);
    return acc;
  }, {});

  return (
    <Sidebar className="border-r bg-card h-full" collapsible="icon">
      <SidebarContent className="p-0">
        <div className="mb-0 flex items-center gap-1 p-4">
          <div className="w-8 h-8 bg-gradient-to-br from-primary to-purple-600 rounded-lg flex items-center justify-center">
            <BarChart3 className="h-5 w-5 text-white" />
          </div>
          {!collapsed && (
            <div>
              <h1 className="text-lg font-bold text-foreground">AdminPanel</h1>
              <p className="text-xs text-muted-foreground">Management System</p>
            </div>
          )}
        </div>

        {Object.entries(groupedItems).map(([group, items]) => (
          <SidebarGroup key={group} className="mb-0">
            {!collapsed && (
              <SidebarGroupLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-0 px-4">
                {group}
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu className="space-y-0">
                {items.map((item) => {
                  const hasChildren = !!item.children;
                  const isOpen = openMenus[item.title];

                  return (
                    <SidebarMenuItem key={item.title}>
                      {hasChildren ? (
                        <SidebarMenuButton
                          onClick={() => !collapsed && toggleMenu(item.title)}
                          className={`flex items-center justify-between px-2 py-0.5 rounded-lg transition-all duration-200 ${getNavClasses(
                            item.url || ""
                          )}`}
                        >
                          <div className="flex items-center gap-3">
                            <item.icon className="h-5 w-5 flex-shrink-0" />
                            {!collapsed && (
                              <span className="font-medium">{item.title}</span>
                            )}
                          </div>
                          {!collapsed && (
                            <div className={`transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}>
                              {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                            </div>
                          )}
                        </SidebarMenuButton>
                      ) : (
                        <SidebarMenuButton asChild>
                          <NavLink
                            to={item.url}
                            className={`flex items-center gap-3 px-3 py-1 rounded-lg transition-all duration-200 ${getNavClasses(
                              item.url
                            )}`}
                          >
                            <item.icon className="h-5 w-5 flex-shrink-0" />
                            {!collapsed && <span className="font-medium">{item.title}</span>}
                          </NavLink>
                        </SidebarMenuButton>
                      )}

                      {/* Submenu */}
                      {hasChildren && !collapsed && isOpen && (
                        <div className="ml-8 mt-0 space-y-0">
                          {item.children.map((subItem) => (
                            <NavLink
                              key={subItem.title}
                              to={subItem.url}
                              className={`block px-3 py-1 text-sm font-medium rounded-md ${getNavClasses(subItem.url)}`}
                            >
                              {subItem.title}
                            </NavLink>
                          ))}
                        </div>
                      )}
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
    </Sidebar>
  );
}