import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, MoreHorizontal, Package, DollarSign, TrendingUp, AlertTriangle, Plus, Edit, Trash2, Filter } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import axiosInstance from "../utils/axios";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";


export default function Products() {
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [categories, setCategories] = useState([]);
  const [parentCategories, setParentCategories] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [brands, setBrands] = useState([]);
  const [colorOptions, setColorOptions] = useState([]);
  const [patternOptions, setPatternOptions] = useState([]);
  const [colorNameById, setColorNameById] = useState({});
  const [patternNameById, setPatternNameById] = useState({});
  const [imageViewerOpen, setImageViewerOpen] = useState(false);
  const [imageViewerImages, setImageViewerImages] = useState([]);
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedParents, setSelectedParents] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedManufacturers, setSelectedManufacturers] = useState([]);
  const [selectedBrands, setSelectedBrands] = useState([]);
  const navigate = useNavigate();
  const { toast } = useToast();
  const IMAGE_BASE_URL = "http://192.168.0.9:5000";

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await axiosInstance.get("/products");
        const productsData = Array.isArray(res.data) ? res.data : [];
        setProducts(productsData);
      } catch (error) {
        console.error("Failed to fetch products:", error);
        toast({
          title: "Error",
          description: "Failed to fetch products.",
          variant: "destructive",
        });
      }
    };
    fetchProducts();
  }, []);

  const [unitOptions, setUnitOptions] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [parentRes, catRes, manRes, brandRes, colorsRes, patternsRes, sizesRes] =
          await Promise.all([
            axiosInstance.get("/parent-categories"),
            axiosInstance.get("/categories"),
            axiosInstance.get("/manufacturer"),
            axiosInstance.get("/brands"),
            axiosInstance.get("/product_colors"),
            axiosInstance.get("/product_pattern"),
            axiosInstance.get("/product_sizes"),
          ]);

        setParentCategories(Array.isArray(parentRes.data) ? parentRes.data : []);
        setCategories(Array.isArray(catRes.data) ? catRes.data : []);
        setManufacturers(Array.isArray(manRes.data) ? manRes.data : []);
        setBrands(Array.isArray(brandRes.data) ? brandRes.data : []);

        const colors = (Array.isArray(colorsRes.data) ? colorsRes.data : []).map(
          (it) => ({
            id: String(it.id ?? it._id ?? it.color_id ?? ""),
            name: String(it.color_name ?? it.name ?? it.label ?? it.color ?? ""),
          })
        );
        setColorOptions(colors);
        setColorNameById(
          colors.reduce((acc, c) => ({ ...acc, [c.id]: c.name }), {})
        );

        const patterns = (Array.isArray(patternsRes.data)
          ? patternsRes.data
          : []
        ).map((it) => ({
          id: String(it.id ?? it._id ?? ""),
          name: String(it.pattern ?? it.name ?? it.label ?? it.value ?? ""),
        }));
        setPatternOptions(patterns);
        setPatternNameById(
          patterns.reduce((acc, p) => ({ ...acc, [p.id]: p.name }), {})
        );

        const units = (Array.isArray(sizesRes.data) ? sizesRes.data : []).map(
          (it) => ({
            id: String(it.id ?? it._id ?? it.size_id ?? ""),
            name: String(it.unit ?? it.size_name ?? it.label ?? it.value ?? ""),
          })
        );
        setUnitOptions(units);
      } catch (error) {
        console.error("Failed to fetch dropdown data:", error);
        toast({
          title: "Error",
          description: "Failed to fetch dropdown data.",
          variant: "destructive",
        });
      }
    };
    fetchData();
  }, []);

  // Helper functions
  const stripHtml = (html) => {
    if (!html) return "";
    const el = document.createElement("div");
    el.innerHTML = html;
    return el.textContent || el.innerText || "";
  };

  const splitTags = (tags) =>
    (tags || "")
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);

  const formatDimensions = (attrs) => {
    if (!attrs) return "-";
    const L = attrs.length ?? "-";
    const W = attrs.width ?? "-";
    const H = attrs.height ?? "-";
    const U = attrs.unit ?? "";
    if (L === "-" && W === "-" && H === "-") return "-";
    return `${L} × ${W} × ${H} ${U}`.trim();
  };

  const getParentCategoryNameById = (id) =>
    parentCategories.find((c) => String(c.id) === String(id))?.name ?? String(id);

  const getCategoryNameById = (id) =>
    categories.find((c) => String(c.id) === String(id))?.name ?? String(id);

  const getColorNameById = (id) =>
    colorNameById[String(id)] ?? String(id) ?? "";

  const getPatternNameById = (id) =>
    patternNameById[String(id)] ?? String(id) ?? "";

  const toggleParent = (id) => {
    const strId = String(id);
    setSelectedParents((prev) =>
      prev.includes(strId) ? prev.filter((p) => p !== strId) : [...prev, strId]
    );
  };

  const toggleCategory = (id) => {
    const strId = String(id);
    setSelectedCategories((prev) =>
      prev.includes(strId) ? prev.filter((c) => c !== strId) : [...prev, strId]
    );
  };

  const toggleManufacturer = (name) => {
    setSelectedManufacturers((prev) =>
      prev.includes(name) ? prev.filter((m) => m !== name) : [...prev, name]
    );
  };

  const toggleBrand = (name) => {
    setSelectedBrands((prev) =>
      prev.includes(name) ? prev.filter((b) => b !== name) : [...prev, name]
    );
  };

  const filteredProducts = products.filter((product) => {
    const id = (product.id || "").toString().toLowerCase();
    const title = (product.title || "").toString().toLowerCase();
    const tags = (product.tags || "").toString().toLowerCase();
    const desc = (product.description || "").toString().toLowerCase();

    const matchesSearch =
      id.includes(searchTerm.toLowerCase()) ||
      title.includes(searchTerm.toLowerCase()) ||
      tags.includes(searchTerm.toLowerCase()) ||
      desc.includes(searchTerm.toLowerCase());

    const matchesParent =
      selectedParents.length === 0 ||
      selectedParents.includes(String(product.parent_category));
    const matchesCategory =
      selectedCategories.length === 0 ||
      selectedCategories.includes(String(product.product_category));
    const matchesManufacturer =
      selectedManufacturers.length === 0 ||
      selectedManufacturers.includes(product.general_info?.manufacturer_name);
    const matchesBrand =
      selectedBrands.length === 0 ||
      selectedBrands.includes(product.general_info?.manufacturer_brand);

    return (
      matchesSearch &&
      matchesParent &&
      matchesCategory &&
      matchesManufacturer &&
      matchesBrand
    );
  });

  const handleAddProduct = () => {
    navigate("/products/create");
  };

  const handleEditProduct = (product) => {
    const id = product.id ?? product._id;
    navigate(`/products/edit/${id}`);
  };

  const handleDeleteProduct = async (productId) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this product?"
    );
    if (!confirmDelete) return;

    try {
      await axiosInstance.delete(`/products/${productId}`);
      setProducts(products.filter((product) => {
        const id = product.id ?? product._id;
        return id !== productId;
      }));
      toast({
        title: "Product deleted",
        description: "Product has been successfully deleted.",
      });
    } catch (error) {
      console.error("Failed to delete product:", error);
      toast({
        title: "Error",
        description: "Something went wrong while deleting the product.",
        variant: "destructive",
      });
    }
  };

  const totalProducts = products.length;
  const totalValue = products.reduce((sum, p) => {
    const price = parseFloat(p.general_info?.price ?? 0);
    const stock = parseInt(p.general_info?.stock ?? 0);
    return sum + price * stock;
  }, 0);
  const lowStockCount = products.filter((p) => {
    const stock = parseInt(p.general_info?.stock ?? 0);
    return stock < 10 && stock > 0;
  }).length;
  const outOfStockCount = products.filter((p) => {
    const stock = parseInt(p.general_info?.stock ?? 0);
    return stock === 0;
  }).length;

  const getImageUrl = (path) => {
    if (!path) return "";
    return path.startsWith("http") ? path : `${IMAGE_BASE_URL}${path}`;
  };

  const getStatusBadge = (status) => {
    if (status === "Inactive") {
      return <Badge variant="destructive">Inactive</Badge>;
    }
    return (
      <Badge variant="default" className="bg-success text-success-foreground">
        Active
      </Badge>
    );
  };

  const truncateText = (text, maxLength = 30) => {
    if (!text) return "";
    return text.length > maxLength ? text.substring(0, maxLength) + "..." : text;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Products</h1>
          <p className="text-muted-foreground">
            Manage your product inventory and catalog
          </p>
        </div>
        <Button onClick={handleAddProduct}>
          <Plus className="mr-2 h-4 w-4" />
          Add Product
        </Button>
      </div>

      <div className="w-full">
        <div className="flex flex-col gap-4 md:flex-row md:flex-wrap">
          <Card className="flex-1 min-w-full sm:min-w-[210px]">
            <div className="p-6 flex items-center w-full rounded-lg gap-3">
              <div className="flex items-center justify-center p-3 mr-4 rounded-full bg-gray-200 border">
                <Package className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-lg mb-1 font-medium text-muted-foreground">
                  Total Products
                </h6>
                <p className="text-xl font-bold leading-none">
                  {totalProducts}
                </p>
              </div>
            </div>
          </Card>

          <Card className="flex-1 min-w-full sm:min-w-[200px]">
            <div className="p-6 flex items-center w-full rounded-lg gap-3">
              <div className="flex items-center justify-center p-3 mr-4 rounded-full bg-gray-200 border">
                <DollarSign className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-lg mb-1 font-medium text-muted-foreground">
                  Inventory Value
                </h6>
                <p className="text-xl font-bold leading-none">
                  ${totalValue.toLocaleString()}
                </p>
              </div>
            </div>
          </Card>

          <Card className="flex-1 min-w-full sm:min-w-[200px]">
            <div className="p-6 flex items-center w-full rounded-lg gap-3">
              <div className="flex items-center justify-center p-3 mr-4 rounded-full bg-gray-200 border">
                <TrendingUp className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-lg mb-1 font-medium text-muted-foreground">
                  Low Stock
                </h6>
                <p className="text-xl font-bold leading-none">
                  {lowStockCount}
                </p>
              </div>
            </div>
          </Card>

          <Card className="flex-1 min-w-full sm:min-w-[200px]">
            <div className="p-6 flex items-center w-full rounded-lg gap-3">
              <div className="flex items-center justify-center p-3 mr-4 rounded-full bg-gray-200 border">
                <AlertTriangle className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <h6 className="text-lg mb-1 font-medium text-muted-foreground">
                  Out of Stock
                </h6>
                <p className="text-xl font-bold leading-none">
                  {outOfStockCount}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Products</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative w-[40%] flex items-center mb-4">
            <Input
              type="text"
              placeholder="Search by Name..."
              className="border border-gray-200 rounded px-3 py-2 w-full focus:outline-none focus:ring-1 focus:ring-purple-500 pr-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 h-8 w-8 text-lg flex items-center justify-center"
              onClick={() => setFilterOpen(true)}
            >
              <Filter className="h-4 w-4" />
            </button>
          </div>
          <div className="w-full">
            {/* Product Table Layout */}
            <div className="border rounded-md">
              {/* Scrollable Container */}
              <div className="max-h-[600px] overflow-auto"> {/* Changed to overflow-auto for both x and y */}
                <Table className="table-fixed min-w-[210%]">
                  <TableHeader className="sticky top-0 z-30 bg-gray-50">
                    <TableRow className="text-gray-700 text-center">
                      <TableHead className="text-center w-[5%] sticky left-0 bg-gray-50 z-20">Id</TableHead> {/* Keep left-0 for frozen column */}
                      <TableHead className="text-center w-[20%]">Product Title</TableHead>
                      <TableHead className="text-center w-[30%]">Description</TableHead>
                      <TableHead className="text-center w-[15%]">Parent Category</TableHead>
                      <TableHead className="text-center w-[15%]">Product Category</TableHead>
                      <TableHead className="text-center w-[15%]">Product Tags</TableHead>
                      <TableHead className="text-center w-[15%]">Product Images</TableHead>
                      <TableHead className="text-center w-[15%]">Size Dimensions</TableHead>
                      <TableHead className="text-center w-[16%]">Size Category</TableHead>
                      <TableHead className="text-center w-[18%]">Manufacturer Name</TableHead>
                      <TableHead className="text-center w-[12%]">Brand Name</TableHead>
                      <TableHead className="text-center w-[10%]">Color</TableHead>
                      <TableHead className="text-center w-[12%]">Pattern</TableHead>
                      <TableHead className="text-center w-[8%]">Stock</TableHead>
                      <TableHead className="text-center w-[8%]">Price</TableHead>
                      <TableHead className="text-center w-[8%]">Discount</TableHead>
                      <TableHead className="text-center w-[10%]">Status</TableHead>
                      <TableHead className="text-center w-[8%]">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProducts.map((product) => {
                      const id = product.id ?? product._id;
                      return (
                        <TableRow
                          key={id}
                          className="hover:bg-gray-50 transition duration-150"
                        >
                          <TableCell className="text-center align-middle font-medium text-muted-foreground w-[5%] sticky left-0 bg-white z-10"> {/* Sticky left for ID cell, assume bg-white for body */}
                            {id}
                          </TableCell>
                          <TableCell className="text-center align-middle w-[20%]">
                            <span className="font-medium text-gray-800">{product.title}</span>
                          </TableCell>
                          <TableCell className="text-center w-[30%]">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="cursor-pointer">
                                    {truncateText(stripHtml(product.description), 50)}
                                  </span>
                                </TooltipTrigger>
                                <TooltipContent className="max-w-sm whitespace-pre-wrap text-sm text-gray-800 p-4">
                                  {stripHtml(product.description)}
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </TableCell>
                          <TableCell className="text-center w-[15%]">
                            {getParentCategoryNameById(product.parent_category)}
                          </TableCell>
                          <TableCell className="text-center w-[15%]">
                            {getCategoryNameById(product.product_category)}
                          </TableCell>
                          <TableCell className="text-center w-[15%]">
                            <div className="flex flex-wrap justify-center gap-1">
                              {splitTags(product.tags).map((t, i) => (
                                <Badge key={i} variant="secondary">
                                  {t}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className="text-center w-[15%]">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setImageViewerImages(product.images || []);
                                setImageViewerOpen(true);
                              }}
                            >
                              View ({(product.images || []).length})
                            </Button>
                          </TableCell>
                          <TableCell className="text-center w-[15%]">
                            {formatDimensions(product.attributes)}
                          </TableCell>
                          <TableCell className="text-center w-[16%]">
                            {product.attributes?.size_category || "-"}
                          </TableCell>
                          <TableCell className="text-center w-[18%]">
                            {product.general_info?.manufacturer_name}
                          </TableCell>
                          <TableCell className="text-center w-[12%]">
                            {product.general_info?.manufacturer_brand}
                          </TableCell>
                          <TableCell className="text-center w-[10%]">
                            {getColorNameById(product.attributes?.color)}
                          </TableCell>
                          <TableCell className="text-center w-[12%]">
                            {getPatternNameById(product.attributes?.pattern)}
                          </TableCell>
                          <TableCell className="text-center w-[8%]">
                            {product.general_info?.stock ?? ""}
                          </TableCell>
                          <TableCell className="text-center w-[8%]">
                            ${product.general_info?.price ?? ""}
                          </TableCell>
                          <TableCell className="text-center w-[8%]">
                            {product.general_info?.discount ?? ""}
                          </TableCell>
                          <TableCell className="text-center w-[10%]">
                            {getStatusBadge(product.status)}
                          </TableCell>
                          <TableCell className="text-center w-[8%]">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() => handleEditProduct(product)}
                                  className="gap-2"
                                >
                                  <Edit className="h-4 w-4" /> Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => handleDeleteProduct(id)}
                                  className="gap-2 text-red-600"
                                >
                                  <Trash2 className="h-4 w-4" /> Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>

              <Dialog open={imageViewerOpen} onOpenChange={setImageViewerOpen}>
                <DialogContent className="max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>Product Images</DialogTitle>
                  </DialogHeader>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {(imageViewerImages?.length ? imageViewerImages : []).map((src, i) => (
                      <img
                        key={i}
                        src={getImageUrl(src)}
                        alt={`Product ${i + 1}`}
                        className="w-full h-48 object-contain rounded border"
                      />
                    ))}
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={filterOpen} onOpenChange={setFilterOpen}>
                <DialogContent className="bg-white rounded-lg shadow-xl p-6 w-[40rem]">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">Filter Products</h2>
                  <div className="max-h-[70vh] overflow-y-auto space-y-6 pr-2">
                    <div>
                      <h3 className="text-sm font-medium capitalize">parent category</h3>
                      <div className="flex flex-wrap gap-3 mt-2">
                        {parentCategories.map((cat) => (
                          <label key={cat.id} className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                              checked={selectedParents.includes(String(cat.id))}
                              onChange={() => toggleParent(cat.id)}
                            />
                            {cat.name}
                          </label>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium capitalize">product category</h3>
                      <div className="flex flex-wrap gap-3 mt-2">
                        {categories.map((cat) => (
                          <label key={cat.id} className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                              checked={selectedCategories.includes(String(cat.id))}
                              onChange={() => toggleCategory(cat.id)}
                            />
                            {cat.name}
                          </label>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium capitalize">manufacturer name</h3>
                      <div className="flex flex-wrap gap-3 mt-2">
                        {manufacturers.map((man) => (
                          <label key={man.id} className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                              checked={selectedManufacturers.includes(man.name)}
                              onChange={() => toggleManufacturer(man.name)}
                            />
                            {man.name}
                          </label>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium capitalize">brand name</h3>
                      <div className="flex flex-wrap gap-3 mt-2">
                        {brands.map((brand) => (
                          <label key={brand.id} className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                              checked={selectedBrands.includes(brand.name)}
                              onChange={() => toggleBrand(brand.name)}
                            />
                            {brand.name}
                          </label>
                        ))}
                      </div>
                    </div>
                    <div className="flex justify-end gap-3">
                      <button
                        className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300"
                        onClick={() => setFilterOpen(false)}
                      >
                        Cancel
                      </button>
                      <button
                        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                        onClick={() => setFilterOpen(false)}
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardContent>
      </Card>

    </div>
  );
}