import React from 'react'
import PersonImg from '../assets/girl2.png'
import GreenShape from '../assets/greenshap.png';

function CallUs() {
  return (
    <>
    
     <section className="bg-white mb-24 lg:mb-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">

          <div className="relative bg-gray-100 rounded-2xl px-6 sm:px-8 lg:pl-10 lg:pr-0 flex flex-col lg:flex-row items-center justify-between overflow-hidden">

            {/* CONTENT */}
            <div className="max-w-xl z-10 text-center lg:text-left py-10 lg:py-0">

              <p className="text-gray-800 font-semibold tracking-wider uppercase text-[14px] mb-5">
                GET AN APPOINTMENT
              </p>

              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-[39px] font-bold text-gray-900 leading-tight mb-4">
                Your first step <br /> toward smart planning
              </h2>

              <p className="text-gray-700 mb-8 text-sm sm:text-base">
                Connect with our financial experts to discuss your goals, explore suitable
                investment options, and create a clear path toward long-term financial security.
              </p>

              <button className="bg-black text-white px-8 py-3 rounded-lg font-semibold hover:bg-gray-900 transition">
                  <a
                    href="tel:+918826012778"
                  >
                    Call Us
                  </a> 
              </button>
            </div>

            {/* IMAGES */}
            <div className="relative w-full lg:w-1/2 flex justify-center lg:justify-end items-center mt-10 lg:mt-0 pb-10 lg:pb-0">

              <img
                src={GreenShape}
                alt="Shape"
                className="absolute right-0 top-0 w-32 sm:w-36 lg:w-46 z-0"
              />

              <img
                src={PersonImg}
                alt="Support agent"
                className="relative w-64 sm:w-72 lg:w-80 z-10"
              />

            </div>

          </div>
        </div>
      </section>
    </>
  )
}

export default CallUs