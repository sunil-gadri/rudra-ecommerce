import React from 'react'
import ManImg2 from '../assets/ManImg2.jpg';  


function OurApproach() {
  return (<>
  <section className="bg-white mb-24 lg:mb-30">
     <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-10 lg:px-20 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
       {/* LEFT IMAGE */}
       <div className="relative flex justify-center lg:block">
   
         <img
           src={ManImg2}
           alt="Business meeting"
           className="rounded-2xl w-full object-cover h-[55vh] sm:h-[65vh] md:h-[70vh] lg:h-[85vh]"
         />
   
         {/* Decorative dots */}
         <div className="absolute bottom-6 left-6 grid grid-cols-5 gap-2">
           {Array.from({ length: 25 }).map((_, i) => (
             <span
               key={i}
               className="w-1.5 h-1.5 bg-purple-400 rounded-full opacity-70"
             />
           ))}
         </div>
       </div>
   
       {/* RIGHT CONTENT */}
       <div className="text-center lg:text-left">
   
         <p className="text-gray-800 mb-4 font-semibold tracking-wider uppercase text-[14px]">
           OUR APPROACH
         </p>
   
         <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-[39px] font-bold text-gray-900 leading-tight mb-4">
   Smart strategies. <br /> Clear financial growth.    
     </h2>
   
         <p className="text-gray-600 text-[14px] mb-2 max-w-xl mx-auto lg:mx-0">
           By combining profound market understanding, bespoke financial planning, and ethical practices, we enable long-term stability and growth.
         </p>
   
         {/* LIST */}
         <div className="space-y-3">
   
           {[
             {
               title: "Defining What Matters Most to You",
               description:
                 "Listening comes first. We build every recommendation on your income, objectives, risk preferences, and long-term vision.",
             },
             {
               title: "Individually Crafted Financial Solutions",
               description:
                 "Your uniqueness inspires our approach—we build strategies that honor your goals and secure lasting growth.",
             },
             {
               title: "Decisions Guided by Insightful Research",
               description:
                 "Backed by research, driven by data, and anchored in proven principles—our advice is never speculative.",
             },
             {
               title: "Guidance Built on Trust and Transparency",
               description:
                 "We prioritize openness, delivering straightforward explanations, genuine advice, and complete clarity in every interaction.",
             },
             {
               title: "Consistent Monitoring & Personalized Assistance",
               description:
                 "With evolving markets and changing objectives, we consistently reassess and fine-tune your financial strategy for lasting alignment.",
             },
           ].map((item, index) => (
             <div
               key={index}
               className="flex items-start justify-between border-b border-gray-300 pb-2 text-left"
             >
               <div>
                 <h4 className="text-[16px] font-semibold text-gray-900 mb-2">
                   {item.title}
                 </h4>
                 <p className="text-gray-600 text-[14px] max-w-lg">
                   {item.description}
                 </p>
               </div>
             </div>
           ))}
         </div>
   
       </div>
     </div>
   </section>
  </>
  )
}

export default OurApproach;