import React, { use, useState } from "react";
import { Phone } from "lucide-react";
import Logo from "../assets/Logo.png";
import Secure from "../assets/secure.png";
import { Facebook, Instagram, Linkedin, X } from "lucide-react";
import toast, { Toaster } from "react-hot-toast"; 
import api from "../api/axios";

function Footer() {
  const currentYear = new Date().getFullYear();

const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false);


 const handleNewsletterSubmit = async (e) => {
    e.preventDefault();
    if (!email) {
      toast.error("Please enter your email");
      return;
    }

    setLoading(true);
    const formData = new FormData();
    formData.append("email", email);

    try {
      const response = await api.post("newsletter.php", formData);

      if (response.data.status === true) {
        toast.success(response.data.message || "Subscribed successfully!");
        setEmail("");
      } else {
        toast.error(response.data.message || "Something went wrong");
      }
    } catch (err) {
      console.error(err);
      toast.error("Server error, try again later");
    } finally {
      setLoading(false);
    }
  };


  return (
    <footer className="bg-black text-white rounded-tl-[40px] rounded-tr-[40px] overflow-hidden">
                    <Toaster position="top-right" />

      <div className="max-w-7xl mx-auto px-6 md:px-10 lg:px-12 py-3">


          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8 mb-6 pt-4">
          <h2 className="text-xl md:text-2xl font-bold max-w-xl">
            Sign up for our newsletter to get updates, news, and free insights.
          </h2>

          <form
            onSubmit={handleNewsletterSubmit}
            className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto lg:min-w-[400px]"
          >
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 px-6 py-3 rounded-lg bg-gray-900 text-gray-200 placeholder-gray-500 border border-gray-700 focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading}
              className={`px-8 py-3 text-black font-semibold rounded-lg transition ${
                loading ? "bg-gray-500 cursor-not-allowed" : "bg-white hover:bg-gray-200"
              }`}
            >
              {loading ? "Subscribing..." : "SIGN UP"}
            </button>
          </form>
        </div>

        <hr className="border-gray-800 mb-6" />

        {/* Footer Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6 mb-6">

          {/* Logo */}
          <div>
            <a href="./">
              <img src={Logo} alt="Money Matters Logo" className="w-40 sm:w-44 lg:w-50 mb-4" />
            </a>

            <div className="flex items-center gap-4">
<p className="w-full md:w-[200px] text-[13px] text-gray-400 leading-6 ">
                Partnering with you to protect, manage, and grow wealth through trusted expertise, customized planning, and guidance you can count on for years to come.
              </p>
            </div>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-xl font-bold mb-3 relative inline-block">
              <span className="absolute -left-4 top-0 bottom-0 w-1 bg-gray-400"></span>
              Company
            </h3>

            <ul className="space-y-1">
              <li className="w-[200px]">
                <a href="./" className="block text-[14px] text-gray-400 hover:text-white transition">
                  Home
                </a>
              </li>
              <li className="w-[200px]">
                <a href="./about" className="block text-[14px] text-gray-400 hover:text-white transition">
                  About Us
                </a>
              </li>
              <li className="w-[200px]">
                <a href="./services" className="block text-[14px] text-gray-400 hover:text-white transition">
                  Services
                </a>
              </li>
              <li className="w-[200px]">
                <a href="./products" className="block text-[14px] text-gray-400 hover:text-white transition">
                  Products
                </a>
              </li>
              <li className="w-[200px]">
                <a href="./contact" className="block text-[14px] text-gray-400 hover:text-white transition">
                  Contact Us
                </a>
              </li>
             <li className="w-[200px]">
  <a
    href="https://users.madosx.co.in"
    target="_blank"
    rel="noopener noreferrer"
    className="block text-[14px] text-gray-400 hover:text-white transition"
  >
    Portfolio Login
  </a>
</li>

            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-4 relative inline-block">
              <span className="absolute -left-4 top-0 bottom-0 w-1 bg-gray-400"></span>
              Get in Touch
            </h3>

            <div className="flex flex-col sm:flex-row lg:flex-col gap-4">

              {/* Delhi */}
              <div>
                <p className="text-gray-300 text-[14px] font-medium mb-1">
                  New Delhi Office
                </p>
                <p className="text-gray-400 text-[14px] leading-relaxed">
                  RZ-B1/48, 1st Floor, 203, White House Building, Masoodpur,
                  Vasant Kunj, New Delhi - 110070
                </p>
                <a
                  href="tel:+918826012778"
                  className="flex items-center gap-2 text-[14px] text-gray-400 hover:text-white"
                >
                  <Phone className="w-3 h-3" />
                  +91 88260 12778
                </a>
              </div>

              {/* Jaipur */}
              <div>
                <p className="text-gray-300 text-[14px] font-medium mb-1">
                  Jaipur Office
                </p>
                <p className="text-gray-400 text-[14px] leading-relaxed">
                  520, Mansarovar Plaza, Madhyam Marg, <br />
                  Mansarovar, Jaipur – 302020
                </p>
                <a
                  href="tel:+919352023049"
                  className="flex items-center gap-2 text-[14px] text-gray-400 hover:text-white"
                >
                  <Phone className="w-3 h-3" />
                  +91 93520 23049
                </a>
              </div>

            </div>
          </div>

          {/* Follow Us */}
          <div className="ml-0 lg:ml-20">
            <h3 className="text-xl font-bold mb-3 relative inline-block">
              <span className="absolute -left-4 top-0 bottom-0 w-1 bg-gray-400"></span>
              Follow Us
            </h3>

            <div>
              <div className="flex gap-4 mt-2 -ml-2">
                <a
                  href="https://www.facebook.com/Moneymatters.co.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition"
                >
                  <Facebook className="w-4 h-4" />
                </a>

                <a href="#" className="text-gray-400 hover:text-white transition">
                  <Instagram className="w-4 h-4" />
                </a>

                <a href="https://www.linkedin.com/company/moneymatters/" className="text-gray-400 hover:text-white transition">
                  <Linkedin className="w-4 h-4" />
                </a>

                <a
                  href="https://x.com/moneyma39232311"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition"
                >
                  <X className="w-4 h-4" />
                </a>
              </div>

             <img
  className="mt-6 lg:mt-10 w-24 sm:w-28 lg:w-30 mx-auto lg:mx-0 lg:-ml-5"
  src={Secure}
  alt="img"
/>
<p className="mt-4 text-gray-400 text-xs leading-relaxed text-left">
  ARN Code: 121821
  <br />
  IRDA No: ICI01317115
  <br />
  BSE Member ID: 13832
  <br />
  Member ID NSE Star MF : 1024824
</p>



            </div>
          </div>

        </div>

        <hr className="border-gray-800 mb-6" />

        {/* Disclaimer */}
<div className="grid grid-cols-1 gap-4 text-gray-500 text-xs md:text-sm">
  <div>
    <strong>Disclaimer :-</strong>
  </div>

<ul className="list-disc list-outside pl-5 space-y-2 text-gray-500 text-[12px] leading-relaxed marker:text-gray-400">
  <li>
    Mutual fund investments are subject to market risks. Please read the offer document carefully before investing. Past performance may or may not be sustained in future.
  </li>
  <li>
    Equity or equity related investments are subject to market risks, including possible loss of principal. Please read all scheme-related documents carefully before investing. Past performance is not indicative of future results. The value of investments may fluctuate due to changes in market conditions, interest rates, or other economic factors.
  </li>
  <li>
    This website, company or founders does not constitute investment advice or a recommendation. Investors should consider their specific investment objectives, financial situation, and risk tolerance before making any investment decision. Tax implications on investments may vary depending on individual circumstances; consult your tax advisor for guidance.
  </li>
  <li>
    Neither company or website nor its founders guarantee returns or assure capital protection. All information provided herein is for educational purposes only and is subject to change without notice.
  </li>
  <li>
    Alternative Investment Funds (AIFs) are regulated by the Securities and Exchange Board of India (SEBI). Investments in AIFs are subject to market risks, illiquidity, and other risks associated with unlisted securities and alternative assets. Past performance of the AIF or its manager is not indicative of future results.
  </li>
  <li>
    Units of AIFs are not listed on any stock exchange and may have limited exit options. Investors should carefully read the Private Placement Memorandum (PPM), contribution agreement, and other scheme-related documents before investing.
  </li>

    <li>
      In accordance with SEBI and AMFI guidelines, we disclose the range of commissions we may receive from various Asset Management Companies (AMCs) for the mutual fund schemes recommended/distributed by us. A detailed commission structure is available upon request. The commission received does not influence our scheme recommendations, which are based solely on product suitability and your stated financial goals.
  </li>
</ul>

</div>


        <hr className="border-gray-800 my-6" />

        {/* Copyright */}
        <div className="flex flex-col md:flex-row justify-between items-center text-gray-500 text-sm pb-2 gap-2">
          <p>© {currentYear} Money Matters. All rights reserved.</p>
          <p>Powered by Infomagine Softwares</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
