import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import Logo from '../assets/Logo.png';

function Header() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <>
      {/* Main Navbar */}
      <nav className="absolute top-0 left-0 right-0 z-50 bg-transparent">
        <div className="mx-auto px-5 sm:px-6 md:px-8 lg:px-17 py-5 md:py-6">
          <div className="flex items-center justify-between">
            {/* Logo – left side */}
            <div className="flex items-center">
              <a href="./">
              <img
                src={Logo}
                alt="Money Matters Logo"
                className="w-28 sm:w-32 md:w-36 lg:w-50 h-auto transition-all duration-300"
              />
              </a>
            </div>

            {/* Desktop Menu + Button */}
            <div className="hidden lg:flex items-center gap-8 xl:gap-10">
              <a
                href="./"
                className="text-white font-medium text-base hover:text-gray-300 transition-colors duration-200"
              >
                Home
              </a>
              <a
                href="./about"
                className="text-white font-medium text-base hover:text-gray-300 transition-colors duration-200"
              >
                About Us
              </a>
               <a
                href="./products"
                className="text-white font-medium text-base hover:text-gray-300 transition-colors duration-200"
              >
                Products
              </a>
              <a
                href="./services"
                className="text-white font-medium text-base hover:text-gray-300 transition-colors duration-200"
              >
                Services
              </a>
             
              <a
                href="./contact"
                className="text-white font-medium text-base hover:text-gray-300 transition-colors duration-200"
              >
                Contact Us
              </a>

              {/* Desktop Button */}
             <a
  href="https://users.madosx.co.in/pages/auth/login"
  target="_blank"
  rel="noopener noreferrer"
  className="ml-4"
>
  <button className="px-6 py-2.5 md:px-8 md:py-3 bg-white text-black font-semibold text-sm md:text-base rounded-lg hover:bg-gray-100 transition-colors duration-200">
    Portfolio Login
  </button>
</a>

            </div>

            {/* Mobile Hamburger */}
            <button
              className="lg:hidden text-white p-2 focus:outline-none"
              onClick={toggleMenu}
              aria-label="Toggle menu"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Sidebar */}
      <div
        className={`fixed top-0 right-0 h-full w-72 sm:w-80 bg-black/95 backdrop-blur-md z-50 transform transition-transform duration-300 ease-in-out lg:hidden ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full p-6 sm:p-8">
          {/* Close button */}
          <div className="flex justify-end mb-10 sm:mb-12">
            <button onClick={toggleMenu} className="text-white">
              <X size={32} />
            </button>
          </div>

          {/* Menu items */}
          <div className="flex flex-col gap-7 sm:gap-8 text-lg sm:text-xl">
            <a
              href="./"
              className="text-white font-medium hover:text-gray-300 transition-colors"
              onClick={toggleMenu}
            >
              Home
            </a>
            <a
              href="./about"
              className="text-white font-medium hover:text-gray-300 transition-colors"
              onClick={toggleMenu}
            >
              About us
            </a>
           
            <a
              href="./products"
              className="text-white font-medium hover:text-gray-300 transition-colors"
              onClick={toggleMenu}
            >
              Products
            </a>
             <a
              href="./services"
              className="text-white font-medium hover:text-gray-300 transition-colors"
              onClick={toggleMenu}
            >
              Services
            </a>
            <a
              href="./contact"
              className="text-white font-medium hover:text-gray-300 transition-colors"
              onClick={toggleMenu}
            >
              Contact us
            </a>

            {/* Mobile Button */}
            <a
              href="https://users.madosx.co.in/pages/auth/login"
              className="mt-8 sm:mt-10"
              onClick={toggleMenu}
            >
              <button className="w-full py-3.5 sm:py-4 bg-white text-black font-semibold rounded-lg hover:bg-gray-100 transition-colors duration-200">
                GET STARTED
              </button>
            </a>
          </div>
        </div>
      </div>

      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 lg:hidden"
          onClick={toggleMenu}
        />
      )}
    </>
  );
}

export default Header;