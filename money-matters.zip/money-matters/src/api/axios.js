// src/api/axios.js
import axios from "axios";

const api = axios.create({
  baseURL: "https://moneymatters.co.in/api/", // Live API URL
  timeout: 30000,
  headers: {
    Accept: "application/json",
  },
});

export default api;
