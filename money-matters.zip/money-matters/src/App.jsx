import { Routes, Route } from 'react-router-dom';
import Footer from "./Comopnents/Footer"
import Header from "./Comopnents/Header"
import Home from './Pages/Home';
import About from './Pages/About';
import Contact from './Pages/Contact';
import Services from './Pages/Services';
import Products from './Pages/Products';
import PageNotFound from './Pages/PageNotFound';

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Main content - grows to fill space */}
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/services" element={<Services />} />
          <Route path="/products" element={<Products />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </main>

      <Footer />
    </div>
  );
}

export default App;