import { TrendingUp, Building2, ClipboardEdit, PiggyBank } from 'lucide-react';
import { PieChart, BarChart3, Award, Headphones } from 'lucide-react';
import headrimg from '../assets/header.png'
import CountUp from 'react-countup';
import ManImg from '../assets/ManImg.png'
import counterBg from '../assets/stock.jpg'
import Girl from '../assets/girl.jpg'
import Trad from '../assets/trad.jpg'
import PersonImg from '../assets/girl2.png'
import GreenShape from '../assets/greenshap.png';
import ManImg2 from '../assets/ManImg2.jpg';
import New from '../assets/new.jpg';
import OurApproach from '../Comopnents/OurApproach';
import CallUs from '../Comopnents/CallUs';
import { Helmet } from "react-helmet-async";


export default function Home() {
  return (
    <>

    <Helmet>
  <title>
    Money Matters – Trusted Financial Planning & Investment Advisory
  </title>

  <meta
    name="description"
    content="Money Matters offers personalized financial planning, investment strategies, wealth management, mutual funds, insurance & investment solutions designed to help you grow and protect your wealth."
  />

  <link rel="canonical" href="https://moneymatters.co.in/" />

  <meta property="og:type" content="website" />
  <meta
    property="og:title"
    content="Money Matters – Trusted Financial Planning & Investment Advisory"
  />
  <meta
    property="og:description"
    content="Personalized financial planning and wealth management solutions designed to grow and protect your wealth."
  />
  <meta property="og:url" content="https://moneymatters.co.in/" />
</Helmet>
      {/* Hero Section */}
      <section
        className="relative min-h-[110vh] lg:min-h-[112vh] w-full flex items-center bg-cover bg-center overflow-x-hidden"
        style={{ backgroundImage: `url(${headrimg})` }}
      >
        <div className="relative z-10 px-4 md:px-8 lg:px-[5vw] pt-12 lg:pt-15">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-12 items-center">

            {/* TEXT */}
            <div className="space-y-6 text-white text-center lg:text-left">
              <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">
                Smart Financial Planning for a Secure Tomorrow
              </h1>

              <p className="text-white/90 text-[14px] md:text-[15px] max-w-xl mx-auto lg:mx-0">
                Make confident financial decisions with expert guidance tailored to your goals.
                We help you plan, protect, and grow your wealth through transparent and
                personalized financial solutions.
              </p>

              <button className="mt-6 inline-flex items-center gap-3 px-7 py-3 bg-white text-black font-semibold rounded-md transition-all duration-300 shadow-lg hover:shadow-gray-500/30">
                <a href="./services">
                  DISCOVER MORE
                </a>
              </button>
            </div>

            {/* IMAGE */}
            <div className="flex justify-center lg:justify-end">
              <img
                className="w-[75%] sm:w-[60%] md:w-[55%] lg:w-[70%]"
                src={ManImg}
                alt="man"
              />
            </div>

          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="relative bg-white py-16 md:py-24 lg:py-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 md:px-10 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">

            {/* Left - Image */}
            <div className="relative">
              <img
                src={New}
                alt="Team meeting"
                className="w-full h-auto object-cover aspect-[4/3] lg:aspect-[5/4] rounded-2xl border border-gray-200 shadow-sm"
              />
            </div>

            {/* Right - Text */}
            <div className="space-y-8 lg:space-y-4 pl-2">
              <div className="inline-block">
                <span className="text-gray-800 font-semibold tracking-wider uppercase text-[14px]  ">
                  ABOUT US
                </span>
              </div>

              <h2 className="text-[39px] font-bold text-gray-900 leading-tight">
                Your Trusted Financial Partner
              </h2>

              <p className="text-[14px] md:text-[14px] text-gray-600 leading-relaxed max-w-2xl text-justify leading-5">
                At Money Matters, we help individuals, families and institutions take control of their financial future through clear, reliable, and personalized financial guidance.
                We believe that successful financial planning starts with understanding your goals, risk profile, and long-term vision. Our approach focuses on creating strategies that are practical, transparent, and aligned with your life plans.
              </p>

              <p className="text-[14px] md:text-[14px] text-gray-600 leading-relaxed max-w-2xl text-justify leading-5">
                Backed by market research and ethical practices, we simplify complex financial decisions across investments, insurance, and wealth management—so you can make informed choices with confidence.
              </p>

              <p className="text-[14px] md:text-[14px] text-gray-600 leading-relaxed max-w-2xl text-justify leading-5">
                Our commitment is to build long-term relationships, not short-term gains, ensuring steady growth and financial security at every stage of your journey.
              </p>

              <div className="pt-3">
                <button className="inline-flex items-center gap-3 px-8 py-3 bg-black text-white font-semibold rounded-xl transition-all duration-300 shadow-lg hover:shadow-gray-500/30 transform hover:-translate-y-1">
                  <a href="./about">
                    DISCOVER MORE
                  </a>
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-6 bg-gradient-to-b from-gray-100 to-white">
        <div className="max-w-7xl mx-auto">

          {/* Header */}
          <div className="text-center mb-16">
            <p className="text-gray-800 font-semibold tracking-wider uppercase text-[14px] ">
              WHAT WE DO
            </p>
            <div className="text-[39px] font-bold text-gray-900 leading-tight mb-5 mt-3">
              Solutions for Every Financial Goal
            </div>
            <p className="text-gray-600 text-[16px]  max-w-4xl lg:max-w-4xl mx-auto leading-relaxed px-5 md:px-8">
              At Money Matters, we provide comprehensive financial guidance to help individuals and families plan, protect, and grow their wealth. Our services are designed to simplify financial decisions and create long-term financial security through personalized and transparent solutions.</p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">

            {/* Card 1 */}
            <div className="rounded-2xl p-8 bg-black text-white transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="mb-6 text-white">
                <TrendingUp className="w-12 h-12" />
              </div>
              <h3 className="text-[20px] font-bold mb-4 leading-tight">
                Financial Planning
              </h3>
              <p className="text-[14px] mb-6 leading-relaxed text-gray-300">
                We assess your income, goals, and risk profile to create a structured financial roadmap that supports your short-term needs and long-term aspirations.
              </p>

            </div>

            {/* Card 2 */}
            <div className="rounded-2xl p-8 bg-white text-gray-900 shadow-md transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="mb-6 text-black">
                <Building2 className="w-12 h-12" />
              </div>
              <h3 className="text-[20px] font-bold mb-4 leading-tight">
                Investment Advisory
              </h3>
              <p className="text-[14px] mb-6 leading-relaxed text-gray-600">
                We help you choose the right investment options with a balanced approach focused on steady growth, risk management, and market-backed strategies.
              </p>

            </div>

            {/* Card 3 */}
            <div className="rounded-2xl p-8 bg-white text-gray-900 shadow-md transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="mb-6 text-black">
                <ClipboardEdit className="w-12 h-12" />
              </div>
              <h3 className="text-[20px] font-bold mb-4 leading-tight">
                Insurance & Risk Management
              </h3>
              <p className="text-[14px] mb-6 leading-relaxed text-gray-600">
                Protecting your family and assets is essential. We recommend suitable insurance solutions to safeguard you against life’s uncertainties.

              </p>

            </div>

            {/* Card 4 */}
            <div className="rounded-2xl p-8 bg-white text-gray-900 shadow-md transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="mb-6 text-black">
                <PiggyBank className="w-12 h-12" />
              </div>
              <h3 className="text-[20px] font-bold mb-4 leading-tight">
                Portfolio Review & Ongoing Support
              </h3>
              <p className="text-[14px] mb-6 leading-relaxed text-gray-600">
                We continuously monitor and review your portfolio to ensure it remains aligned with your changing goals and market conditions.
              </p>

            </div>

          </div>
        </div>
      </section>

      <section
        className="relative py-10 bg-cover bg-center bg-no-repeat mb-30"
        style={{ backgroundImage: `url(${counterBg})` }}
      >
        <div className="absolute inset-0 bg-black/70"></div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 lg:px-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-10 md:gap-12 lg:gap-16 text-center">
            {/* Counter 1 */}
            <div className="space-y-3">
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
                <CountUp start={0} end={750} duration={2.5} separator="," />+
              </h2>
              <p className="text-gray-300 text-base md:text-lg font-medium">Happy Customer</p>
            </div>

            {/* Counter 2 */}
            <div className="space-y-3">
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
                <CountUp start={0} end={95} duration={2.5} />%
              </h2>
              <p className="text-gray-300 text-base md:text-lg font-medium">Client Retention</p>
            </div>

            {/* Counter 3 */}
            <div className="space-y-3">
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
                <CountUp start={0} end={10} duration={2.5} separator="," />+
              </h2>
              <p className="text-gray-300 text-base md:text-lg font-medium">Marketing Expert</p>
            </div>

            {/* Counter 4 */}
            <div className="space-y-3">
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
                <CountUp start={0} end={25} duration={2.5} separator="," />+
              </h2>
              <p className="text-gray-300 text-base md:text-lg font-medium">Years of Experience</p>
            </div>
          </div>
        </div>
      </section>




      <section className="relative mb-24 lg:mb-40 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-10">


          <div className="grid grid-cols-1 lg:grid-cols-[45%_55%] gap-12 lg:gap-6 items-center">

            {/* Image */}
            <div className="relative flex justify-center lg:justify-start">
              <div className="relative rounded-3xl">
                <img
                  src={Girl}
                  alt="Happy professional woman"
                  className="w-full sm:w-[85%] lg:w-[90%] h-auto object-cover aspect-[4/5] md:aspect-[5/6] rounded-3xl"
                />
              </div>
            </div>

            {/* Content */}
            <div className="space-y-8 lg:space-y-10 text-center lg:text-left">

              <div className="">
                <span className="text-gray-800 font-semibold tracking-wider uppercase text-[14px]">
                  WHY CHOOSE US
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-[39px] font-bold text-gray-900 leading-tight">
                Expert Guidance. Trusted Results.
              </h2>

              <p className="text-[14px] max-w-3xl mx-auto lg:mx-0">
                At Money Matters, we believe financial success comes from informed
                decisions and trusted guidance. With a client-centric approach, expert
                insights, and transparent practices, we help you build, manage, and
                grow your wealth with confidence.
              </p>

              {/* Features */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

                {/* Feature */}
                <div className="flex gap-5 text-left">
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gray-200 flex items-center justify-center">
                    <PieChart className="w-7 h-7 text-gray-900" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">
                      Trusted Financial Guidance
                    </h4>
                    <p className="text-[14px]">
                      We offer transparent, research-backed financial solutions designed
                      to protect and grow your wealth.
                    </p>
                  </div>
                </div>

                <div className="flex gap-5 text-left">
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gray-200 flex items-center justify-center">
                    <BarChart3 className="w-7 h-7 text-gray-900" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">
                      Experienced Advisors
                    </h4>
                    <p className="text-[14px]">
                      Our team brings deep market knowledge and practical expertise
                      across investments, insurance, and financial planning.
                    </p>
                  </div>
                </div>

                <div className="flex gap-5 text-left">
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gray-200 flex items-center justify-center">
                    <Award className="w-7 h-7 text-gray-900" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">
                      Smart & Simple Solutions
                    </h4>
                    <p className="text-[14px]">
                      We simplify complex financial decisions with clear advice and
                      easy-to-understand strategies.
                    </p>
                  </div>
                </div>

                <div className="flex gap-5 text-left">
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gray-200 flex items-center justify-center">
                    <Headphones className="w-7 h-7 text-gray-900" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">
                      Long-Term Wealth Focus
                    </h4>
                    <p className="text-[14px]">
                      We focus on sustainable, long-term financial growth—not short-term
                      speculation.
                    </p>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </section>



      <section className="relative mb-24 lg:mb-30 min-h-[60vh] lg:min-h-[70vh]">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${Trad})` }}
        ></div>

        {/* Overlay */}
        <div className="absolute inset-0 bg-black/60"></div>

        {/* Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 md:px-10 lg:px-12 py-16 sm:py-18 md:py-20 text-center">

          {/* Heading */}
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-[39px] font-bold text-white leading-tight">
            Empowering individuals and businesses with strategic expertise to drive
            meaningful change and achieve financial excellence.
          </h2>

          <div className="flex justify-center mt-10 sm:mt-12 lg:mt-15">
            <button
              className="
      bg-white text-black 
      px-8 py-3 rounded-lg 
      border border-black 
      hover:bg-black hover:text-white 
      transition-colors duration-300
      cursor-pointer
      font-medium text-sm sm:text-base
    "
            >
              <a href="./contact">
                GET STARTED
              </a>
            </button>
          </div>

        </div>
      </section>

  <OurApproach/>
<CallUs/>

      <section className="bg-white pb-30">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <h2 className="text-[39px] font-light text-gray-900 leading-tight">
            Money Matters is trusted by{" "}
            <span className="relative font-bold inline-block">
              750+ Users
            </span>
          </h2>
        </div>
      </section>
    </>
  );
}
