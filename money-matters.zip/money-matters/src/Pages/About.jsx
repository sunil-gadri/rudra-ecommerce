import { useState, useEffect } from 'react';
import headrimg from "../assets/hero-nav.png";
import teamImg from "../assets/presons.jpeg";
import teamImg2 from "../assets/about.jpeg";
import Rohit  from '../assets/rohit.jpg'
import Bhartandu  from '../assets/bhartandu.jpg'
import OurApproach from '../Comopnents/OurApproach';
import CallUs from '../Comopnents/CallUs';
import { Linkedin } from 'lucide-react';
import { Helmet } from "react-helmet-async";



export default function About() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="bg-white">
      <Helmet>
  <title>
    About Money Matters – Financial Advisory Experts
  </title>

  <meta
    name="description"
    content="Learn more about Money Matters, our mission, values, and experienced financial advisors committed to helping you achieve long-term financial success with transparent and customized guidance."
  />

  <link rel="canonical" href="https://moneymatters.co.in/about" />

  <meta property="og:type" content="website" />
  <meta
    property="og:title"
    content="About Money Matters – Financial Advisory Experts"
  />
  <meta
    property="og:description"
    content="Meet the experienced financial advisors behind Money Matters and discover our approach to wealth management and long-term financial success."
  />
  <meta property="og:url" content="https://moneymatters.co.in/about" />
</Helmet>
      {/* ================= HERO SECTION ================= */}
      <section
        className="relative w-full h-[50vh] md:h-[70vh] flex items-center justify-center bg-center bg-cover"
        style={{ backgroundImage: `url(${headrimg})` }}
      >

        {/* Animated Hero Content */}
        <div className={`relative z-10 text-center transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="relative text-white text-[39px]  font-bold tracking-tight">
            About Us
          </div>
          <div className="mt-4 h-1 w-24 bg-white mx-auto"></div>
        </div>
      </section>

      {/* ================= WHO WE ARE SECTION ================= */}
  <section className="bg-gradient-to-b from-white to-gray-50 py-12 md:py-16 lg:py-20 overflow-hidden px-5 sm:px-6 md:px-8 lg:px-10 xl:px-12">
      <div className="max-w-7xl mx-auto">

        {/* TEXT + IMAGE side by side on lg+ */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 xl:gap-20 items-start">

          {/* LEFT - TEXT (first part) */}
          <div className="text-gray-700 leading-relaxed text-sm sm:text-base">
            <div className="mb-6 sm:mb-6">
              <h2 className="text-gray-800 font-semibold tracking-wider uppercase text-xs sm:text-sm mb-3 sm:mb-2">
                WHO WE ARE
              </h2>
              <p className="text-3xl sm:text-4xl md:text-[39px] font-bold text-gray-900 leading-tight">
               Introducing the Team Behind Your Financial Future
              </p>
            </div>

          <p className="relative pl-5 text-[14px] leading-5  sm:pl-6 border-l-2 border-gray-200 hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify">
            We are a collective of financial experts dedicated to helping our clients achieve enhanced returns from conventional yet often unpredictable and complex financial products. With over Three decades of experience in the markets—seemingly straightforward but inherently intricate—we operate on a core principle: by adopting a timely, disciplined, and focused investment approach, and by selecting the right mix of products, investors can consistently generate superior returns compared to benchmark alternatives.
           </p>

            <p className="relative pl-5 text-[14px]  leading-5  sm:pl-6 border-l-2 border-gray-200 hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify">
            We carefully design and recommend diverse investment strategies, and this expertise has enabled us to successfully serve and retain a broad spectrum of investors—including HNIs, Ultra HNIs, and retail clients—while ensuring their satisfaction. Our constant endeavour is to build and nurture long-term, mutually rewarding relationships founded on trust and performance.
            </p>
          </div>

          {/* RIGHT - IMAGE (with hover effects) */}
          <div className="relative group order-first lg:order-last mt-8 lg:mt-0">
            {/* Decorative gradient background */}
            <div className="absolute -inset-3 sm:-inset-4 bg-gradient-to-br from-gray-100 to-gray-50 rounded-2xl sm:rounded-3xl -z-10 group-hover:from-gray-200 group-hover:to-gray-100 transition-all duration-500"></div>

            {/* Image container */}
            <div className="relative rounded-xl sm:rounded-2xl overflow-hidden shadow-xl sm:shadow-2xl aspect-[4/3] border-4 border-white">
              <img
                src={teamImg2}
                alt="About Moneymatters Team"
                className="w-full h-full object-cover transform group-hover:scale-105 sm:group-hover:scale-110 transition-transform duration-700 ease-out"
              />

              {/* Dark overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            </div>
          </div>
        </div>

        {/* BOTTOM TEXT - full width on all screens */}
        <div className="text-gray-700 leading-relaxed text-sm sm:text-base space-y-5 sm:space-y-6">
          
<h1 className='text-[16px] font-bold pl-8'>Our Approach to Wealth Management</h1>

         <p className="relative pl-5 text-[14px]  leading-5  sm:pl-6 border-l-2 border-gray-200 hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify">
            At Moneymatters, every investment strategy we propose is tailored exclusively to meet the unique expectations of each client. Our wealth management and financial planning solutions are carefully designed around an individual’s profile, financial goals, and advised risk parameters—taking into account age, return expectations, and investment horizon.
                       Over the years, we have developed strong expertise across a wide range of investment products, including Mutual Funds, Debt Management, Portfolio Management Services (PMS), Insurance, Wealth Management, Retirement Planning, Structured Investment Funds (SIF), Alternate Investment Funds (AIF) & Equity Broking.
            </p>


          <p className="relative pl-5 text-[14px]  leading-5  sm:pl-6 border-l-2 border-gray-200 hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify">
          Unlike conventional product-driven advisory models, Moneymatters is built on research-driven solutions. This ensures that every client’s investment choices are uniquely positioned, with their priorities fully addressed. Our guiding principle—NEED-BASED SERVICE—is non-negotiable and consistently upheld by every member of our team.
            </p>

        <p className="relative pl-5 text-[14px]  leading-5  sm:pl-6 border-l-2 border-gray-200 hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify">
           Client satisfaction, wealth creation, and long-term retention are the true rewards of our efforts. This value system keeps us grounded, agile, and constantly aligned with dynamic market trends. The trust and happiness of our investors have propelled us forward, inspiring our team to deliver their very best.
           We continue to grow alongside our clients, and we remain committed to proving ourselves worthy of every new relationship we build.
            </p>
        </div>

      </div>
    </section>


  <section className="bg-gradient-to-b from-gray-50 to-white py-10 md:py-14 lg:py-16 relative overflow-hidden mb-12 md:mb-20 lg:mb-24 px-4 sm:px-6 lg:px-0">
  {/* Decorative background blobs */}
  <div className="absolute top-0 left-0 w-64 h-64 sm:w-80 sm:h-80 lg:w-96 lg:h-96 bg-black/5 rounded-full blur-3xl -translate-x-1/3 -translate-y-1/3"></div>
  <div className="absolute bottom-0 right-0 w-64 h-64 sm:w-80 sm:h-80 lg:w-96 lg:h-96 bg-black/5 rounded-full blur-3xl translate-x-1/3 translate-y-1/3"></div>

  <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-12 relative z-10">
    {/* Section Header */}
    <div className="text-center mb-10 md:mb-12 lg:mb-14 mt-4 md:mt-5">
      <p className="text-gray-800 font-semibold tracking-wider uppercase text-xs sm:text-sm lg:text-[14px] mb-4 md:mb-6">
        MEET OUR TEAM
      </p>
      <div className="text-3xl sm:text-4xl md:text-5xl lg:text-[39px] font-bold text-gray-900 leading-tight px-2 sm:px-0">
        Teamwork makes the dream work.
      </div>
    </div>

    {/* Team Members */}
    <div className="space-y-16 sm:space-y-20 lg:space-y-32">

      {/* 1. Mr. Rohit Khandelwal */}
      <div className="grid lg:grid-cols-2 items-center gap-8 sm:gap-10 lg:gap-16">
        <div className="relative group order-1 lg:order-1">
           <div className="relative mx-auto w-full max-w-[380vw] sm:max-w-[420vw] lg:max-w-none lg:w-[35vw] aspect-[3/4] sm:aspect-[4/5] lg:aspect-auto lg:h-[70vh] rounded-2xl sm:rounded-3xl overflow-hidden shadow-xl lg:shadow-2xl border-6 sm:border-8 border-white bg-gray-50 group">
            <img
              src={Rohit}
              alt="Mr. Rohit Khandelwal"
              className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
            />

            
            <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </div>
        </div>

        {/* Text Content */}
        <div className="order-2 lg:order-2 space-y-6 sm:space-y-7 px-2 sm:px-4 lg:px-0 text-center lg:text-left">
          <div>
            <div className="text-2xl sm:text-3xl lg:text-2xl font-bold text-gray-900 mb-2">
              Mr. Rohit Khandelwal
            </div>
          </div>

          <div className="space-y-4 sm:space-y-5 text-gray-700 leading-relaxed text-sm sm:text-base lg:text-[14px]">
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>Mr. Rohit Khandelwal is a distinguished wealth management professional with 22 years of extensive experience in guiding individuals and institutions toward sustainable financial growth. Holding an MBA in Finance from IIF, Delhi, he combines academic rigor with practical expertise to deliver comprehensive investment strategies. A seasoned investor himself, Mr. Khandelwal actively participates across multiple asset classes, giving him a unique perspective on both opportunities and risks in dynamic markets. His deep engagement with the Indian stock market as well as international financial markets enables him to provide clients with well-rounded, globally informed advice.</p>
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>Throughout his career, he has contributed to the success of renowned financial institutions including Way2Wealth, Angel Broking, CD Equisearch, and HDFC Bank, where he specialized in portfolio management, equity advisory, and client-centric financial planning. His philosophy—"The choices you make today shape the future you won’t regret."—underscores his commitment to proactive wealth creation and disciplined financial planning.</p>
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>Mr. Khandelwal’s expertise lies in:
              - Wealth Management & Portfolio Structuring – Tailoring solutions to meet diverse client goals.
              - Equity & Market Advisory – Leveraging insights from Indian and global markets.
              - Financial Literacy & Client Empowerment – Simplifying complex financial concepts for informed decision-making.  With a proven track record of delivering value-driven strategies, Mr. Rohit Khandelwal continues to empower investors to build resilient portfolios and achieve long-term financial security.</p>
          </div>
 <a
  href="https://www.linkedin.com/in/rohit-khandelwal-a86a8912/"
  target="_blank"
  rel="noopener noreferrer"
  aria-label="Visit LinkedIn Profile"
  className="inline-flex items-center justify-center p-2 rounded-md
             bg-[#0A66C2] text-white
             hover:bg-[#004182]
             transition-colors duration-300"
>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 448 512"
    className="w-[18px] h-[18px] fill-white"
  >
    <path d="M100.28 448H7.4V148.9h92.88zm-46.44-341C24.3 107 0 82.7 0 53.8A53.79 53.79 0 0 1 107.6 53.8c0 28.9-24.3 53.2-53.76 53.2zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"/>
  </svg>
</a>



        </div>
      </div>

      {/* 2. Mr. Sumit Kumar */}
      <div className="grid lg:grid-cols-2 gap-8 sm:gap-10 lg:gap-16 items-center lg:flex-row-reverse">
        <div className="relative group order-1 lg:order-2">
           <div className="relative mx-auto w-full max-w-[380vw] sm:max-w-[420vw] lg:max-w-none lg:w-[35vw] aspect-[3/4] sm:aspect-[4/5] lg:aspect-auto lg:h-[70vh] rounded-2xl sm:rounded-3xl overflow-hidden shadow-xl lg:shadow-2xl border-6 sm:border-8 border-white bg-gray-50 group">
            <img
              src={teamImg}
              alt="Mr. Rohit Khandelwal"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />

            
            <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </div>
        </div>

        <div className="order-2 lg:order-1 space-y-6 sm:space-y-7 px-2 sm:px-4 lg:px-0 text-center lg:text-left">
          <div>
            <h3 className="text-2xl sm:text-3xl lg:text-2xl font-bold text-gray-900 mb-2">
              Mr. Sumit Kumar
            </h3>
          </div>

          <div className="space-y-4 sm:space-y-5 text-gray-700 leading-relaxed text-sm sm:text-base lg:text-[14px]">
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>Mr. Sumit Kumar is a seasoned financial advisory professional with over 18 years of rich experience in the wealth management and capital markets industry. Throughout his distinguished career, he has been associated with leading institutions such as Aditya Birla Money Limited, Angel Broking, and CD Equisearch, where he honed his expertise in investment strategy, client relationship management, and market research.</p>
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>His professional journey reflects a deep understanding of both retail and institutional advisory, encompassing equity markets, mutual funds, and portfolio structuring. Known for his analytical acumen and client-centric approach, Mr. Kumar has consistently guided investors toward achieving their financial goals while balancing risk and return.</p>
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>With a proven track record of delivering insightful market perspectives and tailored investment solutions, Mr. Kumar brings not only technical proficiency but also a commitment to financial literacy and long-term wealth creation. His ability to simplify complex financial concepts and build trust with clients has made him a respected advisor in the industry. Today, he continues to leverage his extensive experience to empower individuals and organizations with sound financial strategies, helping them navigate dynamic markets with confidence</p>
          </div>
           <a
  href="https://www.linkedin.com/in/sumit-kumar-393677177/"
  target="_blank"
  rel="noopener noreferrer"
  aria-label="Visit LinkedIn Profile"
  className="inline-flex items-center justify-center p-2 rounded-md
             bg-[#0A66C2] text-white
             hover:bg-[#004182]
             transition-colors duration-300"
>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 448 512"
    className="w-[18px] h-[18px] fill-white"
  >
    <path d="M100.28 448H7.4V148.9h92.88zm-46.44-341C24.3 107 0 82.7 0 53.8A53.79 53.79 0 0 1 107.6 53.8c0 28.9-24.3 53.2-53.76 53.2zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"/>
  </svg>
</a>
        </div>
      </div>

      {/* 3. Bhartendu Kumar */}
      <div className="grid lg:grid-cols-2 gap-8 sm:gap-10 lg:gap-16 items-center">
        <div className="relative group order-1 lg:order-1">
           <div className="relative mx-auto w-full max-w-[380vw] sm:max-w-[420vw] lg:max-w-none lg:w-[35vw] aspect-[3/4] sm:aspect-[4/5] lg:aspect-auto lg:h-[70vh] rounded-2xl sm:rounded-3xl overflow-hidden shadow-xl lg:shadow-2xl border-6 sm:border-8 border-white bg-gray-50 group">
            <img
              src={Bhartandu}
              alt="Mr. Rohit Khandelwal"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />

            <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </div>
        </div>

        <div className="order-2 lg:order-2 space-y-6 sm:space-y-7 px-2 sm:px-4 lg:px-0 text-center lg:text-left">
          <div>
            <h3 className="text-2xl sm:text-3xl lg:text-2xl font-bold text-gray-900 mb-2">
              Bhartendu Kumar
            </h3>
          </div>

          <div className="space-y-4 sm:space-y-5 text-gray-700 leading-relaxed text-sm sm:text-base lg:text-[14px]">
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>Bhartendu Kumar is a seasoned business development professional with over 20 years of experience in driving growth and building high-performing teams across reputed companies. He holds an MBA and has consistently demonstrated excellence in sales, strategy, and client relationship management throughout his career.</p>
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>To further enhance his strategic and leadership capabilities, Bhartendu completed a Management Development Programme in Sales and Marketing from the prestigious Indian Institute of Management, Kozhikode (IIM-K).</p>
            <p className='relative text-[14px] leading-5  hover:border-gray-400 transition-colors duration-300 mb-5 sm:mb-6 text-justify'>As a co-founder of Money Matters, he brings a sharp focus on innovation, execution, and customer-centricity to the company’s mission of transforming financial advisory services in India.</p>
          </div>
 <a
  href="https://www.linkedin.com/in/bhartendu-kumar-0023b913?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app"
  target="_blank"
  rel="noopener noreferrer"
  aria-label="Visit LinkedIn Profile"
  className="inline-flex items-center justify-center p-2 rounded-md
             bg-[#0A66C2] text-white
             hover:bg-[#004182]
             transition-colors duration-300"
>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 448 512"
    className="w-[18px] h-[18px] fill-white"
  >
    <path d="M100.28 448H7.4V148.9h92.88zm-46.44-341C24.3 107 0 82.7 0 53.8A53.79 53.79 0 0 1 107.6 53.8c0 28.9-24.3 53.2-53.76 53.2zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"/>
  </svg>
</a>

        </div>
      </div>

    </div>
  </div>
</section>  

<OurApproach/>
     
   <CallUs/>

    </div>
  );
}