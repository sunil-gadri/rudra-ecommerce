import { useState } from "react";
import ReCAPTCHA from "react-google-recaptcha";
import toast, { Toaster } from "react-hot-toast";
import headrimg from "../assets/hero-nav.png";
import { Building2, Phone, Mail } from "lucide-react";
import api from "../api/axios";
import { Helmet } from "react-helmet-async";

export default function Contact() {
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");

  const [recaptchaToken, setRecaptchaToken] = useState(null);
  const [loading, setLoading] = useState(false);

  // Handle reCAPTCHA success
  const handleCaptchaChange = (token) => {
    setRecaptchaToken(token);
  };

  // Handle form submit
  const handleSubmit = async (e) => {
  e.preventDefault();
  setLoading(true);

  const formdata = new FormData();
  formdata.append("name", name);
  formdata.append("company", company);
  formdata.append("email", email);
  formdata.append("phone", phone);
  formdata.append("message", message);

  try {
    const response = await api.post("contact.php", formdata);

    if (response.data.status === true) {
      toast.success("Message sent successfully");

      setName("");
      setCompany("");
      setEmail("");
      setPhone("");
      setMessage("");
    } else {
      toast.error(response.data.message || "Something went wrong");
    }
  } catch (error) {
    console.error(error);
    toast.error("Server error");
  } finally {
    setLoading(false);
  }
};

  return (
    <>
    <Helmet>
  <title>Contact Money Matters – Financial Advisors for Consultation</title>

  <meta
    name="description"
    content="Get in touch with Money Matters for expert financial guidance and support. Schedule a consultation to discuss your goals, investments, and wealth management strategies."
  />

  <meta
    name="keywords"
    content="Financial advisor consultation, Investment advisor contact , Wealth management consultation , Book financial appointment , Financial consultation services"
  />

  <link rel="canonical" href="https://moneymatters.co.in/contact" />

  <meta property="og:title" content="Contact Money Matters – Financial Consultation" />
  <meta property="og:description" content="Get in touch with Money Matters for expert financial guidance and support. Schedule a consultation to discuss your goals, investments, and wealth management strategies." />
  <meta property="og:type" content="website" />
</Helmet>
      <Toaster position="top-right" />

      {/* HERO */}
      <section
        className="relative w-full h-[50vh] md:h-[70vh] flex items-center justify-center bg-center bg-cover"
        style={{ backgroundImage: `url(${headrimg})` }}
      >
        <div className="relative z-10 text-center transition-all duration-1000">
          <div className="relative text-white text-[39px] font-bold tracking-tight">
            Contact Us
          </div>
          <div className="mt-4 h-1 w-24 bg-white mx-auto"></div>
        </div>
      </section>

      {/* MAIN SECTION */}
      <section className="py-16 sm:py-20 px-6 sm:px-10 lg:px-20 lg:py-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 lg:gap-24 items-start">

            {/* LEFT COLUMN */}
            <div className="space-y-12 text-center lg:text-left">
              <div>
                <p className="text-gray-800 font-semibold tracking-wider uppercase text-[14px] mb-6">
                  Start Your Financial Journey With Us
                </p>
                <h1 className="relative text-[14px] tracking-tight text-black max-w-xl mx-auto lg:mx-0">
                  Whether you’re planning for the future or optimizing your finances today,
                  we’re here to provide expert guidance every step of the way.
                </h1>
              </div>

              <div className="space-y-10">
                {/* Delhi Office */}
                <div className="flex items-start gap-5">
                  <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-black flex-shrink-0">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold text-black mb-2">
                      New Delhi Office
                    </h4>
                    <p className="text-gray-700 text-[14px]">
                      White House Building, Masoodpur,<br />
                      Vasant Kunj, New Delhi – 110070
                    </p>
                    <p className="text-gray-700 mt-2 flex items-center gap-2 text-[14px]">
                      <Phone className="w-4 h-4 text-black" />
                      <a href="tel:+918826012778">+91 88260 12778</a>
                    </p>
                    <p className="text-gray-700 flex items-center gap-2 mt-2 text-[14px]">
                      <Mail className="w-4 h-4 text-black" />
                      <a href="mailto:contactus@moneymatters.co.in">
                        contactus@moneymatters.co.in
                      </a>
                    </p>
                  </div>
                </div>

                {/* Jaipur Office */}
                <div className="flex items-start gap-5">
                  <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-black flex-shrink-0">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold text-black mb-2">
                      Jaipur Office
                    </h4>
                    <p className="text-gray-700 text-[14px]">
                      Money Matters, 520, Mansarovar Plaza,<br />
                      Madhyam Marg, Mansarovar, Jaipur-302020
                    </p>
                    <p className="text-gray-700 mt-2 flex items-center gap-2 text-[14px]">
                      <Phone className="w-4 h-4 text-black" />
                      <a href="tel:+919352023049">+91 93520 23049</a>
                    </p>
                    <p className="text-gray-700 flex items-center gap-2 mt-2 text-[14px]">
                      <Mail className="w-4 h-4 text-black" />
                      <a href="mailto:contactus@moneymatters.co.in">
                        contactus@moneymatters.co.in
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN - FORM */}
            <div className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 lg:p-10 border border-gray-200">
              <h3 className="text-xl md:text-2xl font-bold text-black mb-4 text-center lg:text-left">
                Send us a message
              </h3>

              <p className="text-gray-600 mb-6 text-sm text-center lg:text-left">
                Our team will get back to you within 24 hours.
              </p>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <input
                    type="text"
                    placeholder="Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-sm rounded-lg border"
                  />

                  <input
                    type="text"
                    placeholder="Company"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border"
                  />
                </div>

                <input
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-sm rounded-lg border"
                />

                <input
                  type="tel"
                  placeholder="Phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border"
                />

                <textarea
                  rows={2}
                  placeholder="Message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-sm rounded-lg border"
                />

                <ReCAPTCHA
                  sitekey="6LfEsFEsAAAAAPWXMFz6SFJ-uY_d9l-5Vl1O8e3M"
                  onChange={handleCaptchaChange}
                />

                <button
                  type="submit"
                  disabled={loading || !recaptchaToken}
                  className={`w-full py-3 rounded-lg text-white ${
                    loading || !recaptchaToken
                      ? "bg-gray-500"
                      : "bg-black hover:bg-gray-900"
                  }`}
                >
                  {loading ? "Sending..." : "Send Message"}
                </button>
              </form>
            </div>

          </div>
        </div>
      </section>
    </>
  );
}
