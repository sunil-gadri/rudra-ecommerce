import React, { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import headrimg from "../assets/hero-nav.png";

function PageNotFound() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
  <>
  {/* SEO */}
  <Helmet>
    <title>404 - Page Not Found | Money Matters</title>
    <meta
      name="description"
      content="The page you are looking for does not exist. Visit Money Matters for professional financial advisory services."
    />
    <meta name="robots" content="noindex, follow" />
  </Helmet>

  {/* HERO SECTION */}
  <section
    className="relative w-full h-[50vh] md:h-[70vh] flex items-center justify-center bg-center bg-cover"
    style={{ backgroundImage: `url(${headrimg})` }}
  >
    {/* Dark overlay */}

    <div
      className={`relative z-10 text-center transition-all duration-1000 ${
        isVisible
          ? "opacity-100 translate-y-0"
          : "opacity-0 translate-y-10"
      }`}
    >
      <h1 className="text-white text-[39px] font-bold tracking-tight">
        404 - Page Not Found
      </h1>

      <div className="mt-4 h-1 w-24 bg-white mx-auto"></div>

      <p className="text-white mt-6 max-w-xl mx-auto">
        Sorry, the page you are looking for does not exist or has been moved.
      </p>
    </div>
  </section>

  {/* WHITE SECTION BELOW */}
  <section className="bg-white py-20">
    <div className="max-w-4xl mx-auto text-center px-6">
      <p className="text-gray-600 mb-8 text-lg">
        Let us help you get back on track and explore our financial advisory
        services.
      </p>

      <Link
        to="/"
        className="inline-block bg-black text-white px-8 py-3 rounded-lg font-semibold hover:bg-gray-800 transition"
      >
        Back to Home
      </Link>
    </div>
  </section>
</>
  );
}

export default PageNotFound;