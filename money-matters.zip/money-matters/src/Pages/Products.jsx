import React from "react";
import headrimg from "../assets/hero-nav.png";
import {
  PieChart,
  CreditCard,
  ClipboardList,
  Wallet,
  Percent,
  Shield,
} from "lucide-react";
import ManImg2 from '../assets/ManImg2.jpg';  
import GreenShape from '../assets/greenshap.png';
import PersonImg  from '../assets/girl2.png'
import OurApproach from "../Comopnents/OurApproach";
import CallUs from "../Comopnents/CallUs";
import { Helmet } from "react-helmet-async";

function Products() {
  return (
    <>
<Helmet>
  <title>
    Investment Products – Wealth Management, Mutual Funds & More
  </title>

  <meta
    name="description"
    content="Discover our investment products such as wealth management, mutual funds, AIF, PMS, structured products, and insurance solutions tailored for your financial goals and risk profile."
  />

  <link rel="canonical" href="https://moneymatters.co.in/products" />

  <meta property="og:type" content="website" />
  <meta
    property="og:title"
    content="Investment Products – Wealth Management, Mutual Funds & More"
  />
  <meta
    property="og:description"
    content="Explore professional wealth management, mutual funds, AIF, PMS, structured products, and insurance solutions designed to grow and protect your wealth."
  />
  <meta property="og:url" content="https://moneymatters.co.in/products" />
</Helmet>

      {/* HERO SECTION */}
      <section
        className="relative w-full h-[50vh] md:h-[70vh] flex items-center justify-center bg-center bg-cover"
        style={{ backgroundImage: `url(${headrimg})` }}
      >
        <div className="relative z-10 text-center transition-all duration-1000">
          <div className="relative text-white text-[39px] font-bold tracking-tight">
            Products
          </div>
          <div className="mt-4 h-1 w-24 bg-white mx-auto"></div>
        </div>
      </section>


      <section className="pt-10 bg-white">
        <div className="max-w-5xl mx-auto px-6 lg:px-12 text-center">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-5 leading-tight">
            Our Financial Solutions
          </h2>
          <p className="text-gray-600 leading-relaxed max-w-3xl mx-auto">
            Our products are crafted to support every stage of your financial journey, combining expert guidance, transparency, and long-term value creation.
          </p>
        </div>
      </section>

      {/* PRODUCTS GRID */}
      <section className="py-20 px-6 lg:px-20 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">

            {/* Wealth Management */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <PieChart className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Wealth Management
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Comprehensive financial planning and investment strategies designed to grow, protect, and manage your wealth long term.
              </p>
            </div>

            {/* Mutual Funds */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <CreditCard className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Mutual Funds
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Expert-selected mutual fund solutions aligned with your goals, risk profile, and long-term financial objectives.
              </p>
            </div>

            {/* AIF */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <ClipboardList className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                AIF (Alternative Investment Funds)
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Access carefully curated alternative investments offering diversification, higher potential returns, and strategic portfolio balance.
              </p>
            </div>

            {/* PMS */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <Wallet className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                PMS (Portfolio Management Services)
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Personalized portfolio management with professional oversight, strategic asset allocation, and disciplined investment execution.
              </p>
            </div>

            {/* Structured Products */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <Percent className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Structured Products
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Innovative investment solutions combining capital protection and market-linked returns for investors seeking balanced risk and growth.
              </p>
            </div>

            {/* Insurance */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <Shield className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Insurance
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Comprehensive insurance solutions to protect your family, assets, and financial future against unforeseen risks.
              </p>
            </div>

          </div>
        </div>
      </section>

      
 <OurApproach/>
<CallUs/>      
    </>
  );
}

export default Products;
