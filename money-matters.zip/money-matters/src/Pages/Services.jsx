import React from "react";
import headrimg from "../assets/hero-nav.png";
import {
  PieChart,
  CreditCard,
  ClipboardList,
  Wallet,
  Percent,
  ShieldCheck ,
} from "lucide-react";
import ManImg2 from '../assets/ManImg2.jpg';  
import GreenShape from '../assets/greenshap.png';
import PersonImg  from '../assets/girl2.png'
import OurApproach from "../Comopnents/OurApproach";
import CallUs from "../Comopnents/CallUs";
import { Helmet } from "react-helmet-async";



function Services() {
  return (
    <>

    <Helmet>
  <title>
    Our Financial Advisory Services – Money Matters
  </title>

  <meta
    name="description"
    content="Explore professional services by Money Matters including model portfolios, debt advisory, financial planning, money management, and fund & fee based advisory for better financial outcomes."
  />

  <link rel="canonical" href="https://moneymatters.co.in/services" />

  <meta property="og:type" content="website" />
  <meta
    property="og:title"
    content="Our Financial Advisory Services – Money Matters"
  />
  <meta
    property="og:description"
    content="Professional financial advisory services including retirement planning, model portfolios, debt advisory and money management solutions."
  />
  <meta property="og:url" content="https://moneymatters.co.in/services" />
</Helmet>
      {/* HERO SECTION */}
      <section
        className="relative w-full h-[50vh] md:h-[70vh] flex items-center justify-center bg-center bg-cover"
        style={{ backgroundImage: `url(${headrimg})` }}
      >
        <div className="relative z-10 text-center transition-all duration-1000">
          <div className="relative text-white text-[39px] font-bold tracking-tight">
            Services
          </div>
          <div className="mt-4 h-1 w-24 bg-white mx-auto"></div>
        </div>
      </section>

      <section className="pt-10 bg-white">
        <div className="max-w-5xl mx-auto px-6 lg:px-12 text-center">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-5 leading-tight">
            Services We Offer
          </h2>
          <h1 className="text-gray-600 leading-relaxed max-w-4xl mx-auto">
            We provide expert financial advisory services designed to help you manage money wisely, minimize risk, and achieve long-term financial stability through informed decision-making.
          </h1>
        </div>
      </section>

      {/* SERVICES GRID */}
      <section className="py-20 px-6 lg:px-20 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">

             <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <ShieldCheck className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
              Retirement Planning
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Plan today for a comfortable, independent, and worry-free retirement. We help you build a structured retirement strategy focused on steady income, capital protection, and long-term financial security.
              </p>
            </div>

            {/* Debt Adviser */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <CreditCard className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Debt Advisory
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Professional advice on debt and fixed-income instruments to ensure stability, predictable returns, and portfolio balance.
              </p>
            </div>

            {/* Financial Planning */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <ClipboardList className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Financial Planning
              </h3>
              <p className="text-gray-600 leading-relaxed">
                End-to-end financial planning covering goals, investments, insurance, and tax strategies for long-term financial security.
              </p>
            </div>

            {/* Money Management */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <Wallet className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Money Management
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Strategic management of cash flow and investments to control risk and support steady financial growth.
              </p>
            </div>

            {/* Fund Fee & Based Adviser */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <Percent className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Fund & Fee-Based Advisory
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Transparent advisory services offering unbiased recommendations through fund-based and fee-only models.
              </p>
            </div>

             {/* Model Portfolio */}
            <div className="rounded-2xl border border-gray-200 p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                <PieChart className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-xl font-bold text-black mb-4">
                Model Portfolios
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Research-backed investment portfolios tailored to different risk profiles, designed for disciplined and consistent wealth creation.
              </p>
            </div>

          </div>
        </div>
      </section>

<OurApproach/>     
           <CallUs/> 
    </>
  );
}

export default Services;
