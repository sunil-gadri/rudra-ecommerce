/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0D0D0F',
        surface: '#161618',
        surface2: '#1D1D20',
        line: '#2A2A2E',
        bone: '#F4F3EF',
        mute: '#8C8C93',
        amber: '#E8A33D',
        teal: '#3E6B63',
        clay: '#C4664B',
      },
      fontFamily: {
        display: ['"InterVariable"', '"Inter"', 'sans-serif'],
        body: ['"InterVariable"', '"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      maxWidth: {
        content: '72rem',
      },
    },
  },
  plugins: [],
}
