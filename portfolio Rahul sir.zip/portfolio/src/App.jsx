import Header from './components/Header'
import Hero from './components/Hero'
import About from './components/About'
import Services from './components/Services'
import Testimonials from './components/Testimonials'
import FAQ from './components/FAQ'
import Contact from './components/Contact'
import Footer from './components/Footer'
import ProjectRow from './components/ProjectRow'
import BrandTag from './components/BrandTag'
import Timeline from './components/Timeline'
import Skills from './components/Skills'

export default function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <BrandTag/>
      <main>
        <Hero />
        <ProjectRow />
        <About />
        <Skills/>
        <Timeline/>
        <Services />
        <Testimonials />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  )
}
