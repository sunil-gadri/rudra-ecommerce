// Swap this placeholder content for your own projects, copy, and images.
// Each project has an `images` array — drop your real screenshot paths in
// (e.g. '/images/nimbus-1.png') once you have them. Until then the tiles
// render as labelled gradient placeholders so the gallery layout still works.

export const projects = [
  {
    id: '01',
    name: 'Nimbus',
    tagline: 'An enterprise platform for AI agents',
    description:
      'Design system and production UI for a platform that lets support teams supervise and hand off work between AI agents and humans.',
    link: { label: 'View project', href: '#' },
    accent: 'amber',
    images: [
      { label: 'Dashboard' },
      { label: 'Live queue' },
      { label: 'Sign in' },
      { label: 'Workspace switcher' },
    ],
  },
  {
    id: '02',
    name: 'Fieldwork',
    tagline: 'The full-stack CX platform',
    description:
      'End-to-end interface design for a contact-center product spanning softphone, live analytics, and workforce reporting.',
    link: { label: 'View project', href: '#' },
    accent: 'teal',
    images: [
      { label: 'Softphone' },
      { label: 'Agent stats' },
      { label: 'Reports' },
    ],
  },
  {
    id: '03',
    name: 'Ledger',
    tagline: 'Customer management for SaaS teams',
    description:
      'A billing and account-health workspace that gives revenue teams one place to see plans, usage, and renewal risk.',
    link: { label: "Let's talk", href: '#contact' },
    accent: 'clay',
    images: [
      { label: 'Revenue overview' },
      { label: 'Accounts' },
      { label: 'Billing' },
      { label: 'Search' },
    ],
  },
  {
    id: '04',
    name: 'Harbor',
    tagline: 'Helpdesk for the agentic AI era',
    description:
      'Ticketing interface where an AI assistant drafts replies and hands off low-confidence cases to a human, with full context attached.',
    link: { label: "Let's talk", href: '#contact' },
    accent: 'amber',
    images: [
      { label: 'Ticket view' },
      { label: 'AI draft reply' },
      { label: 'Handoff' },
    ],
  },
]

export const services = [
  {
    title: 'Product design sprint',
    description:
      'Focused support for a key product challenge, from early direction to polished UI.',
    price: 'From $2,500',
    items: [
      'New feature or workflow',
      'Product redesign',
      'Interactive prototype',
      'Design system foundations',
    ],
    cta: { label: 'Discuss a project', href: 'mailto:you@example.com' },
  },
  {
    title: 'Ongoing product support',
    description:
      'Flexible design and frontend support for teams building and improving digital products.',
    price: 'From $5,000/month',
    items: [
      'Product and interaction design',
      'Design system work',
      'Frontend implementation',
      'Ongoing product refinement',
    ],
    cta: { label: 'Discuss ongoing support', href: 'mailto:you@example.com' },
  },
]

export const testimonial = {
  quote:
    'Working together was a genuinely smooth experience — a strong grasp of both UI craft and the underlying product thinking, with real ownership over the outcome.',
  name: 'Jordan Avery',
  role: 'Co-Founder, Example Inc.',
}

export const faqs = [
  {
    q: 'What kind of work do you take on?',
    a: 'Product design, complex workflows, design systems, prototypes, and frontend implementation for AI and SaaS products.',
  },
  {
    q: 'Do you work with startups or larger teams?',
    a: 'Both. I work best with teams building complex digital products that need strong design thinking and hands-on execution.',
  },
  {
    q: 'Can you work with an existing product team?',
    a: 'Yes. I can join an existing product and engineering workflow, collaborate asynchronously, and work within established systems.',
  },
  {
    q: 'Do you handle frontend implementation?',
    a: 'Yes. I can implement production interfaces using React, HTML, CSS, and modern frontend tooling.',
  },
  {
    q: 'Are you available for full-time roles?',
    a: "Yes. I'm open to remote international roles and relocation, alongside selected freelance engagements.",
  },
  {
    q: 'How do projects usually start?',
    a: 'With a short call to understand the product, scope, team, and expected outcome.',
  },
]

export const socials = [
  { label: 'Email', href: 'mailto:you@example.com' },
  { label: 'Twitter', href: 'https://twitter.com' },
  { label: 'LinkedIn', href: 'https://linkedin.com' },
  { label: 'Instagram', href: 'https://instagram.com' },
  { label: 'Behance', href: 'https://behance.net' },
  { label: 'Resume', href: '#' },
]
