import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Building2 } from 'lucide-react';

const TIMELINE_DATA = [
  {
    year: 1999,
    period: '1999 — 2005',
    badge: 'Engineer',
    role: 'Lead Developer/System Analyst',
    organization: 'Jurassic Age Softwares',
    summary:
      'Started out writing low-level C/C++ for desktop systems, working close to the hardware on performance-critical enterprise tooling.',
    details: [
      'Built and maintained C/C++ desktop applications for internal enterprise workflows.',
      'Debugged and optimized performance-critical modules across Windows desktop environments.',
      'Worked directly with systems teams to translate business requirements into low-level implementations.',
    ],
    techHighlights: ['C', 'C++', 'Win32 API', 'SQL'],
    metrics: '50+ systems shipped',
  },
  {
    year: 2005,
    period: '2005 — 2007',
    badge: 'Lead Developer',
    role: 'Enterprise Software Architect & Technical Lead',
    organization: 'REDTRAY Interactive Solutions Pvt. Ltd.',
    summary:
      'Moved into leading small engineering teams, delivering full enterprise applications end to end for mid-size clients.',
    details: [
      'Led a team of engineers delivering desktop-to-web enterprise application migrations.',
      'Introduced structured code review and release processes across client projects.',
      'Owned architecture decisions for multi-module enterprise systems.',
    ],
    techHighlights: ['C#', '.NET', 'SQL Server', 'ASP.NET'],
    metrics: '500+ Web & Enterprise Systems Delivered',
  },
  {
    year: 2007,
    period: '2007 — Present',
    badge: 'Founder & Director',
    role: 'Founder & Director',
    organization: 'Vk Softwares',
    summary:
      'Founded my first software agency, building custom web and enterprise products for clients across multiple industries.',
    details: [
      'Founded and scaled a software agency from solo founder to a multi-person team.',
      'Delivered custom web platforms, internal tools, and enterprise integrations for clients.',
      'Managed client relationships, project scoping, and technical delivery end to end.',
    ],
    techHighlights: ['PHP', 'JavaScript', 'MySQL', 'jQuery'],
    metrics: '2,000+ Cloud & Mobile Projects Managed',
  },
  {
    year: 2014,
    period: '2014 — Present',
    badge: 'Founder',
    role: 'Founder & Technical Director',
    organization: 'Infomagine Softwares',
    summary:
      'Founded a second agency focused on modern web applications, shifting the stack toward React and cloud-native infrastructure.',
    details: [
      'Rebuilt the agency\u2019s technical foundation around React, Node.js, and cloud infrastructure.',
      'Directed architecture and design system decisions across all client engagements.',
      'Grew the team and mentored engineers moving from traditional stacks into modern JavaScript.',
    ],
    techHighlights: ['React', 'Node.js', 'AWS', 'PostgreSQL'],
    metrics: '5,000+ Total Career Software Deployments',
  },
  {
    year: 2018,
    period: '2018 — Present',
    badge: 'Co-Founder',
    role: 'Co-Founder & Strategic Advisor',
    organization: 'FundNest LLP',
    summary:
      'Advised startup founders and enterprise boards as Lead Software Architect and Technical Management Specialist, performing architectural code audits, due diligence, and system modernization.',
    details: [
      'Conducted deep-dive technical due diligence and architectural audits for 30+ funded startup teams.',
      'Served as Fractional CTO & Software Management Expert, advising C-suite executives on technical roadmaps, team structure, and cloud cost optimization.',
      'Architected enterprise legal platforms (SKP Legal Solutions) and HIPAA-compliant healthcare portals (Udawat Clinic).',
    ],
    techHighlights: ['React', 'TypeScript', 'Figma', 'Design Systems'],
    metrics: '30+ Tech Startups Audited & Advised',
  },
]

// Custom-spaced dashed styles (native border-dashed can't control dash/gap size).
// NOTE: border-image with a horizontal gradient only renders correctly on
// top/bottom edges — the same slice stretched onto left/right edges can land
// on a transparent gap depending on box width, making that side vanish.
// Using background-image dashes (one gradient per axis) fixes this on all 4 sides.
const dashColor = 'rgba(255,255,255,0.35)'
const dashedBox = {
  backgroundImage: `
    linear-gradient(to right, ${dashColor} 50%, transparent 0%),
    linear-gradient(to right, ${dashColor} 50%, transparent 0%),
    linear-gradient(${dashColor} 50%, transparent 0%),
    linear-gradient(${dashColor} 50%, transparent 0%)
  `,
  backgroundPosition: 'top left, bottom left, top left, top right',
  backgroundSize: '4px 1px, 4px 1px, 1px 4px, 1px 4px',
  backgroundRepeat: 'repeat-x, repeat-x, repeat-y, repeat-y',
}
const dashedLineBottom = {
  borderBottomWidth: '1px',
  borderBottomStyle: 'dashed',
  borderImage:
    'repeating-linear-gradient(to right, rgba(255,255,255,0.28) 0 2px, transparent 2px 4px) 1',
}

export default function Timeline() {
  const [activeMilestone, setActiveMilestone] = useState(
    TIMELINE_DATA[TIMELINE_DATA.length - 1]
  );

  return (
    <section
      id="timeline"
      className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] py-12 sm:py-16 lg:py-28 scroll-mt-16"
    >
      {/* Eyebrow */}
      <div className="relative inline-block px-3 sm:px-4 py-1.5" style={dashedBox}>
        <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.2em] font-bold text-[#f7f8f8]">
          Timeline
        </span>
        <span className="absolute top-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 -translate-y-1/2" />
        <span className="absolute top-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 -translate-y-1/2" />
        <span className="absolute bottom-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 translate-y-1/2" />
        <span className="absolute bottom-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="mt-6 flex flex-col gap-4 sm:gap-6 lg:gap-8">
  <h2 className="w-full text-[28px] leading-[1.15] sm:text-[36px] md:text-[50px] lg:text-[64px] lg:leading-[1.05] font-bold text-[#f7f8f8]">
    27 years of continuous enterprise evolution.
  </h2>

  <p className="text-[#9e9e9e] text-[14px] sm:text-[15px] leading-relaxed max-w-sm">
    Tracing 27 years from low-level C/C++ desktop system analysis in 1999 to founding
    multiple software agencies and pioneering generative AI pipelines today.
  </p>
</div>

      {/* Timeline layout */}
      <div className="mt-8 sm:mt-12 lg:mt-16 grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-10 lg:gap-12 items-start">
        {/* Milestone list */}
        <div className="lg:col-span-5 space-y-3">
          {TIMELINE_DATA.map((item) => {
            const isActive = activeMilestone.year === item.year;
            return (
              <button
                key={item.year}
                type="button"
                onClick={() => setActiveMilestone(item)}
                className={`w-full text-left p-4 sm:p-5 transition-colors ${
                  isActive ? 'bg-white/[0.04]' : 'hover:bg-white/[0.02]'
                }`}
                style={dashedBox}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[#f7f8f8]">{item.period}</span>
                  <span className="text-[10px] uppercase tracking-[0.1em] px-2 py-0.5 text-[#9e9e9e] border border-white/10 whitespace-nowrap">
                    {item.badge}
                  </span>
                </div>

                <h3 className="text-[15px] sm:text-base font-semibold text-[#f7f8f8] mt-2 break-words">
                  {item.role}
                </h3>
                <p className="text-[13px] text-[#9e9e9e] mt-0.5 break-words">{item.organization}</p>
              </button>
            );
          })}
        </div>

        {/* Milestone detail panel */}
        <div className="lg:col-span-7">
          <motion.div
            key={activeMilestone.year}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
            className="p-5 sm:p-6 lg:p-10 space-y-6 sm:space-y-8 lg:sticky lg:top-28"
            style={dashedBox}
          >
            <div
              className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 pb-6"
              style={dashedLineBottom}
            >
              <div className="min-w-0">
                <div className="text-[11px] uppercase font-bold tracking-[0.15em] text-[#9e9e9e]">
                  Milestone ({activeMilestone.period})
                </div>
                <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold text-[#f7f8f8] mt-2 break-words">
                  {activeMilestone.role}
                </h3>
                <p className="text-sm text-[#9e9e9e] flex items-center gap-2 mt-2 break-words">
                  <Building2 className="w-4 h-4 text-[#9e9e9e] shrink-0" strokeWidth={1.75} />
                  {activeMilestone.organization}
                </p>
              </div>

              <div className="p-3 text-left sm:text-right shrink-0" style={dashedBox}>
                <div className="text-[10px] text-[#9e9e9e] uppercase tracking-[0.1em]">
                  Metric
                </div>
       <div className="w-[100px] text-xs font-semibold text-[#f7f8f8] mt-1 whitespace-normal">
  {activeMilestone.metrics}
</div>
              </div>
            </div>

            {/* Summary */}
            <div className="space-y-3">
              <h4 className="text-[11px] uppercase tracking-[0.15em] font-bold text-[#9e9e9e]">
                Strategic scope &amp; context
              </h4>
              <p className="text-[14px] sm:text-[15px] text-[#9e9e9e] leading-relaxed">
                {activeMilestone.summary}
              </p>
            </div>

            {/* Accomplishments */}
            <div className="space-y-3">
              <h4 className="text-[11px] uppercase tracking-[0.15em] font-bold text-[#9e9e9e]">
                Key accomplishments &amp; systems built
              </h4>
              <ul className="space-y-2.5">
                {activeMilestone.details.map((detail, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-[13px] sm:text-[14px] text-[#9e9e9e]">
                    <CheckCircle2 className="w-4 h-4 text-[#f7f8f8] shrink-0 mt-0.5" strokeWidth={1.75} />
                    <span className="break-words">{detail}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Tech highlights */}
            <div
              className="pt-6 space-y-3"
              style={{
                borderTopWidth: '1px',
                borderTopStyle: 'dashed',
                borderImage: dashedLineBottom.borderImage,
              }}
            >
              <h4 className="text-[11px] uppercase tracking-[0.15em] font-bold text-[#9e9e9e]">
                Key toolkits &amp; stacks introduced
              </h4>
              <div className="flex flex-wrap gap-2">
                {activeMilestone.techHighlights.map((tech, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 text-xs font-medium text-[#9e9e9e]"
                    style={dashedBox}
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}