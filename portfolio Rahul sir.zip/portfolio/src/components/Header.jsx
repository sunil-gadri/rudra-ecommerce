import { useEffect, useState } from "react";
import Logo from "./../../public/images/image.png";

export default function Header() {
  const [active, setActive] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const sections = [
      document.getElementById("work"),
      document.getElementById("about"),
      document.getElementById("services"),
      document.getElementById("testimonials"),
      document.getElementById("contact"),
    ].filter(Boolean);

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(entry.target.id);
          }
        });
      },
      {
        rootMargin: "-45% 0px -50% 0px",
        threshold: 0,
      }
    );

    sections.forEach((section) => observer.observe(section));

    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();

    window.addEventListener("scroll", onScroll, { passive: true });

    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  const handleNavClick = (e, id) => {
    e.preventDefault();
    document.getElementById(id)?.scrollIntoView({
      behavior: "smooth",
    });
    setMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-300 ${
        scrolled
          ? "bg-ink/80 backdrop-blur-md border-b border-line/60"
          : "bg-transparent"
      }`}
    >
      <div className="relative max-w-[1400px] mx-auto h-20">
        {/* Logo - pinned to the true left, independent of the content column */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({
              top: 0,
              behavior: "smooth",
            });
            setMenuOpen(false);
          }}
          className="absolute left-6 sm:left-10 top-1/2 -translate-y-1/2 font-display font-semibold text-lg text-bone hover:text-amber transition-colors"
          aria-label="Back to top"
        >
          <img src={Logo} width="100" height="100" alt="Logo" />
        </a>

        {/* Nav row - starts at the same content column as the other sections */}
        <div className="h-full flex items-center justify-end md:justify-between px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem]">
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-[30px] text-[12px] font-bold">
            <a
              href="#work"
              onClick={(e) => handleNavClick(e, "work")}
              className={`transition-colors ${
                active === "work"
                  ? "text-amber"
                  : "text-mute hover:text-bone"
              }`}
            >
              WORK
            </a>

            <a
              href="#about"
              onClick={(e) => handleNavClick(e, "about")}
              className={`transition-colors ${
                active === "about"
                  ? "text-amber"
                  : "text-mute hover:text-bone"
              }`}
            >
              EXPERIENCE
            </a>

            <a
              href="#services"
              onClick={(e) => handleNavClick(e, "services")}
              className={`transition-colors ${
                active === "services"
                  ? "text-amber"
                  : "text-mute hover:text-bone"
              }`}
            >
              SERVICES
            </a>

            
            <a
              href="#testimonials "
              onClick={(e) => handleNavClick(e, "testimonials")}
              className={`transition-colors ${
                active === "testimonials"
                  ? "text-amber"
                  : "text-mute hover:text-bone"
              }`}
            >
              TESTIMONIALS
            </a>

            <a
              href="#faq "
              onClick={(e) => handleNavClick(e, "faq")}
              className={`transition-colors ${
                active === "faq"
                  ? "text-amber"
                  : "text-mute hover:text-bone"
              }`}
            >
              FAQ
            </a>
            

            <a
              href="#contact"
              onClick={(e) => handleNavClick(e, "contact")}
              className={`transition-colors ${
                active === "contact"
                  ? "text-amber"
                  : "text-mute hover:text-bone"
              }`}
            >
              CONTACT
            </a>
          </nav>

          {/* Desktop Social Links */}
          <div className="hidden md:flex items-center gap-6 text-[12px] font-bold">
            <a
              href="https://x.com/rahulvkk"
              target="_blank"
              rel="noreferrer"
              className="text-mute hover:text-bone transition-colors"
            >
              TWITTER
            </a>

            <a
              href="https://rahul.vk.khandelwal78@gmail.com"
              className="text-mute hover:text-bone transition-colors"
            >
              EMAIL
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-bone"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((prev) => !prev)}
          >
            <span className="relative block w-6 h-4">
              <span
                className={`absolute left-0 top-0 w-6 h-px bg-bone transition-transform duration-300 ${
                  menuOpen ? "translate-y-[7px] rotate-45" : ""
                }`}
              />
              <span
                className={`absolute left-0 bottom-0 w-6 h-px bg-bone transition-transform duration-300 ${
                  menuOpen ? "-translate-y-[7px] -rotate-45" : ""
                }`}
              />
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out border-t border-line/60 ${
          menuOpen ? "max-h-96" : "max-h-0 border-t-0"
        }`}
      >
        <nav className="flex flex-col px-6 py-4 gap-4 text-sm bg-ink">
          <a
            href="#work"
            onClick={(e) => handleNavClick(e, "work")}
            className={active === "work" ? "text-amber" : "text-mute"}
          >
            WORK
          </a>

          <a
            href="#experience"
            onClick={(e) => handleNavClick(e, "experience")}
            className={active === "experience" ? "text-amber" : "text-mute"}
          >
            EXPERIENCE
          </a>

          <a
            href="#services"
            onClick={(e) => handleNavClick(e, "services")}
            className={active === "services" ? "text-amber" : "text-mute"}
          >
            SERVICES
          </a>

          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, "contact")}
            className={active === "contact" ? "text-amber" : "text-mute"}
          >
            CONTACT
          </a>

          <a
            href="https://x.com/rahulvkk"
            target="_blank"
            rel="noreferrer"
            className="text-mute"
          >
            TWITTER
          </a>

          <a href="https://rahul.vk.khandelwal78@gmail.com" className="text-mute">
            EMAIL
          </a>
        </nav>
      </div>
    </header>
  );
}