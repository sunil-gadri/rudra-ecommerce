const dashedLine = {
  borderTopWidth: '1px',
  borderTopStyle: 'dashed',
  borderImage:
    'repeating-linear-gradient(to right, rgba(255,255,255,0.28) 0 2px, transparent 2px 4px) 1',
}

export default function Footer() {
  return (
    <footer className="bg-[#0d0d0d]" style={dashedLine}>
      <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pr-[8rem] py-8 sm:py-10">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 sm:gap-0">
          <p className="text-[13px] text-[#9e9e9e] text-left">
          </p>

          <a
            href="#"
            onClick={(e) => {
              e.preventDefault()
              window.scrollTo({ top: 0, behavior: "smooth" })
            }}
            className="text-[12px] font-semibold uppercase tracking-[0.15em] text-[#9e9e9e] hover:text-[#f7f8f8] transition-colors"
          >
            Back to top
          </a>
        </div>
      </div>
    </footer>
  )
}