import { useReveal } from "../hooks/useReveal";
import PortraitImage from "../../public/images/about.JPEG";

export default function About() {
  const ref = useReveal();

  return (
    <section
      id="about"
      className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] py-16 lg:py-28 scroll-mt-16"
    >
      {/* About Heading */}
      <div className="relative inline-block border border-dashed border-[#3a3a3a] px-4 py-1 mb-8 lg:mb-10">
        <span className="text-[10px] uppercase tracking-[0.25em] font-semibold text-white">
          About
        </span>

        {/* Corner Dots */}
        <span className="absolute top-0 left-0 w-1 h-1 bg-white rounded-full -translate-x-1/2 -translate-y-1/2"></span>
        <span className="absolute top-0 right-0 w-1 h-1 bg-white rounded-full translate-x-1/2 -translate-y-1/2"></span>
        <span className="absolute bottom-0 left-0 w-1 h-1 bg-white rounded-full -translate-x-1/2 translate-y-1/2"></span>
        <span className="absolute bottom-0 right-0 w-1 h-1 bg-white rounded-full translate-x-1/2 translate-y-1/2"></span>
      </div>

      <div
        ref={ref}
        className="reveal grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_350px] gap-10 lg:gap-20 items-center"
      >
        {/* Left Content */}
        <div className="w-full order-2 lg:order-1">
          <h2 className="text-[36px] sm:text-[44px] lg:text-[62px] leading-[1.1] lg:leading-[1.05] font-bold tracking-tight text-white">
            A little about me
          </h2>

          <p className="mt-6 text-[15px] lg:text-[16px] leading-6 text-[#9b9b9b]">
            It’s been quite a ride. I started my journey in software development nearly three decades ago, back when the web was just finding its footing. What began as a simple love for building things and solving puzzles has evolved into a career of designing digital ecosystems that businesses truly rely on. I’ve seen the tech landscape change entirely, but the core challenge remains the same: making complex things feel simple.
          </p>

          <p className="mt-5 text-[15px] lg:text-[16px] leading-6 text-[#9b9b9b]">
            Over the years, my role naturally shifted from writing every single line of code to guiding the bigger picture. Today, my sweet spot is in software management and system architecture. Instead of just fixing bugs, I help brands map out the smartest way to build robust platforms—whether that’s untangling a messy CRM system, planning out a full-stack mobile app, or making sure all the backend APIs actually talk to each other the way they’re supposed to.
          </p>

          <p className="mt-5 text-[15px] lg:text-[16px] leading-6 text-[#9b9b9b]">
           I love stepping in to take the technical stress off a team's shoulders so they can focus on growing their business. I’m always open to discussing new challenges, mentoring teams, or partnering on projects where thoughtful architecture can make all the difference.
          </p>
        </div>

        {/* Right Image */}
        <div className="flex justify-center lg:justify-end order-1 lg:order-2">
          <div className="relative w-[240px] h-[340px] sm:w-[300px] sm:h-[420px] lg:w-[350px] lg:h-[500px]">
            <div
              className="absolute inset-0 overflow-hidden rounded-2xl border border-[#2a2a2a]"
              style={{
                clipPath:
                  "polygon(38% 0%,100% 0%,100% 100%,0% 100%,0% 30%,14% 30%,14% 18%,26% 18%,26% 8%,38% 8%)",
              }}
            >
              <img
                src={PortraitImage}
                alt="Portrait"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}