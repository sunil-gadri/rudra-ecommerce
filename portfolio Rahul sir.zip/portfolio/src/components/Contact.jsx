import { Mail, FileText } from 'lucide-react'

// Custom-spaced dashed line (native border-dashed can't control dash/gap size)
const dashedLine = {
  borderTopWidth: '1px',
  borderTopStyle: 'dashed',
  borderImage:
    'repeating-linear-gradient(to right, rgba(255,255,255,0.28) 0 2px, transparent 2px 4px) 1',
}
const dashedLineBottom = {
  borderBottomWidth: '1px',
  borderBottomStyle: 'dashed',
  borderImage:
    'repeating-linear-gradient(to right, rgba(255,255,255,0.28) 0 2px, transparent 2px 4px) 1',
}
const dashedBox = {
  borderWidth: '1px',
  borderStyle: 'dashed',
  borderImage:
    'repeating-linear-gradient(to right, rgba(255,255,255,0.35) 0 2px, transparent 2px 4px) 1',
}

function LinkedInIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M6.94 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0ZM3.25 8.75h3.4V21h-3.4V8.75Zm6.2 0h3.26v1.68h.05c.45-.85 1.56-1.75 3.21-1.75 3.44 0 4.08 2.26 4.08 5.2V21h-3.4v-6.4c0-1.53-.03-3.5-2.13-3.5-2.14 0-2.47 1.67-2.47 3.39V21H9.45V8.75Z" />
    </svg>
  )
}

function InstagramIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...props}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
    </svg>
  )
}

function CosmosIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <circle cx="12" cy="4.5" r="1.6" />
      <circle cx="19.5" cy="12" r="1.6" />
      <circle cx="12" cy="19.5" r="1.6" />
      <circle cx="4.5" cy="12" r="1.6" />
      <circle cx="12" cy="12" r="2.2" />
    </svg>
  )
}
function XIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M18.9 2H22l-7.5 8.6L23.3 22H16.9l-5-6.5L6.1 22H3l8-9.2L2.2 2h6.6l4.6 6L18.9 2Zm-1.1 18h1.7L7.2 3.9H5.4L17.8 20Z" />
    </svg>
  )
}

function BehanceIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M4 6h6.3c1.6 0 2.8.4 3.6 1.1.8.7 1.2 1.6 1.2 2.7 0 .7-.2 1.3-.5 1.8-.3.5-.8.9-1.4 1.2.8.3 1.4.7 1.8 1.3.4.6.6 1.3.6 2.1 0 .8-.2 1.5-.5 2.1a3.6 3.6 0 0 1-1.5 1.4c-.6.3-1.3.5-2.1.6-.4 0-.9.1-1.5.1H4V6Zm2.7 5.1h3.1c.7 0 1.2-.1 1.6-.4.4-.3.6-.7.6-1.3 0-.6-.2-1-.6-1.3-.4-.3-.9-.4-1.6-.4H6.7v3.4Zm0 5.6h3.4c.8 0 1.4-.1 1.8-.4.4-.3.6-.8.6-1.4 0-.6-.2-1.1-.6-1.4-.4-.3-1-.4-1.8-.4H6.7v3.6ZM15 8.3h5.6v1.4H15V8.3Zm2.8 3.1c1.3 0 2.4.4 3.1 1.2.7.8 1.1 1.9 1.1 3.2v.6h-6.2c0 .7.3 1.3.7 1.7.4.4 1 .6 1.6.6.5 0 .9-.1 1.2-.3.3-.2.6-.5.7-.9h2.2c-.2.9-.7 1.6-1.5 2.1-.7.5-1.6.8-2.7.8-1.4 0-2.6-.4-3.4-1.3-.8-.9-1.2-2-1.2-3.4 0-1.4.4-2.5 1.2-3.4.9-.6 2-1 3.2-1Zm2.1 3.6c0-.6-.2-1.1-.6-1.5-.4-.4-.9-.5-1.5-.5-.6 0-1.1.2-1.5.5-.4.4-.6.9-.7 1.5h4.3Z" />
    </svg>
  )
}

function SaveeIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M6.5 3a4.5 4.5 0 0 0 0 9 4.5 4.5 0 1 1 0 9M13 12h5.5a4.5 4.5 0 1 0-4.5-4.5" strokeLinecap="round" stroke="currentColor" fill="none" strokeWidth="1.8" />
    </svg>
  )
}

const links = [
  { label: 'Email', href: 'https://rahul.vk.khandelwal78@gmail.com', Icon: Mail },
  { label: 'Twitter', href: 'https://x.com/rahulvkk', Icon: XIcon },
  { label: 'LinkedIn', href: 'https://in.linkedin.com/in/rahulvkkhandelwal', Icon: LinkedInIcon },
]

export default function Contact() {
  return (
    <section
      id="contact"
      className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] py-16 sm:py-20 lg:py-28 scroll-mt-16"
    >
      <div className="relative inline-block px-4 py-1.5" style={dashedBox}>
        <span className="text-[11px] uppercase tracking-[0.2em] font-bold text-[#f7f8f8]">
          Contact
        </span>
        <span className="absolute top-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 -translate-y-1/2" />
        <span className="absolute top-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 -translate-y-1/2" />
        <span className="absolute bottom-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 translate-y-1/2" />
        <span className="absolute bottom-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="mt-6 flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6 sm:gap-8">
        <h2 className="text-[32px] leading-[1.15] font-bold text-[#f7f8f8] sm:text-[40px] sm:leading-[1.1] md:text-[50px] md:leading-[1.08] max-w-xl">
          Available for new opportunities
        </h2>
        <p className="text-[#9e9e9e] text-base sm:text-lg leading-relaxed max-w-sm lg:pt-3">
          Backed by 27 years of executive tech leadership. I partner with scaling brands for complex software management and bespoke technical architecture with zero-risk SLA delivery.
        </p>
      </div>

      <div className="mt-10 sm:mt-16 grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-4 gap-x-8">
        {links.map(({ label, href, Icon }, i) => (
          <a
            key={label}
            href={href}
            target={href.startsWith('http') ? '_blank' : undefined}
            rel={href.startsWith('http') ? 'noreferrer' : undefined}
            className="flex items-center gap-2.5 py-4 text-[#f7f8f8] hover:text-[#9e9e9e] transition-colors"
            style={i < 4 ? { ...dashedLine, ...dashedLineBottom } : dashedLineBottom}
          >
            <Icon className="w-[18px] h-[18px] text-[#9e9e9e] shrink-0" strokeWidth={1.75} aria-hidden="true" />
            <span className="text-base font-medium">{label}</span>
          </a>
        ))}
      </div>
    </section>
  )
}