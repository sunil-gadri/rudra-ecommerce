import { Feather, PanelLeft, Smartphone, Blend, Atom } from 'lucide-react'
import { useReveal } from '../hooks/useReveal'

function ServiceCard({ title, description, price, items, ctaLabel, ctaHref }) {
  const ref = useReveal()
  return (
    <div
      ref={ref}
      className="reveal relative border border-dotted border-white/[0.12] p-6 lg:p-8 flex flex-col"
    >
      {/* Corner Dots - square, not round */}
      <span className="absolute top-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 -translate-y-1/2" />
      <span className="absolute top-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 -translate-y-1/2" />
      <span className="absolute bottom-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 translate-y-1/2" />
      <span className="absolute bottom-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 translate-y-1/2" />

      <h3 className="text-lg lg:text-xl font-medium text-[#f7f8f8]">{title}</h3>
      <p className="text-[#9e9e9e] mt-3 text-[14px] lg:text-[15px] leading-relaxed">{description}</p>
      <p className="text-[#f7f8f8] mt-6 text-[14px] lg:text-[15px] font-semibold">{price}</p>

      <ul className="mt-8 space-y-4 flex-1">
        {items.map(({ icon: Icon, label }) => (
          <li key={label} className="flex items-center gap-3 text-[14px] lg:text-[15px] text-[#9e9e9e]">
            <Icon className="w-4 h-4 text-[#9e9e9e] shrink-0" strokeWidth={1.75} aria-hidden="true" />
            {label}
          </li>
        ))}
      </ul>

      < a
        href={ctaHref}
        className="mt-8 inline-flex items-center justify-between rounded-full bg-[#f7f8f8] px-5 lg:px-6 py-3.5 lg:py-4 text-xs font-semibold uppercase tracking-[0.1em] text-[#111111] hover:bg-amber transition-colors"
      >
        {ctaLabel}
        <span aria-hidden="true">&rsaquo;</span>
      </a>
    </div>
  )
}

export default function Services() {
  return (
    <section
      id="services"
      className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] py-16 lg:py-28 scroll-mt-16"
    >
      <div className="relative inline-block border border-dashed border-[#3a3a3a] px-4 py-1 mb-8 lg:mb-10">
        <span className="text-[10px] uppercase tracking-[0.25em] font-semibold text-white">
          Services
        </span>

        {/* Corner Dots */}
        <span className="absolute top-0 left-0 w-1 h-1 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
        <span className="absolute top-0 right-0 w-1 h-1 bg-white rounded-full translate-x-1/2 -translate-y-1/2" />
        <span className="absolute bottom-0 left-0 w-1 h-1 bg-white rounded-full -translate-x-1/2 translate-y-1/2" />
        <span className="absolute bottom-0 right-0 w-1 h-1 bg-white rounded-full translate-x-1/2 translate-y-1/2" />
      </div>

     <h2 className="text-pretty text-[28px] leading-[34px] sm:text-[34px] sm:leading-[40px] font-semibold text-ink-primary md:text-[55px] md:leading-[56px] max-w-4xl">
  From custom CRM technology stack to comprehensive <br /> mobile enterprise architecture.
</h2>

      <div className="mt-8 lg:mt-10 grid md:grid-cols-2 gap-5 lg:gap-6">
        <ServiceCard
          title="Enterprise CRM Architecture & Management"
          description="Bespoke, scalable CRM solutions engineered to automate complex business logic, integrate seamlessly via APIs, and manage high-volume data securely."
          price="From $5,500"
          items={[
            { icon: Feather, label: 'Custom ERP/CRM system blueprinting' },
            { icon: PanelLeft, label: 'Automated workflow & data routing' },
            { icon: Smartphone, label: 'Deep third-party API integrations' },
            { icon: Blend, label: 'Ongoing software management & scaling' },
          ]}
          ctaLabel="DISCUSS CRM ARCHITECTURE"
          ctaHref="#contact"
        />

        <ServiceCard
          title="Full-Stack Mobile App Engineering"
          description="End-to-end technical leadership and development of resilient, high-performance mobile applications backed by robust, custom backend infrastructure."
          price="From $8,500"
          items={[
            { icon: Feather, label: 'Cross-platform mobile architecture' },
            { icon: Blend, label: 'Scalable backend API development' },
            { icon: PanelLeft, label: 'Real-time data synchronization' },
            { icon: Atom, label: 'Zero-risk, SLA-backed deployment' },
          ]}
          ctaLabel="DISCUSS MOBILE DEVELOPMENT"
          ctaHref="#contact"
        />
      </div>
    </section>
  )
}