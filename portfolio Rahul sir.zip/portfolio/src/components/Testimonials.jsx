import { useReveal } from '../hooks/useReveal'

import Review1 from "../../public/images/review1.png";


export default function Testimonials() {
  const ref = useReveal()
  return (
    <section
      id="testimonials"
      className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] py-16 scroll-mt-16"
    >
      <div className="relative inline-block border border-dashed border-white/[0.25] px-4 py-1.5">
        <span className="text-[11px] uppercase tracking-[0.2em] font-bold text-[#f7f8f8]">
          Testimonials
        </span>

        {/* Corner Dots - square */}
        <span className="absolute top-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 -translate-y-1/2" />
        <span className="absolute top-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 -translate-y-1/2" />
        <span className="absolute bottom-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 translate-y-1/2" />
        <span className="absolute bottom-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 translate-y-1/2" />
      </div>

      <h2 className="mt-6 text-[36px] leading-[1.1] sm:text-[44px] md:text-[50px] lg:text-[64px] lg:leading-[1.05] font-bold text-[#f7f8f8]">
        Kind words.
      </h2>

      <div className="mt-8 lg:mt-12 border-t border-dotted border-white/[0.14]" />

      <blockquote
        ref={ref}
        className="reveal mt-8 lg:mt-12 text-lg sm:text-xl md:text-[27px] leading-snug text-[#9e9e9e] max-w-4xl"
      >
        &ldquo;He is way above. Not only did we gain a developer, but we gained a Fractional Principal Architect that turned our complicated financial logistics into a very secure web portal. His high-end software management and risk-free delivery model are precisely what enterprise growth needs.&rdquo;
      </blockquote>

      <div className="mt-8 lg:mt-10 flex items-center gap-3">
        <img
          src={Review1}
          alt="Rohit Khandelwal"
          className="w-11 h-11 rounded-full object-cover border border-white/10 shrink-0"
        />
        <p className="text-[15px]">
          <span className="block text-[#f7f8f8] font-semibold">Rohit Khandelwal</span>
          <span className="block text-[#9e9e9e]">Founder, MoneyMatters</span>
        </p>
      </div>

      <div className="mt-8 lg:mt-12 border-t border-dotted border-white/[0.14]" />
    </section>
  )
}