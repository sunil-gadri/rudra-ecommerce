import { useState } from "react";
import { ChevronRight, X } from "lucide-react";
import ProjectImage from "../../public/images/project1/p1.png";
import ProjectImage2 from "../../public/images/project1/p2.png";
import ProjectImage3 from "../../public/images/project1/p3.png";
import ProjectImage4 from "../../public/images/project1/p4.png";
import ProjectImage5 from "../../public/images/project1/p5.png";
import ProjectImage6 from "../../public/images/project1/p6.png";


import P1 from "../../public/images/project2/p1.png";
import P2 from "../../public/images/project2/p2.png";
import P3 from "../../public/images/project2/p3.png";
import P4 from "../../public/images/project2/p4.png";


import P31 from "../../public/images/project3/p1.png";
import P32 from "../../public/images/project3/p2.png";
import P33 from "../../public/images/project3/p3.png";


import P41 from "../../public/images/project4/p1.png";
import P42 from "../../public/images/project4/p2.png";


import P51 from "../../public/images/project5/p1.png";
import P52 from "../../public/images/project5/p2.png";
import P53 from "../../public/images/project5/p3.png";
import P54 from "../../public/images/project5/p4.png";

import P61 from "../../public/images/project6/p1.png";

import P71 from "../../public/images/project7/p1.png";
import P72 from "../../public/images/project7/p2.png";
import P73 from "../../public/images/project7/p3.png";


import P81 from "../../public/images/project8/p1.png";
import P82 from "../../public/images/project8/p2.png";
import P83 from "../../public/images/project8/p3.png";



export default function Projects() {
  const [lightboxImage, setLightboxImage] = useState(null);

  const openLightbox = (img) => setLightboxImage(img);
  const closeLightbox = () => setLightboxImage(null);

  return (
    <section id="work"  className="py-16 sm:py-20 md:py-28 bg-[#0b0b0b]">

{/* Project1 */}
      <div  className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem]">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4">
          {/* Left */}
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <h2 className="text-[16px] font-bold text-white">PVAR & ASSOCIATES</h2>
            <div className="w-px h-4 bg-[#3a3a3a]" />
            <p className="text-[14px] text-[#9b9b9b]">
              Established chartered accountancy firm in India.
            </p>
          </div>
          {/* Right */}
          <a
            href="https://pvarassociates.in"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-[12px] font-semibold text-[#bdbdbd] hover:text-white transition shrink-0"
          >
            VIEW PROJECT
            <ChevronRight size={12} />
          </a>
        </div>

        {/* Project Images */}
        <button
          type="button"
          onClick={() => openLightbox(ProjectImage)}
          className="block w-full overflow-hidden rounded-2xl border border-[#2a2a2a]"
        >
          <img
            src={ProjectImage}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(ProjectImage2)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={ProjectImage2}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(ProjectImage3)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={ProjectImage3}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(ProjectImage4)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={ProjectImage4}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(ProjectImage5)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={ProjectImage5}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>
        <button
          type="button"
          onClick={() => openLightbox(ProjectImage6)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={ProjectImage6}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>
      </div>

     {/* Project2 */}
      <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] mt-16 sm:mt-20 md:mt-24">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4">
          {/* Left */}
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <h2 className="text-[16px] font-bold text-white">AVI</h2>
            <div className="w-px h-4 bg-[#3a3a3a]" />
            <p className="text-[14px] text-[#9b9b9b]">
              AC FIXER SERVICE CRM 
            </p>
          </div>
          {/* Right */}
            <a
              href="https://mail.google.com/mail/?view=cm&fs=1&to=rahul.vk.khandelwal78@gmail.com"
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => {
                e.preventDefault();
                window.open(
                  "https://mail.google.com/mail/?view=cm&fs=1&to=rahul.vk.khandelwal78@gmail.com",
                  "_blank"
                );
              }}
              className="flex items-center gap-2 text-[12px] font-semibold text-[#bdbdbd] hover:text-white transition shrink-0"
            >
              LET'S TALK
              <ChevronRight size={12} />
            </a>
        </div>

        {/* Project Images */}
        <button
          type="button"
          onClick={() => openLightbox(P1)}
          className="block w-full overflow-hidden rounded-2xl border border-[#2a2a2a]"
        >
          <img
            src={P1}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(P2)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P2}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(P3)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P3}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
          
        </button>
         <button
          type="button"
          onClick={() => openLightbox(P4)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P4}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>
      </div>


      {/* Project3 */}
       <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] mt-16 sm:mt-20 md:mt-24">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4">
          {/* Left */}
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <h2 className="text-[16px] font-bold text-white">Dr. Harsh Udawat</h2>
            <div className="w-px h-4 bg-[#3a3a3a]" />
            <p className="text-[14px] text-[#9b9b9b]">
              Gastroenterology Specialist in India.
            </p>
          </div>
          {/* Right */}
          <a
              href="https://mail.google.com/mail/?view=cm&fs=1&to=rahul.vk.khandelwal78@gmail.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-[12px] font-semibold text-[#bdbdbd] hover:text-white transition shrink-0"
            >
              LET'S TALK
              <ChevronRight size={12} />
            </a>  
        </div>

        {/* Project Images */}
        <button
          type="button"
          onClick={() => openLightbox(P31)}
          className="block w-full overflow-hidden rounded-2xl border border-[#2a2a2a]"
        >
          <img
            src={P31}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(P32)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P32}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(P33)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P33}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>
       
      </div>

      {/* Project4 */}
      <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] mt-16 sm:mt-20 md:mt-24">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4">
          {/* Left */}
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <h2 className="text-[16px] font-bold text-white">Money Matters</h2>
            <div className="w-px h-4 bg-[#3a3a3a]" />
            <p className="text-[14px] text-[#9b9b9b]">
            Financial Advisory Firm in India
            </p>
          </div>
          {/* Right */}
          <a
            href="https://moneymatters.co.in"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-[12px] font-semibold text-[#bdbdbd] hover:text-white transition shrink-0"
          >
            VIEW PROJECT
            <ChevronRight size={12} />
          </a>
        </div>

        {/* Project Images */}
        <button
          type="button"
          onClick={() => openLightbox(P41)}
          className="block w-full overflow-hidden rounded-2xl border border-[#2a2a2a]"
        >
          <img
            src={P41}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(P42)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P42}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

      </div>

      {/* Project5 */}

       <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] mt-16 sm:mt-20 md:mt-24">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4">
          {/* Left */}
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <h2 className="text-[16px] font-bold text-white">InviteHive</h2>
            <div className="w-px h-4 bg-[#3a3a3a]" />
            <p className="text-[14px] text-[#9b9b9b]">
            An Invitation & Sharing Mobile App
            </p>
          </div>
          {/* Right */}
          <a
              href="https://mail.google.com/mail/?view=cm&fs=1&to=rahul.vk.khandelwal78@gmail.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-[12px] font-semibold text-[#bdbdbd] hover:text-white transition shrink-0"
            >
              LET'S TALK
              <ChevronRight size={12} />
            </a>  
        </div>

        {/* Project Images */}
        <button
          type="button"
          onClick={() => openLightbox(P51)}
          className="block w-full overflow-hidden rounded-2xl border border-[#2a2a2a]"
        >
          <img
            src={P51}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(P52)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P52}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

        <button
          type="button"
          onClick={() => openLightbox(P53)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P53}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

         <button
          type="button"
          onClick={() => openLightbox(P54)}
          className="block w-full overflow-hidden rounded-2xl mt-6 sm:mt-10 border border-[#2a2a2a]"
        >
          <img
            src={P54}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>


      </div>


{/* Project7 */}

      <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] mt-16 sm:mt-20 md:mt-24">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4">
          {/* Left */}
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <h2 className="text-[16px] font-bold text-white">ZedBox</h2>
            <div className="w-px h-4 bg-[#3a3a3a]" />
            <p className="text-[14px] text-[#9b9b9b]">
            Industrial Manufacturer Based in Jaipur.
            </p>
          </div>
          {/* Right */}
          <a
            href="https://zedbox.co.in"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-[12px] font-semibold text-[#bdbdbd] hover:text-white transition shrink-0"
          >
            VIEW PROJECT
            <ChevronRight size={12} />
          </a>
        </div>

        {/* Project Images */}
       <button
  type="button"
  onClick={() => openLightbox(P71)}
  className="block w-full overflow-hidden rounded-2xl border border-[#2a2a2a]"
>
  <img src={P71} alt="Project" className="w-full rounded-2xl hover:scale-[1.02] transition duration-500" />
</button>

 <button
  type="button"
  onClick={() => openLightbox(P72)}
  className="block w-full overflow-hidden rounded-2xl mt-6 border border-[#2a2a2a]" 
>
  <img src={P72} alt="Project" className="w-full rounded-2xl hover:scale-[1.02] transition duration-500" />
</button>

 <button
  type="button"
  onClick={() => openLightbox(P73)}
  className="block w-full overflow-hidden rounded-2xl mt-6 border border-[#2a2a2a]"   
>
  <img src={P73} alt="Project" className="w-full rounded-2xl hover:scale-[1.02] transition duration-500" />
</button>
      </div>

{/* Project6 */}

      <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] mt-16 sm:mt-20 md:mt-24">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4">
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <h2 className="text-[16px] font-bold text-white">Kanha Home Tuition</h2>
            <div className="w-px h-4 bg-[#3a3a3a]" />
            <p className="text-[14px] text-[#9b9b9b]">
            Prominent educational platform in India.
            </p>
          </div>
          <a
            href="https://kanhahometutions.com"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-[12px] font-semibold text-[#bdbdbd] hover:text-white transition shrink-0"
          >
            VIEW PROJECT
            <ChevronRight size={12} />
          </a>
        </div>

        <button
          type="button"
          onClick={() => openLightbox(P61)}
          className="block w-full overflow-hidden rounded-2xl border border-[#2a2a2a]"
        >
          <img
            src={P61}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

      </div>


      {/* Project8 */}

      <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] mt-16 sm:mt-20 md:mt-24">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4">
          {/* Left */}
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <h2 className="text-[16px] font-bold text-white">DigiWorker</h2>
            <div className="w-px h-4 bg-[#3a3a3a]" />
            <p className="text-[14px] text-[#9b9b9b]">
            Indian temporary employment staffing agency.
            </p>
          </div>
          {/* Right */}
          <a
              href="https://mail.google.com/mail/?view=cm&fs=1&to=rahul.vk.khandelwal78@gmail.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-[12px] font-semibold text-[#bdbdbd] hover:text-white transition shrink-0"
            >
              LET'S TALK
              <ChevronRight size={12} />
            </a>  
        </div>

        {/* Project Images */}
        <button
          type="button"
          onClick={() => openLightbox(P81)}
          className="block w-full overflow-hidden rounded-2xl border border-[#2a2a2a]"
        >
          <img
            src={P81}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>


        <button
          type="button"
          onClick={() => openLightbox(P81)}
          className="block w-full overflow-hidden rounded-2xl mt-6 border border-[#2a2a2a]"
        >
          <img
            src={P82}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

         <button
          type="button"
          onClick={() => openLightbox(P83)}
          className="block w-full overflow-hidden rounded-2xl mt-6 border border-[#2a2a2a]"
        >
          <img
            src={P83}
            alt="Project"
            className="w-full rounded-2xl hover:scale-[1.02] transition duration-500"
          />
        </button>

      </div>

      {/* Lightbox Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 sm:p-6"
          onClick={closeLightbox}
        >
          <button
            type="button"
            onClick={closeLightbox}
            aria-label="Close"
            className="absolute top-4 right-4 sm:top-6 sm:right-6 z-50 flex items-center justify-center w-10 h-10 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-white hover:bg-[#2a2a2a] transition"
          >
            <X size={20} />
          </button>
          <img
            src={lightboxImage}
            alt="Project preview"
            onClick={(e) => e.stopPropagation()}
            className="max-w-full max-h-full rounded-2xl object-contain"
          />
        </div>
      )}
    </section>
  );
}