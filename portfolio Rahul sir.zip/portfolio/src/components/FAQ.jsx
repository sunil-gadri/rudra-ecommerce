import { useState } from 'react'
import { useReveal } from '../hooks/useReveal'

function FAQItem({ question, answer, isOpen, onToggle }) {
  return (
    <div className="border-t border-dotted border-white/[0.14] py-5 lg:py-6">
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-3 lg:gap-4 text-left"
        aria-expanded={isOpen}
      >
        <span
          className={`text-[#9e9e9e] text-xl leading-none shrink-0 transition-transform duration-300 ${
            isOpen ? 'rotate-45' : ''
          }`}
          aria-hidden="true"
        >
          +
        </span>
        <span className="text-base lg:text-lg font-semibold text-[#f7f8f8]">{question}</span>
      </button>
      <div
        className={`grid transition-all duration-300 ease-in-out ${
          isOpen ? 'grid-rows-[1fr] opacity-100 mt-3' : 'grid-rows-[0fr] opacity-0'
        }`}
      >
        <p className="overflow-hidden pl-7 lg:pl-9 text-[#9e9e9e] text-[14px] lg:text-[15px] leading-relaxed max-w-xl">
          {answer}
        </p>
      </div>
    </div>
  )
}

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0)
  const ref = useReveal()

  return (
    <section
      id="faq"
      className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] py-16 scroll-mt-16"
    >
      <div className="relative inline-block border border-dashed border-white/[0.25] px-4 py-1.5">
        <span className="text-[11px] uppercase tracking-[0.2em] font-bold text-[#f7f8f8]">
          FAQs
        </span>

        {/* Corner Dots - square */}
        <span className="absolute top-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 -translate-y-1/2" />
        <span className="absolute top-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 -translate-y-1/2" />
        <span className="absolute bottom-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 translate-y-1/2" />
        <span className="absolute bottom-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 translate-y-1/2" />
      </div>

      <h2 className="mt-6 text-[36px] leading-[1.1] sm:text-[44px] md:text-[50px] lg:text-[64px] lg:leading-[1.05] font-bold text-[#f7f8f8]">
        Questions, answered.
      </h2>

      <div ref={ref} className="reveal mt-8 lg:mt-10 border-b border-dashed border-white/[0.14]">
        <FAQItem
          question="What type of architectural projects do you take on?"
          answer="We have specialized in software management that is highly complicated, customized Shopify architecture, custom middleware, and deep ERP/CRM API integration in scalable organizations."
          isOpen={openIndex === 0}
          onToggle={() => setOpenIndex(openIndex === 0 ? -1 : 0)}
        />
        <FAQItem
          question="How do you integrate with existing enterprise teams?"
          answer="I function as a fractional Principal Software Architect and work closely with your team members to ensure successful management of the technology roadmap."
          isOpen={openIndex === 1}
          onToggle={() => setOpenIndex(openIndex === 1 ? -1 : 1)}
        />
        <FAQItem
          question="Do you build custom middleware and API integrations?"
          answer="Yes. Beyond frontend implementation, our main areas of focus are creating secure connections between data, automated workflow management, and complex third-party system synchronization."
          isOpen={openIndex === 2}
          onToggle={() => setOpenIndex(openIndex === 2 ? -1 : 2)}
        />
        <FAQItem
          question="Do you manage the full software deployment lifecycle?"
          answer="Absolutely. We provide complete software management from start to finish—this means from the first technical discovery all the way through to the design and performance Liquid engineering and QA testing."
          isOpen={openIndex === 3}
          onToggle={() => setOpenIndex(openIndex === 3 ? -1 : 3)}
        />
        <FAQItem
          question="Why partner with a Principal Architect over a standard agency?"
          answer="You get 27 years of tech experience and the execution of over 2,000 projects. We provide zero-risk SLA engineering, not templating."
          isOpen={openIndex === 4}
          onToggle={() => setOpenIndex(openIndex === 4 ? -1 : 4)}
        />
        <FAQItem
          question="How do we initiate the technical discovery phase?"
          answer="First we perform a full technical audit and requirement gathering to plan your system architecture before we write one line of code."
          isOpen={openIndex === 5}
          onToggle={() => setOpenIndex(openIndex === 5 ? -1 : 5)}
        />
      </div>
    </section>
  )
}