import { ChevronRight } from "lucide-react";

export default function Hero() {
  return (
    <section className="pt-36 md:pt-60 pb-24 md:pb-32">
      <div className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem]">
        <div className="w-full max-w-[900px]">

          {/* Small Tag */}
          <div className="mb-8">
           <span className="inline-flex items-center rounded-[10px] border-2 border-white px-1 py-0 text-[12px] font-semibold">
  OPEN
</span>

            <span className="ml-3 text-[16px] font-bold">
                 For technical leadership roles
            </span>
          </div>

          {/* Heading */}
          <h1 className="text-left font-bold leading-[0.95] tracking-[-0.04em]
                         text-[36px]
                         sm:text-[56px]
                         md:text-[72px]
                         lg:text-[92px]
                         xl:text-[64px]">
            Lead software architect
            <br />
             and software management
            <br />
           expert for scalable tech.
          </h1>

          {/* Buttons */}
         <div className="mt-16 flex flex-col sm:flex-row items-stretch sm:items-center gap-4 sm:gap-6">
  {/* View Work */}
  <a
    href="#work"
    className="inline-flex items-center justify-between gap-8 rounded-full bg-[#F2F2F2] px-4 h-10 w-full sm:w-auto sm:min-w-[220px] text-[14px] font-semibold text-black transition-all duration-300 hover:bg-white"
  >
    <span>VIEW WORK</span>
    <ChevronRight size={22} strokeWidth={2.8} />
  </a>

  {/* View Resume */}
  <a
    href="#about"
    className="inline-flex items-center justify-between gap-8 rounded-full bg-[#F2F2F2] px-4 h-10 w-full sm:w-auto sm:min-w-[220px] text-[14px] font-semibold text-black transition-all duration-300 hover:bg-white"
  >
    <span>ABOUT ME</span>
    <ChevronRight size={22} strokeWidth={2.8} />
  </a>
</div>

        </div>
      </div>
    </section>
  );
}