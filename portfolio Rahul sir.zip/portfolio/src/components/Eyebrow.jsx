// Small corner-bracket label used above every section heading,
// echoing a lab-instrument / spec-sheet marker rather than plain text.
export default function Eyebrow({ children }) {
  return (
    <div className="inline-flex items-center gap-1.5 font-mono text-xs tracking-widest uppercase text-mute mb-4">
      <span className="w-1.5 h-1.5 border-t border-l border-amber" aria-hidden="true" />
      {children}
      <span className="w-1.5 h-1.5 border-b border-r border-amber" aria-hidden="true" />
    </div>
  )
}
