export default function BrandTag() {
  return (
    <div className="fixed bottom-6 left-6 sm:left-10 z-40 pointer-events-none">
      <span className="font-display text-[12px] font-bold uppercase tracking-[0.15em] text-mute">
        © 2026 Infomagine
      </span>
    </div>
  );
}