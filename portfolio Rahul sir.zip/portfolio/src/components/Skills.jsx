import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Cpu, Database, Gamepad2, Server, Code2, ChevronRight, Check, X } from 'lucide-react';

// Same dashed-border technique used in Timeline.jsx — background-image dashes
// (one gradient per axis) instead of border-image, so all 4 sides render
// consistently regardless of box width.
const dashColor = 'rgba(255,255,255,0.35)';
const dashedBox = {
  backgroundImage: `
    linear-gradient(to right, ${dashColor} 50%, transparent 0%),
    linear-gradient(to right, ${dashColor} 50%, transparent 0%),
    linear-gradient(${dashColor} 50%, transparent 0%),
    linear-gradient(${dashColor} 50%, transparent 0%)
  `,
  backgroundPosition: 'top left, bottom left, top left, top right',
  backgroundSize: '4px 1px, 4px 1px, 1px 4px, 1px 4px',
  backgroundRepeat: 'repeat-x, repeat-x, repeat-y, repeat-y',
};

const SKILLS_DATA = [
  {
    id: 'systems',
    iconName: 'Cpu',
    title: 'Systems & Low-Level Engineering',
    subtitle: '27 years of close-to-the-hardware experience',
    colSpan: 'lg:col-span-7',
    highlights: [
      'Performance-critical C/C++ desktop and enterprise tooling.',
      'Memory-conscious architecture for high-throughput systems.',
    ],
    items: [
      { name: 'C', level: 'Expert' },
      { name: 'C++', level: 'Expert' },
      { name: 'Win32 API', level: 'Advanced' },
      { name: 'SQL', level: 'Advanced' },
    ],
  },
  {
    id: 'databases',
    iconName: 'Database',
    title: 'Data & Databases',
    subtitle: 'Relational and cloud-native data layers',
    colSpan: 'lg:col-span-5',
    highlights: [
      'Schema design for multi-tenant SaaS platforms.',
      'Query optimization across large production datasets.',
    ],
    items: [
      { name: 'PostgreSQL', level: 'Advanced' },
      { name: 'SQL Server', level: 'Advanced' },
      { name: 'MySQL', level: 'Advanced' },
    ],
  },
  {
    id: 'backend',
    iconName: 'Server',
    title: 'Backend & Infrastructure',
    subtitle: 'Cloud-native architecture and delivery',
    colSpan: 'lg:col-span-5',
    highlights: [
      'AWS-based infrastructure for React/Node.js platforms.',
      'CI/CD, release processes, and architecture ownership.',
    ],
    items: [
      { name: 'Node.js', level: 'Expert' },
      { name: 'AWS', level: 'Advanced' },
      { name: 'ASP.NET', level: 'Advanced' },
    ],
  },
  {
    id: 'ai',
    iconName: 'Gamepad2',
    title: 'Generative AI & Pipelines',
    subtitle: 'AI-native product architecture',
    colSpan: 'lg:col-span-7',
    highlights: [
      'Generative AI pipelines integrated into production SaaS.',
      'Advising teams on scalable, AI-native engineering practice.',
    ],
    items: [
      { name: 'LLM Pipelines', level: 'Advanced' },
      { name: 'System Architecture', level: 'Expert' },
    ],
  },
  {
    id: 'frontend',
    iconName: 'Code2',
    title: 'Frontend & Design Systems',
    subtitle: 'Product-facing engineering',
    colSpan: 'lg:col-span-12',
    highlights: [
      'Design systems used across web and mobile products.',
      'Frontend architecture supporting rapid product iteration.',
    ],
    items: [
      { name: 'React', level: 'Expert' },
      { name: 'TypeScript', level: 'Advanced' },
      { name: 'Figma', level: 'Advanced' },
    ],
  },
];

const iconMap = {
  Cpu: <Cpu className="w-5 h-5 text-[#f7f8f8]" strokeWidth={1.75} />,
  Database: <Database className="w-5 h-5 text-[#f7f8f8]" strokeWidth={1.75} />,
  Gamepad2: <Gamepad2 className="w-5 h-5 text-[#f7f8f8]" strokeWidth={1.75} />,
  Server: <Server className="w-5 h-5 text-[#f7f8f8]" strokeWidth={1.75} />,
  Code2: <Code2 className="w-5 h-5 text-[#f7f8f8]" strokeWidth={1.75} />,
};

export default function Skills() {
  const [selectedCategory, setSelectedCategory] = useState(null);

  return (
    <section
      id="skills"
      className="max-w-[1400px] mx-auto px-6 sm:px-10 lg:pl-[20rem] lg:pr-[8rem] py-12 sm:py-16 lg:py-28 scroll-mt-16"
    >
      {/* Eyebrow */}
      <div className="relative inline-block px-3 sm:px-4 py-1.5" style={dashedBox}>
        <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.2em] font-bold text-[#f7f8f8]">
          Skills
        </span>
        <span className="absolute top-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 -translate-y-1/2" />
        <span className="absolute top-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 -translate-y-1/2" />
        <span className="absolute bottom-0 left-0 w-[6px] h-[6px] bg-[#f7f8f8] -translate-x-1/2 translate-y-1/2" />
        <span className="absolute bottom-0 right-0 w-[6px] h-[6px] bg-[#f7f8f8] translate-x-1/2 translate-y-1/2" />
      </div>

      {/* Header */}
      <div className="mt-6 flex flex-col gap-4 sm:gap-6 lg:gap-8">
        <h2 className="w-full text-[28px] leading-[1.15] sm:text-[36px] md:text-[50px] lg:text-[64px] lg:leading-[1.05] font-bold text-[#f7f8f8]">
          Expansive toolkit, polyglot architecture.
        </h2>
        <p className="text-[#9e9e9e] text-[14px] sm:text-[15px] leading-relaxed max-w-sm">
          No reliance on single-framework silver bullets. Deep, hands-on proficiency across
          20+ technologies, applying the right tool to every problem.
        </p>
      </div>

      {/* Bento grid */}
      <div className="mt-8 sm:mt-12 lg:mt-16 grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
        {SKILLS_DATA.map((skill) => (
          <motion.button
            key={skill.id}
            type="button"
            whileHover={{ y: -4 }}
            transition={{ duration: 0.25 }}
            onClick={() => setSelectedCategory(skill)}
            className={`group relative text-left p-5 sm:p-6 lg:p-8 transition-colors hover:bg-white/[0.02] flex flex-col justify-between gap-6 ${skill.colSpan}`}
            style={dashedBox}
          >
            <div className="space-y-4 sm:space-y-6">
              {/* Icon + view hint */}
              <div className="flex items-center justify-between">
                <div className="p-3" style={dashedBox}>
                  {iconMap[skill.iconName]}
                </div>
                <span className="text-[10px] uppercase tracking-[0.15em] text-[#9e9e9e] group-hover:text-[#f7f8f8] transition-colors">
                  View stack
                </span>
              </div>

              <div>
                <h3 className="text-lg sm:text-xl font-bold text-[#f7f8f8]">{skill.title}</h3>
                <p className="text-[13px] text-[#9e9e9e] mt-1">{skill.subtitle}</p>
              </div>

              {/* Highlights */}
              <ul className="space-y-2 text-[13px] text-[#9e9e9e]">
                {skill.highlights.map((item, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1 h-1 mt-2 shrink-0 bg-[#9e9e9e]" />
                    <span className="break-words">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Item badges */}
            <div className="pt-4 flex flex-wrap items-center gap-2" style={{ borderTopWidth: '1px', borderTopStyle: 'dashed', borderImage: 'repeating-linear-gradient(to right, rgba(255,255,255,0.28) 0 2px, transparent 2px 4px) 1' }}>
              {skill.items.slice(0, 4).map((item, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 text-[11px] font-medium text-[#9e9e9e] border border-white/10"
                >
                  {item.name}
                </span>
              ))}
              {skill.items.length > 4 && (
                <span className="text-[11px] text-[#f7f8f8] flex items-center gap-0.5">
                  +{skill.items.length - 4} more <ChevronRight size={11} />
                </span>
              )}
            </div>
          </motion.button>
        ))}
      </div>

      {/* Detail Modal */}
      {selectedCategory && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md"
          onClick={() => setSelectedCategory(null)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-2xl p-6 sm:p-8 space-y-6 bg-[#0d0d0d] relative max-h-[85vh] overflow-y-auto"
            style={dashedBox}
          >
            <button
              type="button"
              onClick={() => setSelectedCategory(null)}
              aria-label="Close"
              className="absolute top-4 right-4 sm:top-6 sm:right-6 flex items-center justify-center w-9 h-9 text-[#9e9e9e] hover:text-[#f7f8f8] transition-colors"
              style={dashedBox}
            >
              <X size={16} />
            </button>

            <div className="flex items-center gap-3 pr-10">
              <div className="p-3 shrink-0" style={dashedBox}>
                {iconMap[selectedCategory.iconName]}
              </div>
              <div className="min-w-0">
                <h3 className="text-xl sm:text-2xl font-bold text-[#f7f8f8] break-words">
                  {selectedCategory.title}
                </h3>
                <p className="text-[13px] text-[#9e9e9e]">{selectedCategory.subtitle}</p>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-[11px] uppercase tracking-[0.15em] font-bold text-[#9e9e9e]">
                Key technical highlights &amp; principles
              </h4>
              <ul className="space-y-2 text-[14px] text-[#9e9e9e]">
                {selectedCategory.highlights.map((h, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="w-4 h-4 text-[#f7f8f8] shrink-0 mt-0.5" strokeWidth={1.75} />
                    <span className="break-words">{h}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div
              className="space-y-3 pt-4"
              style={{ borderTopWidth: '1px', borderTopStyle: 'dashed', borderImage: 'repeating-linear-gradient(to right, rgba(255,255,255,0.28) 0 2px, transparent 2px 4px) 1' }}
            >
              <h4 className="text-[11px] uppercase tracking-[0.15em] font-bold text-[#9e9e9e]">
                Full stack &amp; toolkit breakdown
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {selectedCategory.items.map((item, idx) => (
                  <div key={idx} className="p-3 text-left" style={dashedBox}>
                    <div className="text-xs font-bold text-[#f7f8f8]">{item.name}</div>
                    <div className="text-[10px] text-[#9e9e9e] mt-0.5">{item.level}</div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </section>
  );
}